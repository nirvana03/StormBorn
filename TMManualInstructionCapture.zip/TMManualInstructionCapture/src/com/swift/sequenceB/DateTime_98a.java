package com.swift.sequenceB;

public class DateTime_98a {

	private String id = "";
	private String dataSourceScheme = "";
	private String dataSourceSchemeValue = "";
	private String date = "";
	private String time = "";
	private String decimals = "";
	private String UTCIndicator = "";
	private String option = "";
	private String qualifier = "";
	private String dateTime = "";
	private String dateCode = "";
	
	public String getDateCode() {
		return dateCode;
	}
	public void setDateCode(String dateCode) {
		this.dateCode = dateCode;
	}
	public String getDateTime() {
		return dateTime;
	}
	public void setDateTime(String dateTime) {
		this.dateTime = dateTime;
	}
	public String getQualifier() {
		return qualifier;
	}
	public void setQualifier(String qualifier) {
		this.qualifier = qualifier;
	}
	public String getOption() {
		return option;
	}
	public void setOption(String option) {
		this.option = option;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getDataSourceScheme() {
		return dataSourceScheme;
	}
	public void setDataSourceScheme(String dataSourceScheme) {
		this.dataSourceScheme = dataSourceScheme;
	}
	public String getDataSourceSchemeValue() {
		return dataSourceSchemeValue;
	}
	public void setDataSourceSchemeValue(String dataSourceSchemeValue) {
		this.dataSourceSchemeValue = dataSourceSchemeValue;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public String getDecimals() {
		return decimals;
	}
	public void setDecimals(String decimals) {
		this.decimals = decimals;
	}
	public String getUTCIndicator() {
		return UTCIndicator;
	}
	public void setUTCIndicator(String indicator) {
		UTCIndicator = indicator;
	}
	
	
	
}
