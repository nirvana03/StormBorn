package com.swift.sequenceB;

public class Place_94a {
	
	private String id = "";
	private String dataSourceScheme = "";
	private String dataSourceSchemeValue = "";
	private String placeCode = "";
	private String narrative = "";
	private String identifierCode = "";
	private String qualifier = "";
	
	
	
	public String getQualifier() {
		return qualifier;
	}
	public void setQualifier(String qualifier) {
		this.qualifier = qualifier;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getDataSourceScheme() {
		return dataSourceScheme;
	}
	public void setDataSourceScheme(String dataSourceScheme) {
		this.dataSourceScheme = dataSourceScheme;
	}
	public String getDataSourceSchemeValue() {
		return dataSourceSchemeValue;
	}
	public void setDataSourceSchemeValue(String dataSourceSchemeValue) {
		this.dataSourceSchemeValue = dataSourceSchemeValue;
	}
	public String getPlaceCode() {
		return placeCode;
	}
	public void setPlaceCode(String placeCode) {
		this.placeCode = placeCode;
	}
	public String getNarrative() {
		return narrative;
	}
	public void setNarrative(String narrative) {
		this.narrative = narrative;
	}
	public String getIdentifierCode() {
		return identifierCode;
	}
	public void setIdentifierCode(String identifierCode) {
		this.identifierCode = identifierCode;
	}
	

}
