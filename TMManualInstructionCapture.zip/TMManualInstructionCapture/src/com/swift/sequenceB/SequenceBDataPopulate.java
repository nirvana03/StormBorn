package com.swift.sequenceB;

import com.swift.sequenceB.sequenceB1.B1_Date_98A;
import com.swift.sequenceB.sequenceB1.B1_FinancialInstrument_12a;
import com.swift.sequenceB.sequenceB1.B1_Flag_17B;
import com.swift.sequenceB.sequenceB1.B1_IdentificationFinancialInstrument_35B;
import com.swift.sequenceB.sequenceB1.B1_Indicator_22F;
import com.swift.sequenceB.sequenceB1.B1_NumberIdentification_13a;
import com.swift.sequenceB.sequenceB1.B1_Price_90a;
import com.swift.sequenceB.sequenceB1.B1_QuantityFinancialInstrument_36B;
import com.swift.sequenceB.sequenceB1.B1_Rate_92A;
import com.webmethods.caf.faces.util.LogUtils;
import com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F12a_Type;
import com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F13a_Type;
import com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F17a_Type;
import com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F22a_Type;
import com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F35a_Type;
import com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F36a_Type;
import com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F90a_Type;
import com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F92a_Type;
import com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F98a_Type;
import com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F22a_Type;
import com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F25a_Type;
import com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F70a_Type;
import com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F94a_Type;
import com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F98a_Type;
import com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_Type;


public class SequenceBDataPopulate {
	
	TMCommon_docType_MT54x_docTypeRef_ns_SeqB_Type tmCommonDocTypeMTMsgSeqB;
	
	
	public Indicator_22F[] indcator_22F_Initial(TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F22a_Type[] indicator)
	{
		
		   Indicator_22F[] tempIndicatorArr=null;
		   if (indicator!=null && indicator.length!=0)
		   { 
			     tempIndicatorArr = new Indicator_22F[indicator.length];
			     
			     int tempSeqBIndicator =500;
			     
			     for (int i = 0; i < indicator.length;i++)
			     {
			    	 TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F22a_Type tempF22a =  indicator[i];
			    	 
			    	 
			    	 Indicator_22F  tempBean =  new Indicator_22F();
			    	 
			    	 tempSeqBIndicator=tempSeqBIndicator+1;
			    	 tempBean.setId(tempSeqBIndicator+"");
			    	 if (tempF22a!=null){
			    	 if (tempF22a.getNsPROC().getNsF22F().getNsDataSourceScheme()!=null || tempF22a.getNsPROC().getNsF22F().getNsIndicator()!=null){
			    		    tempBean.setQualifier("PROC");
			    		    if (tempF22a.getNsPROC().getNsF22F().getNsDataSourceScheme()!=null)
			    		    {
			    		    	tempBean.setDataSourceScheme("DataSourceScheme");
			    		    	tempBean.setDataSoruceSchemeValue(tempF22a.getNsPROC().getNsF22F().getNsDataSourceScheme());
			    		    	
			    		    }
			    		    	  tempBean.setIndicator(tempF22a.getNsPROC().getNsF22F().getNsIndicator());
			    		    	
			    		  
			    	 } else  if (tempF22a.getNsRPOR().getNsF22F().getNsDataSourceScheme()!=null || tempF22a.getNsRPOR().getNsF22F().getNsIndicator()!=null){
			    		    tempBean.setQualifier("RPOR");
			    		    if (tempF22a.getNsRPOR().getNsF22F().getNsDataSourceScheme()!=null)
			    		    {
			    		    	tempBean.setDataSourceScheme("DataSourceScheme");
			    		    	tempBean.setDataSoruceSchemeValue(tempF22a.getNsRPOR().getNsF22F().getNsDataSourceScheme());
			    		    	
			    		    }
			    		    	  tempBean.setIndicator(tempF22a.getNsRPOR().getNsF22F().getNsIndicator());
			    		    	
			    		
			    	 } else  if (tempF22a.getNsPRIR().getNsF22F().getNsDataSourceScheme()!=null || tempF22a.getNsPRIR().getNsF22F().getNsIndicator()!=null){
			    		    tempBean.setQualifier("PRIR");
			    		    if (tempF22a.getNsPRIR().getNsF22F().getNsDataSourceScheme()!=null)
			    		    {
			    		    	tempBean.setDataSourceScheme("DataSourceScheme");
			    		    	tempBean.setDataSoruceSchemeValue(tempF22a.getNsPRIR().getNsF22F().getNsDataSourceScheme());
			    		    	
			    		    }
			    		    	  tempBean.setIndicator(tempF22a.getNsPRIR().getNsF22F().getNsIndicator());
			    		    	
			    		   
			    	 }else  if (tempF22a.getNsBORR().getNsF22F().getNsDataSourceScheme()!=null || tempF22a.getNsBORR().getNsF22F().getNsIndicator()!=null){
			    		    tempBean.setQualifier("BORR");
			    		    if (tempF22a.getNsBORR().getNsF22F().getNsDataSourceScheme()!=null)
			    		    {
			    		    	tempBean.setDataSourceScheme("DataSourceScheme");
			    		    	tempBean.setDataSoruceSchemeValue(tempF22a.getNsBORR().getNsF22F().getNsDataSourceScheme());
			    		    	
			    		    }
			    		    	  tempBean.setIndicator(tempF22a.getNsBORR().getNsF22F().getNsIndicator());
			    		    	
			    		   
			    	 }else  if (tempF22a.getNsTTCO().getNsF22F().getNsDataSourceScheme()!=null || tempF22a.getNsTTCO().getNsF22F().getNsIndicator()!=null){
			    		    tempBean.setQualifier("TTCO");
			    		    if (tempF22a.getNsTTCO().getNsF22F().getNsDataSourceScheme()!=null)
			    		    {
			    		    	tempBean.setDataSourceScheme("DataSourceScheme");
			    		    	tempBean.setDataSoruceSchemeValue(tempF22a.getNsTTCO().getNsF22F().getNsDataSourceScheme());
			    		    	
			    		    }
			    		    	  tempBean.setIndicator(tempF22a.getNsTTCO().getNsF22F().getNsIndicator());
			    		    	
			    		   
			    	 }else  if (tempF22a.getNsINCA().getNsF22F().getNsDataSourceScheme()!=null || tempF22a.getNsINCA().getNsF22F().getNsIndicator()!=null){
			    		    tempBean.setQualifier("INCA");
			    		    if (tempF22a.getNsINCA().getNsF22F().getNsDataSourceScheme()!=null)
			    		    {
			    		    	tempBean.setDataSourceScheme("DataSourceScheme");
			    		    	tempBean.setDataSoruceSchemeValue(tempF22a.getNsINCA().getNsF22F().getNsDataSourceScheme());
			    		    	
			    		    }
			    		    	  tempBean.setIndicator(tempF22a.getNsINCA().getNsF22F().getNsIndicator());
			    		    	
			    		   
			    	 }else  if (tempF22a.getNsTRCA().getNsF22F().getNsDataSourceScheme()!=null || tempF22a.getNsTRCA().getNsF22F().getNsIndicator()!=null){
			    		    tempBean.setQualifier("TRCA");
			    		    if (tempF22a.getNsTRCA().getNsF22F().getNsDataSourceScheme()!=null)
			    		    {
			    		    	tempBean.setDataSourceScheme("DataSourceScheme");
			    		    	tempBean.setDataSoruceSchemeValue(tempF22a.getNsTRCA().getNsF22F().getNsDataSourceScheme());
			    		    	
			    		    }
			    		    	  tempBean.setIndicator(tempF22a.getNsTRCA().getNsF22F().getNsIndicator());
			    		    	
			    		   
			    	 }else  if (tempF22a.getNsPRIC().getNsF22F().getNsDataSourceScheme()!=null || tempF22a.getNsPRIC().getNsF22F().getNsIndicator()!=null){
			    		    tempBean.setQualifier("PRIC");
			    		    if (tempF22a.getNsPRIC().getNsF22F().getNsDataSourceScheme()!=null)
			    		    {
			    		    	tempBean.setDataSourceScheme("DataSourceScheme");
			    		    	tempBean.setDataSoruceSchemeValue(tempF22a.getNsPRIC().getNsF22F().getNsDataSourceScheme());
			    		    	
			    		    }
			    		    	  tempBean.setIndicator(tempF22a.getNsPRIC().getNsF22F().getNsIndicator());
			    		    	
			    		   
			    	 }
			    	 }
			    	 tempIndicatorArr[i] = tempBean;
			      
			     }
			   
			   
			   
		   }
		return tempIndicatorArr;
		
	}

  public Status_25D[] status_25D_Initial(TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F25a_Type[] status)
  {
	  Status_25D[] tempStatus = null;
	  
	  if (status!=null && status.length!=0)
	  {
		   tempStatus =  new Status_25D[status.length];
		   
		   int tempSeqBStatus =600;
		   
		   for (int i = 0; i < status.length;i++)
		   {
			   
			   TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F25a_Type temp=status[i];
			   
			   
			   
			   
			   Status_25D tempBean = new Status_25D();
			   
			   tempSeqBStatus=tempSeqBStatus+1;
			   tempBean.setId(tempSeqBStatus+"");
			   
			   if (temp!=null){
			   
			   if (temp.getNsAFFM().getNsF25D().getNsDataSourceScheme()!=null || temp.getNsAFFM().getNsF25D().getNsStatusCode()!=null)
			   {    tempBean.setQualifier("AFFM");
				    if (temp.getNsAFFM().getNsF25D().getNsDataSourceScheme()!=null)
				    {
				    	 tempBean.setDataSourceScheme("DataSourceScheme");
				    	 tempBean.setDataSourceSchemeValue(temp.getNsAFFM().getNsF25D().getNsDataSourceScheme());
				    	
				    }  
				    	
				    	tempBean.setStatusCode(temp.getNsAFFM().getNsF25D().getNsStatusCode());
				    	
				
				    	
				   
				   
			   } else  if (temp.getNsMTCH().getNsF25D().getNsDataSourceScheme()!=null || temp.getNsMTCH().getNsF25D().getNsStatusCode()!=null)
			      {    tempBean.setQualifier("MTCH");
			           if (temp.getNsMTCH().getNsF25D().getNsDataSourceScheme()!=null)
			           				{
			        	   			tempBean.setDataSourceScheme("DataSourceScheme");
			        	   			tempBean.setDataSourceSchemeValue(temp.getNsMTCH().getNsF25D().getNsDataSourceScheme());
			    	
			                 } 
			    	
			    					tempBean.setStatusCode(temp.getNsMTCH().getNsF25D().getNsStatusCode());
			    	
			    					
			    	
			   
			   
		   }
			   }  
			   tempStatus[i]=tempBean;
		   
		   }
		  
		  
	  }
	  
	  return tempStatus;
	  
  }
  
  
 public Narrative_70E[] narrative_70E_Initial(TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F70a_Type[] narrative)
 {
	 
	  Narrative_70E[] tempNarrative = null;
	  
	  if (narrative!=null && narrative.length!=0){
		  
		  tempNarrative = new Narrative_70E[narrative.length];
		  
		  int tempSeqBNarrative =700;
		  
		  for (int i = 0; i < narrative.length;i++)
		  {
			  
			  TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F70a_Type temp = narrative[i];
			  
			 
			  
			  Narrative_70E tempBean =  new Narrative_70E();
			  
			  tempSeqBNarrative=tempSeqBNarrative+1;
			  tempBean.setId(tempSeqBNarrative+"");
			  
			  
			  if (temp!=null){
			  if (temp.getNsFXIN().getNsF70E().getNsNarrative().getNsLine()!=null)
			  {
				  tempBean.setQualifier("FXIN");
				  String[] tempNarrativeArr = temp.getNsFXIN().getNsF70E().getNsNarrative().getNsLine();
				  
				  for (int j = 0; j < tempNarrativeArr.length;j++ ){
					  
					  if (tempNarrativeArr[j]!=null){
					  
					  if (j==0)
						  tempBean.setNarrative1(tempNarrativeArr[j]);
					  else if (j==1 )
						  tempBean.setNarrative2(tempNarrativeArr[j]);
					  else if (j==2)
						  tempBean.setNarrative3(tempNarrativeArr[j]);
					
					  else if (j==3)
						  tempBean.setNarrative4(tempNarrativeArr[j]);
					  else if (j==4)
						  tempBean.setNarrative5(tempNarrativeArr[j]);
					  else if (j==5)
						  tempBean.setNarrative6(tempNarrativeArr[j]);
					  else if (j==6)
						  tempBean.setNarrative7(tempNarrativeArr[j]);
					  else if (j==7)
						  tempBean.setNarrative8(tempNarrativeArr[j]);
					  else if (j==8)
						  tempBean.setNarrative9(tempNarrativeArr[j]);
					  else if (j==9)
						  tempBean.setNarrative10(tempNarrativeArr[j]);
					  }
				  }
				  
				  
			  } else if (temp.getNsSPRO().getNsF70E().getNsNarrative().getNsLine()!=null)
			  {
				  tempBean.setQualifier("SPRO");
				  String[] tempNarrativeArr = temp.getNsSPRO().getNsF70E().getNsNarrative().getNsLine();
				  for (int j = 0; j < tempNarrativeArr.length;j++ ){
					  
					  if (tempNarrativeArr[j]!=null){
					  if (j==0)
						  tempBean.setNarrative1(tempNarrativeArr[j]);
					  else if (j==1)
						  tempBean.setNarrative2(tempNarrativeArr[j]);
					  else if (j==2)
						  tempBean.setNarrative3(tempNarrativeArr[j]);
					  else if (j==4)
						  tempBean.setNarrative5(tempNarrativeArr[j]);
					  else if (j==3)
						  tempBean.setNarrative4(tempNarrativeArr[j]);
					  else if (j==5)
						  tempBean.setNarrative6(tempNarrativeArr[j]);
					  else if (j==6)
						  tempBean.setNarrative7(tempNarrativeArr[j]);
					  else if (j==7)
						  tempBean.setNarrative8(tempNarrativeArr[j]);
					  else if (j==8)
						  tempBean.setNarrative9(tempNarrativeArr[j]);
					  else if (j==9)
						  tempBean.setNarrative10(tempNarrativeArr[j]);
					  }
				  }
				  
			  } 
			  }
			 tempNarrative[i]=tempBean; 
		 
		  }	  
		  
		  
	  }
	 
	  return tempNarrative;
	 
	 
 }
 
public  Place_94a[] place_94a_Initial(TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F94a_Type[] place)
{
       Place_94a[] tempPlace=null;
       
       if (place!=null && place.length!=0)
       {
    	   
    	   tempPlace = new Place_94a[place.length];
    	   
    	   int tempSeqBPlace =5000;
    	   for (int i = 0; i < place.length ;i++)
    	   {
    		   
    		   TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F94a_Type temp = place[i];
    		   
    		  
    		   
    		   Place_94a tempBean = new Place_94a();
    		   
    		   tempSeqBPlace=tempSeqBPlace+1;
    		   tempBean.setId(tempSeqBPlace+"");
    		   
    		   
    		   if (temp!=null){
               if (temp.getNsCLEA().getNsF94H().getNsIdentifierCode()!=null)
               {
            	   tempBean.setQualifier("CLEA");
            	   tempBean.setIdentifierCode(temp.getNsCLEA().getNsF94H().getNsIdentifierCode());
            	   
               }
               /*SR-2016
               else if(temp.getNsCLEA().getNsF94L().getNsLegalEntityIdentifier()!=null){
            	   tempBean.setQualifier("CLEA");
            	   tempBean.set
               }*/
               else if (temp.getNsTRAD().getNsF94B().getNsDataSourceScheme()!=null || temp.getNsTRAD().getNsF94B().getNsNarrative()!=null || temp.getNsTRAD().getNsF94B().getNsPlaceCode()!=null)
               {   
            	   
            	    tempBean.setNarrative(temp.getNsTRAD().getNsF94B().getNsNarrative());
            	    tempBean.setQualifier("TRAD");
            	   if (temp.getNsTRAD().getNsF94B().getNsDataSourceScheme()!=null)
            	   {
            		   tempBean.setDataSourceScheme("DataSourceScheme");
            		   tempBean.setDataSourceSchemeValue(temp.getNsTRAD().getNsF94B().getNsDataSourceScheme());
            		   
            		   
            	   } else
            		   tempBean.setPlaceCode(temp.getNsTRAD().getNsF94B().getNsPlaceCode());
            	   
            	   
               }
    		   }  
    		  tempPlace[i]=tempBean; 
    	    
    	   }
    	   
    	   
       }
       
       
       
       return tempPlace;


}

public B1_Indicator_22F[] b1_Indicator_22F_Initial(TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F22a_Type[] b1Indicator) {
	
	B1_Indicator_22F[] tempB1Indicator = null;	

	if (b1Indicator!=null && b1Indicator.length!=0) {
	
	 tempB1Indicator = new B1_Indicator_22F[b1Indicator.length];
	 
	 int tempSeqBIndicator =800;
	 
	 for (int i = 0; i < b1Indicator.length;i++) {
		 
		  B1_Indicator_22F tempBean = new B1_Indicator_22F();
		  
		  tempSeqBIndicator=tempSeqBIndicator+1;
		  tempBean.setId(tempSeqBIndicator+"");
		  
		  TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F22a_Type temp = b1Indicator[i];
		  
		  if (temp!=null){
		  
			  if (temp.getNsMICO().getNsF22F().getNsDataSourceScheme()!=null || temp.getNsMICO().getNsF22F().getNsIndicator()!=null) {
				  
				  tempBean.setQualifier("MICO");
				  
				  if (temp.getNsMICO().getNsF22F().getNsDataSourceScheme()!=null) {
					  
					   tempBean.setDataSourceScheme("DataSourceScheme");
					   tempBean.setDataSoruceSchemeValue(temp.getNsMICO().getNsF22F().getNsDataSourceScheme());
				   }
				  
				  tempBean.setIndicator(temp.getNsMICO().getNsF22F().getNsIndicator());
				  
			  }else  if (temp.getNsFORM().getNsF22F().getNsDataSourceScheme()!=null || temp.getNsFORM().getNsF22F().getNsIndicator()!=null) {
				  
				  tempBean.setQualifier("FORM");
				   if (temp.getNsFORM().getNsF22F().getNsDataSourceScheme()!=null) {
					   
					   tempBean.setDataSourceScheme("DataSourceScheme");
					   tempBean.setDataSoruceSchemeValue(temp.getNsFORM().getNsF22F().getNsDataSourceScheme());
				   } 
				   
				   tempBean.setIndicator(temp.getNsFORM().getNsF22F().getNsIndicator());
			  
			  }else  if (temp.getNsPFRE().getNsF22F().getNsDataSourceScheme()!=null || temp.getNsPFRE().getNsF22F().getNsIndicator()!=null) {
				  
				  tempBean.setQualifier("PFRE");
				  
				  if (temp.getNsPFRE().getNsF22F().getNsDataSourceScheme()!=null) {
					  
					   tempBean.setDataSourceScheme("DataSourceScheme");
					   tempBean.setDataSoruceSchemeValue(temp.getNsPFRE().getNsF22F().getNsDataSourceScheme());
				   }
				  
				   tempBean.setIndicator(temp.getNsPFRE().getNsF22F().getNsIndicator());
		  
			  }
			  
			  /* Comment the code for SR2012 version - Start
	  
			  else  if (temp.getNsPREF().getNsF22F().getNsDataSourceScheme()!=null || temp.getNsPREF().getNsF22F().getNsIndicator()!=null)
			  {     
			  	
			   tempBean.setQualifier("PREF");
			   if (temp.getNsPREF().getNsF22F().getNsDataSourceScheme()!=null) {
			   
				   tempBean.setDataSourceScheme("DataSourceScheme");
				   tempBean.setDataSoruceSchemeValue(temp.getNsPREF().getNsF22F().getNsDataSourceScheme());
			   } 
			   tempBean.setIndicator(temp.getNsPREF().getNsF22F().getNsIndicator());
	
			}
			
			Comment the code for SR2012 version - End */
			  
			else  if (temp.getNsPAYS().getNsF22F().getNsDataSourceScheme()!=null || temp.getNsPAYS().getNsF22F().getNsIndicator()!=null) {
		  
		  
				tempBean.setQualifier("PAYS");
			   if (temp.getNsPAYS().getNsF22F().getNsDataSourceScheme()!=null) {
				   
				   tempBean.setDataSourceScheme("DataSourceScheme");
				   tempBean.setDataSoruceSchemeValue(temp.getNsPAYS().getNsF22F().getNsDataSourceScheme());
			   } 
			   tempBean.setIndicator(temp.getNsPAYS().getNsF22F().getNsIndicator());
	  
			}
			/* Comment the code for SR2012 version - Start
		    
		    
		    else  if (temp.getNsPADI().getNsF22F().getNsDataSourceScheme()!=null || temp.getNsPADI().getNsF22F().getNsIndicator()!=null) {
		         
		       tempBean.setQualifier("PADI");
			   if (temp.getNsPADI().getNsF22F().getNsDataSourceScheme()!=null)
			   {
				   tempBean.setDataSourceScheme("DataSourceScheme");
				   tempBean.setDataSoruceSchemeValue(temp.getNsPADI().getNsF22F().getNsDataSourceScheme());
			   } 
			   tempBean.setIndicator(temp.getNsPADI().getNsF22F().getNsIndicator());
	  
	 		}
	 		
	 		Comment the code for SR2012 version - Start */ 
			  
			else  if (temp.getNsCFRE().getNsF22F().getNsDataSourceScheme()!=null || temp.getNsCFRE().getNsF22F().getNsIndicator()!=null) {
				
				tempBean.setQualifier("CFRE");
		    	if (temp.getNsCFRE().getNsF22F().getNsDataSourceScheme()!=null) {
		    		
	    			tempBean.setDataSourceScheme("DataSourceScheme");
	    			tempBean.setDataSoruceSchemeValue(temp.getNsCFRE().getNsF22F().getNsDataSourceScheme());
		    	} 
	    		tempBean.setIndicator(temp.getNsCFRE().getNsF22F().getNsIndicator());
	        }
		  }
		  
	tempB1Indicator[i]=tempBean;		 
	
	}
}    

    return tempB1Indicator;
}
	
public B1_FinancialInstrument_12a[] b1_FinancialInstrument_12a_Initial(TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F12a_Type[] financialInstrument){
	
	B1_FinancialInstrument_12a[] tempFinancialInstr = null;
	
	if (financialInstrument!=null && financialInstrument.length > 0)
	{
		 tempFinancialInstr = new B1_FinancialInstrument_12a[financialInstrument.length];
		 int tempSeqBFinancial =900;
		 
		 for (int i = 0 ; i < financialInstrument.length;i++)
		 {
			 
			  TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F12a_Type temp = financialInstrument[i];
			  B1_FinancialInstrument_12a tempBean =  new B1_FinancialInstrument_12a();
			  
			  tempSeqBFinancial=tempSeqBFinancial+1;
			  tempBean.setId(tempSeqBFinancial+"");
			
			  if (temp!=null){
			  if (temp.getNsCLAS().getNsF12A().getNsDataSourceScheme()!=null || temp.getNsCLAS().getNsF12A().getNsInstrumentCodeOrDescription()!=null || temp.getNsCLAS().getNsF12C().getNsCFICode()!=null )
			  {
				    tempBean.setQualifier("CLAS");
				   if (temp.getNsCLAS().getNsF12C().getNsCFICode()!=null)
				   {
					   tempBean.setOption("CFICode");
					   tempBean.setCode(temp.getNsCLAS().getNsF12C().getNsCFICode());
					   
				   } else
				   {
					    tempBean.setOption("InstrumentCode");
					    tempBean.setDataSoruceSchemeValue(temp.getNsCLAS().getNsF12A().getNsDataSourceScheme());
					    tempBean.setCode(temp.getNsCLAS().getNsF12A().getNsInstrumentCodeOrDescription());
					   
				   }
				  
				  
			  }  else if (temp.getNsOPST().getNsF12B().getNsDataSourceScheme()!=null || temp.getNsOPST().getNsF12B().getNsInstrumentTypeCode()!=null)
			  {      
				     tempBean.setQualifier("OPST");
				     tempBean.setOption("InstrumentTypeCode");
			         if (temp.getNsOPST().getNsF12B().getNsDataSourceScheme()!=null)
			         {
			        	  tempBean.setDataSourceScheme("DataSourceScheme");
			        	  tempBean.setDataSoruceSchemeValue(temp.getNsOPST().getNsF12B().getNsDataSourceScheme());
			        	 
			         }
			        	 tempBean.setCode(temp.getNsOPST().getNsF12B().getNsInstrumentTypeCode());
			        	 
			        
			             
				   
				  
			  } else if (temp.getNsOPTI().getNsF12B().getNsDataSourceScheme()!=null || temp.getNsOPTI().getNsF12B().getNsInstrumentTypeCode()!=null)
			  {      
				     tempBean.setQualifier("OPTI");
				     tempBean.setOption("InstrumentTypeCode");
			         if (temp.getNsOPTI().getNsF12B().getNsDataSourceScheme()!=null)
			         {
			        	  tempBean.setDataSourceScheme("DataSourceScheme");
			        	  tempBean.setDataSoruceSchemeValue(temp.getNsOPTI().getNsF12B().getNsDataSourceScheme());
			        	 
			         }
			        	 tempBean.setCode(temp.getNsOPTI().getNsF12B().getNsInstrumentTypeCode());
			        	 
			       
			             
				   
				  
			  }
			  }  
			 tempFinancialInstr[i]= tempBean; 
			 
		 }
		
	}
	
	
	return tempFinancialInstr;
}

public B1_Date_98A[] b1_Date_98A_Initial(TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F98a_Type[] date) {
	
       B1_Date_98A[] tempDate = null;
       
       if (date!=null && date.length!=0) {
    	   
    	    tempDate = new B1_Date_98A[date.length];
    	    
    	    int tempSeqBDate =200;
    	    
    	    for (int i = 0; i < date.length;i++)
    	    {
    	    	B1_Date_98A tempBean =  new B1_Date_98A();
    	    	
    	    	tempSeqBDate=tempSeqBDate+1;
    	    	tempBean.setId(tempSeqBDate+"");
    	    	
    	    	TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F98a_Type temp =  date[i];
    	    	
    	    	if (temp!=null){
    	    	
    	    	if (temp.getNsCOUP().getNsF98A().getNsDate()!=null)
    	    	{
    	    		tempBean.setQualifier("COUP");
    	    		tempBean.setDate(temp.getNsCOUP().getNsF98A().getNsDate());
    	    		
    	    	} else if (temp.getNsEXPI().getNsF98A().getNsDate()!=null)
    	    	{
    	    		tempBean.setQualifier("EXPI");
    	    		tempBean.setDate(temp.getNsEXPI().getNsF98A().getNsDate());
    	    		
    	    	}else if (temp.getNsFRNR().getNsF98A().getNsDate()!=null)
    	    	{
    	    		tempBean.setQualifier("FRNR");
    	    		tempBean.setDate(temp.getNsFRNR().getNsF98A().getNsDate());
    	    		
    	    	}else if (temp.getNsMATU().getNsF98A().getNsDate()!=null)
    	    	{
    	    		tempBean.setQualifier("MATU");
    	    		tempBean.setDate(temp.getNsMATU().getNsF98A().getNsDate());
    	    		
    	    	}else if (temp.getNsISSU().getNsF98A().getNsDate()!=null)
    	    	{
    	    		tempBean.setQualifier("ISSU");
    	    		tempBean.setDate(temp.getNsISSU().getNsF98A().getNsDate());
    	    		
    	    	}else if (temp.getNsCALD().getNsF98A().getNsDate()!=null)
    	    	{
    	    		tempBean.setQualifier("CALD");
    	    		tempBean.setDate(temp.getNsCALD().getNsF98A().getNsDate());
    	    		
    	    	}else if (temp.getNsPUTT().getNsF98A().getNsDate()!=null)
    	    	{
    	    		tempBean.setQualifier("PUTT");
    	    		tempBean.setDate(temp.getNsPUTT().getNsF98A().getNsDate());
    	    		
    	    	}else if (temp.getNsDDTE().getNsF98A().getNsDate()!=null)
    	    	{
    	    		tempBean.setQualifier("DDTE");
    	    		tempBean.setDate(temp.getNsDDTE().getNsF98A().getNsDate());
    	    		
    	    	}else if (temp.getNsFCOU().getNsF98A().getNsDate()!=null)
    	    	{
    	    		tempBean.setQualifier("FCOU");
    	    		tempBean.setDate(temp.getNsFCOU().getNsF98A().getNsDate());
    	    		
    	    	}
    	    	} 	
    	    tempDate[i] = tempBean;	
    	    }
     }
               
   return tempDate;
}

public B1_Rate_92A[] b1_Rate_92A_Initial(TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F92a_Type[] rate) {
	
	B1_Rate_92A[] tempRate = null;
	   
	   if (rate!=null && rate.length!=0)
	   {
		   
		   tempRate =  new B1_Rate_92A[rate.length];
		   int tempSeqBRate =300;
		   
		   for (int i = 0; i < tempRate.length;i++)
		   {
			   
			   B1_Rate_92A tempBean = new B1_Rate_92A();
			   
			   tempSeqBRate=tempSeqBRate+1;
			   tempBean.setId(tempSeqBRate+"");
			   
			   TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F92a_Type temp = rate[i];
			   
			   if (temp!=null){
			   
				   if (temp.getNsPRFC().getNsF92A().getNsRate()!=null || temp.getNsPRFC().getNsF92A().getNsSign()!=null)
				   {
					   tempBean.setQualifer("PRFC");
					   tempBean.setRate(temp.getNsPRFC().getNsF92A().getNsRate());
					   tempBean.setSign(temp.getNsPRFC().getNsF92A().getNsSign());
					   
				   } else   if (temp.getNsCUFC().getNsF92A().getNsRate()!=null || temp.getNsCUFC().getNsF92A().getNsSign()!=null)
				   {
					   tempBean.setQualifer("CUFC");
					   tempBean.setRate(temp.getNsCUFC().getNsF92A().getNsRate());
					   tempBean.setSign(temp.getNsCUFC().getNsF92A().getNsSign());
					   
				   } else   if (temp.getNsNWFC().getNsF92A().getNsRate()!=null || temp.getNsNWFC().getNsF92A().getNsSign()!=null)
				   {
					   tempBean.setQualifer("NWFC");
					   tempBean.setRate(temp.getNsNWFC().getNsF92A().getNsRate());
					   tempBean.setSign(temp.getNsNWFC().getNsF92A().getNsSign());
					   
				   } else   if (temp.getNsINTR().getNsF92A().getNsRate()!=null || temp.getNsINTR().getNsF92A().getNsSign()!=null)
				   {
					   tempBean.setQualifer("INTR");
					   tempBean.setRate(temp.getNsINTR().getNsF92A().getNsRate());
					   tempBean.setSign(temp.getNsINTR().getNsF92A().getNsSign());
					   
				   } else   if (temp.getNsNXRT().getNsF92A().getNsRate()!=null || temp.getNsNXRT().getNsF92A().getNsSign()!=null)
				   {
					   tempBean.setQualifer("NXRT");
					   tempBean.setRate(temp.getNsNXRT().getNsF92A().getNsRate());
					   tempBean.setSign(temp.getNsNXRT().getNsF92A().getNsSign());
					   
				   } else   if (temp.getNsINDX().getNsF92A().getNsRate()!=null || temp.getNsINDX().getNsF92A().getNsSign()!=null)
				   {
					   tempBean.setQualifer("INDX");
					   tempBean.setRate(temp.getNsINDX().getNsF92A().getNsRate());
					   tempBean.setSign(temp.getNsINDX().getNsF92A().getNsSign());
					   
				   } 
				   // Add the code for SR2012 version - Start 
				   else if (temp.getNsYTMR().getNsF92A().getNsRate()!=null || temp.getNsYTMR().getNsF92A().getNsSign()!=null)
				   {
					   tempBean.setQualifer("YTMR");
					   tempBean.setRate(temp.getNsYTMR().getNsF92A().getNsRate());
					   tempBean.setSign(temp.getNsYTMR().getNsF92A().getNsSign());
					   
					   
				   } 
				   // Add the code for SR2012 version - End
			   } 
			   tempRate[i] = tempBean;
		   }
	   }
	   return tempRate;
}

public B1_NumberIdentification_13a[] b1_NumberIdentification_13a_Initial(TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F13a_Type[] numberId) {
	
	B1_NumberIdentification_13a[] tempNumberId = null;
    
    if (numberId!=null && numberId.length!=0) {
    	
  	   tempNumberId =  new B1_NumberIdentification_13a[numberId.length];
  	   
  	   int tempSeqBBNumberIdentification =2000;
  	   
  	   for (int i = 0 ;i < numberId.length;i++) {
  		   
  		   B1_NumberIdentification_13a tempBean = new B1_NumberIdentification_13a();
  		   
  		   tempSeqBBNumberIdentification=tempSeqBBNumberIdentification+1;
  		   tempBean.setId(tempSeqBBNumberIdentification+"");
  		   
  		   TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F13a_Type temp = numberId[i];
  		   
  		   if (temp!=null){
  			   
	  		   if (temp.getNsCOUP().getNsF13A().getNsNumberId()!=null || temp.getNsCOUP().getNsF13B().getNsDataSourceScheme()!=null 
	  				   || temp.getNsCOUP().getNsF13B().getNsNumber()!=null) {
	  			   
	  			   tempBean.setQualifier("COUP");
	  			   if (temp.getNsCOUP().getNsF13A().getNsNumberId()!=null) {
	  				   
	  				   tempBean.setOption("NumberId");
	  				   tempBean.setNumberId(temp.getNsCOUP().getNsF13A().getNsNumberId());
	  			   } else {
	  				   
	  				    tempBean.setOption("Number");
	  				    tempBean.setDataSourceSchemeValue(temp.getNsCOUP().getNsF13B().getNsDataSourceScheme());
	  				    tempBean.setNumberId(temp.getNsCOUP().getNsF13B().getNsNumber());
	  			   }
	  			   
	  		   } else  if (temp.getNsPOOL().getNsF13B().getNsDataSourceScheme()!=null || temp.getNsPOOL().getNsF13B().getNsNumber()!=null) {
	  			   
	  			   tempBean.setQualifier("POOL");
	  			   
	  			   /* Comment the code for SR2012 version - Start
	  			    * 
	  			   if (temp.getNsPOOL().getNsF13A().getNsNumberId()!=null)
	  			   {
	  				   tempBean.setOption("NumberId");
	  				   tempBean.setNumberId(temp.getNsPOOL().getNsF13A().getNsNumberId());
	  			   } else
	  			   {
	  			   
	  			   Comment the code for SR2012 version - End */
	  			   
				    tempBean.setOption("Number");
				    tempBean.setDataSourceSchemeValue(temp.getNsPOOL().getNsF13B().getNsDataSourceScheme());
				    tempBean.setNumberId(temp.getNsPOOL().getNsF13B().getNsNumber());
	  				   
	  			  // }
	  		   }
  		   } 
  		 tempNumberId[i]= tempBean;  
  		   
  	   }
    }
    return tempNumberId;
}

public B1_Flag_17B[] b1_Flag_17B_Initial(TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F17a_Type[] flag)
{
	
	 B1_Flag_17B[] tempFlag = null;
	 
	 if (flag!=null && flag.length!=0)
	 {
		 tempFlag =  new B1_Flag_17B[flag.length];
		 int tempSeqBB1Flag =400;
		 
		 for (int i = 0 ; i < flag.length;i++)
		 {
			 B1_Flag_17B tempBean = new B1_Flag_17B();
			 
			 tempSeqBB1Flag=tempSeqBB1Flag+1;
			 tempBean.setId(tempSeqBB1Flag+"");
			 
			 TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F17a_Type temp = flag[i];
			 
			 if (temp!=null){
			 
			 if (temp.getNsFRNF().getNsF17B().getNsFlag()!=null)
			 {
				 tempBean.setQualifier("FRNF");
				 tempBean.setFlag(temp.getNsFRNF().getNsF17B().getNsFlag());
				 
				 
			 } else  if (temp.getNsCALL().getNsF17B().getNsFlag()!=null)
			 {
				 tempBean.setQualifier("CALL");
				 tempBean.setFlag(temp.getNsCALL().getNsF17B().getNsFlag());
				 
				 
			 } else  if (temp.getNsPUTT().getNsF17B().getNsFlag()!=null)
			 {
				 tempBean.setQualifier("PUTT");
				 tempBean.setFlag(temp.getNsPUTT().getNsF17B().getNsFlag());
				 
				 
			 }
				 
			 }
			 tempFlag[i] =  tempBean;
			 
			 
		 }
		 
		 
		 
		 
	 }
	 
	 
	 return tempFlag;
	




}

public B1_Price_90a[] b1_Price_90a_Initial(TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F90a_Type[] price)
{
	
  B1_Price_90a[] tempPrice = null;
  
  if (price!=null &&  price.length!=0)
  {
	  tempPrice = new B1_Price_90a[price.length];
	  
	  int tempSeqBB1Price =1500;
	  
	  for (int i = 0; i < price.length;i++)
	  {
		  B1_Price_90a tempBean = new B1_Price_90a();
		  
		  tempSeqBB1Price=tempSeqBB1Price+1;
		  tempBean.setId(tempSeqBB1Price+"");
		  
		  TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F90a_Type temp = price[i];
		  
		 /* LogUtils.log("-----temp.getNsINDC().getNsF90B().getNsPrice()-----"+temp.getNsINDC().getNsF90B().getNsPrice());
		  LogUtils.log("-----temp.getNsINDC().getNsF90B().getNsAmountTypeCode()-----"+temp.getNsINDC().getNsF90B().getNsAmountTypeCode());
		  LogUtils.log("-----temp.getNsINDC().getNsF90B().getNsCurrencyCode()-----"+temp.getNsINDC().getNsF90B().getNsCurrencyCode());
		  */
		  
		  if (temp!=null){
		  if (temp.getNsINDC().getNsF90A().getNsPercentageTypeCode()!=null || temp.getNsINDC().getNsF90A().getNsPrice()!=null || temp.getNsINDC().getNsF90B().getNsAmountTypeCode()!=null || temp.getNsINDC().getNsF90B().getNsCurrencyCode()!=null || temp.getNsINDC().getNsF90B().getNsPrice()!=null)
		  {
			 // LogUtils.log("-----------------in INDC---------------");
			  tempBean.setQualifier("INDC");
			 if ((temp.getNsINDC().getNsF90A().getNsPercentageTypeCode()!=null) || (temp.getNsINDC().getNsF90A().getNsPrice()!=null))
			 {
				
				 tempBean.setOption("PercentageTypeCode");
				 tempBean.setPrice(temp.getNsINDC().getNsF90A().getNsPrice());
				 tempBean.setCode(temp.getNsINDC().getNsF90A().getNsPercentageTypeCode());
				//SR2016
				 if(null != temp.getNsINDC().getNsF90A().getNsSign())
				 {
					// tempBean.setCode(temp.getNsINDC().getNsF90A().getNsSign());
					// LogUtils.log("Inside SeqB data populate INDC----sign!=null-------setting pricesignB1>>>>>"+temp.getNsINDC().getNsF90A().getNsSign());
					 tempBean.setPriceSignB1(temp.getNsINDC().getNsF90A().getNsSign());
				 }
				 //SR2016
				 
			 } else
			 {
				 tempBean.setOption("AmountTypeCode");
				 tempBean.setPrice(temp.getNsINDC().getNsF90B().getNsPrice());
				 tempBean.setCode(temp.getNsINDC().getNsF90B().getNsAmountTypeCode());
				 tempBean.setCurrencyCode(temp.getNsINDC().getNsF90B().getNsCurrencyCode());
				 
			 }
			  
			  
			  
		  } else if (temp.getNsMRKT().getNsF90A().getNsPercentageTypeCode()!=null || temp.getNsMRKT().getNsF90A().getNsPrice()!=null || temp.getNsMRKT().getNsF90B().getNsAmountTypeCode()!=null || temp.getNsMRKT().getNsF90B().getNsCurrencyCode()!=null || temp.getNsMRKT().getNsF90B().getNsPrice()!=null)
		  {
			  //LogUtilsUtils.log("-----------------in MRKT---------------");
			  tempBean.setQualifier("MRKT");
			 if ((temp.getNsMRKT().getNsF90A().getNsPercentageTypeCode()!=null) || (temp.getNsMRKT().getNsF90A().getNsPrice()!=null))
			 {
				
				 tempBean.setOption("PercentageTypeCode");
				 tempBean.setPrice(temp.getNsMRKT().getNsF90A().getNsPrice());
				 tempBean.setCode(temp.getNsMRKT().getNsF90A().getNsPercentageTypeCode());
				//SR2016
				 if(null != temp.getNsMRKT().getNsF90A().getNsSign())
				 {
					 //LogUtils.log("Inside SeqB data populate MRKT----sign!=null-------setting pricesignB1>>>"+temp.getNsMRKT().getNsF90A().getNsSign());
					 tempBean.setPriceSignB1(temp.getNsMRKT().getNsF90A().getNsSign());
				 }
				 //SR2016
				 
				 
			 } else
			 {
				 tempBean.setOption("AmountTypeCode");
				 tempBean.setPrice(temp.getNsMRKT().getNsF90B().getNsPrice());
				 tempBean.setCode(temp.getNsMRKT().getNsF90B().getNsAmountTypeCode());
				 tempBean.setCurrencyCode(temp.getNsMRKT().getNsF90B().getNsCurrencyCode());
				 
			 }
			  
			  
			  
		  } else if (temp.getNsEXER().getNsF90A().getNsPercentageTypeCode()!=null || temp.getNsEXER().getNsF90A().getNsPrice()!=null || temp.getNsEXER().getNsF90B().getNsAmountTypeCode()!=null || temp.getNsEXER().getNsF90B().getNsCurrencyCode()!=null || temp.getNsEXER().getNsF90B().getNsPrice()!=null)
		  {
			  
			  //LogUtils.log("-----------------in EXER---------------");
			  tempBean.setQualifier("EXER");
			 if ((temp.getNsEXER().getNsF90A().getNsPercentageTypeCode()!=null) || (temp.getNsEXER().getNsF90A().getNsPrice()!=null))
			 {
				
				 tempBean.setOption("PercentageTypeCode");
				 tempBean.setPrice(temp.getNsEXER().getNsF90A().getNsPrice());
				 tempBean.setCode(temp.getNsEXER().getNsF90A().getNsPercentageTypeCode());
				 //SR2016
				 if(null != temp.getNsEXER().getNsF90A().getNsSign())
				 {
					 //LogUtils.log("Inside SeqB data populate MRKT----sign!=null-------setting pricesignB1>>>"+temp.getNsEXER().getNsF90A().getNsSign());
					 tempBean.setPriceSignB1(temp.getNsEXER().getNsF90A().getNsSign());
				 }
				 //SR2016
				 
			 } else
			 {
				 tempBean.setOption("AmountTypeCode");
				 tempBean.setPrice(temp.getNsEXER().getNsF90B().getNsPrice());
				 tempBean.setCode(temp.getNsEXER().getNsF90B().getNsAmountTypeCode());
				 tempBean.setCurrencyCode(temp.getNsEXER().getNsF90B().getNsCurrencyCode());
				 
			 }
			  
			  
			  
		  }
		  }
		  tempPrice[i] = tempBean;
		  
		  
	  }
	  
	  
	  
	  
	  
  }
  
  return tempPrice;



}

public B1_QuantityFinancialInstrument_36B[] b1_QuantityFinancialInstr_36B_Initial(TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F36a_Type[] quantityFinInstru)
{

	  B1_QuantityFinancialInstrument_36B[] tempQtyFinInst = null ;
	  
	  if (quantityFinInstru!=null && quantityFinInstru.length!=0)
	  {
		  tempQtyFinInst = new B1_QuantityFinancialInstrument_36B[quantityFinInstru.length];
		  
		  int tempSeqBB1QuantityFinancialInstr =1600;
		  
		  
		  for (int i = 0; i < quantityFinInstru.length;i++)
		  {
			  
			  B1_QuantityFinancialInstrument_36B tempBean = new B1_QuantityFinancialInstrument_36B();
			  
			  tempSeqBB1QuantityFinancialInstr=tempSeqBB1QuantityFinancialInstr+1;
			  tempBean.setId(tempSeqBB1QuantityFinancialInstr+"");
			  
			  TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F36a_Type temp = quantityFinInstru[i];
			  
			  if (temp!=null){
			  
			  if (temp.getNsMINO().getNsF36B().getNsQuantity()!=null || temp.getNsMINO().getNsF36B().getNsQuantityTypeCode()!=null)
			  {
				 tempBean.setQualifier("MINO");
				 tempBean.setQuantity(temp.getNsMINO().getNsF36B().getNsQuantity());
				 tempBean.setQuantityTypeCode(temp.getNsMINO().getNsF36B().getNsQuantityTypeCode());
				  
			  } else  if (temp.getNsSIZE().getNsF36B().getNsQuantity()!=null || temp.getNsSIZE().getNsF36B().getNsQuantityTypeCode()!=null)
			  {
					 tempBean.setQualifier("SIZE");
					 tempBean.setQuantity(temp.getNsSIZE().getNsF36B().getNsQuantity());
					 tempBean.setQuantityTypeCode(temp.getNsSIZE().getNsF36B().getNsQuantityTypeCode());
					  
				  }
			  }
			  tempQtyFinInst[i] = tempBean;
			  
		  }
		  
		  
		  
	  }
	  
	  
	  
	  return tempQtyFinInst;


}

public B1_IdentificationFinancialInstrument_35B[] b1_IdentificaitonFinIstr_35B_Initial(TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F35a_Type[] idFinInst)
{

	 B1_IdentificationFinancialInstrument_35B[] tempIdFinInst = null;
	 
	 if  (idFinInst!=null && idFinInst.length!=0)
	 {
		  tempIdFinInst = new B1_IdentificationFinancialInstrument_35B[idFinInst.length];
		  
		  int tempSeqBB1IdentificaitonFinIstr =1700;
		  
		  for (int i =0 ;i  < idFinInst.length ;i++)
		  {
			  
			  B1_IdentificationFinancialInstrument_35B tempBean = new B1_IdentificationFinancialInstrument_35B();
			 
			  tempSeqBB1IdentificaitonFinIstr=tempSeqBB1IdentificaitonFinIstr+1;
			  tempBean.setId(tempSeqBB1IdentificaitonFinIstr+"");
			  
			  TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F35a_Type temp = idFinInst[i];
			  
			  if (temp!=null) {
			  
			  if (temp.getNsF35B().getNsDescriptionOfSecurity().getNsLine()!=null || temp.getNsF35B().getNsIdentificationOfSecurity()!=null)
			  {
				  
				  tempBean.setSecurityId(temp.getNsF35B().getNsIdentificationOfSecurity());
				  
				  if (temp.getNsF35B().getNsDescriptionOfSecurity().getNsLine()!=null)
				  {
					  
					  for (int j = 0; j < temp.getNsF35B().getNsDescriptionOfSecurity().getNsLine().length;j++)
					  {
						  if (temp.getNsF35B().getNsDescriptionOfSecurity().getNsLine()[j]!=null){
						  if (j==0)
							  tempBean.setDesc1(temp.getNsF35B().getNsDescriptionOfSecurity().getNsLine()[j]);
						  else if (j==1)
							  tempBean.setDesc2(temp.getNsF35B().getNsDescriptionOfSecurity().getNsLine()[j]);
						  else if (j==2)
							  tempBean.setDesc3(temp.getNsF35B().getNsDescriptionOfSecurity().getNsLine()[j]);
						  else if (j==3)
							  tempBean.setDesc4(temp.getNsF35B().getNsDescriptionOfSecurity().getNsLine()[j]);
						  }
						  
					  }
					  
					  
				  }
					  
				  
				  
				  
				  
			  }
			  }
			  tempIdFinInst[i] = tempBean;  
			  
			  
		  }
		 
		 
	 }
	 
	 return tempIdFinInst;
	

}


public DateTime_98a[] dateTime_98a_Initial(TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F98a_Type[] dateTime)
{
       DateTime_98a[] tempDateTime = null;
       
       
       if (dateTime!=null && dateTime.length!=0)
       {
    	     tempDateTime = new DateTime_98a[dateTime.length];
    	     int tempSeqBdateTime =5000;
    	     
    	     for (int i = 0; i < dateTime.length;i++)
    	     {
    	    	 TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F98a_Type temp = dateTime[i];
    	    	 DateTime_98a tempBean = new DateTime_98a(); 
    	    	 
    	    	 tempSeqBdateTime=tempSeqBdateTime+1;
    	    	 tempBean.setId(tempSeqBdateTime+"");
    	    	 
    	    	 
    	    	 if (temp!=null){
    	    	 if (temp.getNsSETT().getNsF98A().getNsDate()!=null || temp.getNsSETT().getNsF98B().getNsDataSourceScheme()!=null || temp.getNsSETT().getNsF98B().getNsDateCode()!=null || temp.getNsSETT().getNsF98C().getNsDate()!=null)
    	    	 {     tempBean.setQualifier("SETT");
    	    		  if (temp.getNsSETT().getNsF98A().getNsDate()!=null)
    	    		  {
    	    			  tempBean.setOption("Date"); 
    	    			  tempBean.setDate(temp.getNsSETT().getNsF98A().getNsDate());
    	    			  
    	    		  } else if (temp.getNsSETT().getNsF98B().getNsDataSourceScheme()!=null || temp.getNsSETT().getNsF98B().getNsDateCode()!=null)
    	    		  {
    	    			      tempBean.setOption("DateCode");
    	    			      if (temp.getNsSETT().getNsF98B().getNsDataSourceScheme()!=null)
    	    			      {
    	    			    	    tempBean.setDataSourceScheme("DataSourceScheme");
    	    			    	    tempBean.setDataSourceSchemeValue(temp.getNsSETT().getNsF98B().getNsDataSourceScheme());
    	    			      }else {
    	    			    	  
    	    			    	     tempBean.setDate(temp.getNsSETT().getNsF98B().getNsDateCode());
    	    			      }
    	    			    	  
    	    			  
    	    		  } else
    	    		  {        tempBean.setOption("DateTime");
    	    			       tempBean.setDateTime(temp.getNsSETT().getNsF98C().getNsDate()+" "+temp.getNsSETT().getNsF98C().getNsTime() );
    	    			  
    	    		  }
    	    		 
    	    		 
    	    		 
    	    	 } else if (temp.getNsTRAD().getNsF98A().getNsDate()!=null || temp.getNsTRAD().getNsF98B().getNsDataSourceScheme()!=null || temp.getNsTRAD().getNsF98B().getNsDateCode()!=null || temp.getNsTRAD().getNsF98C().getNsDate()!=null || temp.getNsTRAD().getNsF98E().getNsDate()!=null || temp.getNsTRAD().getNsF98E().getNsDecimals()!=null || temp.getNsTRAD().getNsF98E().getNsTime()!=null || temp.getNsTRAD().getNsF98E().getNsUTCIndicator()!=null)
    	    	 {
    	    		 
    	    		 tempBean.setQualifier("TRAD");	
   	    		  if (temp.getNsTRAD().getNsF98A().getNsDate()!=null)
   	    		  {
   	    			tempBean.setOption("Date"); 
   	    			  tempBean.setDate(temp.getNsTRAD().getNsF98A().getNsDate());
   	    			  
   	    		  } else if (temp.getNsTRAD().getNsF98B().getNsDataSourceScheme()!=null || temp.getNsTRAD().getNsF98B().getNsDateCode()!=null)
   	    		  {       tempBean.setOption("DateCode");
   	    			      if (temp.getNsTRAD().getNsF98B().getNsDataSourceScheme()!=null)
   	    			      {
   	    			    	    tempBean.setDataSourceScheme("DataSourceScheme");
   	    			    	    tempBean.setDataSourceSchemeValue(temp.getNsTRAD().getNsF98B().getNsDataSourceScheme());
   	    			      }else {
   	    			    	  
   	    			    	     tempBean.setDate(temp.getNsTRAD().getNsF98B().getNsDateCode());
   	    			      }
   	    			    	  
   	    			  
   	    		  } else if (temp.getNsTRAD().getNsF98C().getNsDate()!=null || temp.getNsTRAD().getNsF98C().getNsTime()!=null)
   	    		  {        tempBean.setOption("DateTime");  
   	    			       tempBean.setDateTime(temp.getNsTRAD().getNsF98C().getNsDate()+" "+temp.getNsSETT().getNsF98C().getNsTime() );
   	    			  
   	    		  } else {
   	    			tempBean.setOption("DateTimeUTCIndicator");
   	    			      tempBean.setDateTime(temp.getNsTRAD().getNsF98E().getNsDate()+" "+temp.getNsTRAD().getNsF98E().getNsTime());
   	    			      tempBean.setDecimals(temp.getNsTRAD().getNsF98E().getNsDecimals());
   	    			      tempBean.setUTCIndicator(temp.getNsTRAD().getNsF98E().getNsUTCIndicator());
   	    			  
   	    		  }
   	    		 
   	    		 
   	    		 
   	    	 }else if (temp.getNsADEL().getNsF98A().getNsDate()!=null || temp.getNsADEL().getNsF98C().getNsDate()!=null)
	    	 {     tempBean.setQualifier("ADEL");
   		  if (temp.getNsADEL().getNsF98A().getNsDate()!=null)
   		  {
   			 tempBean.setOption("Date");
   			  tempBean.setDate(temp.getNsSETT().getNsF98A().getNsDate());
   			  
   		  }  else
   		  {         tempBean.setOption("DateTime"); 
   			       tempBean.setDateTime(temp.getNsADEL().getNsF98C().getNsDate()+" "+temp.getNsADEL().getNsF98C().getNsTime() );
   			  
   		  }
   		 
   		 
   		 
   	 } else if (temp.getNsCERT().getNsF98A().getNsDate()!=null || temp.getNsCERT().getNsF98C().getNsDate()!=null)
	 {     tempBean.setQualifier("CERT");
		  if (temp.getNsCERT().getNsF98A().getNsDate()!=null)
		  {
			  tempBean.setOption("Date");
			  tempBean.setDate(temp.getNsCERT().getNsF98A().getNsDate());
			  
		  }  else
		  {         tempBean.setOption("DateTime"); 
			       tempBean.setDateTime(temp.getNsCERT().getNsF98C().getNsDate()+" "+temp.getNsADEL().getNsF98C().getNsTime() );
			  
		  }
    	    	 
    	    	 
    	     }
    	    	 } 
    	    tempDateTime[i] = tempBean;
     	   
    	     }  
       }
       

  return tempDateTime;

}

}