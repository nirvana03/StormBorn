package com.swift.sequenceB;

import com.swift.sequenceB.sequenceB1.B1_Date_98A;
import com.swift.sequenceB.sequenceB1.B1_FinancialInstrument_12a;
import com.swift.sequenceB.sequenceB1.B1_Flag_17B;
import com.swift.sequenceB.sequenceB1.B1_IdentificationFinancialInstrument_35B;
import com.swift.sequenceB.sequenceB1.B1_Indicator_22F;
import com.swift.sequenceB.sequenceB1.B1_NumberIdentification_13a;
import com.swift.sequenceB.sequenceB1.B1_Price_90a;
import com.swift.sequenceB.sequenceB1.B1_QuantityFinancialInstrument_36B;
import com.swift.sequenceB.sequenceB1.B1_Rate_92A;
import com.webmethods.caf.faces.util.LogUtils;
import com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F12a_Type;
import com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F13a_Type;
import com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F17a_Type;
import com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F22a_Type;
import com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F35a_Type;
import com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F36a_Type;
import com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F90a_Type;
import com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F92a_Type;
import com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F98a_Type;
import com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F22a_Type;
import com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F25a_Type;
import com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F70a_Type;
import com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F94a_Type;
import com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F98a_Type;

public class SequenceBDataUpdation {

	public TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F22a_Type[] indcator_22F_Updation(
			Indicator_22F[] indicator) {

		TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F22a_Type[] tempIndicatorArr = null;

		if (indicator != null && indicator.length != 0) {
			tempIndicatorArr = new TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F22a_Type[indicator.length];

			for (int i = 0; i < indicator.length; i++) {
				TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F22a_Type tempBean = new TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F22a_Type();
				Indicator_22F temp = indicator[i];

				if (temp.getQualifier().equalsIgnoreCase("PROC")) {
					if (temp.getDataSourceScheme() != null
							&& temp.getDataSourceScheme().length() != 0) {
						tempBean.getNsPROC().getNsF22F().setNsDataSourceScheme(
								temp.getDataSoruceSchemeValue());
					}

					tempBean.getNsPROC().getNsF22F().setNsIndicator(
							temp.getIndicator());

				} else if (temp.getQualifier().equalsIgnoreCase("RPOR")) {
					if (temp.getDataSourceScheme() != null
							&& temp.getDataSourceScheme().length() != 0) {
						tempBean.getNsRPOR().getNsF22F().setNsDataSourceScheme(
								temp.getDataSoruceSchemeValue());
					}

					tempBean.getNsRPOR().getNsF22F().setNsIndicator(
							temp.getIndicator());

				} else if (temp.getQualifier().equalsIgnoreCase("PRIR")) {
					if (temp.getDataSourceScheme() != null
							&& temp.getDataSourceScheme().length() != 0) {
						tempBean.getNsPRIR().getNsF22F().setNsDataSourceScheme(
								temp.getDataSoruceSchemeValue());
					}

					tempBean.getNsPRIR().getNsF22F().setNsIndicator(
							temp.getIndicator());

				} else if (temp.getQualifier().equalsIgnoreCase("BORR")) {

					if (temp.getDataSourceScheme() != null
							&& temp.getDataSourceScheme().length() != 0) {
						tempBean.getNsBORR().getNsF22F().setNsDataSourceScheme(
								temp.getDataSoruceSchemeValue());
					}

					tempBean.getNsBORR().getNsF22F().setNsIndicator(
							temp.getIndicator());

				} else if (temp.getQualifier().equalsIgnoreCase("TTCO")) {
					if (temp.getDataSourceScheme() != null
							&& temp.getDataSourceScheme().length() != 0) {
						tempBean.getNsTTCO().getNsF22F().setNsDataSourceScheme(
								temp.getDataSoruceSchemeValue());
					}

					tempBean.getNsTTCO().getNsF22F().setNsIndicator(
							temp.getIndicator());

				} else if (temp.getQualifier().equalsIgnoreCase("INCA")) {
					if (temp.getDataSourceScheme() != null
							&& temp.getDataSourceScheme().length() != 0) {
						tempBean.getNsINCA().getNsF22F().setNsDataSourceScheme(
								temp.getDataSoruceSchemeValue());
					}

					tempBean.getNsINCA().getNsF22F().setNsIndicator(
							temp.getIndicator());

				} else if (temp.getQualifier().equalsIgnoreCase("TRCA")) {
					if (temp.getDataSourceScheme() != null
							&& temp.getDataSourceScheme().length() != 0) {
						tempBean.getNsTRCA().getNsF22F().setNsDataSourceScheme(
								temp.getDataSoruceSchemeValue());
					}

					tempBean.getNsTRCA().getNsF22F().setNsIndicator(
							temp.getIndicator());

				} else if (temp.getQualifier().equalsIgnoreCase("PRIC")) {
					if (temp.getDataSourceScheme() != null
							&& temp.getDataSourceScheme().length() != 0) {
						tempBean.getNsPRIC().getNsF22F().setNsDataSourceScheme(
								temp.getDataSoruceSchemeValue());
					}

					tempBean.getNsPRIC().getNsF22F().setNsIndicator(
							temp.getIndicator());

				}

				tempIndicatorArr[i] = tempBean;

			}

		}

		return tempIndicatorArr;

	}

	public TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F25a_Type[] status_25D_Updation(
			Status_25D[] status) {
		TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F25a_Type[] tempStatus = null;

		if (status != null && status.length != 0) {
			tempStatus = new TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F25a_Type[status.length];

			for (int i = 0; i < status.length; i++) {
				TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F25a_Type tempBean = new TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F25a_Type();
				Status_25D temp = status[i];

				if (temp.getQualifier().equalsIgnoreCase("MTCH")) {
					if (temp.getDataSourceScheme() != null
							&& temp.getDataSourceScheme().length() != 0) {
						tempBean.getNsMTCH().getNsF25D().setNsDataSourceScheme(
								temp.getDataSourceSchemeValue());
					}

					tempBean.getNsMTCH().getNsF25D().setNsStatusCode(
							temp.getStatusCode());

				} else if (temp.getQualifier().equalsIgnoreCase("AFFM")) {
					if (temp.getDataSourceScheme() != null
							&& temp.getDataSourceScheme().length() != 0) {
						tempBean.getNsAFFM().getNsF25D().setNsDataSourceScheme(
								temp.getDataSourceSchemeValue());
					}

					tempBean.getNsAFFM().getNsF25D().setNsStatusCode(
							temp.getStatusCode());

				}

				tempStatus[i] = tempBean;

			}

		}

		return tempStatus;

	}

	public TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F70a_Type[] narrative_70E_Updation(
			Narrative_70E[] narrative) {

		TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F70a_Type[] tempNarrative = null;

		if (narrative != null && narrative.length != 0) {

			tempNarrative = new TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F70a_Type[narrative.length];

			for (int i = 0; i < narrative.length; i++) {
				TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F70a_Type tempBean = new TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F70a_Type();

				Narrative_70E temp = narrative[i];

				String[] tempStr = new String[10];

				if (temp.getQualifier().equalsIgnoreCase("FXIN")) {
					tempStr[0] = temp.getNarrative1();
					tempStr[1] = temp.getNarrative2();
					tempStr[2] = temp.getNarrative3();

					//LogUtils.log("temp[2] = " + temp.getNarrative3());

					tempStr[3] = temp.getNarrative4();
					tempStr[4] = temp.getNarrative5();
					tempStr[5] = temp.getNarrative6();
					tempStr[6] = temp.getNarrative7();
					tempStr[7] = temp.getNarrative8();
					tempStr[8] = temp.getNarrative9();
					tempStr[9] = temp.getNarrative10();
					tempBean.getNsFXIN().getNsF70E().getNsNarrative()
							.setNsLine(tempStr);

				} else if (temp.getQualifier().equalsIgnoreCase("SPRO")) {
					tempStr[0] = temp.getNarrative1();
					tempStr[1] = temp.getNarrative2();
					tempStr[2] = temp.getNarrative3();
					tempStr[3] = temp.getNarrative4();
					tempStr[4] = temp.getNarrative5();
					tempStr[5] = temp.getNarrative6();
					tempStr[6] = temp.getNarrative7();
					tempStr[7] = temp.getNarrative8();
					tempStr[8] = temp.getNarrative9();
					tempStr[9] = temp.getNarrative10();
					tempBean.getNsSPRO().getNsF70E().getNsNarrative()
							.setNsLine(tempStr);

				}

				tempNarrative[i] = tempBean;

			}

		}

		return tempNarrative;

	}

	public TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F94a_Type[] place_94a_Updation(
			Place_94a[] place) {
		TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F94a_Type[] tempPlace = null;

		if (place != null && place.length != 0) {
			tempPlace = new TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F94a_Type[place.length];

			for (int i = 0; i < place.length; i++) {
				TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F94a_Type tempBean = new TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F94a_Type();
				// Place_94a temp = new Place_94a();
				Place_94a temp = place[i];

				if (temp.getQualifier().equalsIgnoreCase("CLEA")) {
					
					tempBean.getNsCLEA().getNsF94H().setNsIdentifierCode(
							temp.getIdentifierCode());


				} else if (temp.getQualifier().equalsIgnoreCase("TRAD")) {
					tempBean.getNsTRAD().getNsF94B().setNsNarrative(
							temp.getNarrative());

					if (temp.getDataSourceScheme() != null
							&& temp.getDataSourceScheme().length() != 0) {
						tempBean.getNsTRAD().getNsF94B().setNsDataSourceScheme(
								temp.getDataSourceSchemeValue());
					} else {
						tempBean.getNsTRAD().getNsF94B().setNsPlaceCode(
								temp.getPlaceCode());
					}

				}
				
				tempPlace[i] = tempBean;

			}

		}

		return tempPlace;

	}

	public TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F22a_Type[] b1_Indicator_22F_Updation(B1_Indicator_22F[] b1Indicator) {
		
		TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F22a_Type[] tempB1Indicator = null;

		if (b1Indicator != null && b1Indicator.length != 0) {

			tempB1Indicator = new TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F22a_Type[b1Indicator.length];

			for (int i = 0; i < b1Indicator.length; i++) {
				
				TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F22a_Type tempBean = new TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F22a_Type();
				B1_Indicator_22F temp = b1Indicator[i];

				if (temp.getQualifier().equalsIgnoreCase("MICO")) {
					if (temp.getDataSourceScheme() != null
							&& temp.getDataSourceScheme().length() != 0) {
						tempBean.getNsMICO().getNsF22F().setNsDataSourceScheme(
								temp.getDataSoruceSchemeValue());
					}

					tempBean.getNsMICO().getNsF22F().setNsIndicator(
							temp.getIndicator());
				} else if (temp.getQualifier().equalsIgnoreCase("FORM")) {
					if (temp.getDataSourceScheme() != null
							&& temp.getDataSourceScheme().length() != 0) {
						tempBean.getNsFORM().getNsF22F().setNsDataSourceScheme(
								temp.getDataSoruceSchemeValue());
					}

					tempBean.getNsFORM().getNsF22F().setNsIndicator(
							temp.getIndicator());
				} else if (temp.getQualifier().equalsIgnoreCase("PFRE")) {
					if (temp.getDataSourceScheme() != null
							&& temp.getDataSourceScheme().length() != 0) {
						tempBean.getNsPFRE().getNsF22F().setNsDataSourceScheme(
								temp.getDataSoruceSchemeValue());
					}

					tempBean.getNsPFRE().getNsF22F().setNsIndicator(
							temp.getIndicator());
				} 
				/* Comment the code for SR2012 version - Start
				
				   else if (temp.getQualifier().equalsIgnoreCase("PREF")) {
					if (temp.getDataSourceScheme() != null
							&& temp.getDataSourceScheme().length() != 0) {
						tempBean.getNsPREF().getNsF22F().setNsDataSourceScheme(
								temp.getDataSoruceSchemeValue());
					}

					tempBean.getNsPREF().getNsF22F().setNsIndicator(
							temp.getIndicator());
				} 
				
				Comment the code for SR2012 version - End */
				
				else if (temp.getQualifier().equalsIgnoreCase("PAYS")) {
					if (temp.getDataSourceScheme() != null
							&& temp.getDataSourceScheme().length() != 0) {
						tempBean.getNsPAYS().getNsF22F().setNsDataSourceScheme(
								temp.getDataSoruceSchemeValue());
					}

					tempBean.getNsPAYS().getNsF22F().setNsIndicator(
							temp.getIndicator());
				}
				
				/* Comment the code for SR2012 version - Start 
				  
				else if (temp.getQualifier().equalsIgnoreCase("PADI")) {
					if (temp.getDataSourceScheme() != null
							&& temp.getDataSourceScheme().length() != 0) {
						tempBean.getNsPADI().getNsF22F().setNsDataSourceScheme(
								temp.getDataSoruceSchemeValue());
					}

					tempBean.getNsPADI().getNsF22F().setNsIndicator(
							temp.getIndicator());
				}
				
				 Comment the code for SR2012 version - End */
				
				else if (temp.getQualifier().equalsIgnoreCase("CFRE")) {
					if (temp.getDataSourceScheme() != null
							&& temp.getDataSourceScheme().length() != 0) {
						tempBean.getNsCFRE().getNsF22F().setNsDataSourceScheme(
								temp.getDataSoruceSchemeValue());
					}

					tempBean.getNsCFRE().getNsF22F().setNsIndicator(
							temp.getIndicator());
				}

				tempB1Indicator[i] = tempBean;

			}

		}

		return tempB1Indicator;
	}

	public TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F12a_Type[] b1_FinancialInstrument_12a_Updation(
			B1_FinancialInstrument_12a[] financialInstrument) {

		TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F12a_Type[] tempFinancialInstr = null;

		if (financialInstrument != null && financialInstrument.length != 0) {
			tempFinancialInstr = new TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F12a_Type[financialInstrument.length];

			for (int i = 0; i < financialInstrument.length; i++) {
				TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F12a_Type tempBean = new TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F12a_Type();
				B1_FinancialInstrument_12a temp = financialInstrument[i];

				if (temp.getQualifier().equalsIgnoreCase("CLAS")) {
					if (temp.getOption().equalsIgnoreCase("CFICode")) {
						tempBean.getNsCLAS().getNsF12C().setNsCFICode(
								temp.getCode());
					} else {
						tempBean.getNsCLAS().getNsF12A().setNsDataSourceScheme(
								temp.getDataSoruceSchemeValue());
						tempBean.getNsCLAS().getNsF12A()
								.setNsInstrumentCodeOrDescription(
										temp.getCode());
					}

				} else if (temp.getQualifier().equalsIgnoreCase("OPST")) {
					if (temp.getDataSourceScheme() != null
							&& temp.getDataSourceScheme().length() != 0) {
						tempBean.getNsOPST().getNsF12B().setNsDataSourceScheme(
								temp.getDataSoruceSchemeValue());
					}

					tempBean.getNsOPST().getNsF12B().setNsInstrumentTypeCode(
							temp.getCode());

				} else if (temp.getQualifier().equalsIgnoreCase("OPTI")) {
					if (temp.getDataSourceScheme() != null
							&& temp.getDataSourceScheme().length() != 0) {
						tempBean.getNsOPTI().getNsF12B().setNsDataSourceScheme(
								temp.getDataSoruceSchemeValue());
					}

					tempBean.getNsOPTI().getNsF12B().setNsInstrumentTypeCode(
							temp.getCode());

				}

				tempFinancialInstr[i] = tempBean;
			}

		}

		return tempFinancialInstr;
	}

	public TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F98a_Type[] b1_Date_98A_Updation(
			B1_Date_98A[] date) {
		TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F98a_Type[] tempDate = null;

		if (date != null && date.length != 0) {
			tempDate = new TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F98a_Type[date.length];

			for (int i = 0; i < date.length; i++) {
				TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F98a_Type tempBean = new TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F98a_Type();
				B1_Date_98A temp = date[i];

				if (temp.getQualifier().equalsIgnoreCase("COUP")) {
					tempBean.getNsCOUP().getNsF98A().setNsDate(temp.getDate());

				} else if (temp.getQualifier().equalsIgnoreCase("EXPI")) {
					tempBean.getNsEXPI().getNsF98A().setNsDate(temp.getDate());

				} else if (temp.getQualifier().equalsIgnoreCase("FRNR")) {
					tempBean.getNsFRNR().getNsF98A().setNsDate(temp.getDate());

				} else if (temp.getQualifier().equalsIgnoreCase("MATU")) {
					tempBean.getNsMATU().getNsF98A().setNsDate(temp.getDate());

				} else if (temp.getQualifier().equalsIgnoreCase("ISSU")) {
					tempBean.getNsISSU().getNsF98A().setNsDate(temp.getDate());

				} else if (temp.getQualifier().equalsIgnoreCase("CALD")) {
					tempBean.getNsCALD().getNsF98A().setNsDate(temp.getDate());

				} else if (temp.getQualifier().equalsIgnoreCase("PUTT")) {
					tempBean.getNsPUTT().getNsF98A().setNsDate(temp.getDate());

				} else if (temp.getQualifier().equalsIgnoreCase("DDTE")) {
					tempBean.getNsDDTE().getNsF98A().setNsDate(temp.getDate());

				} else if (temp.getQualifier().equalsIgnoreCase("FCOU")) {
					tempBean.getNsFCOU().getNsF98A().setNsDate(temp.getDate());

				}

				tempDate[i] = tempBean;
			}

		}

		return tempDate;

	}

	public TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F92a_Type[] b1_Rate_92A_Updation(B1_Rate_92A[] rate) {

		TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F92a_Type[] tempRate = null;

		if (rate != null && rate.length != 0) {

			tempRate = new TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F92a_Type[rate.length];

			for (int i = 0; i < tempRate.length; i++) {
				TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F92a_Type tempBean = new TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F92a_Type();
				B1_Rate_92A temp = rate[i];

				if (temp.getQualifer().equalsIgnoreCase("PRFC")) {
					tempBean.getNsPRFC().getNsF92A().setNsRate(
							getUpdatedAmtValue(temp.getRate()));
					tempBean.getNsPRFC().getNsF92A().setNsSign(temp.getSign());
				} else if (temp.getQualifer().equalsIgnoreCase("CUFC")) {
					tempBean.getNsCUFC().getNsF92A().setNsRate(
							getUpdatedAmtValue(temp.getRate()));
					tempBean.getNsCUFC().getNsF92A().setNsSign(temp.getSign());
				} else if (temp.getQualifer().equalsIgnoreCase("NWFC")) {
					tempBean.getNsNWFC().getNsF92A().setNsRate(
							getUpdatedAmtValue(temp.getRate()));
					tempBean.getNsNWFC().getNsF92A().setNsSign(temp.getSign());
				} else if (temp.getQualifer().equalsIgnoreCase("INTR")) {
					tempBean.getNsINTR().getNsF92A().setNsRate(
							getUpdatedAmtValue(temp.getRate()));
					tempBean.getNsINTR().getNsF92A().setNsSign(temp.getSign());
				} else if (temp.getQualifer().equalsIgnoreCase("NXRT")) {
					tempBean.getNsNXRT().getNsF92A().setNsRate(
							getUpdatedAmtValue(temp.getRate()));
					tempBean.getNsNXRT().getNsF92A().setNsSign(temp.getSign());
				} else if (temp.getQualifer().equalsIgnoreCase("INDX")) {
					tempBean.getNsINDX().getNsF92A().setNsRate(
							getUpdatedAmtValue(temp.getRate()));
					tempBean.getNsINDX().getNsF92A().setNsSign(temp.getSign());
				} 
				
				//Add the code for SR2012 version - Start
				
				else if (temp.getQualifer().equalsIgnoreCase("YTMR"))
				{   tempBean.getNsYTMR().getNsF92A().setNsRate(temp.getRate());
				    tempBean.getNsYTMR().getNsF92A().setNsSign(temp.getSign());
					
					
				} 
				
				//Add the code for SR2012 version - End

				tempRate[i] = tempBean;

			}

		}

		return tempRate;

	}

	public TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F13a_Type[] b1_NumberIdentification_13a_Updation(B1_NumberIdentification_13a[] numberId) {
		
		TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F13a_Type[] tempNumberId = null;

		if (numberId != null && numberId.length != 0) {
			tempNumberId = new TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F13a_Type[numberId.length];

			for (int i = 0; i < numberId.length; i++) {
				TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F13a_Type tempBean = new TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F13a_Type();
				B1_NumberIdentification_13a temp = numberId[i];

				if (temp.getQualifier().equalsIgnoreCase("COUP")) {
					if (temp.getOption().equalsIgnoreCase("Number")) {
						tempBean.getNsCOUP().getNsF13B().setNsDataSourceScheme(
								temp.getDataSourceSchemeValue());
						tempBean.getNsCOUP().getNsF13B().setNsNumber(
								temp.getNumberId());
					} else {
						tempBean.getNsCOUP().getNsF13A().setNsNumberId(
								temp.getNumberId());

					}

				} else if (temp.getQualifier().equalsIgnoreCase("POOL")) {
					if (temp.getOption().equalsIgnoreCase("Number")) {
						tempBean.getNsPOOL().getNsF13B().setNsDataSourceScheme(
								temp.getDataSourceSchemeValue());
						tempBean.getNsPOOL().getNsF13B().setNsNumber(
								temp.getNumberId());
					}
					
					/* Comment the code for SR2012 version - Start
					 
					   else {
						tempBean.getNsPOOL().getNsF13A().setNsNumberId(
								temp.getNumberId());

					}
					 
					Comment the code for SR2012 version - End */
				}
				tempNumberId[i] = tempBean;
			}
		}
		return tempNumberId;
	}

	public TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F17a_Type[] b1_Flag_17B_Updation(
			B1_Flag_17B[] flag) {

		TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F17a_Type[] tempFlag = null;

		if (flag != null && flag.length != 0) {
			tempFlag = new TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F17a_Type[flag.length];

			for (int i = 0; i < flag.length; i++) {
				TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F17a_Type tempBean = new TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F17a_Type();
				B1_Flag_17B temp = flag[i];

				if (temp.getQualifier().equalsIgnoreCase("FRNF")) {
					tempBean.getNsFRNF().getNsF17B().setNsFlag(temp.getFlag());

				} else if (temp.getQualifier().equalsIgnoreCase("CALL")) {
					tempBean.getNsCALL().getNsF17B().setNsFlag(temp.getFlag());

				} else if (temp.getQualifier().equalsIgnoreCase("PUTT")) {
					tempBean.getNsPUTT().getNsF17B().setNsFlag(temp.getFlag());

				}
				tempFlag[i] = tempBean;

			}

		}

		return tempFlag;

	}

	public TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F90a_Type[] b1_Price_90a_Updation(
			B1_Price_90a[] price) {

		TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F90a_Type[] tempPrice = null;

		if (price != null && price.length != 0) {
			tempPrice = new TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F90a_Type[price.length];

			for (int i = 0; i < price.length; i++) {
				TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F90a_Type tempBean = new TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F90a_Type();
				B1_Price_90a temp = price[i];

				if (temp.getQualifier().equalsIgnoreCase("INDC")) {

					if (temp.getOption().equalsIgnoreCase("PercentageTypeCode")) {
						tempBean.getNsINDC().getNsF90A()
								.setNsPercentageTypeCode(temp.getCode());
						tempBean.getNsINDC().getNsF90A().setNsPrice(
								getUpdatedAmtValue(temp.getPrice()));
						//SR2016
						if (null != temp.getPriceSignB1() || !(temp.getPriceSignB1().equals("")) )
						{
							//LogUtils.log("Seq B1 --date update----Sign!=null---------INDC---------"+temp.getPriceSignB1());
							tempBean.getNsINDC().getNsF90A().setNsSign(temp.getPriceSignB1());
						}
						//SR2016

					} else {

						tempBean.getNsINDC().getNsF90B().setNsAmountTypeCode(
								temp.getCode());
						tempBean.getNsINDC().getNsF90B().setNsCurrencyCode(
								temp.getCurrencyCode());
						tempBean.getNsINDC().getNsF90B().setNsPrice(
								getUpdatedAmtValue(temp.getPrice()));
					}

				} else if (temp.getQualifier().equalsIgnoreCase("MRKT")) {
					if (temp.getOption().equalsIgnoreCase("PercentageTypeCode")) {
						tempBean.getNsMRKT().getNsF90A()
								.setNsPercentageTypeCode(temp.getCode());
						tempBean.getNsMRKT().getNsF90A().setNsPrice(
								getUpdatedAmtValue(temp.getPrice()));
						//SR2016
						if (null != temp.getPriceSignB1() || !(temp.getPriceSignB1().equals("")) )
						{
							//LogUtils.log("Seq B1 --date update----Sign!=null---------MRKT---------"+temp.getPriceSignB1());
							tempBean.getNsMRKT().getNsF90A().setNsSign(temp.getPriceSignB1());
						}
						//SR2016
					} else {

						tempBean.getNsMRKT().getNsF90B().setNsAmountTypeCode(
								temp.getCode());
						tempBean.getNsMRKT().getNsF90B().setNsCurrencyCode(
								temp.getCurrencyCode());
						tempBean.getNsMRKT().getNsF90B().setNsPrice(
								getUpdatedAmtValue(temp.getPrice()));
					}

				} else if (temp.getQualifier().equalsIgnoreCase("EXER")) {
					if (temp.getOption().equalsIgnoreCase("PercentageTypeCode")) {
						tempBean.getNsEXER().getNsF90A()
								.setNsPercentageTypeCode(temp.getCode());
						tempBean.getNsEXER().getNsF90A().setNsPrice(
								getUpdatedAmtValue(temp.getPrice()));
						//SR2016
						if (null != temp.getPriceSignB1() || !(temp.getPriceSignB1().equals("")) )
						{
							//LogUtils.log("Seq B1 --date update----Sign!=null---------EXER---------"+temp.getPriceSignB1());
							tempBean.getNsEXER().getNsF90A().setNsSign(temp.getPriceSignB1());
						}
						//SR2016

					} else {

						tempBean.getNsEXER().getNsF90B().setNsAmountTypeCode(
								temp.getCode());
						tempBean.getNsEXER().getNsF90B().setNsCurrencyCode(
								temp.getCurrencyCode());
						tempBean.getNsEXER().getNsF90B().setNsPrice(
								getUpdatedAmtValue(temp.getPrice()));
					}

				}

				tempPrice[i] = tempBean;

			}

		}

		return tempPrice;

	}

	public TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F36a_Type[] b1_QuantityFinancialInstr_36B_Updation(
			B1_QuantityFinancialInstrument_36B[] quantityFinInstru) {

		TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F36a_Type[] tempQtyFinInst = null;

		if (quantityFinInstru != null && quantityFinInstru.length != 0) {
			tempQtyFinInst = new TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F36a_Type[quantityFinInstru.length];

			for (int i = 0; i < quantityFinInstru.length; i++) {
				TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F36a_Type tempBean = new TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F36a_Type();
				B1_QuantityFinancialInstrument_36B temp = quantityFinInstru[i];

				if (temp.getQualifier().equalsIgnoreCase("MINO")) {
					tempBean.getNsMINO().getNsF36B().setNsQuantity(
							getUpdatedAmtValue(temp.getQuantity()));
					tempBean.getNsMINO().getNsF36B().setNsQuantityTypeCode(
							temp.getQuantityTypeCode());

				} else if (temp.getQualifier().equalsIgnoreCase("SIZE")) {
					tempBean.getNsSIZE().getNsF36B().setNsQuantity(
							getUpdatedAmtValue(temp.getQuantity()));
					tempBean.getNsSIZE().getNsF36B().setNsQuantityTypeCode(
							temp.getQuantityTypeCode());

				}

				tempQtyFinInst[i] = tempBean;
			}

		}

		return tempQtyFinInst;

	}

	public TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F35a_Type[] b1_IdentificaitonFinIstr_35B_Updation(
			B1_IdentificationFinancialInstrument_35B[] idFinInst) {

		TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F35a_Type[] tempIdFinInst = null;

		if (idFinInst != null && idFinInst.length != 0) {
			tempIdFinInst = new TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F35a_Type[idFinInst.length];

			for (int i = 0; i < idFinInst.length; i++) {
				TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F35a_Type tempBean = new TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F35a_Type();
				B1_IdentificationFinancialInstrument_35B temp = idFinInst[i];

				String[] tempStr = new String[4];

				tempStr[0] = temp.getDesc1();
				tempStr[1] = temp.getDesc2();
				tempStr[2] = temp.getDesc3();
				tempStr[3] = temp.getDesc4();

				tempBean.getNsF35B().setNsIdentificationOfSecurity(
						temp.getSecurityId());
				tempBean.getNsF35B().getNsDescriptionOfSecurity().setNsLine(
						tempStr);

				tempIdFinInst[i] = tempBean;

			}

		}

		return tempIdFinInst;

	}

	public TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F98a_Type[] dateTime_98a_Updation(
			DateTime_98a[] dateTime) {
		TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F98a_Type[] tempDateTime = null;

		if (dateTime != null && dateTime.length != 0) {
			tempDateTime = new TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F98a_Type[dateTime.length];

			for (int i = 0; i < dateTime.length; i++) {
				TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F98a_Type tempBean = new TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F98a_Type();
				DateTime_98a temp = dateTime[i];

				if (temp.getQualifier().equalsIgnoreCase("SETT")) {

					if (temp.getOption().equalsIgnoreCase("Date")) {
						tempBean.getNsSETT().getNsF98A().setNsDate(
								temp.getDate());

					} else if (temp.getOption().equalsIgnoreCase("DateCode")) {
						if (temp.getDataSourceScheme() != null
								&& temp.getDataSourceScheme().length() != 0) {
							tempBean.getNsSETT().getNsF98B()
									.setNsDataSourceScheme(
											temp.getDataSourceSchemeValue());
						} else {
							tempBean.getNsSETT().getNsF98B().setNsDateCode(
									temp.getDate());
						}

					} else if (temp.getOption().equalsIgnoreCase("DateTime")) {
						tempBean.getNsSETT().getNsF98C().setNsDate(
								temp.getDateTime());

					}

				} else if (temp.getQualifier().equalsIgnoreCase("TRAD")) {

					if (temp.getOption().equalsIgnoreCase("Date")) {
						tempBean.getNsTRAD().getNsF98A().setNsDate(
								temp.getDate());

					} else if (temp.getOption().equalsIgnoreCase("DateCode")) {
						if (temp.getDataSourceScheme() != null
								&& temp.getDataSourceScheme().length() != 0) {
							tempBean.getNsTRAD().getNsF98B()
									.setNsDataSourceScheme(
											temp.getDataSourceSchemeValue());
						} else {
							tempBean.getNsTRAD().getNsF98B().setNsDateCode(
									temp.getDate());
						}

					} else if (temp.getOption().equalsIgnoreCase("DateTime")) {
						tempBean.getNsTRAD().getNsF98C().setNsDate(
								temp.getDateTime());

					} else if (temp.getOption().equalsIgnoreCase(
							"DateTimeUTCIndicator")) {
						tempBean.getNsTRAD().getNsF98E().setNsDate(
								temp.getDateTime());
						tempBean.getNsTRAD().getNsF98E().setNsUTCIndicator(
								temp.getUTCIndicator());
						tempBean.getNsTRAD().getNsF98E().setNsDecimals(
								temp.getDecimals());
					}

				} else if (temp.getQualifier().equalsIgnoreCase("ADEL")) {

					if (temp.getOption().equalsIgnoreCase("Date")) {
						tempBean.getNsADEL().getNsF98A().setNsDate(
								temp.getDate());

					} else if (temp.getOption().equalsIgnoreCase("DateTime")) {
						tempBean.getNsADEL().getNsF98C().setNsDate(
								temp.getDateTime());

					}

				} else if (temp.getQualifier().equalsIgnoreCase("CERT")) {

					if (temp.getOption().equalsIgnoreCase("Date")) {
						tempBean.getNsCERT().getNsF98A().setNsDate(
								temp.getDate());

					} else if (temp.getOption().equalsIgnoreCase("DateTime")) {
						tempBean.getNsCERT().getNsF98C().setNsDate(
								temp.getDateTime());

					}

				}

				tempDateTime[i] = tempBean;
			}

		}
		return tempDateTime;

	}

	public String getUpdatedAmtValue(String tempQuantityValue) {

		if (tempQuantityValue != null && tempQuantityValue.trim().length() != 0) {
			
			  tempQuantityValue = tempQuantityValue.replace(".", ",");
	          int index = tempQuantityValue.lastIndexOf(",");
	          if (index!=-1)
	        	  tempQuantityValue = tempQuantityValue.substring(0,index).replace(",", "").concat(tempQuantityValue.substring(index));
	
	           else
	        	   tempQuantityValue=tempQuantityValue+",";            
	    } 

		return tempQuantityValue;

	}

}
