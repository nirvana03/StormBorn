package com.swift.sequenceB;

import java.io.Serializable;



public class SequenceBMasterBean implements Serializable{
	
	private String finInstrDesc1 = "";
	private String finInstrDesc2 = "";
	private String finInstrDesc3 = "";
	private String finInstrDesc4 = "";
	
	private String finInstrAttNarrative1 = "";
	private String finInstrAttNarrative2 = "";
	private String finInstrAttNarrative3 = "";
	private String finInstrAttNarrative4 = "";
	private String finInstrAttNarrative5 = "";
	private String finInstrAttNarrative6 = "";
	private String finInstrAttNarrative7 = "";
	private String finInstrAttNarrative8 = "";
	private String finInstrAttNarrative9 = "";
	private String finInstrAttNarrative10 = "";
	public String getFinInstrDesc1() {
		return finInstrDesc1;
	}
	public void setFinInstrDesc1(String finInstrDesc1) {
		this.finInstrDesc1 = finInstrDesc1;
	}
	public String getFinInstrDesc2() {
		return finInstrDesc2;
	}
	public void setFinInstrDesc2(String finInstrDesc2) {
		this.finInstrDesc2 = finInstrDesc2;
	}
	public String getFinInstrDesc3() {
		return finInstrDesc3;
	}
	public void setFinInstrDesc3(String finInstrDesc3) {
		this.finInstrDesc3 = finInstrDesc3;
	}
	public String getFinInstrDesc4() {
		return finInstrDesc4;
	}
	public void setFinInstrDesc4(String finInstrDesc4) {
		this.finInstrDesc4 = finInstrDesc4;
	}
	public String getFinInstrAttNarrative1() {
		return finInstrAttNarrative1;
	}
	public void setFinInstrAttNarrative1(String finInstrAttNarrative1) {
		this.finInstrAttNarrative1 = finInstrAttNarrative1;
	}
	public String getFinInstrAttNarrative2() {
		return finInstrAttNarrative2;
	}
	public void setFinInstrAttNarrative2(String finInstrAttNarrative2) {
		this.finInstrAttNarrative2 = finInstrAttNarrative2;
	}
	public String getFinInstrAttNarrative3() {
		return finInstrAttNarrative3;
	}
	public void setFinInstrAttNarrative3(String finInstrAttNarrative3) {
		this.finInstrAttNarrative3 = finInstrAttNarrative3;
	}
	public String getFinInstrAttNarrative4() {
		return finInstrAttNarrative4;
	}
	public void setFinInstrAttNarrative4(String finInstrAttNarrative4) {
		this.finInstrAttNarrative4 = finInstrAttNarrative4;
	}
	public String getFinInstrAttNarrative5() {
		return finInstrAttNarrative5;
	}
	public void setFinInstrAttNarrative5(String finInstrAttNarrative5) {
		this.finInstrAttNarrative5 = finInstrAttNarrative5;
	}
	public String getFinInstrAttNarrative6() {
		return finInstrAttNarrative6;
	}
	public void setFinInstrAttNarrative6(String finInstrAttNarrative6) {
		this.finInstrAttNarrative6 = finInstrAttNarrative6;
	}
	public String getFinInstrAttNarrative7() {
		return finInstrAttNarrative7;
	}
	public void setFinInstrAttNarrative7(String finInstrAttNarrative7) {
		this.finInstrAttNarrative7 = finInstrAttNarrative7;
	}
	public String getFinInstrAttNarrative8() {
		return finInstrAttNarrative8;
	}
	public void setFinInstrAttNarrative8(String finInstrAttNarrative8) {
		this.finInstrAttNarrative8 = finInstrAttNarrative8;
	}
	public String getFinInstrAttNarrative9() {
		return finInstrAttNarrative9;
	}
	public void setFinInstrAttNarrative9(String finInstrAttNarrative9) {
		this.finInstrAttNarrative9 = finInstrAttNarrative9;
	}
	public String getFinInstrAttNarrative10() {
		return finInstrAttNarrative10;
	}
	public void setFinInstrAttNarrative10(String finInstrAttNarrative10) {
		this.finInstrAttNarrative10 = finInstrAttNarrative10;
	}
	

}
