package com.swift.sequenceB;

public class Status_25D {
	
	private String id = "";
	private String qualifier = "";
	private String dataSourceScheme = "";
	private String dataSourceSchemeValue = "";
	private String statusCode = "";
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getQualifier() {
		return qualifier;
	}
	public void setQualifier(String qualifier) {
		this.qualifier = qualifier;
	}
	public String getDataSourceScheme() {
		return dataSourceScheme;
	}
	public void setDataSourceScheme(String dataSourceScheme) {
		this.dataSourceScheme = dataSourceScheme;
	}
	public String getDataSourceSchemeValue() {
		return dataSourceSchemeValue;
	}
	public void setDataSourceSchemeValue(String dataSourceSchemeValue) {
		this.dataSourceSchemeValue = dataSourceSchemeValue;
	}
	public String getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}
	
	

}
