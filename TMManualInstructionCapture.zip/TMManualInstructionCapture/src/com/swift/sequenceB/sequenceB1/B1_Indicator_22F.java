package com.swift.sequenceB.sequenceB1;

public class B1_Indicator_22F {
	
	
	private String id = "";
	private String qualifier = "";
	private String indicator = "";
	private String dataSourceScheme = "";
	private String dataSoruceSchemeValue = "";
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getQualifier() {
		return qualifier;
	}
	public void setQualifier(String qualifier) {
		this.qualifier = qualifier;
	}
	public String getIndicator() {
		return indicator;
	}
	public void setIndicator(String indicator) {
		this.indicator = indicator;
	}
	public String getDataSourceScheme() {
		return dataSourceScheme;
	}
	public void setDataSourceScheme(String dataSourceScheme) {
		this.dataSourceScheme = dataSourceScheme;
	}
	public String getDataSoruceSchemeValue() {
		return dataSoruceSchemeValue;
	}
	public void setDataSoruceSchemeValue(String dataSoruceSchemeValue) {
		this.dataSoruceSchemeValue = dataSoruceSchemeValue;
	}
	
	
	

}
