package com.swift.sequenceB.sequenceB1;

public class B1_Price_90a {
	
	private String id = "";
	private String qualifier = "";
	private String option = "";
	private String currencyCode = "";
	private String price = "";
	private String code = "";
	private String priceSignB1;
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getQualifier() {
		return qualifier;
	}
	public void setQualifier(String qualifier) {
		this.qualifier = qualifier;
	}
	public String getOption() {
		return option;
	}
	public void setOption(String option) {
		this.option = option;
	}
	public String getCurrencyCode() {
		return currencyCode;
	}
	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}
	public String getPrice() {
		return price;
	}
	public void setPrice(String price) {
		this.price = price;
	}
	public String getPriceSignB1()  {
		
		return priceSignB1;
	}
	public void setPriceSignB1(java.lang.String priceSignB1)  {
		this.priceSignB1 = priceSignB1;
	}
	
	
	

}
