package com.swift.sequenceB.sequenceB1;

public class B1_QuantityFinancialInstrument_36B {
	
	private String id = "";
	private String qualifier = "";
	private String quantityTypeCode = "";
	private String quantity = "";
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getQualifier() {
		return qualifier;
	}
	public void setQualifier(String qualifier) {
		this.qualifier = qualifier;
	}
	public String getQuantityTypeCode() {
		return quantityTypeCode;
	}
	public void setQuantityTypeCode(String quantityTypeCode) {
		this.quantityTypeCode = quantityTypeCode;
	}
	public String getQuantity() {
		return quantity;
	}
	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}
	
	
	
	

}
