package com.swift.sequenceB.sequenceB1;

public class B1_Rate_92A {
	
	private String id = "";
	private String qualifer = "";
	private String sign = "";
	private String rate = "";
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getQualifer() {
		return qualifer;
	}
	public void setQualifer(String qualifer) {
		this.qualifer = qualifer;
	}
	public String getSign() {
		return sign;
	}
	public void setSign(String sign) {
		this.sign = sign;
	}
	public String getRate() {
		return rate;
	}
	public void setRate(String rate) {
		this.rate = rate;
	}
	

}
