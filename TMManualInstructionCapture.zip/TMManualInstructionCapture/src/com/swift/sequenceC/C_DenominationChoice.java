package com.swift.sequenceC;

public class C_DenominationChoice {
	
	private String narrative1;
	
	private String narrative2;
	
	private String narrative3;
	
	private String narrative4;
	
	private String narrative5;
	
	private String narrative6;

	public String getNarrative1() {
		return narrative1;
	}

	public void setNarrative1(String narrative1) {
		this.narrative1 = narrative1;
	}

	public String getNarrative2() {
		return narrative2;
	}

	public void setNarrative2(String narrative2) {
		this.narrative2 = narrative2;
	}

	public String getNarrative3() {
		return narrative3;
	}

	public void setNarrative3(String narrative3) {
		this.narrative3 = narrative3;
	}

	public String getNarrative4() {
		return narrative4;
	}

	public void setNarrative4(String narrative4) {
		this.narrative4 = narrative4;
	}

	public String getNarrative5() {
		return narrative5;
	}

	public void setNarrative5(String narrative5) {
		this.narrative5 = narrative5;
	}

	public String getNarrative6() {
		return narrative6;
	}

	public void setNarrative6(String narrative6) {
		this.narrative6 = narrative6;
	}

}
