package com.swift.sequenceC;

public class C_Party {

	private String options;
	
	private String dataSourceScheme;
	
	private String dataSourceSchemeValue;
	
	private String value;
	
	//SR2016
	private String alteOption;
	private String alteValue;
	//end SR2016
	public String getAlteOption() {
		return alteOption;
	}

	public void setAlteOption(String alteOption) {
		this.alteOption = alteOption;
	}

	public String getAlteValue() {
		return alteValue;
	}

	public void setAlteValue(String alteValue) {
		this.alteValue = alteValue;
	}


	public String getDataSourceScheme() {
		return dataSourceScheme;
	}

	public void setDataSourceScheme(String dataSourceScheme) {
		this.dataSourceScheme = dataSourceScheme;
	}

	public String getDataSourceSchemeValue() {
		return dataSourceSchemeValue;
	}

	public void setDataSourceSchemeValue(String dataSourceSchemeValue) {
		this.dataSourceSchemeValue = dataSourceSchemeValue;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public String getOptions() {
		return options;
	}

	public void setOptions(String options) {
		this.options = options;
	}
}
