package com.swift.sequenceC;

public class C_Place {
	
	private String options;
	
	private String dataSourceScheme;
	
	private String dataSourceSchemeValue;
	
	private String placeCode;
	
	private String countryCode;
	
	private String identifierCode;
	
	private String narrative;
	
	public String getDataSourceScheme() {
		return dataSourceScheme;
	}

	public void setDataSourceScheme(String dataSourceScheme) {
		this.dataSourceScheme = dataSourceScheme;
	}

	public String getDataSourceSchemeValue() {
		return dataSourceSchemeValue;
	}

	public void setDataSourceSchemeValue(String dataSourceSchemeValue) {
		this.dataSourceSchemeValue = dataSourceSchemeValue;
	}

	public String getPlaceCode() {
		return placeCode;
	}

	public void setPlaceCode(String placeCode) {
		this.placeCode = placeCode;
	}

	public String getCountryCode() {
		return countryCode;
	}

	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}

	public String getIdentifierCode() {
		return identifierCode;
	}

	public void setIdentifierCode(String identifierCode) {
		this.identifierCode = identifierCode;
	}

	public String getNarrative() {
		return narrative;
	}

	public void setNarrative(String narrative) {
		this.narrative = narrative;
	}

	public String getOptions() {
		return options;
	}

	public void setOptions(String options) {
		this.options = options;
	}

}
