package com.swift.sequenceC;

import com.google.common.base.Strings;
import com.webmethods.caf.faces.util.LogUtils;
import com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqC_F13a_Type;
import com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqC_F36a_Type;
import com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqC_F70a_Type;
import com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqC_F94a_Type;
import com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqC_F95a_Type;
import com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqC_F97a_Type;

public class SequenceCPopulate {

	public C_QuantityOfFinancialInstrument[] populateCFinancialInstrument(
			TMCommon_docType_MT54x_docTypeRef_ns_SeqC_F36a_Type[] tempSeqCFinancialInstr) {

		C_QuantityOfFinancialInstrument[] financialInstrument = null;

		if (null != tempSeqCFinancialInstr
				&& tempSeqCFinancialInstr.length >= 1) {

			financialInstrument = new C_QuantityOfFinancialInstrument[tempSeqCFinancialInstr.length];

			for (int i = 0; i < tempSeqCFinancialInstr.length; i++) {

				C_QuantityOfFinancialInstrument financialInstruBean = new C_QuantityOfFinancialInstrument();

				if (null != tempSeqCFinancialInstr[i].getNsSETT().getNsF36B()
						.getNsQuantityTypeCode()) {
					financialInstruBean
							.setQuantityTypeCode(tempSeqCFinancialInstr[i]
									.getNsSETT().getNsF36B()
									.getNsQuantityTypeCode());
				}
				if (null != tempSeqCFinancialInstr[i].getNsSETT().getNsF36B()
						.getNsQuantity()) {
					financialInstruBean.setQuantity(tempSeqCFinancialInstr[i]
							.getNsSETT().getNsF36B().getNsQuantity());
				}

				financialInstrument[i] = financialInstruBean;
			}
		}
		return financialInstrument;

	}

	public C_DenominationChoice populateCDenominationChoice(
			TMCommon_docType_MT54x_docTypeRef_ns_SeqC_F70a_Type tempSeqCDenomination) {

		C_DenominationChoice denominationBean = null;

		if (null != tempSeqCDenomination) {

			denominationBean = new C_DenominationChoice();

			String[] narrative = tempSeqCDenomination.getNsDENC().getNsF70D()
					.getNsNarrative().getNsLine();

			if (null != narrative && narrative.length >= 1) {

				for (int i = 0; i < narrative.length; i++) {

					if (i == 0 && null != narrative[i]) {

						denominationBean.setNarrative1(narrative[i]);

					} else if (i == 1 && null != narrative[i]) {

						denominationBean.setNarrative2(narrative[i]);

					} else if (i == 2 && null != narrative[i]) {

						denominationBean.setNarrative3(narrative[i]);

					} else if (i == 3 && null != narrative[i]) {

						denominationBean.setNarrative4(narrative[i]);

					} else if (i == 4 && null != narrative[i]) {

						denominationBean.setNarrative5(narrative[i]);

					} else if (i == 5 && null != narrative[i]) {

						denominationBean.setNarrative6(narrative[i]);
					}
				}
			}
		}

		return denominationBean;
	}

	public C_NumberIdentification[] populateCNumberIdentification(
			TMCommon_docType_MT54x_docTypeRef_ns_SeqC_F13a_Type[] tempSeqCNumberIdentification) {

		C_NumberIdentification[] numberIdentification = null;

		int tempSeqCNumber = 5000;

		if (null != tempSeqCNumberIdentification
				&& tempSeqCNumberIdentification.length >= 1) {

			numberIdentification = new C_NumberIdentification[tempSeqCNumberIdentification.length];
			for (int i = 0; i < tempSeqCNumberIdentification.length; i++) {

				C_NumberIdentification numberIdentificationBean = new C_NumberIdentification();

				tempSeqCNumber = tempSeqCNumber + 1;
				numberIdentificationBean.setId(tempSeqCNumber + "");

				if (null != tempSeqCNumberIdentification[i].getNsCERT()
						.getNsF13B().getNsDataSourceScheme()) {

					numberIdentificationBean
							.setDataSourceScheme("DataSourceScheme");
					numberIdentificationBean
							.setDataSourceSchemeValue(tempSeqCNumberIdentification[i]
									.getNsCERT().getNsF13B()
									.getNsDataSourceScheme());
				}

				if (null != tempSeqCNumberIdentification[i].getNsCERT()
						.getNsF13B().getNsNumber()) {

					numberIdentificationBean
							.setNumber(tempSeqCNumberIdentification[i]
									.getNsCERT().getNsF13B().getNsNumber());
				}

				numberIdentification[i] = numberIdentificationBean;
			}
		}
		return numberIdentification;
	}

/*
	public C_Party populateCParty(TMCommon_docType_MT54x_docTypeRef_ns_SeqC_F95a_Type[] tempSeqCParty) {
		
		C_Party partyBean = new C_Party();
		
		if (null !=tempSeqCParty) {
			
				
					if (null != tempSeqCParty.getNsACOW().getNsF95P().getNsIdentifierCode()) {
				
							partyBean.setOptions("Identifier Code");
							partyBean.setValue(tempSeqCParty.getNsACOW().getNsF95P().getNsIdentifierCode());
			}
			
					if (null != tempSeqCParty.getNsACOW().getNsF95R().getNsDataSourceScheme() || 
						null != tempSeqCParty.getNsACOW().getNsF95R().getNsProprietaryCode()) {
				
							partyBean.setOptions("Proprietary Code");
							partyBean.setDataSourceScheme("DataSourceScheme");
							partyBean.setDataSourceSchemeValue(tempSeqCParty.getNsACOW().getNsF95R().getNsDataSourceScheme());
							partyBean.setValue(tempSeqCParty.getNsACOW().getNsF95R().getNsProprietaryCode());
			} 
			//SR2016
					if (null != tempSeqCParty.getNsALTE().getNsF95L().getNsLegalEntityIdentifier()) {
							LogUtils.log("SeqC populate--------------------LEI>>>>>>>>>>>>>>>>>>>"+tempSeqCParty.getNsALTE().getNsF95L().getNsLegalEntityIdentifier());
		
							partyBean.setAlteOption("LegalEntityIdentifier");
							partyBean.setAlteValue(tempSeqCParty.getNsALTE().getNsF95L().getNsLegalEntityIdentifier());
			}
			//SR2016
		}
		
		return partyBean;
	}*/

  //updated for SR2016
  public C_Party populateCParty(TMCommon_docType_MT54x_docTypeRef_ns_SeqC_F95a_Type[] tempSeqCParty) {

		C_Party partyBean = new C_Party();
		//LogUtils.log("Seq C ----C PartyPopulate---------------------Length of tempSeqC Party--"+tempSeqCParty.length);
		
	//	if (null != tempSeqCParty) {

					//				LogUtils.log("SeqC Populate----tempSeqCParty not nulll---going in ---------------------------");
					
		try{
			
			if(tempSeqCParty.length==0){
				//LogUtils.log("SeqC Populate----Party---Length=0---return null");
				return null;
			}
				
			
			
			if(tempSeqCParty.length==1){
					
					if(tempSeqCParty[0]!=null){
						
						//LogUtils.log("seq c populate ---length=1");
						if(tempSeqCParty[0].getNsACOW().getNsF95P().getNsIdentifierCode()!=null || tempSeqCParty[0].getNsACOW().getNsF95R().getNsProprietaryCode()!=null){
							
							if (null != tempSeqCParty[0].getNsACOW().getNsF95P().getNsIdentifierCode() && !Strings.isNullOrEmpty(tempSeqCParty[0].getNsACOW().getNsF95P().getNsIdentifierCode())) {

								//LogUtils.log("SeqC Populate--------------Inside Identifier Code------------length=1-------");
								partyBean.setOptions("Identifier Code");
								//LogUtils.log("SeqC populate Id code value-------------"+ tempSeqCParty[0].getNsACOW().getNsF95P().getNsIdentifierCode());
								partyBean.setValue(tempSeqCParty[0].getNsACOW().getNsF95P().getNsIdentifierCode());
								//LogUtils.log("Seq C-----populate--------partybean value set with id code");
							//	LogUtils.log("Seq C Populate--------Party bean value being set for Idcode---iteration"+i);
						}
							//LogUtils.log("Seq C Populate----outside of ACOW for length=0");
							
							if(null!=tempSeqCParty[0].getNsACOW().getNsF95R().getNsDataSourceScheme() || null!=tempSeqCParty[0].getNsACOW().getNsF95R().getNsProprietaryCode()){
								
								//LogUtils.log("SeqC Populate--------------Inside Prop Code------------length=1-------");
								partyBean.setOptions("Proprietary Code");
								
								
								partyBean.setDataSourceScheme("DataSourceScheme");
								if (null != tempSeqCParty[0].getNsACOW().getNsF95R()
										.getNsDataSourceScheme()){
								partyBean.setDataSourceSchemeValue(tempSeqCParty[0]
										.getNsACOW().getNsF95R()
										.getNsDataSourceScheme());
								}
								//LogUtils.log("SeqC populate Prop code value-------------"+ partyBean.getValue());
								if( null != tempSeqCParty[0].getNsACOW().getNsF95R()
								.getNsProprietaryCode()){
								partyBean.setValue(tempSeqCParty[0].getNsACOW()
										.getNsF95R().getNsProprietaryCode());
								}
							}
					}
						//LogUtils.log("Seq C Populate----outside of ACOW for length=0---PropCode");
					
							if (null != tempSeqCParty[0].getNsALTE().getNsF95L().getNsLegalEntityIdentifier()) 
							{
							//LogUtils.log("SeqC populate----length=0----------------LEI>>>>>>>>>>>>>>>>>>>"
							//		+ tempSeqCParty[0].getNsALTE().getNsF95L()
							//		.getNsLegalEntityIdentifier());

								partyBean.setAlteOption("LegalEntityIdentifier");
								partyBean.setAlteValue(tempSeqCParty[0].getNsALTE()
											.getNsF95L().getNsLegalEntityIdentifier());
								//LogUtils.log("Seq C Populate-----lenght=1---Party bean value being set for Alte---");								
							}
					}
							
					
				
					//LogUtils.log("Seq Cpopuluate---length=1---returning party"+partyBean.getValue());
					return partyBean;
				}
			
			//LogUtils.log("SeqC Populate---between length 1 and 2");
			
			
			if(tempSeqCParty.length==2){
			
				//LogUtils.log("seq C populate----array length=2");
			
				
				for (int i = 0; i < tempSeqCParty.length; i++) {

								if (i == 0 && null != tempSeqCParty[i] && (tempSeqCParty[i].getNsACOW().getNsF95P().getNsIdentifierCode() != null
																|| tempSeqCParty[i].getNsACOW().getNsF95R()
										.getNsProprietaryCode() != null || tempSeqCParty[i]
								.getNsALTE().getNsF95L()
								.getNsLegalEntityIdentifier() != null)) {
//Null check for 1st iteration for ACCW
					
										//logging
									//LogUtils.log("Seq C====populate=====iteration----------------------------i"+i);
										//LogUtils.log("FirstIteration----------------Value of Identifier code,Propriet Code are::"
						//	+ tempSeqCParty[i].getNsACOW().getNsF95P()
							//		.getNsIdentifierCode()
						//	+ "::::"
							//+ tempSeqCParty[i].getNsACOW().getNsF95R()
							//		.getNsProprietaryCode());//logging end

								if (null != tempSeqCParty[i].getNsACOW().getNsF95P().getNsIdentifierCode()) {

										//LogUtils.log("SeqC Populate--------------Inside Identifier Code-------------------");
										partyBean.setOptions("Identifier Code");
									//	LogUtils.log("SeqC populate Id code value-------------"+ partyBean.getOptions());
										partyBean.setValue(tempSeqCParty[i].getNsACOW().getNsF95P().getNsIdentifierCode());
										//LogUtils.log("Seq C Populate--------Party bean value being set for Idcode---iteration"+i);
																											}

								if (null != tempSeqCParty[i].getNsACOW().getNsF95R()
							.getNsDataSourceScheme()
							|| null != tempSeqCParty[i].getNsACOW().getNsF95R()
									.getNsProprietaryCode()) {
									//LogUtils.log("SeqC Populate--------------Inside Prop Code-------------------");
									partyBean.setOptions("Proprietary Code");
									
								
									partyBean.setDataSourceScheme("DataSourceScheme");
									if (null != tempSeqCParty[i].getNsACOW().getNsF95R()
											.getNsDataSourceScheme()){
									partyBean.setDataSourceSchemeValue(tempSeqCParty[i]
											.getNsACOW().getNsF95R()
											.getNsDataSourceScheme());
									}
									
									if( null != tempSeqCParty[i].getNsACOW().getNsF95R()
									.getNsProprietaryCode()){
									partyBean.setValue(tempSeqCParty[i].getNsACOW()
											.getNsF95R().getNsProprietaryCode());
									}
									//LogUtils.log("Seq C Populate--------Party bean value being set for Propcode---iteration"+i);
									
															}
					//LogUtils.log("SeqC Populate--------------partyBean.getOptions()-------------------"
				//			+ partyBean.getOptions());
				//	LogUtils.log("SeqC Populate--------------partyBean.getValue()-------------------"
				//			+ partyBean.getValue());
																	} 
								
								
								else {
					// SR2016
									//LogUtils.log("Second Iteration----For ALTE---Seqcpopulate");
									if (null == tempSeqCParty[i]) {
											//LogUtils.log("Do Nothing--------------------------------------------------------");
									} else {
												if (null != tempSeqCParty[i].getNsALTE().getNsF95L()
															.getNsLegalEntityIdentifier()) 
													{
													//LogUtils.log("SeqC populate--------------------LEI>>>>>>>>>>>>>>>>>>>"
														//	+ tempSeqCParty[i].getNsALTE().getNsF95L()
													//		.getNsLegalEntityIdentifier());

														partyBean.setAlteOption("LegalEntityIdentifier");
														partyBean.setAlteValue(tempSeqCParty[i].getNsALTE()
																	.getNsF95L().getNsLegalEntityIdentifier());
														//LogUtils.log("Seq C Populate--------Party bean value being set for Alte---iteration"+i);								
													}//--if
											}//else inner
					
										}//-else outer
									}// for
			// SR2016
								//		}

							
						}//length=2;
			//LogUtils.log("SeqC Populate--------------returning Party Bean");
			return partyBean;
		}
		
  
  
  catch(Exception e){
	  
	  //LogUtils.log("Seq C Populate ------catch-----");
	//  if(e==null){
	//  LogUtils.log("SeqC Populate----Catch----------returning Party Bean"+partyBean.getValue());
	  return null;
	 
	  }
  }
//  }
//		return partyBean;
 // }	

	public C_Account[] populateCAccount(
			TMCommon_docType_MT54x_docTypeRef_ns_SeqC_F97a_Type[] tempSeqCAccount) {

		C_Account[] tempAccount = null;

		if (null != tempSeqCAccount && tempSeqCAccount.length >= 1) {

			tempAccount = new C_Account[tempSeqCAccount.length];

			for (int i = 0; i < tempSeqCAccount.length; i++) {

				C_Account accountBean = new C_Account();
				if (null != tempSeqCAccount[i].getNsCASH().getNsF97A()
						.getNsAccountNumber()) {

					accountBean.setQualifier("CASH");
					accountBean.setOptions("AccountNumber");
					accountBean.setAccountNumber(tempSeqCAccount[i].getNsCASH()
							.getNsF97A().getNsAccountNumber());

				} else if (null != tempSeqCAccount[i].getNsCASH().getNsF97E()
						.getNsInternationalBankAccountNumber()) {

					accountBean.setQualifier("CASH");
					accountBean.setOptions("InternationalAccountNumber");
					accountBean.setAccountNumber(tempSeqCAccount[i].getNsCASH()
							.getNsF97E().getNsInternationalBankAccountNumber());
				}

				if (null != tempSeqCAccount[i].getNsREGI().getNsF97A()
						.getNsAccountNumber()) {

					accountBean.setQualifier("REGI");
					accountBean.setOptions("AccountNumber");
					accountBean.setAccountNumber(tempSeqCAccount[i].getNsREGI()
							.getNsF97A().getNsAccountNumber());

				}

				if (null != tempSeqCAccount[i].getNsREGI().getNsF97B()
						.getNsDataSourceScheme()
						|| null != tempSeqCAccount[i].getNsREGI().getNsF97B()
								.getNsAccountNumber()
						|| null != tempSeqCAccount[i].getNsREGI().getNsF97B()
								.getNsAccountTypeCode()) {

					accountBean.setQualifier("REGI");
					accountBean.setOptions("AccountTypeCode");
					accountBean.setDataSourceSchemeValue(tempSeqCAccount[i]
							.getNsREGI().getNsF97B().getNsDataSourceScheme());
					accountBean.setDataSourceScheme("DataSourceScheme");
					accountBean.setAccountNumber(tempSeqCAccount[i].getNsREGI()
							.getNsF97B().getNsAccountNumber());
					accountBean.setAccountTypeCode(tempSeqCAccount[i]
							.getNsREGI().getNsF97B().getNsAccountTypeCode());
				}

				if (null != tempSeqCAccount[i].getNsSAFE().getNsF97A()
						.getNsAccountNumber()) {

					accountBean.setQualifier("SAFE");
					accountBean.setOptions("AccountNumber");
					accountBean.setAccountNumber(tempSeqCAccount[i].getNsSAFE()
							.getNsF97A().getNsAccountNumber());
				}

				if (null != tempSeqCAccount[i].getNsSAFE().getNsF97B()
						.getNsDataSourceScheme()
						|| null != tempSeqCAccount[i].getNsSAFE().getNsF97B()
								.getNsAccountTypeCode()
						|| null != tempSeqCAccount[i].getNsSAFE().getNsF97B()
								.getNsAccountNumber()) {

					accountBean.setQualifier("SAFE");
					accountBean.setOptions("AccountTypeCode");
					accountBean.setDataSourceSchemeValue(tempSeqCAccount[i]
							.getNsSAFE().getNsF97B().getNsDataSourceScheme());
					accountBean.setDataSourceScheme("DataSourceScheme");
					accountBean.setAccountNumber(tempSeqCAccount[i].getNsSAFE()
							.getNsF97B().getNsAccountNumber());
					accountBean.setAccountTypeCode(tempSeqCAccount[i]
							.getNsSAFE().getNsF97B().getNsAccountTypeCode());
				}
			}
		}

		return tempAccount;

	}

	public C_Place populateCPlace(
			TMCommon_docType_MT54x_docTypeRef_ns_SeqC_F94a_Type tempSeqCPlace) {

		C_Place placeBean = null;
		if (null != tempSeqCPlace) {

			placeBean = new C_Place();

			if (null != tempSeqCPlace.getNsSAFE().getNsF94B()
					.getNsDataSourceScheme()
					&& tempSeqCPlace.getNsSAFE().getNsF94B()
							.getNsDataSourceScheme().length() >= 1) {

				placeBean.setOptions("Place Code");
				placeBean.setDataSourceScheme("DataSourceScheme");
				placeBean.setDataSourceSchemeValue(tempSeqCPlace.getNsSAFE()
						.getNsF94B().getNsDataSourceScheme());
				placeBean.setNarrative(tempSeqCPlace.getNsSAFE().getNsF94B()
						.getNsNarrative());

			} else if (null != tempSeqCPlace.getNsSAFE().getNsF94B()
					.getNsPlaceCode()) {

				placeBean.setOptions("Place Code");
				placeBean.setNarrative(tempSeqCPlace.getNsSAFE().getNsF94B()
						.getNsNarrative());
				placeBean.setPlaceCode(tempSeqCPlace.getNsSAFE().getNsF94B()
						.getNsPlaceCode());
			}

			if (null != tempSeqCPlace.getNsSAFE().getNsF94C()
					.getNsCountryCode()) {

				placeBean.setOptions("Country Code");
				placeBean.setCountryCode(tempSeqCPlace.getNsSAFE().getNsF94C()
						.getNsCountryCode());

			}

			if (null != tempSeqCPlace.getNsSAFE().getNsF94F()
					.getNsIdentifierCode()
					|| null != tempSeqCPlace.getNsSAFE().getNsF94F()
							.getNsPlaceCode()) {

				placeBean.setOptions("Identifier Code");
				placeBean.setIdentifierCode(tempSeqCPlace.getNsSAFE()
						.getNsF94F().getNsIdentifierCode());
				placeBean.setPlaceCode(tempSeqCPlace.getNsSAFE().getNsF94F()
						.getNsPlaceCode());
			}

		}
		return placeBean;
	}

}
