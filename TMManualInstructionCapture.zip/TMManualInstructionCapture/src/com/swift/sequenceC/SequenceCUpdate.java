package com.swift.sequenceC;

import com.google.common.base.Strings;
import com.webmethods.caf.faces.util.LogUtils;
import com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqC_F13a_Type;
import com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqC_F36a_Type;
import com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqC_F70a_Type;
import com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqC_F94a_Type;
import com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqC_F95a_Type;
import com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqC_F97a_Type;

public class SequenceCUpdate {
	
	public TMCommon_docType_MT54x_docTypeRef_ns_SeqC_F36a_Type[] updateCFinancialInstrument(C_QuantityOfFinancialInstrument[] tempSeqCFinancial) {
		
		TMCommon_docType_MT54x_docTypeRef_ns_SeqC_F36a_Type[] tempSeqC_F36a = null;
		
		if (null !=tempSeqCFinancial && tempSeqCFinancial.length >= 1) {
			
			tempSeqC_F36a = new TMCommon_docType_MT54x_docTypeRef_ns_SeqC_F36a_Type[tempSeqCFinancial.length];
			for (int i = 0 ; i< tempSeqCFinancial.length ; i++) {
				
				TMCommon_docType_MT54x_docTypeRef_ns_SeqC_F36a_Type seqCFinanceBean = new TMCommon_docType_MT54x_docTypeRef_ns_SeqC_F36a_Type();
				
				if (null != tempSeqCFinancial[i].getQuantityTypeCode()) {
					//LogUtils.log("quantity type code+++ update" + tempSeqCFinancial[i].getQuantityTypeCode() + "For loop " + i);
					seqCFinanceBean.getNsSETT().getNsF36B().setNsQuantityTypeCode(tempSeqCFinancial[i].getQuantityTypeCode());
				}
				
				if (null != tempSeqCFinancial[i].getQuantity()) {
					//LogUtils.log("quantity type code+++ update" + tempSeqCFinancial[i].getQuantityTypeCode()+ "For loop " + i);
					seqCFinanceBean.getNsSETT().getNsF36B().setNsQuantity(tempSeqCFinancial[i].getQuantity());
				}
				
				tempSeqC_F36a[i] = seqCFinanceBean;
			}
		}
		return tempSeqC_F36a;
	}


	public TMCommon_docType_MT54x_docTypeRef_ns_SeqC_F70a_Type updateCDenomination(C_DenominationChoice tempSeqCDenomination) {
		
		TMCommon_docType_MT54x_docTypeRef_ns_SeqC_F70a_Type tempSeqC_F70a = null;
		
		if (null != tempSeqCDenomination) {
			
			tempSeqC_F70a = new TMCommon_docType_MT54x_docTypeRef_ns_SeqC_F70a_Type();
			String[] narrative = tempSeqC_F70a.getNsDENC().getNsF70D().getNsNarrative().getNsLine();
			narrative = new String[6];
			
			if (null != tempSeqCDenomination.getNarrative1()) {
				
				narrative[0] = tempSeqCDenomination.getNarrative1();
			}
			
			if (null != tempSeqCDenomination.getNarrative2()) {
				
				narrative[1] = tempSeqCDenomination.getNarrative2();
			}
			
			if (null != tempSeqCDenomination.getNarrative3()) {
				
				narrative[2] = tempSeqCDenomination.getNarrative3();
			}
			
			if (null != tempSeqCDenomination.getNarrative4()) {
				
				narrative[3] = tempSeqCDenomination.getNarrative4();
			}
			
			if (null != tempSeqCDenomination.getNarrative5()) {
				
				narrative[4] = tempSeqCDenomination.getNarrative5();
			}
			
			if (null != tempSeqCDenomination.getNarrative6()) {
				
				narrative[5] = tempSeqCDenomination.getNarrative6();
			}
			
			tempSeqC_F70a.getNsDENC().getNsF70D().getNsNarrative().setNsLine(narrative);
		}
		
		return tempSeqC_F70a;
	}

	public TMCommon_docType_MT54x_docTypeRef_ns_SeqC_F13a_Type[] updateCNumberIdentification(C_NumberIdentification[] tempSeqCNumberIdentification) {
		
		TMCommon_docType_MT54x_docTypeRef_ns_SeqC_F13a_Type[] tempSeqC_F13a = null;

		if (null != tempSeqCNumberIdentification && tempSeqCNumberIdentification.length >=1) {
			
			tempSeqC_F13a = new TMCommon_docType_MT54x_docTypeRef_ns_SeqC_F13a_Type[tempSeqCNumberIdentification.length];
			for (int i = 0; i< tempSeqCNumberIdentification.length ; i++) {
				
				TMCommon_docType_MT54x_docTypeRef_ns_SeqC_F13a_Type tempSeqC_F13Bean = new TMCommon_docType_MT54x_docTypeRef_ns_SeqC_F13a_Type();
				if (null != tempSeqCNumberIdentification[i].getDataSourceSchemeValue()) {
					
					tempSeqC_F13Bean.getNsCERT().getNsF13B().setNsDataSourceScheme(tempSeqCNumberIdentification[i].getDataSourceSchemeValue());
					
				}
				
				if(null != tempSeqCNumberIdentification[i].getNumber()) {
					
					tempSeqC_F13Bean.getNsCERT().getNsF13B().setNsNumber(tempSeqCNumberIdentification[i].getNumber());
				}
				tempSeqC_F13a[i] = tempSeqC_F13Bean;
			}
		}
		return tempSeqC_F13a;
	}

	public TMCommon_docType_MT54x_docTypeRef_ns_SeqC_F95a_Type[] updateCParty(C_Party tempSeqCParty) {
		
		TMCommon_docType_MT54x_docTypeRef_ns_SeqC_F95a_Type[] tempSeqC_F95a = null;
		String flag="false";
		//LogUtils.log("Sequence C Update---------------updateCParty-----tempSeqCParty:ACOW>>>>>>>"+tempSeqCParty.getValue());
		//LogUtils.log("Sequence C Update---------------updateCParty-----tempSeqCParty:ALTE>>>>>>>"+tempSeqCParty.getAlteValue());
		
		String tempAlteValue=tempSeqCParty.getAlteValue();
		String tempValue=tempSeqCParty.getValue();
		
		if(tempAlteValue !=null && !tempAlteValue.isEmpty()){
		//	LogUtils.log("Seq C---Update C Party----flag is true for alte value"+tempAlteValue);
			flag="true";
		}
		
		if(tempValue !=null && !tempValue.isEmpty() && tempValue!=""){
		//	LogUtils.log("Seq C---Update C Party----flag is true for alte value"+tempValue);
			flag="true";
		}
		
		try{
		if (null != tempSeqCParty && flag=="true") {
			
			tempSeqC_F95a = new TMCommon_docType_MT54x_docTypeRef_ns_SeqC_F95a_Type[2];
			
		//	if(null!=tempSeqC_F95a){
				
			for(int i=0;i<tempSeqC_F95a.length;i++){
				
				TMCommon_docType_MT54x_docTypeRef_ns_SeqC_F95a_Type tempbeanStore=new TMCommon_docType_MT54x_docTypeRef_ns_SeqC_F95a_Type();
				
				if(i==0){
					
				//LogUtils.log("iteration Update C party------"+i);
			
					if (null != tempSeqCParty.getOptions() && tempSeqCParty.getOptions().equalsIgnoreCase("Identifier Code")){
				
						if (null != tempSeqCParty.getValue() && ! Strings.isNullOrEmpty(tempSeqCParty.getValue())) {
					
					//		LogUtils.log(i+" iteration Update C party------inside Identifier code"+i);
							tempbeanStore.getNsACOW().getNsF95P().setNsIdentifierCode(tempSeqCParty.getValue());
							//LogUtils.log("Seq C update--------Identifier Code-------------tempbeanStore"+tempbeanStore.getNsACOW().getNsF95P().getNsIdentifierCode());
							tempSeqC_F95a[i]=tempbeanStore;
				//	LogUtils.log("Seq C Update------ID code---tempSeqC_F95a[i]"+i+"::"+tempSeqC_F95a[i].getNsACOW().getNsF95P().getNsIdentifierCode());
							}
							}
			
					if (null != tempSeqCParty.getOptions() && tempSeqCParty.getOptions().equalsIgnoreCase("Proprietary Code")) {
				
							if (null != tempSeqCParty.getDataSourceSchemeValue() && !Strings.isNullOrEmpty(tempSeqCParty.getValue())) {
								//LogUtils.log("Iteration Update C party------inside if--Prop Code"+i);
					
								tempbeanStore.getNsACOW().getNsF95R().setNsDataSourceScheme(tempSeqCParty.getDataSourceSchemeValue());
							//	tempbeanStore.getNsACOW().getNsF95R().setNsProprietaryCode(tempSeqCParty.getValue());
						//LogUtils.log("Seq C update--------Prop Code-------------tempbeanStore"+tempbeanStore.getNsACOW().getNsF95R().getNsDataSourceScheme());
						tempSeqC_F95a[i]=tempbeanStore;
						//LogUtils.log("Seq C Update------ID code---tempSeqC_F95a[i]"+i+"::"+tempSeqC_F95a[i].getNsACOW().getNsF95R().getNsDataSourceScheme());
					
							}
				
								if (null != tempSeqCParty.getValue() && ! Strings.isNullOrEmpty(tempSeqCParty.getValue())) {
									//LogUtils.log("Iteration Update C party------inside if--Prop value----->"+i);
									tempbeanStore.getNsACOW().getNsF95R().setNsProprietaryCode(tempSeqCParty.getValue());
									//LogUtils.log("Seq C update--------Prop Code-------------tempbeanStore"+tempbeanStore.getNsACOW().getNsF95R().getNsProprietaryCode());
									tempSeqC_F95a[i]=tempbeanStore;
									//LogUtils.log("Seq C update------Prop code---tempSeqC_F95a[i]"+i+"::"+tempSeqC_F95a[i].getNsACOW().getNsF95R().getNsProprietaryCode());
									}
			}
				}
				
				else{
				//SR2016/
					//LogUtils.log("iteration Update C party for ALTE------"+i);
					//	if (null != tempSeqCParty.getAlteOption() && tempSeqCParty.getAlteOption().equalsIgnoreCase("LegalEntityIdentifier")){
					
								if (null != tempSeqCParty.getAlteValue() && !Strings.isNullOrEmpty(tempSeqCParty.getAlteValue())) {
										//LogUtils.log("Iteration Update C party------inside if for ALTE---------"+i);
										//LogUtils.log("Seq C Update-----value of LEI--"+tempSeqCParty.getAlteValue());
										tempbeanStore.getNsALTE().getNsF95L().setNsLegalEntityIdentifier(tempSeqCParty.getAlteValue());
										tempSeqC_F95a[i]=tempbeanStore;
										//LogUtils.log("Seq C update------ID code---tempSeqC_F95a[i]"+i+"::"+tempSeqC_F95a[i].getNsALTE().getNsF95L().getNsLegalEntityIdentifier());
						
											}
								}
				//SR2016
			//	tempSeqC_F95a[i] = tempSeqC_F95Bean;
						}
				
						}
			
	//}
		
		
		return tempSeqC_F95a;
		}//}
		/*
		else{
			
			LogUtils.log("Seq C Populate flag value is false");
			
		}
		//return tempSeqC_F95a;
		}
		*/
		catch(Exception e){
			//LogUtils.log("Seq C Update-----------Exception occurred-----------"+e);
			return null;
		}
	
			
			
	
			}

	public TMCommon_docType_MT54x_docTypeRef_ns_SeqC_F97a_Type[] updateCAccount(C_Account[] tempSeqCAccount) {
		
		TMCommon_docType_MT54x_docTypeRef_ns_SeqC_F97a_Type[] tempSeqC_F97a = null;
		if (null != tempSeqCAccount && tempSeqCAccount.length >= 1) {
			
			tempSeqC_F97a = new TMCommon_docType_MT54x_docTypeRef_ns_SeqC_F97a_Type[tempSeqCAccount.length];
			for (int i =0; i< tempSeqCAccount.length ; i++) {
				
				TMCommon_docType_MT54x_docTypeRef_ns_SeqC_F97a_Type tempSeqC_F97Bean = new TMCommon_docType_MT54x_docTypeRef_ns_SeqC_F97a_Type();
				
				if(null != tempSeqCAccount[i].getQualifier() && tempSeqCAccount[i].getQualifier().equalsIgnoreCase("SAFE")) {
					
					if (null != tempSeqCAccount[i].getOptions() && tempSeqCAccount[i].getOptions().equalsIgnoreCase("AccountNumber")) {
						
						if (null != tempSeqCAccount[i].getAccountNumber()) {
							tempSeqC_F97Bean.getNsSAFE().getNsF97A().setNsAccountNumber(tempSeqCAccount[i].getAccountNumber());
						}
					}
					
					if (null != tempSeqCAccount[i].getOptions() && tempSeqCAccount[i].getOptions().equalsIgnoreCase("AccountTypeCode")) {
						
						if (null != tempSeqCAccount[i].getDataSourceSchemeValue() ||
									null != tempSeqCAccount[i].getAccountNumber()  || null != tempSeqCAccount[i].getAccountTypeCode()) {
							
							tempSeqC_F97Bean.getNsSAFE().getNsF97B().setNsDataSourceScheme(tempSeqCAccount[i].getDataSourceSchemeValue());
							tempSeqC_F97Bean.getNsSAFE().getNsF97B().setNsAccountNumber(tempSeqCAccount[i].getAccountNumber());
							tempSeqC_F97Bean.getNsSAFE().getNsF97B().setNsAccountTypeCode(tempSeqCAccount[i].getAccountTypeCode());
						}  
						
					}
				}
				
				if (null != tempSeqCAccount[i].getQualifier() && tempSeqCAccount[i].getQualifier().equalsIgnoreCase("CASH")) {
					
					if (null != tempSeqCAccount[i].getOptions() && tempSeqCAccount[i].getOptions().equalsIgnoreCase("AccountNumber")) {
						
						if (null != tempSeqCAccount[i].getAccountNumber()) {
							
							tempSeqC_F97Bean.getNsCASH().getNsF97A().setNsAccountNumber(tempSeqCAccount[i].getAccountNumber());
						}
					}
					
					if (null != tempSeqCAccount[i].getOptions() && tempSeqCAccount[i].getOptions().equalsIgnoreCase("InternationalAccountNumber")) {
						
						if (null != tempSeqCAccount[i].getAccountNumber()) {
							
							tempSeqC_F97Bean.getNsCASH().getNsF97E().setNsInternationalBankAccountNumber(tempSeqCAccount[i].getAccountNumber());
						}
					}
				}
				
				if (null != tempSeqCAccount[i].getQualifier() && tempSeqCAccount[i].getQualifier().equalsIgnoreCase("REGI")) {
					
					if (null != tempSeqCAccount[i].getOptions() && tempSeqCAccount[i].getOptions().equalsIgnoreCase("AccountNumber")) {
						
						if (null != tempSeqCAccount[i].getAccountNumber()) {
							
							tempSeqC_F97Bean.getNsREGI().getNsF97A().setNsAccountNumber(tempSeqCAccount[i].getAccountNumber());
						}
					}
					
					if (null != tempSeqCAccount[i].getOptions() && tempSeqCAccount[i].getOptions().equalsIgnoreCase("AccountTypeCode")) {
						
						if (null != tempSeqCAccount[i].getDataSourceSchemeValue() ||
									null != tempSeqCAccount[i].getAccountTypeCode() || null != tempSeqCAccount[i].getAccountNumber()) {
							
							tempSeqC_F97Bean.getNsREGI().getNsF97B().setNsDataSourceScheme(tempSeqCAccount[i].getDataSourceSchemeValue());
							tempSeqC_F97Bean.getNsREGI().getNsF97B().setNsAccountTypeCode(tempSeqCAccount[i].getAccountTypeCode());
							tempSeqC_F97Bean.getNsREGI().getNsF97B().setNsAccountNumber(tempSeqCAccount[i].getAccountNumber());
						}
					}
				}
				
				tempSeqC_F97a[i] = tempSeqC_F97Bean;
			}
			
		}
		return tempSeqC_F97a;
	}

	public TMCommon_docType_MT54x_docTypeRef_ns_SeqC_F94a_Type updateCPlace(C_Place tempSeqCPlace) {
	
		TMCommon_docType_MT54x_docTypeRef_ns_SeqC_F94a_Type tempSeqC_F94a = null;
		
		if (null != tempSeqCPlace) {
			
			tempSeqC_F94a = new TMCommon_docType_MT54x_docTypeRef_ns_SeqC_F94a_Type();
			
			if (null != tempSeqCPlace.getOptions() && tempSeqCPlace.getOptions().equalsIgnoreCase("Place Code")) {
				
				if(null != tempSeqCPlace.getNarrative()) {
					
					tempSeqC_F94a.getNsSAFE().getNsF94B().setNsNarrative(tempSeqCPlace.getNarrative());
				}
				
				if (null != tempSeqCPlace.getDataSourceScheme() && tempSeqCPlace.getDataSourceScheme().equalsIgnoreCase("DataSourceScheme")) {
					//LogUtils.log("Inside data source scheme update" + tempSeqCPlace.getDataSourceSchemeValue());
					tempSeqC_F94a.getNsSAFE().getNsF94B().setNsDataSourceScheme(tempSeqCPlace.getDataSourceSchemeValue());
					
				} else if (null != tempSeqCPlace.getPlaceCode()) {
					
					tempSeqC_F94a.getNsSAFE().getNsF94B().setNsPlaceCode(tempSeqCPlace.getPlaceCode());
				}
			}
			
			if (null != tempSeqCPlace.getOptions() && tempSeqCPlace.getOptions().equalsIgnoreCase("Country Code")) {
				
				if (null != tempSeqCPlace.getCountryCode()) {
					
					tempSeqC_F94a.getNsSAFE().getNsF94C().setNsCountryCode(tempSeqCPlace.getCountryCode());
				}
			}
			
			if (null != tempSeqCPlace.getOptions() && tempSeqCPlace.getOptions().equalsIgnoreCase("Identifier Code")) {
				
				if (null != tempSeqCPlace.getPlaceCode()) {
					
					tempSeqC_F94a.getNsSAFE().getNsF94F().setNsPlaceCode(tempSeqCPlace.getPlaceCode());
				}
				
				if (null != tempSeqCPlace.getIdentifierCode()) {
					
					tempSeqC_F94a.getNsSAFE().getNsF94F().setNsIdentifierCode(tempSeqCPlace.getIdentifierCode());
				}
			}
			
		}
		return tempSeqC_F94a;
	}

}
