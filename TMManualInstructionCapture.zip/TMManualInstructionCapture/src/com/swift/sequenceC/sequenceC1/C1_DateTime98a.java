package com.swift.sequenceC.sequenceC1;

public class C1_DateTime98a {

	
	private String options;

	private String date;
	
	private String time;
	
	private String dateTime;
	
	private String decimal;
	
	private String utcIndicator;
	
	public String getOptions() {
		return options;
	}

	public void setOptions(String options) {
		this.options = options;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getDateTime() {
		return dateTime;
	}

	public void setDateTime(String dateTime) {
		this.dateTime = dateTime;
	}

	public String getDecimal() {
		return decimal;
	}

	public void setDecimal(String decimal) {
		this.decimal = decimal;
	}

	public String getUtcIndicator() {
		return utcIndicator;
	}

	public void setUtcIndicator(String utcIndicator) {
		this.utcIndicator = utcIndicator;
	}

	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}
}
