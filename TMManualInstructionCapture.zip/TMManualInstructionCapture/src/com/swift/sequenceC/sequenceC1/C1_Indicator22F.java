package com.swift.sequenceC.sequenceC1;

public class C1_Indicator22F {
	
	private String dataSourceScheme;
	
	private String dataSourceschemeValue;
	
	private String indicator;

	public String getDataSourceScheme() {
		return dataSourceScheme;
	}

	public void setDataSourceScheme(String dataSourceScheme) {
		this.dataSourceScheme = dataSourceScheme;
	}

	public String getIndicator() {
		return indicator;
	}

	public void setIndicator(String indicator) {
		this.indicator = indicator;
	}

	public String getDataSourceschemeValue() {
		return dataSourceschemeValue;
	}

	public void setDataSourceschemeValue(String dataSourceschemeValue) {
		this.dataSourceschemeValue = dataSourceschemeValue;
	}

}
