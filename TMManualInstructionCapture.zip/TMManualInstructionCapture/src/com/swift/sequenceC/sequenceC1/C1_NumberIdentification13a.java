package com.swift.sequenceC.sequenceC1;

public class C1_NumberIdentification13a {
	
	private String options;
	private String dataSourceScheme;
	private String dataSourceSchemeValue;
	private String value;
	
	public String getOptions() {
		return options;
	}
	public void setOptions(String options) {
		this.options = options;
	}
	public String getDataSourceScheme() {
		return dataSourceScheme;
	}
	public void setDataSourceScheme(String dataSourceScheme) {
		this.dataSourceScheme = dataSourceScheme;
	}
	public String getDataSourceSchemeValue() {
		return dataSourceSchemeValue;
	}
	public void setDataSourceSchemeValue(String dataSourceSchemeValue) {
		this.dataSourceSchemeValue = dataSourceSchemeValue;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}

}
