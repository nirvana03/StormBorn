package com.swift.sequenceC.sequenceC1;

public class C1_Price90a {
	
	private String options;
	
	private String percentageTypeCode;
	
	private String amountTypeCode;
	
	private String currencyCode;
	
	private String price;

	private String priceSign;

	public String getOptions() {
		return options;
	}

	public void setOptions(String options) {
		this.options = options;
	}

	public String getPercentageTypeCode() {
		return percentageTypeCode;
	}

	public void setPercentageTypeCode(String percentageTypeCode) {
		this.percentageTypeCode = percentageTypeCode;
	}

	public String getAmountTypeCode() {
		return amountTypeCode;
	}

	public void setAmountTypeCode(String amountTypeCode) {
		this.amountTypeCode = amountTypeCode;
	}

	public String getCurrencyCode() {
		return currencyCode;
	}

	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}

	public String getPrice() {
		return price;
	}

	public void setPrice(String price) {
		this.price = price;
	}

	public java.lang.String getPriceSign()  {
		
		return priceSign;
	}

	public void setPriceSign(java.lang.String priceSign)  {
		this.priceSign = priceSign;
	}

}
