package com.swift.sequenceC.sequenceC1;

import com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqC1_F13a_Type;
import com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqC1_F22a_Type;
import com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqC1_F36a_Type;
import com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqC1_F90a_Type;
import com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqC1_F98a_Type;

public class SequenceC1Populate {
	
	public C1_NumberIdentification13a populateNumberIdentification13a(TMCommon_docType_MT54x_docTypeRef_ns_SeqC1_F13a_Type tempSeqC1_13a) {
		
		C1_NumberIdentification13a numberIdentification13a = null;
		
		if (null != tempSeqC1_13a) {
			
			numberIdentification13a = new C1_NumberIdentification13a();
			
			//Populate for option A
			/* Comment the code for SR2012 version - Start
			 
			 if (null != tempSeqC1_13a.getNsLOTS().getNsF13A().getNsNumberId()) {
					
				numberIdentification13a.setOptions("Number Id");
				numberIdentification13a.setValue(tempSeqC1_13a.getNsLOTS().getNsF13A().getNsNumberId());
			}
			
             Comment the code for SR2012 version - End */			
			//Populate for option B
			
			if(null != tempSeqC1_13a.getNsLOTS().getNsF13B().getNsDataSourceScheme() 
						|| null != tempSeqC1_13a.getNsLOTS().getNsF13B().getNsNumber()) {
				numberIdentification13a.setOptions("Number");
				numberIdentification13a.setDataSourceScheme("DataSourceScheme");
				numberIdentification13a.setDataSourceSchemeValue(tempSeqC1_13a.getNsLOTS().getNsF13B().getNsDataSourceScheme());
				numberIdentification13a.setValue(tempSeqC1_13a.getNsLOTS().getNsF13B().getNsNumber());	
			}
		}
		return numberIdentification13a;
	}
	
	public C1_QuantityOfFinancialInstrument36a populateQuantityOfFinancialInstrument(TMCommon_docType_MT54x_docTypeRef_ns_SeqC1_F36a_Type tempSeqC1_36a) {
		
		C1_QuantityOfFinancialInstrument36a financialInstrument = null;
		
		if (null != tempSeqC1_36a) {
			
			financialInstrument = new C1_QuantityOfFinancialInstrument36a();
		
			if(null != tempSeqC1_36a.getNsLOTS().getNsF36B().getNsQuantity() ||
					null != tempSeqC1_36a.getNsLOTS().getNsF36B().getNsQuantityTypeCode()) {
				
				financialInstrument.setQuantity(tempSeqC1_36a.getNsLOTS().getNsF36B().getNsQuantity());
				financialInstrument.setQuantityTypeCode(tempSeqC1_36a.getNsLOTS().getNsF36B().getNsQuantityTypeCode());
			}
		}
		return financialInstrument;
	}

	public C1_DateTime98a populateDateTime98a(TMCommon_docType_MT54x_docTypeRef_ns_SeqC1_F98a_Type tempSeqC1_98a) {
		
		C1_DateTime98a dateTime = null; 
		
		if (null != tempSeqC1_98a) {
			
			dateTime = new C1_DateTime98a();
			//Option A
			if(null != tempSeqC1_98a.getNsLOTS().getNsF98A().getNsDate()) {
				
				dateTime.setOptions("Date");
				dateTime.setDate(tempSeqC1_98a.getNsLOTS().getNsF98A().getNsDate());
				
			}
			//Option C
			if(null != tempSeqC1_98a.getNsLOTS().getNsF98C().getNsDate() ||
							null != tempSeqC1_98a.getNsLOTS().getNsF98C().getNsTime()) {
				
				dateTime.setOptions("Date Time");
				dateTime.setDateTime(tempSeqC1_98a.getNsLOTS().getNsF98C().getNsDate()+tempSeqC1_98a.getNsLOTS().getNsF98C().getNsTime());
				//dateTime.setTime(tempSeqC1_98a.getNsLOTS().getNsF98C().getNsTime());
				
			}
			//Option E
			if(null != tempSeqC1_98a.getNsLOTS().getNsF98E().getNsDate() || null != tempSeqC1_98a.getNsLOTS().getNsF98E().getNsTime() ||
					null != tempSeqC1_98a.getNsLOTS().getNsF98E().getNsDecimals() || null != tempSeqC1_98a.getNsLOTS().getNsF98E().getNsUTCIndicator()) {
				
				dateTime.setOptions("Date Time Indicator");
				dateTime.setDateTime(tempSeqC1_98a.getNsLOTS().getNsF98E().getNsDate()+tempSeqC1_98a.getNsLOTS().getNsF98E().getNsTime());
				//dateTime.setTime(tempSeqC1_98a.getNsLOTS().getNsF98E().getNsTime());
				dateTime.setDecimal(tempSeqC1_98a.getNsLOTS().getNsF98E().getNsDecimals());
				dateTime.setUtcIndicator(tempSeqC1_98a.getNsLOTS().getNsF98E().getNsUTCIndicator());
			}
		}
		return dateTime;
	}
	
	public C1_Price90a populatePrice90a(TMCommon_docType_MT54x_docTypeRef_ns_SeqC1_F90a_Type tempSeqC1_90a) {
		
		C1_Price90a price = null; 
		if (null != tempSeqC1_90a) {
			price = new C1_Price90a();
			
			if(null != tempSeqC1_90a.getNsLOTS().getNsF90A().getNsPercentageTypeCode() ||
						null != tempSeqC1_90a.getNsLOTS().getNsF90A().getNsPrice()) {
				
				price.setOptions("Percentage Type Code");
				price.setPercentageTypeCode(tempSeqC1_90a.getNsLOTS().getNsF90A().getNsPercentageTypeCode());
				price.setPrice(tempSeqC1_90a.getNsLOTS().getNsF90A().getNsPrice());
				//SR2016
				if (null !=tempSeqC1_90a.getNsLOTS().getNsF90A().getNsSign())
				{
				price.setPriceSign(tempSeqC1_90a.getNsLOTS().getNsF90A().getNsSign());
				}
				//SR2016
			}
			
			if(null != tempSeqC1_90a.getNsLOTS().getNsF90B().getNsAmountTypeCode() ||
							null != tempSeqC1_90a.getNsLOTS().getNsF90B().getNsCurrencyCode() || 
								null != tempSeqC1_90a.getNsLOTS().getNsF90B().getNsPrice()) {
				
				price.setOptions("Amount Type Code");
				price.setAmountTypeCode(tempSeqC1_90a.getNsLOTS().getNsF90B().getNsAmountTypeCode());
				price.setCurrencyCode(tempSeqC1_90a.getNsLOTS().getNsF90B().getNsCurrencyCode());
				price.setPrice(tempSeqC1_90a.getNsLOTS().getNsF90B().getNsPrice());
			}
		}
		return price;
	}

	public C1_Indicator22F populateIndicator22a(TMCommon_docType_MT54x_docTypeRef_ns_SeqC1_F22a_Type tempSeqC1_22a) {
		
		C1_Indicator22F indicator = null;
		if (null != tempSeqC1_22a) {
			indicator = new C1_Indicator22F();
		
			if(null != tempSeqC1_22a.getNsPRIC().getNsF22F().getNsDataSourceScheme() && 
						tempSeqC1_22a.getNsPRIC().getNsF22F().getNsDataSourceScheme().length() > 0) {
				
				indicator.setDataSourceScheme("DataSourceScheme");
				indicator.setDataSourceschemeValue(tempSeqC1_22a.getNsPRIC().getNsF22F().getNsDataSourceScheme());
			} 
				indicator.setIndicator(tempSeqC1_22a.getNsPRIC().getNsF22F().getNsIndicator());
			
		}
		return indicator;
	}
}
