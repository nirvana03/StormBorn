package com.swift.sequenceC.sequenceC1;

import com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqC1_F13a_Type;
import com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqC1_F22a_Type;
import com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqC1_F36a_Type;
import com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqC1_F90a_Type;
import com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqC1_F98a_Type;

public class SequenceC1Update {
	
	public TMCommon_docType_MT54x_docTypeRef_ns_SeqC1_F13a_Type updateNumberIdentification13a(C1_NumberIdentification13a tempNumberIdentification_13a) {
		
		TMCommon_docType_MT54x_docTypeRef_ns_SeqC1_F13a_Type tempSeqC1_F13a = null; 
		
		if (null != tempNumberIdentification_13a) {
			
		/* Comment the code for SR2012 version - Start
		 
			if(null != tempNumberIdentification_13a.getOptions() && tempNumberIdentification_13a.getOptions().equalsIgnoreCase("Number Id")) {
				
				tempSeqC1_F13a	= new TMCommon_docType_MT54x_docTypeRef_ns_SeqC1_F13a_Type();
				tempSeqC1_F13a.getNsLOTS().getNsF13A().setNsNumberId(tempNumberIdentification_13a.getValue());
				
			} else 
			
		Comment the code for SR2012 version - End */
			
			if (null != tempNumberIdentification_13a.getOptions() && tempNumberIdentification_13a.getOptions().equalsIgnoreCase("Number")) {
				
				tempSeqC1_F13a	= new TMCommon_docType_MT54x_docTypeRef_ns_SeqC1_F13a_Type();
				tempSeqC1_F13a.getNsLOTS().getNsF13B().setNsDataSourceScheme(tempNumberIdentification_13a.getDataSourceSchemeValue());
				tempSeqC1_F13a.getNsLOTS().getNsF13B().setNsNumber(tempNumberIdentification_13a.getValue());
			}
		}
		return tempSeqC1_F13a;
	}

	public TMCommon_docType_MT54x_docTypeRef_ns_SeqC1_F36a_Type updateQuantityOfFinancialInstrument(C1_QuantityOfFinancialInstrument36a tempQuantityOfFinancialInstrument_36a) {
		
		TMCommon_docType_MT54x_docTypeRef_ns_SeqC1_F36a_Type tempSeqC1_F36a = null; 
		
		if (null != tempQuantityOfFinancialInstrument_36a) {
			
			if(tempQuantityOfFinancialInstrument_36a.getQuantityTypeCode()!=null && tempQuantityOfFinancialInstrument_36a.getQuantityTypeCode().trim().length()!=0) {
				
				tempSeqC1_F36a = new TMCommon_docType_MT54x_docTypeRef_ns_SeqC1_F36a_Type();
				tempSeqC1_F36a.getNsLOTS().getNsF36B().setNsQuantity(getUpdatedAmtValue(tempQuantityOfFinancialInstrument_36a.getQuantity()));
				tempSeqC1_F36a.getNsLOTS().getNsF36B().setNsQuantityTypeCode(tempQuantityOfFinancialInstrument_36a.getQuantityTypeCode());
			
			}
			
			
		}
		return tempSeqC1_F36a;
	}
	
	public TMCommon_docType_MT54x_docTypeRef_ns_SeqC1_F98a_Type updateDateTime98a(C1_DateTime98a tempDateTime_98a) {
		
		TMCommon_docType_MT54x_docTypeRef_ns_SeqC1_F98a_Type tempSeqC1_F98a = null; 
		
		if (null != tempDateTime_98a) {	
			
			if(null != tempDateTime_98a.getOptions() && tempDateTime_98a.getOptions().equalsIgnoreCase("Date")) {
				
				tempSeqC1_F98a = new TMCommon_docType_MT54x_docTypeRef_ns_SeqC1_F98a_Type();
				tempSeqC1_F98a.getNsLOTS().getNsF98A().setNsDate(tempDateTime_98a.getDate());
			}
			
			if (null != tempDateTime_98a.getOptions() && tempDateTime_98a.getOptions().equalsIgnoreCase("Date Time")) {
				
				if (null != tempDateTime_98a.getDateTime()) {
					
					tempSeqC1_F98a = new TMCommon_docType_MT54x_docTypeRef_ns_SeqC1_F98a_Type();
					tempSeqC1_F98a.getNsLOTS().getNsF98C().setNsDate(tempDateTime_98a.getDateTime().substring(0,8));
					tempSeqC1_F98a.getNsLOTS().getNsF98C().setNsTime(tempDateTime_98a.getDateTime().substring(8,14));
				}
			}
			
			if (null != tempDateTime_98a.getOptions() && tempDateTime_98a.getOptions().equalsIgnoreCase("Date Time Indicator")) {
				
				tempSeqC1_F98a = new TMCommon_docType_MT54x_docTypeRef_ns_SeqC1_F98a_Type();
				if (null != tempDateTime_98a.getDateTime()) {
					tempSeqC1_F98a.getNsLOTS().getNsF98E().setNsDate(tempDateTime_98a.getDateTime().substring(0,8));
					tempSeqC1_F98a.getNsLOTS().getNsF98E().setNsTime(tempDateTime_98a.getDateTime().substring(8,14));
				}
				tempSeqC1_F98a.getNsLOTS().getNsF98E().setNsDecimals(tempDateTime_98a.getDecimal());
				tempSeqC1_F98a.getNsLOTS().getNsF98E().setNsUTCIndicator(tempDateTime_98a.getUtcIndicator());
				
			}
		}
		return tempSeqC1_F98a;
	}
	
	public TMCommon_docType_MT54x_docTypeRef_ns_SeqC1_F90a_Type updatePrice90a(C1_Price90a tempPrice_90a) {
		
		TMCommon_docType_MT54x_docTypeRef_ns_SeqC1_F90a_Type tempSeqC1_F90a = null; 
		
		if (null != tempPrice_90a) {
			
			if(null != tempPrice_90a.getOptions() && tempPrice_90a.getOptions().equalsIgnoreCase("Percentage Type Code")) {
				
				tempSeqC1_F90a = new TMCommon_docType_MT54x_docTypeRef_ns_SeqC1_F90a_Type();
				tempSeqC1_F90a.getNsLOTS().getNsF90A().setNsPercentageTypeCode(tempPrice_90a.getPercentageTypeCode());
				tempSeqC1_F90a.getNsLOTS().getNsF90A().setNsPrice(getUpdatedAmtValue(tempPrice_90a.getPrice()));
				//SR2016
				if(null != tempPrice_90a.getPriceSign() || !(tempPrice_90a.getPriceSign().equals("")) )
				{
					tempSeqC1_F90a.getNsLOTS().getNsF90A().setNsSign(tempPrice_90a.getPriceSign());
				}
				//SR2016
			}
			if (null != tempPrice_90a.getOptions() && tempPrice_90a.getOptions().equalsIgnoreCase("Amount Type Code")) {
				
				tempSeqC1_F90a = new TMCommon_docType_MT54x_docTypeRef_ns_SeqC1_F90a_Type();
				tempSeqC1_F90a.getNsLOTS().getNsF90B().setNsAmountTypeCode(tempPrice_90a.getAmountTypeCode());
				tempSeqC1_F90a.getNsLOTS().getNsF90B().setNsCurrencyCode(tempPrice_90a.getCurrencyCode());
				tempSeqC1_F90a.getNsLOTS().getNsF90B().setNsPrice(getUpdatedAmtValue(tempPrice_90a.getPrice()));
			}
		}
		return tempSeqC1_F90a;
	}
	
	public TMCommon_docType_MT54x_docTypeRef_ns_SeqC1_F22a_Type updateIndicator22a(C1_Indicator22F tempIndicator_22F) {
		
		TMCommon_docType_MT54x_docTypeRef_ns_SeqC1_F22a_Type tempSeqC1_F22a = null; 
			
		if (null != tempIndicator_22F) {
		
			if (null != tempIndicator_22F.getDataSourceScheme() && tempIndicator_22F.getDataSourceScheme().equalsIgnoreCase("DataSourceScheme")) {
				
				tempSeqC1_F22a = new TMCommon_docType_MT54x_docTypeRef_ns_SeqC1_F22a_Type();
				tempSeqC1_F22a.getNsPRIC().getNsF22F().setNsDataSourceScheme(tempIndicator_22F.getDataSourceschemeValue());
				
			}  if (null != tempIndicator_22F.getIndicator() && tempIndicator_22F.getIndicator().length()!=0) {
				
				if (tempSeqC1_F22a==null)
				tempSeqC1_F22a = new TMCommon_docType_MT54x_docTypeRef_ns_SeqC1_F22a_Type();
				tempSeqC1_F22a.getNsPRIC().getNsF22F().setNsIndicator(tempIndicator_22F.getIndicator());
			}
		
		}
		return tempSeqC1_F22a;
	}

	public String getUpdatedAmtValue(String tempQuantityValue)
	{

		if (tempQuantityValue != null && tempQuantityValue.trim().length() != 0) {
			
			  tempQuantityValue = tempQuantityValue.replace(".", ",");
	          int index = tempQuantityValue.lastIndexOf(",");
	          if (index!=-1)
	        	  tempQuantityValue = tempQuantityValue.substring(0,index).replace(",", "").concat(tempQuantityValue.substring(index));
	
	           else
	        	   tempQuantityValue=tempQuantityValue+",";            
	    } 

		return tempQuantityValue;

	}			
	
	
}
