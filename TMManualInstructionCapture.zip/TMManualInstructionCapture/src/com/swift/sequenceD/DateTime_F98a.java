package com.swift.sequenceD;

public class DateTime_F98a {
	
	private String id;
	
	private String qualifier;
	
	private String options;
	
	private String dataSourceScheme;
	
	private String dataSourceSchemeValue;
	
	private String date;
	
	private String dateTime;
	
	private String dateCode;
	
	
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getQualifier() {
		return qualifier;
	}

	public void setQualifier(String qualifier) {
		this.qualifier = qualifier;
	}

	public String getOptions() {
		return options;
	}

	public void setOptions(String options) {
		this.options = options;
	}

	public String getDataSourceScheme() {
		return dataSourceScheme;
	}

	public void setDataSourceScheme(String dataSourceScheme) {
		this.dataSourceScheme = dataSourceScheme;
	}

	public String getDataSourceSchemeValue() {
		return dataSourceSchemeValue;
	}

	public void setDataSourceSchemeValue(String dataSourceSchemeValue) {
		this.dataSourceSchemeValue = dataSourceSchemeValue;
	}

	

	public String getDateCode() {
		return dateCode;
	}

	public void setDateCode(String dateCode) {
		this.dateCode = dateCode;
	}

	public String getDateTime() {
		return dateTime;
	}

	public void setDateTime(String dateTime) {
		this.dateTime = dateTime;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	
	

}
