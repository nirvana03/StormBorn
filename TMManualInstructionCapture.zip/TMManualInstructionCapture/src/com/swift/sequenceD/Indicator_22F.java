package com.swift.sequenceD;

public class Indicator_22F {
	
	private String id;
	
	private String qualifier;
	
	private String dataSourceScheme;
	
	private String dataSourceSchemeValue;
	
	private String indicator;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getQualifier() {
		return qualifier;
	}

	public void setQualifier(String qualifier) {
		this.qualifier = qualifier;
	}

	public String getDataSourceScheme() {
		return dataSourceScheme;
	}

	public void setDataSourceScheme(String dataSourceScheme) {
		this.dataSourceScheme = dataSourceScheme;
	}

	public String getDataSourceSchemeValue() {
		return dataSourceSchemeValue;
	}

	public void setDataSourceSchemeValue(String dataSourceSchemeValue) {
		this.dataSourceSchemeValue = dataSourceSchemeValue;
	}

	public String getIndicator() {
		return indicator;
	}

	public void setIndicator(String indicator) {
		this.indicator = indicator;
	}
	

}
