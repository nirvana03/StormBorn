package com.swift.sequenceD;

public class Narrative_70C {
	
	private String narrative1;
	
	private String narrative2;
	
	private String narrative3;
	
	private String narrative4;

	public String getNarrative1() {
		return narrative1;
	}

	public void setNarrative1(String narrative1) {
		this.narrative1 = narrative1;
	}

	public String getNarrative2() {
		return narrative2;
	}

	public void setNarrative2(String narrative2) {
		this.narrative2 = narrative2;
	}

	public String getNarrative3() {
		return narrative3;
	}

	public void setNarrative3(String narrative3) {
		this.narrative3 = narrative3;
	}

	public String getNarrative4() {
		return narrative4;
	}

	public void setNarrative4(String narrative4) {
		this.narrative4 = narrative4;
	}

	
	

}
