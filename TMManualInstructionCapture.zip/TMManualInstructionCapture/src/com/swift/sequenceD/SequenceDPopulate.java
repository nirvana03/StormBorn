package com.swift.sequenceD;

import com.webmethods.caf.faces.util.LogUtils;
import com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F19a_Type;
import com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F20a_Type;
import com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F22a_Type;
import com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F70a_Type;
import com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F92a_Type;
import com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F98a_Type;
import com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F99a_Type;

public class SequenceDPopulate {

	public Amount_19A[] populateAmount19A(
			TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F19a_Type[] tempSeqD19A) {

		Amount_19A[] tempAmount_19AArr = null;

		int tempAmountId = 500;

		if (null != tempSeqD19A && tempSeqD19A.length > 0) {

			tempAmount_19AArr = new Amount_19A[tempSeqD19A.length];

			for (int i = 0; i < tempSeqD19A.length; i++) {

				Amount_19A tempAmount_19A = new Amount_19A();

				tempAmountId = tempAmountId + 1;
				tempAmount_19A.setId(tempAmountId + "");

				// For FORF
				if (null != tempSeqD19A[i].getNsFORF().getNsF19A().getNsSign()
						|| null != tempSeqD19A[i].getNsFORF().getNsF19A()
								.getNsCurrencyCode()
						|| null != tempSeqD19A[i].getNsFORF().getNsF19A()
								.getNsAmount()) {

					tempAmount_19A.setQualifier("FORF");
					tempAmount_19A.setSign(tempSeqD19A[i].getNsFORF()
							.getNsF19A().getNsSign());
					tempAmount_19A.setCurrencyCode(tempSeqD19A[i].getNsFORF()
							.getNsF19A().getNsCurrencyCode());
					tempAmount_19A.setAmount(tempSeqD19A[i].getNsFORF()
							.getNsF19A().getNsAmount());
				}

				// For TRTE
				if (null != tempSeqD19A[i].getNsTRTE().getNsF19A().getNsSign()
						|| null != tempSeqD19A[i].getNsTRTE().getNsF19A()
								.getNsCurrencyCode()
						|| null != tempSeqD19A[i].getNsTRTE().getNsF19A()
								.getNsAmount()) {

					tempAmount_19A.setQualifier("TRTE");
					tempAmount_19A.setSign(tempSeqD19A[i].getNsTRTE()
							.getNsF19A().getNsSign());
					tempAmount_19A.setCurrencyCode(tempSeqD19A[i].getNsTRTE()
							.getNsF19A().getNsCurrencyCode());
					tempAmount_19A.setAmount(tempSeqD19A[i].getNsTRTE()
							.getNsF19A().getNsAmount());
				}

				// For REPP
				if (null != tempSeqD19A[i].getNsREPP().getNsF19A().getNsSign()
						|| null != tempSeqD19A[i].getNsREPP().getNsF19A()
								.getNsCurrencyCode()
						|| null != tempSeqD19A[i].getNsREPP().getNsF19A()
								.getNsAmount()) {

					tempAmount_19A.setQualifier("REPP");
					tempAmount_19A.setSign(tempSeqD19A[i].getNsREPP()
							.getNsF19A().getNsSign());
					tempAmount_19A.setCurrencyCode(tempSeqD19A[i].getNsREPP()
							.getNsF19A().getNsCurrencyCode());
					tempAmount_19A.setAmount(tempSeqD19A[i].getNsREPP()
							.getNsF19A().getNsAmount());
				}

				// For ACRU
				if (null != tempSeqD19A[i].getNsACRU().getNsF19A().getNsSign()
						|| null != tempSeqD19A[i].getNsACRU().getNsF19A()
								.getNsCurrencyCode()
						|| null != tempSeqD19A[i].getNsACRU().getNsF19A()
								.getNsAmount()) {

					tempAmount_19A.setQualifier("ACRU");
					tempAmount_19A.setSign(tempSeqD19A[i].getNsACRU()
							.getNsF19A().getNsSign());
					tempAmount_19A.setCurrencyCode(tempSeqD19A[i].getNsACRU()
							.getNsF19A().getNsCurrencyCode());
					tempAmount_19A.setAmount(tempSeqD19A[i].getNsACRU()
							.getNsF19A().getNsAmount());
				}

				// For DEAL
				if (null != tempSeqD19A[i].getNsDEAL().getNsF19A().getNsSign()
						|| null != tempSeqD19A[i].getNsDEAL().getNsF19A()
								.getNsCurrencyCode()
						|| null != tempSeqD19A[i].getNsDEAL().getNsF19A()
								.getNsAmount()) {

					tempAmount_19A.setQualifier("DEAL");
					tempAmount_19A.setSign(tempSeqD19A[i].getNsDEAL()
							.getNsF19A().getNsSign());
					tempAmount_19A.setCurrencyCode(tempSeqD19A[i].getNsDEAL()
							.getNsF19A().getNsCurrencyCode());
					tempAmount_19A.setAmount(tempSeqD19A[i].getNsDEAL()
							.getNsF19A().getNsAmount());
				}

				// For TAPC
				if (null != tempSeqD19A[i].getNsTAPC().getNsF19A().getNsSign()
						|| null != tempSeqD19A[i].getNsTAPC().getNsF19A()
								.getNsCurrencyCode()
						|| null != tempSeqD19A[i].getNsTAPC().getNsF19A()
								.getNsAmount()) {

					tempAmount_19A.setQualifier("TAPC");
					tempAmount_19A.setSign(tempSeqD19A[i].getNsTAPC()
							.getNsF19A().getNsSign());
					tempAmount_19A.setCurrencyCode(tempSeqD19A[i].getNsTAPC()
							.getNsF19A().getNsCurrencyCode());
					tempAmount_19A.setAmount(tempSeqD19A[i].getNsTAPC()
							.getNsF19A().getNsAmount());
				}

				tempAmount_19AArr[i] = tempAmount_19A;

			}

		}

		return tempAmount_19AArr;

	}

	public DateTime_F98a[] populateDateTimeF98a(
			TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F98a_Type[] tempSeqD98a) {

		DateTime_F98a[] dateTimeF98Arr = null;

		int tempdateTimeId = 600;

		if (null != tempSeqD98a && tempSeqD98a.length > 0) {

			dateTimeF98Arr = new DateTime_F98a[tempSeqD98a.length];

			for (int i = 0; i < tempSeqD98a.length; i++) {

				DateTime_F98a tempDateTime98a = new DateTime_F98a();

				tempdateTimeId = tempdateTimeId + 1;
				tempDateTime98a.setId(tempdateTimeId + "");
				// FOR TERM
				if (null != tempSeqD98a[i].getNsTERM().getNsF98A().getNsDate()) {

					tempDateTime98a.setQualifier("TERM");
					tempDateTime98a.setOptions("Date");
					tempDateTime98a.setDate(tempSeqD98a[i].getNsTERM()
							.getNsF98A().getNsDate());

				} else if (null != tempSeqD98a[i].getNsTERM().getNsF98B()
						.getNsDateCode()) {

					tempDateTime98a.setQualifier("TERM");
					tempDateTime98a.setOptions("Date Code");
					tempDateTime98a.setDateCode(tempSeqD98a[i].getNsTERM()
							.getNsF98B().getNsDateCode());
					if (null != tempSeqD98a[i].getNsTERM().getNsF98B()
							.getNsDataSourceScheme()) {

						tempDateTime98a.setDataSourceScheme("DataSourceScheme");
						tempDateTime98a.setDataSourceSchemeValue(tempSeqD98a[i]
								.getNsTERM().getNsF98B()
								.getNsDataSourceScheme());

					}

				} else if (null != tempSeqD98a[i].getNsTERM().getNsF98C()
						.getNsDate()
						&& null != tempSeqD98a[i].getNsTERM().getNsF98C()
								.getNsTime()) {

					tempDateTime98a.setQualifier("TERM");
					tempDateTime98a.setOptions("Date Time");
					tempDateTime98a.setDateTime(tempSeqD98a[i].getNsTERM()
							.getNsF98C().getNsDate()
							+ tempSeqD98a[i].getNsTERM().getNsF98C()
									.getNsTime());
				}

				// For RERA
				if (null != tempSeqD98a[i].getNsRERA().getNsF98A().getNsDate()) {

					tempDateTime98a.setQualifier("RERA");
					tempDateTime98a.setOptions("Date");
					tempDateTime98a.setDate(tempSeqD98a[i].getNsRERA()
							.getNsF98A().getNsDate());

				} else if (null != tempSeqD98a[i].getNsRERA().getNsF98C()
						.getNsDate()
						&& null != tempSeqD98a[i].getNsRERA().getNsF98C()
								.getNsTime()) {

					tempDateTime98a.setQualifier("RERA");
					tempDateTime98a.setOptions("Date Time");
					tempDateTime98a.setDateTime(tempSeqD98a[i].getNsRERA()
							.getNsF98C().getNsDate()
							+ tempSeqD98a[i].getNsRERA().getNsF98C()
									.getNsTime());
				}

				dateTimeF98Arr[i] = tempDateTime98a;
			}
		}

		return dateTimeF98Arr;
	}

	public Indicator_22F[] populateIndicator22F(
			TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F22a_Type[] tempSeqD22F) {

		Indicator_22F[] indicator22FArr = null;

		int tempindicatorId = 700;

		if (null != tempSeqD22F && tempSeqD22F.length > 0) {

			indicator22FArr = new Indicator_22F[tempSeqD22F.length];

			for (int i = 0; i < tempSeqD22F.length; i++) {

				Indicator_22F tempIndicatorBean = new Indicator_22F();
				tempindicatorId = tempindicatorId + 1;
				tempIndicatorBean.setId(tempindicatorId + "");

				// For RERT
				if (null != tempSeqD22F[i].getNsRERT().getNsF22F()
						.getNsDataSourceScheme()) {

					tempIndicatorBean.setQualifier("RERT");
					tempIndicatorBean.setDataSourceScheme("DataSourceScheme");
					tempIndicatorBean.setDataSourceSchemeValue(tempSeqD22F[i]
							.getNsRERT().getNsF22F().getNsDataSourceScheme());

				}
				if (null != tempSeqD22F[i].getNsRERT().getNsF22F()
						.getNsIndicator()) {

					tempIndicatorBean.setQualifier("RERT");
					tempIndicatorBean.setIndicator(tempSeqD22F[i].getNsRERT()
							.getNsF22F().getNsIndicator());
				}

				// For MICO
				if (null != tempSeqD22F[i].getNsMICO().getNsF22F()
						.getNsDataSourceScheme()) {

					tempIndicatorBean.setQualifier("MICO");
					tempIndicatorBean.setDataSourceScheme("DataSourceScheme");
					tempIndicatorBean.setDataSourceSchemeValue(tempSeqD22F[i]
							.getNsMICO().getNsF22F().getNsDataSourceScheme());

				}
				if (null != tempSeqD22F[i].getNsMICO().getNsF22F()
						.getNsIndicator()) {

					tempIndicatorBean.setQualifier("MICO");
					tempIndicatorBean.setIndicator(tempSeqD22F[i].getNsMICO()
							.getNsF22F().getNsIndicator());
				}

				// For REVA
				if (null != tempSeqD22F[i].getNsREVA().getNsF22F()
						.getNsDataSourceScheme()) {

					tempIndicatorBean.setQualifier("REVA");
					tempIndicatorBean.setDataSourceScheme("DataSourceScheme");
					tempIndicatorBean.setDataSourceSchemeValue(tempSeqD22F[i]
							.getNsREVA().getNsF22F().getNsDataSourceScheme());

				}
				if (null != tempSeqD22F[i].getNsREVA().getNsF22F()
						.getNsIndicator()) {

					tempIndicatorBean.setQualifier("REVA");
					tempIndicatorBean.setIndicator(tempSeqD22F[i].getNsREVA()
							.getNsF22F().getNsIndicator());
				}

				// For LEGA
				if (null != tempSeqD22F[i].getNsLEGA().getNsF22F()
						.getNsDataSourceScheme()) {

					tempIndicatorBean.setQualifier("LEGA");
					tempIndicatorBean.setDataSourceScheme("DataSourceScheme");
					tempIndicatorBean.setDataSourceSchemeValue(tempSeqD22F[i]
							.getNsLEGA().getNsF22F().getNsDataSourceScheme());

				}
				if (null != tempSeqD22F[i].getNsLEGA().getNsF22F()
						.getNsIndicator()) {

					tempIndicatorBean.setQualifier("LEGA");
					tempIndicatorBean.setIndicator(tempSeqD22F[i].getNsLEGA()
							.getNsF22F().getNsIndicator());
				}

				// For OMAT
				if (null != tempSeqD22F[i].getNsOMAT().getNsF22F()
						.getNsDataSourceScheme()) {

					tempIndicatorBean.setQualifier("OMAT");
					tempIndicatorBean.setDataSourceScheme("DataSourceScheme");
					tempIndicatorBean.setDataSourceSchemeValue(tempSeqD22F[i]
							.getNsOMAT().getNsF22F().getNsDataSourceScheme());

				}
				if (null != tempSeqD22F[i].getNsOMAT().getNsF22F()
						.getNsIndicator()) {

					tempIndicatorBean.setQualifier("OMAT");
					tempIndicatorBean.setIndicator(tempSeqD22F[i].getNsOMAT()
							.getNsF22F().getNsIndicator());
				}

				// For INTR
				if (null != tempSeqD22F[i].getNsINTR().getNsF22F()
						.getNsDataSourceScheme()) {

					tempIndicatorBean.setQualifier("INTR");
					tempIndicatorBean.setDataSourceScheme("DataSourceScheme");
					tempIndicatorBean.setDataSourceSchemeValue(tempSeqD22F[i]
							.getNsINTR().getNsF22F().getNsDataSourceScheme());

				}
				if (null != tempSeqD22F[i].getNsINTR().getNsF22F()
						.getNsIndicator()) {

					tempIndicatorBean.setQualifier("INTR");
					tempIndicatorBean.setIndicator(tempSeqD22F[i].getNsINTR()
							.getNsF22F().getNsIndicator());
				}

				indicator22FArr[i] = tempIndicatorBean;
			}
		}
		return indicator22FArr;
	}

	public NumberCount_99B[] populateNumberCount98B(
			TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F99a_Type[] tempSeqD98b) {

		NumberCount_99B[] tempNumberCount98BArr = null;

		int tempNumberId = 800;

		if (null != tempSeqD98b && tempSeqD98b.length > 0) {

			tempNumberCount98BArr = new NumberCount_99B[tempSeqD98b.length];

			for (int i = 0; i < tempSeqD98b.length; i++) {

				NumberCount_99B tempNumberCountBean = new NumberCount_99B();

				tempNumberId = tempNumberId + 1;
				tempNumberCountBean.setId(tempNumberId + "");

				// For CADE
				if (null != tempSeqD98b[i].getNsCADE().getNsF99B()
						.getNsNumber()) {

					LogUtils.log("CADE number =="
							+ tempSeqD98b[i].getNsCADE().getNsF99B()
									.getNsNumber());
					tempNumberCountBean.setQualifier("CADE");
					tempNumberCountBean.setNumber(tempSeqD98b[i].getNsCADE()
							.getNsF99B().getNsNumber());
				}

				// For TOCO
				if (null != tempSeqD98b[i].getNsTOCO().getNsF99B()
						.getNsNumber()) {

					LogUtils.log("TOCO number =="
							+ tempSeqD98b[i].getNsTOCO().getNsF99B()
									.getNsNumber());

					tempNumberCountBean.setQualifier("TOCO");
					tempNumberCountBean.setNumber(tempSeqD98b[i].getNsTOCO()
							.getNsF99B().getNsNumber());
				}

				tempNumberCount98BArr[i] = tempNumberCountBean;
			}
		}

		return tempNumberCount98BArr;
	}

	public Rate_92A[] populateRate92A(
			TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F92a_Type[] tempSeqD92a) {

		Rate_92A[] tempRate92aArr = null;

		int tempRateId = 900;

		if (null != tempSeqD92a && tempSeqD92a.length > 0) {

			tempRate92aArr = new Rate_92A[tempSeqD92a.length];

			for (int i = 0; i < tempSeqD92a.length; i++) {

				Rate_92A tempRate92aBean = new Rate_92A();

				tempRateId = tempRateId + 1;
				tempRate92aBean.setId(tempRateId + "");

				// For VASU
				if (null != tempSeqD92a[i].getNsVASU().getNsF92C()
						.getNsDataSourceScheme()
						|| null != tempSeqD92a[i].getNsVASU().getNsF92C()
								.getNsRateName()) {

					tempRate92aBean.setQualifier("VASU");
					tempRate92aBean.setOptions("Rate Name");
					tempRate92aBean.setDataSourceSchemeValue(tempSeqD92a[i]
							.getNsVASU().getNsF92C().getNsDataSourceScheme());
					tempRate92aBean.setRateName(tempSeqD92a[i].getNsVASU()
							.getNsF92C().getNsRateName());
				}

				// For REPO
				if (null != tempSeqD92a[i].getNsREPO().getNsF92A().getNsRate()
						|| null != tempSeqD92a[i].getNsREPO().getNsF92A()
								.getNsSign()) {

					tempRate92aBean.setQualifier("REPO");
					tempRate92aBean.setOptions("Sign Rate");
					tempRate92aBean.setRate(tempSeqD92a[i].getNsREPO()
							.getNsF92A().getNsRate());
					tempRate92aBean.setSign(tempSeqD92a[i].getNsREPO()
							.getNsF92A().getNsSign());
				}

				// For RSPR
				if (null != tempSeqD92a[i].getNsRSPR().getNsF92A().getNsRate()
						|| null != tempSeqD92a[i].getNsRSPR().getNsF92A()
								.getNsSign()) {

					tempRate92aBean.setQualifier("RSPR");
					tempRate92aBean.setOptions("Sign Rate");
					tempRate92aBean.setRate(tempSeqD92a[i].getNsRSPR()
							.getNsF92A().getNsRate());
					tempRate92aBean.setSign(tempSeqD92a[i].getNsRSPR()
							.getNsF92A().getNsSign());
				}

				// For PRIC
				if (null != tempSeqD92a[i].getNsPRIC().getNsF92A().getNsRate()
						|| null != tempSeqD92a[i].getNsPRIC().getNsF92A()
								.getNsSign()) {

					tempRate92aBean.setQualifier("PRIC");
					tempRate92aBean.setOptions("Sign Rate");
					tempRate92aBean.setRate(tempSeqD92a[i].getNsPRIC()
							.getNsF92A().getNsRate());
					tempRate92aBean.setSign(tempSeqD92a[i].getNsPRIC()
							.getNsF92A().getNsSign());

				} else if (null != tempSeqD92a[i].getNsPRIC().getNsF92C()
						.getNsDataSourceScheme()
						|| null != tempSeqD92a[i].getNsPRIC().getNsF92C()
								.getNsRateName()) {

					tempRate92aBean.setQualifier("PRIC");
					tempRate92aBean.setOptions("Rate Name");
					tempRate92aBean.setDataSourceSchemeValue(tempSeqD92a[i]
							.getNsPRIC().getNsF92C().getNsDataSourceScheme());
					tempRate92aBean.setRateName(tempSeqD92a[i].getNsPRIC()
							.getNsF92C().getNsRateName());
				}

				// For SLMG
				if (null != tempSeqD92a[i].getNsSLMG().getNsF92A().getNsRate()
						|| null != tempSeqD92a[i].getNsSLMG().getNsF92A()
								.getNsSign()) {

					tempRate92aBean.setQualifier("SLMG");
					tempRate92aBean.setOptions("Sign Rate");
					tempRate92aBean.setRate(tempSeqD92a[i].getNsSLMG()
							.getNsF92A().getNsRate());
					tempRate92aBean.setSign(tempSeqD92a[i].getNsSLMG()
							.getNsF92A().getNsSign());
				}

				// For SHAI
				if (null != tempSeqD92a[i].getNsSHAI().getNsF92A().getNsRate()
						|| null != tempSeqD92a[i].getNsSHAI().getNsF92A()
								.getNsSign()) {

					tempRate92aBean.setQualifier("SHAI");
					tempRate92aBean.setOptions("Sign Rate");
					tempRate92aBean.setRate(tempSeqD92a[i].getNsSHAI()
							.getNsF92A().getNsRate());
					tempRate92aBean.setSign(tempSeqD92a[i].getNsSHAI()
							.getNsF92A().getNsSign());
				}

				tempRate92aArr[i] = tempRate92aBean;
			}
		}

		return tempRate92aArr;
	}

	public Reference_20C[] populateReference20C(
			TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F20a_Type[] tempSeqD20c) {

		Reference_20C[] tempReference20CArr = null;

		int tempRefrenceId = 100;

		if (null != tempSeqD20c && tempSeqD20c.length > 0) {

			tempReference20CArr = new Reference_20C[tempSeqD20c.length];

			for (int i = 0; i < tempSeqD20c.length; i++) {

				Reference_20C tempReference20cBean = new Reference_20C();

				tempRefrenceId = tempRefrenceId + 1;
				tempReference20cBean.setId(tempRefrenceId + "");

				// For SECO
				if (null != tempSeqD20c[i].getNsSECO().getNsF20C()
						.getNsReference()) {

					tempReference20cBean.setQualifier("SECO");
					tempReference20cBean.setReference(tempSeqD20c[i]
							.getNsSECO().getNsF20C().getNsReference());
				}

				// For REPO
				if (null != tempSeqD20c[i].getNsREPO().getNsF20C()
						.getNsReference()) {

					tempReference20cBean.setQualifier("REPO");
					tempReference20cBean.setReference(tempSeqD20c[i]
							.getNsREPO().getNsF20C().getNsReference());
				}

				tempReference20CArr[i] = tempReference20cBean;
			}
		}

		return tempReference20CArr;
	}

	public Narrative_70C populateNarrative70C(
			TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F70a_Type tempSeqD70C) {

		Narrative_70C tempNarrative70CBean = null;

		if (null != tempSeqD70C.getNsSECO().getNsF70C().getNsNarrative()
				.getNsLine()
				&& tempSeqD70C.getNsSECO().getNsF70C().getNsNarrative()
						.getNsLine().length > 0) {

			tempNarrative70CBean = new Narrative_70C();

			for (int i = 0; i < tempSeqD70C.getNsSECO().getNsF70C()
					.getNsNarrative().getNsLine().length; i++) {
				if (i == 0) {
					tempNarrative70CBean.setNarrative1(tempSeqD70C.getNsSECO()
							.getNsF70C().getNsNarrative().getNsLine()[i]);
				} else if (i == 1) {
					tempNarrative70CBean.setNarrative2(tempSeqD70C.getNsSECO()
							.getNsF70C().getNsNarrative().getNsLine()[i]);
				} else if (i == 2) {
					tempNarrative70CBean.setNarrative3(tempSeqD70C.getNsSECO()
							.getNsF70C().getNsNarrative().getNsLine()[i]);
				} else if (i == 3) {
					tempNarrative70CBean.setNarrative4(tempSeqD70C.getNsSECO()
							.getNsF70C().getNsNarrative().getNsLine()[i]);
				}
			}
		}
		return tempNarrative70CBean;
	}
}
