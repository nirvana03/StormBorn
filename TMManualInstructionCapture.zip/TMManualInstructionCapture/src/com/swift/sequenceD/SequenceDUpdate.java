package com.swift.sequenceD;

import java.util.ArrayList;

import com.webmethods.caf.faces.util.LogUtils;
import com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F19a_Type;
import com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F20a_Type;
import com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F22a_Type;
import com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F70a_Type;
import com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F92a_Type;
import com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F98a_Type;
import com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F99a_Type;

public class SequenceDUpdate {

	public TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F19a_Type[] updateAmount19A(
			Amount_19A[] tempAmount_19A) {

		TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F19a_Type[] tempSeqD19AArr = null;

		if (null != tempAmount_19A && tempAmount_19A.length > 0) {

			tempSeqD19AArr = new TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F19a_Type[tempAmount_19A.length];

			for (int i = 0; i < tempAmount_19A.length; i++) {

				TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F19a_Type tempSeqD19A = new TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F19a_Type();

				// For FORF
				if (null != tempAmount_19A[i].getQualifier()
						&& "FORF".equalsIgnoreCase(tempAmount_19A[i]
								.getQualifier())) {

					tempSeqD19A.getNsFORF().getNsF19A().setNsSign(
							tempAmount_19A[i].getSign());
					tempSeqD19A.getNsFORF().getNsF19A().setNsCurrencyCode(
							tempAmount_19A[i].getCurrencyCode());
					tempSeqD19A.getNsFORF().getNsF19A().setNsAmount(
							getUpdatedAmtValue(tempAmount_19A[i].getAmount()));
				}

				// For TRTE
				if (null != tempAmount_19A[i].getQualifier()
						&& "TRTE".equalsIgnoreCase(tempAmount_19A[i]
								.getQualifier())) {

					tempSeqD19A.getNsTRTE().getNsF19A().setNsSign(
							tempAmount_19A[i].getSign());
					tempSeqD19A.getNsTRTE().getNsF19A().setNsCurrencyCode(
							tempAmount_19A[i].getCurrencyCode());
					tempSeqD19A.getNsTRTE().getNsF19A().setNsAmount(
							getUpdatedAmtValue(tempAmount_19A[i].getAmount()));
				}

				// For REPP
				if (null != tempAmount_19A[i].getQualifier()
						&& "REPP".equalsIgnoreCase(tempAmount_19A[i]
								.getQualifier())) {

					tempSeqD19A.getNsREPP().getNsF19A().setNsSign(
							tempAmount_19A[i].getSign());
					tempSeqD19A.getNsREPP().getNsF19A().setNsCurrencyCode(
							tempAmount_19A[i].getCurrencyCode());
					tempSeqD19A.getNsREPP().getNsF19A().setNsAmount(
							getUpdatedAmtValue(tempAmount_19A[i].getAmount()));
				}

				// For ACRU
				if (null != tempAmount_19A[i].getQualifier()
						&& "ACRU".equalsIgnoreCase(tempAmount_19A[i]
								.getQualifier())) {

					tempSeqD19A.getNsACRU().getNsF19A().setNsSign(
							tempAmount_19A[i].getSign());
					tempSeqD19A.getNsACRU().getNsF19A().setNsCurrencyCode(
							tempAmount_19A[i].getCurrencyCode());
					tempSeqD19A.getNsACRU().getNsF19A().setNsAmount(
							getUpdatedAmtValue(tempAmount_19A[i].getAmount()));
				}

				// For DEAL
				if (null != tempAmount_19A[i].getQualifier()
						&& "DEAL".equalsIgnoreCase(tempAmount_19A[i]
								.getQualifier())) {

					tempSeqD19A.getNsDEAL().getNsF19A().setNsSign(
							tempAmount_19A[i].getSign());
					tempSeqD19A.getNsDEAL().getNsF19A().setNsCurrencyCode(
							tempAmount_19A[i].getCurrencyCode());
					tempSeqD19A.getNsDEAL().getNsF19A().setNsAmount(
							getUpdatedAmtValue(tempAmount_19A[i].getAmount()));
				}

				// For TAPC
				if (null != tempAmount_19A[i].getQualifier()
						&& "TAPC".equalsIgnoreCase(tempAmount_19A[i]
								.getQualifier())) {

					tempSeqD19A.getNsTAPC().getNsF19A().setNsSign(
							tempAmount_19A[i].getSign());
					tempSeqD19A.getNsTAPC().getNsF19A().setNsCurrencyCode(
							tempAmount_19A[i].getCurrencyCode());
					tempSeqD19A.getNsTAPC().getNsF19A().setNsAmount(
							getUpdatedAmtValue(tempAmount_19A[i].getAmount()));
				}

				tempSeqD19AArr[i] = tempSeqD19A;

			}

		}

		return tempSeqD19AArr;
	}

	public TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F98a_Type[] updateDateTimeF98a(
			DateTime_F98a[] dateTimeF98Arr) {

		TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F98a_Type[] tempSeqD98aArr = null;

		if (null != dateTimeF98Arr && dateTimeF98Arr.length > 0) {

			tempSeqD98aArr = new TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F98a_Type[dateTimeF98Arr.length];

			for (int i = 0; i < dateTimeF98Arr.length; i++) {

				TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F98a_Type tempSeqD98a = new TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F98a_Type();

				// FOR TERM
				if (null != dateTimeF98Arr[i].getQualifier()
						&& "TERM".equalsIgnoreCase(dateTimeF98Arr[i]
								.getQualifier())) {

					if (null != dateTimeF98Arr[i].getOptions()
							&& "Date".equalsIgnoreCase(dateTimeF98Arr[i]
									.getOptions())) {

						tempSeqD98a.getNsTERM().getNsF98A().setNsDate(
								dateTimeF98Arr[i].getDate());

					} else if (null != dateTimeF98Arr[i].getOptions()
							&& "Date Code".equalsIgnoreCase(dateTimeF98Arr[i]
									.getOptions())) {

						if (null != dateTimeF98Arr[i].getDataSourceScheme()
								&& "DataSourceScheme"
										.equalsIgnoreCase(dateTimeF98Arr[i]
												.getDataSourceScheme())) {

							tempSeqD98a
									.getNsTERM()
									.getNsF98B()
									.setNsDataSourceScheme(
											dateTimeF98Arr[i]
													.getDataSourceSchemeValue());

						}
						if (null != dateTimeF98Arr[i].getDateCode()) {

							tempSeqD98a.getNsTERM().getNsF98B().setNsDateCode(
									dateTimeF98Arr[i].getDateCode());
						}
					} else if (null != dateTimeF98Arr[i].getOptions()
							&& "Date Time".equalsIgnoreCase(dateTimeF98Arr[i]
									.getOptions())) {

						if (null != dateTimeF98Arr[i].getDateTime()) {

							tempSeqD98a.getNsTERM().getNsF98C().setNsDate(
									dateTimeF98Arr[i].getDateTime().substring(
											0, 8));
							tempSeqD98a.getNsTERM().getNsF98C().setNsTime(
									dateTimeF98Arr[i].getDateTime().substring(
											8, 14));
						}
					}
				}

				// For RERA
				if (null != dateTimeF98Arr[i].getQualifier()
						&& "RERA".equalsIgnoreCase(dateTimeF98Arr[i]
								.getQualifier())) {

					if (null != dateTimeF98Arr[i].getOptions()
							&& "Date".equalsIgnoreCase(dateTimeF98Arr[i]
									.getOptions())) {

						tempSeqD98a.getNsRERA().getNsF98A().setNsDate(
								dateTimeF98Arr[i].getDate());

					} else if (null != dateTimeF98Arr[i].getOptions()
							&& "Date Time".equalsIgnoreCase(dateTimeF98Arr[i]
									.getOptions())) {

						if (null != dateTimeF98Arr[i].getDateTime()) {

							tempSeqD98a.getNsRERA().getNsF98C().setNsDate(
									dateTimeF98Arr[i].getDateTime().substring(
											0, 8));
							tempSeqD98a.getNsRERA().getNsF98C().setNsTime(
									dateTimeF98Arr[i].getDateTime().substring(
											8, 14));
						}
					}
				}

				tempSeqD98aArr[i] = tempSeqD98a;
			}
		}

		return tempSeqD98aArr;
	}

	public TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F22a_Type[] updateIndicator22F(
			Indicator_22F[] indicator22FArr) {

		TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F22a_Type[] tempSeqD22FArr = null;

		if (null != indicator22FArr && indicator22FArr.length > 0) {

			tempSeqD22FArr = new TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F22a_Type[indicator22FArr.length];

			for (int i = 0; i < indicator22FArr.length; i++) {

				TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F22a_Type tempSeqD22aBean = new TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F22a_Type();

				LogUtils.log("indicator qualifier =="
						+ indicator22FArr[i].getQualifier());
				LogUtils.log("indicator Indicator"
						+ indicator22FArr[i].getIndicator());

				// For RERT
				if (null != indicator22FArr[i].getQualifier()
						&& "RERT".equalsIgnoreCase(indicator22FArr[i]
								.getQualifier())) {
					if (null != indicator22FArr[i].getDataSourceScheme()
							&& "DataSourceScheme"
									.equalsIgnoreCase(indicator22FArr[i]
											.getDataSourceScheme())) {

						tempSeqD22aBean.getNsRERT().getNsF22F()
								.setNsDataSourceScheme(
										indicator22FArr[i]
												.getDataSourceSchemeValue());

					}

					tempSeqD22aBean.getNsRERT().getNsF22F().setNsIndicator(
							indicator22FArr[i].getIndicator());

				}

				// For MICO
				if (null != indicator22FArr[i].getQualifier()
						&& "MICO".equalsIgnoreCase(indicator22FArr[i]
								.getQualifier())) {
					if (null != indicator22FArr[i].getDataSourceScheme()
							&& "DataSourceScheme"
									.equalsIgnoreCase(indicator22FArr[i]
											.getDataSourceScheme())) {

						tempSeqD22aBean.getNsMICO().getNsF22F()
								.setNsDataSourceScheme(
										indicator22FArr[i]
												.getDataSourceSchemeValue());

					}

					tempSeqD22aBean.getNsMICO().getNsF22F().setNsIndicator(
							indicator22FArr[i].getIndicator());

				}

				// For REVA
				if (null != indicator22FArr[i].getQualifier()
						&& "REVA".equalsIgnoreCase(indicator22FArr[i]
								.getQualifier())) {
					if (null != indicator22FArr[i].getDataSourceScheme()
							&& "DataSourceScheme"
									.equalsIgnoreCase(indicator22FArr[i]
											.getDataSourceScheme())) {

						tempSeqD22aBean.getNsREVA().getNsF22F()
								.setNsDataSourceScheme(
										indicator22FArr[i]
												.getDataSourceSchemeValue());
					}

					tempSeqD22aBean.getNsREVA().getNsF22F().setNsIndicator(
							indicator22FArr[i].getIndicator());

				}

				// For LEGA
				if (null != indicator22FArr[i].getQualifier()
						&& "LEGA".equalsIgnoreCase(indicator22FArr[i]
								.getQualifier())) {
					if (null != indicator22FArr[i].getDataSourceScheme()
							&& "DataSourceScheme"
									.equalsIgnoreCase(indicator22FArr[i]
											.getDataSourceScheme())) {

						tempSeqD22aBean.getNsLEGA().getNsF22F()
								.setNsDataSourceScheme(
										indicator22FArr[i]
												.getDataSourceSchemeValue());
					}

					tempSeqD22aBean.getNsLEGA().getNsF22F().setNsIndicator(
							indicator22FArr[i].getIndicator());

				}

				// For OMAT
				if (null != indicator22FArr[i].getQualifier()
						&& "OMAT".equalsIgnoreCase(indicator22FArr[i]
								.getQualifier())) {
					if (null != indicator22FArr[i].getDataSourceScheme()
							&& "DataSourceScheme"
									.equalsIgnoreCase(indicator22FArr[i]
											.getDataSourceScheme())) {

						tempSeqD22aBean.getNsOMAT().getNsF22F()
								.setNsDataSourceScheme(
										indicator22FArr[i]
												.getDataSourceSchemeValue());
					}
					tempSeqD22aBean.getNsOMAT().getNsF22F().setNsIndicator(
							indicator22FArr[i].getIndicator());

				}

				// For INTR
				if (null != indicator22FArr[i].getQualifier()
						&& "INTR".equalsIgnoreCase(indicator22FArr[i]
								.getQualifier())) {
					if (null != indicator22FArr[i].getDataSourceScheme()
							&& "DataSourceScheme"
									.equalsIgnoreCase(indicator22FArr[i]
											.getDataSourceScheme())) {

						tempSeqD22aBean.getNsINTR().getNsF22F()
								.setNsDataSourceScheme(
										indicator22FArr[i]
												.getDataSourceSchemeValue());
					}

					tempSeqD22aBean.getNsINTR().getNsF22F().setNsIndicator(
							indicator22FArr[i].getIndicator());

				}

				tempSeqD22FArr[i] = tempSeqD22aBean;
			}
		}
		return tempSeqD22FArr;
	}

	public TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F99a_Type[] updateNumberCount98B(
			NumberCount_99B[] tempNumberCount98BArr) {

		TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F99a_Type[] tempSeqD98bArr = null;

		if (null != tempNumberCount98BArr && tempNumberCount98BArr.length > 0) {

			tempSeqD98bArr = new TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F99a_Type[tempNumberCount98BArr.length];

			for (int i = 0; i < tempNumberCount98BArr.length; i++) {

				TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F99a_Type tempSeqD99aBean = new TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F99a_Type();

				// For CADE
				if (null != tempNumberCount98BArr[i].getQualifier()
						&& "CADE".equalsIgnoreCase(tempNumberCount98BArr[i]
								.getQualifier())) {

					LogUtils.log("cadew ==="
							+ tempNumberCount98BArr[i].getNumber());

					tempSeqD99aBean.getNsCADE().getNsF99B().setNsNumber(
							tempNumberCount98BArr[i].getNumber());
				}

				// For TOCO
				if (null != tempNumberCount98BArr[i].getQualifier()
						&& "TOCO".equalsIgnoreCase(tempNumberCount98BArr[i]
								.getQualifier())) {

					LogUtils.log("TOCO ==="
							+ tempNumberCount98BArr[i].getNumber());

					tempSeqD99aBean.getNsTOCO().getNsF99B().setNsNumber(
							tempNumberCount98BArr[i].getNumber());
				}

				tempSeqD98bArr[i] = tempSeqD99aBean;
			}
		}

		return tempSeqD98bArr;
	}

	public TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F92a_Type[] updateRate92A(
			Rate_92A[] tempRate92aArr) {

		TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F92a_Type[] tempSeqD92aArr = null;

		if (null != tempRate92aArr && tempRate92aArr.length > 0) {

			tempSeqD92aArr = new TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F92a_Type[tempRate92aArr.length];

			for (int i = 0; i < tempRate92aArr.length; i++) {

				TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F92a_Type tempSeqD92aBean = new TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F92a_Type();

				// For VASU
				if (null != tempRate92aArr[i].getQualifier()
						&& "VASU".equalsIgnoreCase(tempRate92aArr[i]
								.getQualifier())) {

					tempSeqD92aBean.getNsVASU().getNsF92C()
							.setNsDataSourceScheme(
									tempRate92aArr[i]
											.getDataSourceSchemeValue());
					tempSeqD92aBean.getNsVASU().getNsF92C().setNsRateName(
							tempRate92aArr[i].getRateName());
				}

				// For REPO
				if (null != tempRate92aArr[i].getQualifier()
						&& "REPO".equalsIgnoreCase(tempRate92aArr[i]
								.getQualifier())) {

					tempSeqD92aBean.getNsREPO().getNsF92A().setNsRate(
							getUpdatedAmtValue(tempRate92aArr[i].getRate()));
					tempSeqD92aBean.getNsREPO().getNsF92A().setNsSign(
							tempRate92aArr[i].getSign());
				}

				// For RSPR
				if (null != tempRate92aArr[i].getQualifier()
						&& "RSPR".equalsIgnoreCase(tempRate92aArr[i]
								.getQualifier())) {

					tempSeqD92aBean.getNsRSPR().getNsF92A().setNsRate(
							getUpdatedAmtValue(tempRate92aArr[i].getRate()));
					tempSeqD92aBean.getNsRSPR().getNsF92A().setNsSign(
							tempRate92aArr[i].getSign());
				}

				// For PRIC
				if (null != tempRate92aArr[i].getQualifier()
						&& "PRIC".equalsIgnoreCase(tempRate92aArr[i]
								.getQualifier())) {

					if (null != tempRate92aArr[i].getOptions()
							&& "Sign Rate".equalsIgnoreCase(tempRate92aArr[i]
									.getOptions())) {

						tempSeqD92aBean.getNsPRIC().getNsF92A()
								.setNsRate(
										getUpdatedAmtValue(tempRate92aArr[i]
												.getRate()));
						tempSeqD92aBean.getNsPRIC().getNsF92A().setNsSign(
								tempRate92aArr[i].getSign());

					} else if (null != tempRate92aArr[i].getOptions()
							&& "Rate Name".equalsIgnoreCase(tempRate92aArr[i]
									.getOptions())) {

						tempSeqD92aBean.getNsPRIC().getNsF92C()
								.setNsDataSourceScheme(
										tempRate92aArr[i]
												.getDataSourceSchemeValue());
						tempSeqD92aBean.getNsPRIC().getNsF92C().setNsRateName(
								tempRate92aArr[i].getRateName());

					}
				}

				// For SLMG
				if (null != tempRate92aArr[i].getQualifier()
						&& "SLMG".equalsIgnoreCase(tempRate92aArr[i]
								.getQualifier())) {

					tempSeqD92aBean.getNsSLMG().getNsF92A().setNsRate(
							getUpdatedAmtValue(tempRate92aArr[i].getRate()));
					tempSeqD92aBean.getNsSLMG().getNsF92A().setNsSign(
							tempRate92aArr[i].getSign());
				}

				// For SHAI
				if (null != tempRate92aArr[i].getQualifier()
						&& "SHAI".equalsIgnoreCase(tempRate92aArr[i]
								.getQualifier())) {

					tempSeqD92aBean.getNsSHAI().getNsF92A().setNsRate(
							getUpdatedAmtValue(tempRate92aArr[i].getRate()));
					tempSeqD92aBean.getNsSHAI().getNsF92A().setNsSign(
							tempRate92aArr[i].getSign());
				}

				tempSeqD92aArr[i] = tempSeqD92aBean;
			}
		}

		return tempSeqD92aArr;
	}

	public TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F20a_Type[] updateReference20C(
			Reference_20C[] tempReference20CArr) {

		TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F20a_Type[] tempSeqD20cArr = null;

		if (null != tempReference20CArr && tempReference20CArr.length > 0) {

			tempSeqD20cArr = new TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F20a_Type[tempReference20CArr.length];

			for (int i = 0; i < tempReference20CArr.length; i++) {

				TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F20a_Type tempSeqD20cBean = new TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F20a_Type();

				// For SECO
				if (null != tempReference20CArr[i].getQualifier()
						&& "SECO".equalsIgnoreCase(tempReference20CArr[i]
								.getQualifier())) {

					tempSeqD20cBean.getNsSECO().getNsF20C().setNsReference(
							tempReference20CArr[i].getReference());
				}

				// For REPO
				if (null != tempReference20CArr[i].getQualifier()
						&& "REPO".equalsIgnoreCase(tempReference20CArr[i]
								.getQualifier())) {

					tempSeqD20cBean.getNsREPO().getNsF20C().setNsReference(
							tempReference20CArr[i].getReference());
				}

				tempSeqD20cArr[i] = tempSeqD20cBean;
			}
		}

		return tempSeqD20cArr;
	}

	public TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F70a_Type updateNarrative70C(
			Narrative_70C tempNarrative70C) {

		TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F70a_Type tempSeqD70CBean = null;

		if (null != tempNarrative70C) {

			tempSeqD70CBean = new TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F70a_Type();

			String[] tempNarra;

			ArrayList<String> tempNarrative = new ArrayList<String>();

			if (null != tempNarrative70C.getNarrative1()
					&& !tempNarrative70C.getNarrative1().trim()
							.equalsIgnoreCase("")) {

				tempNarrative.add(tempNarrative70C.getNarrative1());
			}
			if (null != tempNarrative70C.getNarrative2()
					&& !tempNarrative70C.getNarrative2().trim()
							.equalsIgnoreCase("")) {

				tempNarrative.add(tempNarrative70C.getNarrative2());
			}
			if (null != tempNarrative70C.getNarrative3()
					&& !tempNarrative70C.getNarrative3().trim()
							.equalsIgnoreCase("")) {

				tempNarrative.add(tempNarrative70C.getNarrative3());
			}
			if (null != tempNarrative70C.getNarrative4()
					&& !tempNarrative70C.getNarrative4().trim()
							.equalsIgnoreCase("")) {

				tempNarrative.add(tempNarrative70C.getNarrative4());
			}

			tempNarra = new String[tempNarrative.size()];
			tempNarra = tempNarrative.toArray(tempNarra);
			tempSeqD70CBean.getNsSECO().getNsF70C().getNsNarrative().setNsLine(
					tempNarra);
		}
		return tempSeqD70CBean;
	}

	public String getUpdatedAmtValue(String tempQuantityValue) {

		if (tempQuantityValue != null && tempQuantityValue.trim().length() != 0) {
			
			  tempQuantityValue = tempQuantityValue.replace(".", ",");
	          int index = tempQuantityValue.lastIndexOf(",");
	          if (index!=-1)
	        	  tempQuantityValue = tempQuantityValue.substring(0,index).replace(",", "").concat(tempQuantityValue.substring(index));
	
	           else
	        	   tempQuantityValue=tempQuantityValue+",";            
	    } 

		return tempQuantityValue;

	}

}
