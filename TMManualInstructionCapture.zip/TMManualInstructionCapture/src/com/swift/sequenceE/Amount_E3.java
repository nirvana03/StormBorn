package com.swift.sequenceE;

public class Amount_E3 {
	
	private String id="";
	private String flagQualifier="";
	private String flagValue="";
	private String amountQualifier="";
	private String amountSign="";
	private String amountCurrencyCode="";
	private String amountValue="";
	private String firstCurrencyCode="";
	private String secondCurrencyCode="";
	private String rate="";
	
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getFlagQualifier() {
		return flagQualifier;
	}
	public void setFlagQualifier(String flagQualifier) {
		this.flagQualifier = flagQualifier;
	}
	public String getFlagValue() {
		return flagValue;
	}
	public void setFlagValue(String flagValue) {
		this.flagValue = flagValue;
	}
	public String getAmountQualifier() {
		return amountQualifier;
	}
	public void setAmountQualifier(String amountQualifier) {
		this.amountQualifier = amountQualifier;
	}
	public String getAmountSign() {
		return amountSign;
	}
	public void setAmountSign(String amountSign) {
		this.amountSign = amountSign;
	}
	public String getAmountCurrencyCode() {
		return amountCurrencyCode;
	}
	public void setAmountCurrencyCode(String amountCurrencyCode) {
		this.amountCurrencyCode = amountCurrencyCode;
	}
	public String getAmountValue() {
		return amountValue;
	}
	public void setAmountValue(String amountValue) {
		this.amountValue = amountValue;
	}
	public String getFirstCurrencyCode() {
		return firstCurrencyCode;
	}
	public void setFirstCurrencyCode(String firstCurrencyCode) {
		this.firstCurrencyCode = firstCurrencyCode;
	}
	public String getSecondCurrencyCode() {
		return secondCurrencyCode;
	}
	public void setSecondCurrencyCode(String secondCurrencyCode) {
		this.secondCurrencyCode = secondCurrencyCode;
	}
	public String getRate() {
		return rate;
	}
	public void setRate(String rate) {
		this.rate = rate;
	}

}
