package com.swift.sequenceE;

public class CashParties_E2 {
	
	private String id="";
	private String cashPartyQualifier="";
	private String cashPartyOption="";
	private String cashPartyValue="";
	private String address1="";
	private String address2="";
	private String address3="";
	private String address4="";
	private String dataSourceSchemeValue="";
	private String dataSourceScheme="";
	private String accountQualifier="";
	private String accountOption="";
	private String account="";
	private String narrativeQualifier="";
	private String narrative1="";
	private String narrative2="";
	private String narrative3="";
	private String narrative4="";
	private String narrative5="";
	private String narrative6="";
	private String narrative7="";
	private String narrative8="";
	private String narrative9="";
	private String narrative10="";
	
	private String legalEntityIdentifier="";//SR2016
	
	
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getCashPartyQualifier() {
		return cashPartyQualifier;
	}
	public void setCashPartyQualifier(String cashPartyQualifier) {
		this.cashPartyQualifier = cashPartyQualifier;
	}
	public String getCashPartyOption() {
		return cashPartyOption;
	}
	public void setCashPartyOption(String cashPartyOption) {
		this.cashPartyOption = cashPartyOption;
	}
	public String getCashPartyValue() {
		return cashPartyValue;
	}
	public void setCashPartyValue(String cashPartyValue) {
		this.cashPartyValue = cashPartyValue;
	}
	public String getAddress1() {
		return address1;
	}
	public void setAddress1(String address1) {
		this.address1 = address1;
	}
	public String getAddress2() {
		return address2;
	}
	public void setAddress2(String address2) {
		this.address2 = address2;
	}
	public String getAddress3() {
		return address3;
	}
	public void setAddress3(String address3) {
		this.address3 = address3;
	}
	public String getAddress4() {
		return address4;
	}
	public void setAddress4(String address4) {
		this.address4 = address4;
	}
	public String getDataSourceSchemeValue() {
		return dataSourceSchemeValue;
	}
	public void setDataSourceSchemeValue(String dataSourceSchemeValue) {
		this.dataSourceSchemeValue = dataSourceSchemeValue;
	}
	public String getDataSourceScheme() {
		return dataSourceScheme;
	}
	public void setDataSourceScheme(String dataSourceScheme) {
		this.dataSourceScheme = dataSourceScheme;
	}
	public String getAccountQualifier() {
		return accountQualifier;
	}
	public void setAccountQualifier(String accountQualifier) {
		this.accountQualifier = accountQualifier;
	}
	public String getAccountOption() {
		return accountOption;
	}
	public void setAccountOption(String accountOption) {
		this.accountOption = accountOption;
	}
	public String getAccount() {
		return account;
	}
	public void setAccount(String account) {
		this.account = account;
	}
	public String getNarrativeQualifier() {
		return narrativeQualifier;
	}
	public void setNarrativeQualifier(String narrativeQualifier) {
		this.narrativeQualifier = narrativeQualifier;
	}
	public String getNarrative1() {
		return narrative1;
	}
	public void setNarrative1(String narrative1) {
		this.narrative1 = narrative1;
	}
	public String getNarrative2() {
		return narrative2;
	}
	public void setNarrative2(String narrative2) {
		this.narrative2 = narrative2;
	}
	public String getNarrative3() {
		return narrative3;
	}
	public void setNarrative3(String narrative3) {
		this.narrative3 = narrative3;
	}
	public String getNarrative4() {
		return narrative4;
	}
	public void setNarrative4(String narrative4) {
		this.narrative4 = narrative4;
	}
	public String getNarrative5() {
		return narrative5;
	}
	public void setNarrative5(String narrative5) {
		this.narrative5 = narrative5;
	}
	public String getNarrative6() {
		return narrative6;
	}
	public void setNarrative6(String narrative6) {
		this.narrative6 = narrative6;
	}
	public String getNarrative7() {
		return narrative7;
	}
	public void setNarrative7(String narrative7) {
		this.narrative7 = narrative7;
	}
	public String getNarrative8() {
		return narrative8;
	}
	public void setNarrative8(String narrative8) {
		this.narrative8 = narrative8;
	}
	public String getNarrative9() {
		return narrative9;
	}
	public void setNarrative9(String narrative9) {
		this.narrative9 = narrative9;
	}
	public String getNarrative10() {
		return narrative10;
	}
	public void setNarrative10(String narrative10) {
		this.narrative10 = narrative10;
	}
	public String getLegalEntityIdentifier() {
		return legalEntityIdentifier;
	}
	public void setLegalEntityIdentifier(String legalEntityIdentifier) {
		this.legalEntityIdentifier = legalEntityIdentifier;
	}
	
	
	

}
