package com.swift.sequenceE;

import com.webmethods.caf.faces.util.LogUtils;
import com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE2_F70a_Type;
import com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE2_F95a_Type;
import com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE2_F97a_Type;
import com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE2_Type;
import com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F17a_Type;
import com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F19a_Type;
import com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_Type;
import com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE_F22a_Type;

public class SequenceEDataPopulate {

	public Indicator_22F[] indicator_22F_Initial(
			TMCommon_docType_MT54x_docTypeRef_ns_SeqE_F22a_Type[] indicator) {
		Indicator_22F[] tempIndicatorArr = null;

		int id = 9000;

		if (indicator != null && indicator.length != 0) {
			tempIndicatorArr = new Indicator_22F[indicator.length];

			for (int i = 0; i < indicator.length; i++) {

				TMCommon_docType_MT54x_docTypeRef_ns_SeqE_F22a_Type temp = indicator[i];

				Indicator_22F tempBean = new Indicator_22F();
				id = id + 1;
				tempBean.setId(id + "");

				if (temp != null) {
					if (temp.getNsBENE().getNsF22F().getNsDataSourceScheme() != null
							|| temp.getNsBENE().getNsF22F().getNsIndicator() != null) {
						tempBean.setQualifier("BENE");
						if (temp.getNsBENE().getNsF22F()
								.getNsDataSourceScheme() != null
								&& temp.getNsBENE().getNsF22F()
										.getNsDataSourceScheme().length() != 0) {
							tempBean.setDataSourceScheme("DataSourceScheme");
							tempBean.setDataSourceSchemeValue(temp.getNsBENE()
									.getNsF22F().getNsDataSourceScheme());
						}

						tempBean.setIndicator(temp.getNsBENE().getNsF22F()
								.getNsIndicator());

					} else if (temp.getNsSTCO().getNsF22F()
							.getNsDataSourceScheme() != null
							|| temp.getNsSTCO().getNsF22F().getNsIndicator() != null) {
						tempBean.setQualifier("STCO");
						if (temp.getNsSTCO().getNsF22F()
								.getNsDataSourceScheme() != null
								&& temp.getNsSTCO().getNsF22F()
										.getNsDataSourceScheme().length() != 0) {
							tempBean.setDataSourceScheme("DataSourceScheme");
							tempBean.setDataSourceSchemeValue(temp.getNsSTCO()
									.getNsF22F().getNsDataSourceScheme());
						}

						tempBean.setIndicator(temp.getNsSTCO().getNsF22F()
								.getNsIndicator());

					} else if (temp.getNsSETR().getNsF22F()
							.getNsDataSourceScheme() != null
							|| temp.getNsSETR().getNsF22F().getNsIndicator() != null) {
						tempBean.setQualifier("SETR");
						if (temp.getNsSETR().getNsF22F()
								.getNsDataSourceScheme() != null
								&& temp.getNsSETR().getNsF22F()
										.getNsDataSourceScheme().length() != 0) {
							tempBean.setDataSourceScheme("DataSourceScheme");
							tempBean.setDataSourceSchemeValue(temp.getNsSETR()
									.getNsF22F().getNsDataSourceScheme());
						}

						tempBean.setIndicator(temp.getNsSETR().getNsF22F()
								.getNsIndicator());

					} else if (temp.getNsTRCA().getNsF22F()
							.getNsDataSourceScheme() != null
							|| temp.getNsTRCA().getNsF22F().getNsIndicator() != null) {
						tempBean.setQualifier("TRCA");
						if (temp.getNsTRCA().getNsF22F()
								.getNsDataSourceScheme() != null
								&& temp.getNsTRCA().getNsF22F()
										.getNsDataSourceScheme().length() != 0) {
							tempBean.setDataSourceScheme("DataSourceScheme");
							tempBean.setDataSourceSchemeValue(temp.getNsTRCA()
									.getNsF22F().getNsDataSourceScheme());
						}

						tempBean.setIndicator(temp.getNsTRCA().getNsF22F()
								.getNsIndicator());

					} else if (temp.getNsSTAM().getNsF22F()
							.getNsDataSourceScheme() != null
							|| temp.getNsSTAM().getNsF22F().getNsIndicator() != null) {
						tempBean.setQualifier("STAM");
						if (temp.getNsSTAM().getNsF22F()
								.getNsDataSourceScheme() != null
								&& temp.getNsSTAM().getNsF22F()
										.getNsDataSourceScheme().length() != 0) {
							tempBean.setDataSourceScheme("DataSourceScheme");
							tempBean.setDataSourceSchemeValue(temp.getNsSTAM()
									.getNsF22F().getNsDataSourceScheme());
						}

						tempBean.setIndicator(temp.getNsSTAM().getNsF22F()
								.getNsIndicator());

					} else if (temp.getNsRTGS().getNsF22F()
							.getNsDataSourceScheme() != null
							|| temp.getNsRTGS().getNsF22F().getNsIndicator() != null) {
						tempBean.setQualifier("RTGS");
						if (temp.getNsRTGS().getNsF22F()
								.getNsDataSourceScheme() != null
								&& temp.getNsRTGS().getNsF22F()
										.getNsDataSourceScheme().length() != 0) {
							tempBean.setDataSourceScheme("DataSourceScheme");
							tempBean.setDataSourceSchemeValue(temp.getNsRTGS()
									.getNsF22F().getNsDataSourceScheme());
						}

						tempBean.setIndicator(temp.getNsRTGS().getNsF22F()
								.getNsIndicator());

					} else if (temp.getNsREGT().getNsF22F()
							.getNsDataSourceScheme() != null
							|| temp.getNsREGT().getNsF22F().getNsIndicator() != null) {
						tempBean.setQualifier("REGT");
						if (temp.getNsREGT().getNsF22F()
								.getNsDataSourceScheme() != null
								&& temp.getNsREGT().getNsF22F()
										.getNsDataSourceScheme().length() != 0) {
							tempBean.setDataSourceScheme("DataSourceScheme");
							tempBean.setDataSourceSchemeValue(temp.getNsREGT()
									.getNsF22F().getNsDataSourceScheme());
						}

						tempBean.setIndicator(temp.getNsREGT().getNsF22F()
								.getNsIndicator());

					} else if (temp.getNsCASY().getNsF22F()
							.getNsDataSourceScheme() != null
							|| temp.getNsCASY().getNsF22F().getNsIndicator() != null) {
						tempBean.setQualifier("CASY");
						if (temp.getNsCASY().getNsF22F()
								.getNsDataSourceScheme() != null
								&& temp.getNsCASY().getNsF22F()
										.getNsDataSourceScheme().length() != 0) {
							tempBean.setDataSourceScheme("DataSourceScheme");
							tempBean.setDataSourceSchemeValue(temp.getNsCASY()
									.getNsF22F().getNsDataSourceScheme());
						}

						tempBean.setIndicator(temp.getNsCASY().getNsF22F()
								.getNsIndicator());

					} else if (temp.getNsDBNM().getNsF22F()
							.getNsDataSourceScheme() != null
							|| temp.getNsDBNM().getNsF22F().getNsIndicator() != null) {
						tempBean.setQualifier("DBNM");
						if (temp.getNsDBNM().getNsF22F()
								.getNsDataSourceScheme() != null
								&& temp.getNsDBNM().getNsF22F()
										.getNsDataSourceScheme().length() != 0) {
							tempBean.setDataSourceScheme("DataSourceScheme");
							tempBean.setDataSourceSchemeValue(temp.getNsDBNM()
									.getNsF22F().getNsDataSourceScheme());
						}

						tempBean.setIndicator(temp.getNsDBNM().getNsF22F()
								.getNsIndicator());

					} else if (temp.getNsTCPI().getNsF22F()
							.getNsDataSourceScheme() != null
							|| temp.getNsTCPI().getNsF22F().getNsIndicator() != null) {
						tempBean.setQualifier("TCPI");
						if (temp.getNsTCPI().getNsF22F()
								.getNsDataSourceScheme() != null
								&& temp.getNsTCPI().getNsF22F()
										.getNsDataSourceScheme().length() != 0) {
							tempBean.setDataSourceScheme("DataSourceScheme");
							tempBean.setDataSourceSchemeValue(temp.getNsTCPI()
									.getNsF22F().getNsDataSourceScheme());
						}

						tempBean.setIndicator(temp.getNsTCPI().getNsF22F()
								.getNsIndicator());

					} else if (temp.getNsMACL().getNsF22F()
							.getNsDataSourceScheme() != null
							|| temp.getNsMACL().getNsF22F().getNsIndicator() != null) {
						tempBean.setQualifier("MACL");
						if (temp.getNsMACL().getNsF22F()
								.getNsDataSourceScheme() != null
								&& temp.getNsMACL().getNsF22F()
										.getNsDataSourceScheme().length() != 0) {
							tempBean.setDataSourceScheme("DataSourceScheme");
							tempBean.setDataSourceSchemeValue(temp.getNsMACL()
									.getNsF22F().getNsDataSourceScheme());
						}

						tempBean.setIndicator(temp.getNsMACL().getNsF22F()
								.getNsIndicator());

					} else if (temp.getNsFXCX().getNsF22F()
							.getNsDataSourceScheme() != null
							|| temp.getNsFXCX().getNsF22F().getNsIndicator() != null) {
						tempBean.setQualifier("FXCX");
						if (temp.getNsFXCX().getNsF22F()
								.getNsDataSourceScheme() != null
								&& temp.getNsFXCX().getNsF22F()
										.getNsDataSourceScheme().length() != 0) {
							tempBean.setDataSourceScheme("DataSourceScheme");
							tempBean.setDataSourceSchemeValue(temp.getNsFXCX()
									.getNsF22F().getNsDataSourceScheme());
						}

						tempBean.setIndicator(temp.getNsFXCX().getNsF22F()
								.getNsIndicator());

					} else if (temp.getNsBLOC().getNsF22F()
							.getNsDataSourceScheme() != null
							|| temp.getNsBLOC().getNsF22F().getNsIndicator() != null) {
						tempBean.setQualifier("BLOC");
						if (temp.getNsBLOC().getNsF22F()
								.getNsDataSourceScheme() != null
								&& temp.getNsBLOC().getNsF22F()
										.getNsDataSourceScheme().length() != 0) {
							tempBean.setDataSourceSchemeValue(temp.getNsBLOC()
									.getNsF22F().getNsDataSourceScheme());
							tempBean.setDataSourceScheme("DataSourceScheme");
						}

						tempBean.setIndicator(temp.getNsBLOC().getNsF22F()
								.getNsIndicator());

					} else if (temp.getNsREST().getNsF22F()
							.getNsDataSourceScheme() != null
							|| temp.getNsREST().getNsF22F().getNsIndicator() != null) {
						tempBean.setQualifier("REST");
						if (temp.getNsREST().getNsF22F()
								.getNsDataSourceScheme() != null
								&& temp.getNsREST().getNsF22F()
										.getNsDataSourceScheme().length() != 0) {
							tempBean.setDataSourceScheme("DataSourceScheme");
							tempBean.setDataSourceSchemeValue(temp.getNsREST()
									.getNsF22F().getNsDataSourceScheme());
						}

						tempBean.setIndicator(temp.getNsREST().getNsF22F()
								.getNsIndicator());

					} else if (temp.getNsSETS().getNsF22F()
							.getNsDataSourceScheme() != null
							|| temp.getNsSETS().getNsF22F().getNsIndicator() != null) {
						tempBean.setQualifier("SETS");
						if (temp.getNsSETS().getNsF22F()
								.getNsDataSourceScheme() != null
								&& temp.getNsSETS().getNsF22F()
										.getNsDataSourceScheme().length() != 0) {
							tempBean.setDataSourceSchemeValue(temp.getNsSETS()
									.getNsF22F().getNsDataSourceScheme());
							tempBean.setDataSourceScheme("DataSourceScheme");
						}

						tempBean.setIndicator(temp.getNsSETS().getNsF22F()
								.getNsIndicator());

					} else if (temp.getNsNETT().getNsF22F()
							.getNsDataSourceScheme() != null
							|| temp.getNsNETT().getNsF22F().getNsIndicator() != null) {
						tempBean.setQualifier("NETT");
						if (temp.getNsNETT().getNsF22F()
								.getNsDataSourceScheme() != null
								&& temp.getNsNETT().getNsF22F()
										.getNsDataSourceScheme().length() != 0) {
							tempBean.setDataSourceScheme("DataSourceScheme");
							tempBean.setDataSourceSchemeValue(temp.getNsNETT()
									.getNsF22F().getNsDataSourceScheme());
						}

						tempBean.setIndicator(temp.getNsNETT().getNsF22F()
								.getNsIndicator());

					} else if (temp.getNsCCPT().getNsF22F()
							.getNsDataSourceScheme() != null
							|| temp.getNsCCPT().getNsF22F().getNsIndicator() != null) {
						tempBean.setQualifier("CCPT");
						if (temp.getNsCCPT().getNsF22F()
								.getNsDataSourceScheme() != null
								&& temp.getNsCCPT().getNsF22F()
										.getNsDataSourceScheme().length() != 0) {
							tempBean.setDataSourceScheme("DataSourceScheme");
							tempBean.setDataSourceSchemeValue(temp.getNsCCPT()
									.getNsF22F().getNsDataSourceScheme());
						}

						tempBean.setIndicator(temp.getNsCCPT().getNsF22F()
								.getNsIndicator());

					} else if (temp.getNsLEOG().getNsF22F()
							.getNsDataSourceScheme() != null
							|| temp.getNsLEOG().getNsF22F().getNsIndicator() != null) {
						tempBean.setQualifier("LEOG");
						if (temp.getNsLEOG().getNsF22F()
								.getNsDataSourceScheme() != null
								&& temp.getNsLEOG().getNsF22F()
										.getNsDataSourceScheme().length() != 0) {
							tempBean.setDataSourceSchemeValue(temp.getNsLEOG()
									.getNsF22F().getNsDataSourceScheme());
							tempBean.setDataSourceScheme("DataSourceScheme");
						}

						tempBean.setIndicator(temp.getNsLEOG().getNsF22F()
								.getNsIndicator());

					} else if (temp.getNsCOLA().getNsF22F()
							.getNsDataSourceScheme() != null
							|| temp.getNsCOLA().getNsF22F().getNsIndicator() != null) {
						tempBean.setQualifier("COLA");
						if (temp.getNsCOLA().getNsF22F()
								.getNsDataSourceScheme() != null
								&& temp.getNsCOLA().getNsF22F()
										.getNsDataSourceScheme().length() != 0) {
							tempBean.setDataSourceSchemeValue(temp.getNsCOLA()
									.getNsF22F().getNsDataSourceScheme());
							tempBean.setDataSourceScheme("DataSourceScheme");
						}

						tempBean.setIndicator(temp.getNsCOLA().getNsF22F()
								.getNsIndicator());

					} else if (temp.getNsTRAK().getNsF22F()
							.getNsDataSourceScheme() != null
							|| temp.getNsTRAK().getNsF22F().getNsIndicator() != null) {
						tempBean.setQualifier("TRAK");
						if (temp.getNsTRAK().getNsF22F()
								.getNsDataSourceScheme() != null
								&& temp.getNsTRAK().getNsF22F()
										.getNsDataSourceScheme().length() != 0) {
							tempBean.setDataSourceSchemeValue(temp.getNsTRAK()
									.getNsF22F().getNsDataSourceScheme());
							tempBean.setDataSourceScheme("DataSourceScheme");
						}

						tempBean.setIndicator(temp.getNsTRAK().getNsF22F()
								.getNsIndicator());

					} else if (temp.getNsREPT().getNsF22F()
							.getNsDataSourceScheme() != null
							|| temp.getNsREPT().getNsF22F().getNsIndicator() != null) {
						tempBean.setQualifier("REPT");
						if (temp.getNsREPT().getNsF22F()
								.getNsDataSourceScheme() != null
								&& temp.getNsREPT().getNsF22F()
										.getNsDataSourceScheme().length() != 0) {
							tempBean.setDataSourceSchemeValue(temp.getNsREPT()
									.getNsF22F().getNsDataSourceScheme());
							tempBean.setDataSourceScheme("DataSourceScheme");
						}

						tempBean.setIndicator(temp.getNsREPT().getNsF22F()
								.getNsIndicator());

					} else if (temp.getNsCOLE().getNsF22F()
							.getNsDataSourceScheme() != null
							|| temp.getNsCOLE().getNsF22F().getNsIndicator() != null) {
						tempBean.setQualifier("COLE");
						if (temp.getNsCOLE().getNsF22F()
								.getNsDataSourceScheme() != null
								&& temp.getNsCOLE().getNsF22F()
										.getNsDataSourceScheme().length() != 0) {
							tempBean.setDataSourceSchemeValue(temp.getNsCOLE()
									.getNsF22F().getNsDataSourceScheme());
							tempBean.setDataSourceScheme("DataSourceScheme");
						}

						tempBean.setIndicator(temp.getNsCOLE().getNsF22F()
								.getNsIndicator());

					} else if (temp.getNsSSBT().getNsF22F()
							.getNsDataSourceScheme() != null
							|| temp.getNsSSBT().getNsF22F().getNsIndicator() != null) {
						tempBean.setQualifier("SSBT");
						if (temp.getNsSSBT().getNsF22F()
								.getNsDataSourceScheme() != null
								&& temp.getNsSSBT().getNsF22F()
										.getNsDataSourceScheme().length() != 0) {

							tempBean.setDataSourceSchemeValue(temp.getNsSSBT()
									.getNsF22F().getNsDataSourceScheme());
							tempBean.setDataSourceScheme("DataSourceScheme");
						}

						tempBean.setIndicator(temp.getNsSSBT().getNsF22F()
								.getNsIndicator());
					} else if (temp.getNsCSBT().getNsF22F()
							.getNsDataSourceScheme() != null
							|| temp.getNsCSBT().getNsF22F().getNsIndicator() != null) {
						tempBean.setQualifier("CSBT");
						if (temp.getNsCSBT().getNsF22F()
								.getNsDataSourceScheme() != null
								&& temp.getNsCSBT().getNsF22F()
										.getNsDataSourceScheme().length() != 0) {
							tempBean.setDataSourceSchemeValue(temp.getNsCSBT()
									.getNsF22F().getNsDataSourceScheme());
							tempBean.setDataSourceScheme("DataSourceScheme");
						}

						tempBean.setIndicator(temp.getNsCSBT().getNsF22F()
								.getNsIndicator());
					}
				}
				tempIndicatorArr[i] = tempBean;

			}

		}

		return tempIndicatorArr;

	}

	public CashParties_E2[] seqEE2_Initial(
			TMCommon_docType_MT54x_docTypeRef_ns_SeqE2_Type[] cashParty) {
		CashParties_E2[] tempCashPartyArr = null;
		int id = 8000;

	//	LogUtils.log("SeqE populate-----------cashparty length"+cashParty.length);
		if (cashParty != null && cashParty.length != 0) {

			tempCashPartyArr = new CashParties_E2[cashParty.length];

			for (int i = 0; i < cashParty.length; i++) {
				CashParties_E2 tempBean = new CashParties_E2();
				id = id + 1;

				tempBean.setId(id + "");

				TMCommon_docType_MT54x_docTypeRef_ns_SeqE2_Type temp = cashParty[i];
			//	cashParty[i].getNsF95a()[i].getNsALTE().getNsF95L().getNsLegalEntityIdentifier()
				// cashParty[i].getNsF16a_1().setNsF16R(null);
				// cashParty[i].getNsF16a_2().setNsF16S(null);

				TMCommon_docType_MT54x_docTypeRef_ns_SeqE2_F95a_Type[] temp_95a = temp
						.getNsF95a();
				TMCommon_docType_MT54x_docTypeRef_ns_SeqE2_F95a_Type tempBean_95a1=new TMCommon_docType_MT54x_docTypeRef_ns_SeqE2_F95a_Type();
				if (temp_95a != null && temp_95a.length != 0) {
		//			LogUtils.log("SeqE populate------length-----iniitalising array"+cashParty.length);
					TMCommon_docType_MT54x_docTypeRef_ns_SeqE2_F95a_Type tempBean_95a=null;
           for(int k=0;k<temp.getNsF95a().length;k++)
           {
        	  
					
			//		LogUtils.log("Seq E ---populate---LEI in 1st index"+temp_95a[1].getNsALTE().getNsF95L().getNsLegalEntityIdentifier());
					
					if(null!=temp_95a[k].getNsALTE().getNsF95L().getNsLegalEntityIdentifier()){
						
					 tempBean_95a1 = temp_95a[k];//SR2016
					}
					else{
						 tempBean_95a = temp_95a[k];
					}
					
           }			
					
					if (tempBean_95a != null) {
					
						/* commmenting earlier change for SR2016
						//SR2016
						if (tempBean_95a.getNsALTE().getNsF95L().getNsLegalEntityIdentifier() != null) {
							LogUtils.log("Populating data form Cashparty...Seq E2---ALTE1");

							tempBean.setCashPartyQualifier("ALTE1");
						//	if (tempBean_95a.getNsACCW().getNsF95P()
							//		.getNsIdentifierCode() != null) {
								tempBean.setCashPartyOption("LegalEntityIdentifier");
								tempBean.setCashPartyValue(tempBean_95a
										.getNsALTE().getNsF95L().getNsLegalEntityIdentifier());
								LogUtils.log("Populating data form Cashparty---inside if ()...Seq E2---ALTE1");
					//		}
						}
						//SR2016
*/
						if (tempBean_95a.getNsACCW().getNsF95P()
								.getNsIdentifierCode() != null
								|| tempBean_95a.getNsACCW().getNsF95Q()
										.getNsNameAndAddress().getNsLine() != null
								|| tempBean_95a.getNsACCW().getNsF95R()
										.getNsDataSourceScheme() != null
								|| tempBean_95a.getNsACCW().getNsF95R()
										.getNsProprietaryCode() != null) {
							
							tempBean.setCashPartyQualifier("ACCW");
							if (tempBean_95a.getNsACCW().getNsF95P()
									.getNsIdentifierCode() != null) {
								//LogUtils.log("SeqE Populate--Cash Party----Inside ACCW--Id code");
								tempBean.setCashPartyOption("Identifier Code");
								tempBean.setCashPartyValue(tempBean_95a
										.getNsACCW().getNsF95P()
										.getNsIdentifierCode());
							} else if (tempBean_95a.getNsACCW().getNsF95Q()
									.getNsNameAndAddress().getNsLine() != null
									&& tempBean_95a.getNsACCW().getNsF95Q()
											.getNsNameAndAddress().getNsLine().length != 0) {
								//LogUtils.log("SeqE Populate--Cash Party----Inside ACCW--N&A");
								tempBean.setCashPartyOption("Name and Address");
								String[] str = tempBean_95a.getNsACCW()
										.getNsF95Q().getNsNameAndAddress()
										.getNsLine();
								for (int j = 0; j < str.length; j++) {

									if (str[j] != null) {
										if (j == 0) {
											tempBean.setAddress1(str[j]);
										} else if (j == 1) {
											tempBean.setAddress2(str[j]);
										} else if (j == 2) {
											tempBean.setAddress3(str[j]);
										} else if (j == 3) {
											tempBean.setAddress4(str[j]);
										}
									}
								}

							} else if (tempBean_95a.getNsACCW().getNsF95R()
									.getNsDataSourceScheme() != null
									|| tempBean_95a.getNsACCW().getNsF95R()
											.getNsProprietaryCode() != null) {
								//LogUtils.log("SeqE Populate--Cash Party----Inside ACCW--prop code");
								tempBean.setCashPartyOption("Proprietary Code");
								tempBean.setDataSourceSchemeValue(tempBean_95a
										.getNsACCW().getNsF95R()
										.getNsDataSourceScheme());
								tempBean.setCashPartyValue(tempBean_95a
										.getNsACCW().getNsF95R()
										.getNsProprietaryCode());

							}
							
							//SR2016
						
								if(tempBean_95a1.getNsALTE().getNsF95L().getNsLegalEntityIdentifier()!=null){
								
									//LogUtils.log("SeqE Populate--Cash Party----Inside ACCW--LEI");
								tempBean.setLegalEntityIdentifier(tempBean_95a1.getNsALTE().getNsF95L().getNsLegalEntityIdentifier());
							}

						}
						// Coded Add Newly Qualifier INTM -------Rohit Gupta
						
						else if (tempBean_95a.getNsINTM().getNsF95P()
								.getNsIdentifierCode() != null
								|| tempBean_95a.getNsINTM().getNsF95Q()
										.getNsNameAndAddress().getNsLine() != null
								|| tempBean_95a.getNsINTM().getNsF95R()
										.getNsDataSourceScheme() != null
								|| tempBean_95a.getNsINTM().getNsF95R()
										.getNsProprietaryCode() != null) {
							//LogUtils.log("SeqE Populate--Cash Party----Inside INTM--Id code");

							tempBean.setCashPartyQualifier("INTM");
							if (tempBean_95a.getNsINTM().getNsF95P()
									.getNsIdentifierCode() != null) {
								tempBean.setCashPartyOption("Identifier Code");
								tempBean.setCashPartyValue(tempBean_95a
										.getNsINTM().getNsF95P()
										.getNsIdentifierCode());
							} else if (tempBean_95a.getNsINTM().getNsF95Q()
									.getNsNameAndAddress().getNsLine() != null
									&& tempBean_95a.getNsINTM().getNsF95Q()
											.getNsNameAndAddress().getNsLine().length != 0) {
								//LogUtils.log("SeqE Populate--Cash Party----Inside INTM--N and A");
								tempBean.setCashPartyOption("Name and Address");
								String[] str = tempBean_95a.getNsINTM()
										.getNsF95Q().getNsNameAndAddress()
										.getNsLine();
								for (int j = 0; j < str.length; j++) {

									if (str[j] != null) {
										if (j == 0) {
											tempBean.setAddress1(str[j]);
										} else if (j == 1) {
											tempBean.setAddress2(str[j]);
										} else if (j == 2) {
											tempBean.setAddress3(str[j]);
										} else if (j == 3) {
											tempBean.setAddress4(str[j]);
										}
									}
								}

							} else if (tempBean_95a.getNsINTM().getNsF95R()
									.getNsDataSourceScheme() != null
									|| tempBean_95a.getNsINTM().getNsF95R()
											.getNsProprietaryCode() != null) {
								//LogUtils.log("SeqE Populate--Cash Party----Inside INTM--Prop code");
								tempBean.setCashPartyOption("Proprietary Code");
								tempBean.setDataSourceSchemeValue(tempBean_95a
										.getNsINTM().getNsF95R()
										.getNsDataSourceScheme());
								tempBean.setCashPartyValue(tempBean_95a
										.getNsINTM().getNsF95R()
										.getNsProprietaryCode());

							}
							//SR2016
							if(tempBean_95a1.getNsALTE().getNsF95L().getNsLegalEntityIdentifier()!=null){
							
								//LogUtils.log("SeqE Populate--Cash Party----Inside INTM--LEI");
							tempBean.setLegalEntityIdentifier(tempBean_95a1.getNsALTE().getNsF95L().getNsLegalEntityIdentifier());
						}


						}
							else if (tempBean_95a.getNsBENM().getNsF95P()
								.getNsIdentifierCode() != null
								|| tempBean_95a.getNsBENM().getNsF95Q()
										.getNsNameAndAddress().getNsLine() != null
								|| tempBean_95a.getNsBENM().getNsF95R()
										.getNsDataSourceScheme() != null
								|| tempBean_95a.getNsBENM().getNsF95R()
										.getNsProprietaryCode() != null) {
								//LogUtils.log("SeqE Populate--Cash Party----Inside BENM--Id code");

							tempBean.setCashPartyQualifier("BENM");
							if (tempBean_95a.getNsBENM().getNsF95P()
									.getNsIdentifierCode() != null) {
								tempBean.setCashPartyOption("Identifier Code");
								tempBean.setCashPartyValue(tempBean_95a
										.getNsBENM().getNsF95P()
										.getNsIdentifierCode());
							} else if (tempBean_95a.getNsBENM().getNsF95Q()
									.getNsNameAndAddress().getNsLine() != null
									&& tempBean_95a.getNsBENM().getNsF95Q()
											.getNsNameAndAddress().getNsLine().length != 0) {
								//LogUtils.log("SeqE Populate--Cash Party----Inside ACCW--Id code");
								tempBean.setCashPartyOption("Name and Address");
								String[] str = tempBean_95a.getNsBENM()
										.getNsF95Q().getNsNameAndAddress()
										.getNsLine();
								for (int j = 0; j < str.length; j++) {

									if (str[j] != null) {
										if (j == 0) {
											tempBean.setAddress1(str[j]);
										} else if (j == 1) {
											tempBean.setAddress2(str[j]);
										} else if (j == 2) {
											tempBean.setAddress3(str[j]);
										} else if (j == 3) {
											tempBean.setAddress4(str[j]);
										}
									}
								}

							} else if (tempBean_95a.getNsBENM().getNsF95R()
									.getNsDataSourceScheme() != null
									|| tempBean_95a.getNsBENM().getNsF95R()
											.getNsProprietaryCode() != null) {
								//LogUtils.log("SeqE Populate--Cash Party----Inside BENM--Prop code");
								tempBean.setCashPartyOption("Proprietary Code");
								tempBean.setDataSourceSchemeValue(tempBean_95a
										.getNsBENM().getNsF95R()
										.getNsDataSourceScheme());
								tempBean.setCashPartyValue(tempBean_95a
										.getNsBENM().getNsF95R()
										.getNsProprietaryCode());

							}
							//SR2016
							if(tempBean_95a1.getNsALTE().getNsF95L().getNsLegalEntityIdentifier()!=null){
								
								//LogUtils.log("SeqE Populate--Cash Party----Inside BENM--LEI");
							tempBean.setLegalEntityIdentifier(tempBean_95a1.getNsALTE().getNsF95L().getNsLegalEntityIdentifier());
						}

						} else if (tempBean_95a.getNsDEBT().getNsF95P()
								.getNsIdentifierCode() != null
								|| tempBean_95a.getNsDEBT().getNsF95Q()
										.getNsNameAndAddress().getNsLine() != null
								|| tempBean_95a.getNsDEBT().getNsF95R()
										.getNsDataSourceScheme() != null
								|| tempBean_95a.getNsDEBT().getNsF95R()
										.getNsProprietaryCode() != null) {

							tempBean.setCashPartyQualifier("DEBT");
							if (tempBean_95a.getNsDEBT().getNsF95P()
									.getNsIdentifierCode() != null) {
								tempBean.setCashPartyOption("Identifier Code");
								tempBean.setCashPartyValue(tempBean_95a
										.getNsDEBT().getNsF95P()
										.getNsIdentifierCode());
							} else if (tempBean_95a.getNsDEBT().getNsF95Q()
									.getNsNameAndAddress().getNsLine() != null
									&& tempBean_95a.getNsDEBT().getNsF95Q()
											.getNsNameAndAddress().getNsLine().length != 0) {
								tempBean.setCashPartyOption("Name and Address");
								String[] str = tempBean_95a.getNsDEBT()
										.getNsF95Q().getNsNameAndAddress()
										.getNsLine();
								for (int j = 0; j < str.length; j++) {

									if (str[j] != null) {
										if (j == 0) {
											tempBean.setAddress1(str[j]);
										} else if (j == 1) {
											tempBean.setAddress2(str[j]);
										} else if (j == 2) {
											tempBean.setAddress3(str[j]);
										} else if (j == 3) {
											tempBean.setAddress4(str[j]);
										}
									}
								}

							} else if (tempBean_95a.getNsDEBT().getNsF95R()
									.getNsDataSourceScheme() != null
									|| tempBean_95a.getNsDEBT().getNsF95R()
											.getNsProprietaryCode() != null) {
								tempBean.setCashPartyOption("Proprietary Code");
								tempBean.setDataSourceSchemeValue(tempBean_95a
										.getNsDEBT().getNsF95R()
										.getNsDataSourceScheme());
								tempBean.setCashPartyValue(tempBean_95a
										.getNsDEBT().getNsF95R()
										.getNsProprietaryCode());

							}
							//SR2016
							if(tempBean_95a1.getNsALTE().getNsF95L().getNsLegalEntityIdentifier()!=null){
								
								//LogUtils.log("SeqE Populate--Cash Party----Inside DEBT--LEI");
							tempBean.setLegalEntityIdentifier(tempBean_95a1.getNsALTE().getNsF95L().getNsLegalEntityIdentifier());
						}


						} else if (tempBean_95a.getNsPAYE().getNsF95P()
								.getNsIdentifierCode() != null
								|| tempBean_95a.getNsPAYE().getNsF95Q()
										.getNsNameAndAddress().getNsLine() != null
								|| tempBean_95a.getNsPAYE().getNsF95R()
										.getNsDataSourceScheme() != null
								|| tempBean_95a.getNsPAYE().getNsF95R()
										.getNsProprietaryCode() != null) {

							tempBean.setCashPartyQualifier("PAYE");
							if (tempBean_95a.getNsPAYE().getNsF95P()
									.getNsIdentifierCode() != null) {
								tempBean.setCashPartyOption("Identifier Code");
								tempBean.setCashPartyValue(tempBean_95a
										.getNsPAYE().getNsF95P()
										.getNsIdentifierCode());
							} else if (tempBean_95a.getNsPAYE().getNsF95Q()
									.getNsNameAndAddress().getNsLine() != null
									&& tempBean_95a.getNsPAYE().getNsF95Q()
											.getNsNameAndAddress().getNsLine().length != 0) {
								tempBean.setCashPartyOption("Name and Address");
								String[] str = tempBean_95a.getNsPAYE()
										.getNsF95Q().getNsNameAndAddress()
										.getNsLine();
								for (int j = 0; j < str.length; j++) {

									if (str[j] != null) {
										if (j == 0) {
											tempBean.setAddress1(str[j]);
										} else if (j == 1) {
											tempBean.setAddress2(str[j]);
										} else if (j == 2) {
											tempBean.setAddress3(str[j]);
										} else if (j == 3) {
											tempBean.setAddress4(str[j]);
										}
									}
								}

							} else if (tempBean_95a.getNsPAYE().getNsF95R()
									.getNsDataSourceScheme() != null
									|| tempBean_95a.getNsPAYE().getNsF95R()
											.getNsProprietaryCode() != null) {
								tempBean.setCashPartyOption("Proprietary Code");
								tempBean.setDataSourceSchemeValue(tempBean_95a
										.getNsPAYE().getNsF95R()
										.getNsDataSourceScheme());
								tempBean.setCashPartyValue(tempBean_95a
										.getNsPAYE().getNsF95R()
										.getNsProprietaryCode());

							}
							//SR2016
							if(tempBean_95a1.getNsALTE().getNsF95L().getNsLegalEntityIdentifier()!=null){
								
								//LogUtils.log("SeqE Populate--Cash Party----Inside PAYE--LEI");
							tempBean.setLegalEntityIdentifier(tempBean_95a1.getNsALTE().getNsF95L().getNsLegalEntityIdentifier());
						}

							
							
						}

					}
					

				}

				TMCommon_docType_MT54x_docTypeRef_ns_SeqE2_F97a_Type[] temp_97a = temp
						.getNsF97a();

				if (temp_97a != null && temp_97a.length != 0) {
					TMCommon_docType_MT54x_docTypeRef_ns_SeqE2_F97a_Type tempBean_97a = temp_97a[0];

					if (tempBean_97a != null) {

						if (tempBean_97a.getNsCASH().getNsF97A()
								.getNsAccountNumber() != null
								|| tempBean_97a.getNsCASH().getNsF97E()
										.getNsInternationalBankAccountNumber() != null) {
							tempBean.setAccountQualifier("CASH");
							if (tempBean_97a.getNsCASH().getNsF97A()
									.getNsAccountNumber() != null) {
								tempBean.setAccountOption("AccNo");
								tempBean.setAccount(tempBean_97a.getNsCASH()
										.getNsF97A().getNsAccountNumber());
							} else if (tempBean_97a.getNsCASH().getNsF97E()
									.getNsInternationalBankAccountNumber() != null) {
								tempBean.setAccountOption("IBAN");
								tempBean.setAccount(tempBean_97a.getNsCASH()
										.getNsF97E()
										.getNsInternationalBankAccountNumber());

							}

						} else if (tempBean_97a.getNsCHAR().getNsF97A()
								.getNsAccountNumber() != null
								|| tempBean_97a.getNsCHAR().getNsF97E()
										.getNsInternationalBankAccountNumber() != null) {
							tempBean.setAccountQualifier("CHAR");
							if (tempBean_97a.getNsCHAR().getNsF97A()
									.getNsAccountNumber() != null) {
								tempBean.setAccountOption("AccNo");
								tempBean.setAccount(tempBean_97a.getNsCHAR()
										.getNsF97A().getNsAccountNumber());
							} else if (tempBean_97a.getNsCHAR().getNsF97E()
									.getNsInternationalBankAccountNumber() != null) {
								tempBean.setAccountOption("IBAN");
								tempBean.setAccount(tempBean_97a.getNsCHAR()
										.getNsF97E()
										.getNsInternationalBankAccountNumber());

							}

						} else if (tempBean_97a.getNsCOMM().getNsF97A()
								.getNsAccountNumber() != null
								|| tempBean_97a.getNsCOMM().getNsF97E()
										.getNsInternationalBankAccountNumber() != null) {
							tempBean.setAccountQualifier("COMM");
							if (tempBean_97a.getNsCOMM().getNsF97A()
									.getNsAccountNumber() != null) {
								tempBean.setAccountOption("AccNo");
								tempBean.setAccount(tempBean_97a.getNsCOMM()
										.getNsF97A().getNsAccountNumber());
							} else if (tempBean_97a.getNsCOMM().getNsF97E()
									.getNsInternationalBankAccountNumber() != null) {
								tempBean.setAccountOption("IBAN");
								tempBean.setAccount(tempBean_97a.getNsCOMM()
										.getNsF97E()
										.getNsInternationalBankAccountNumber());

							}

						} else if (tempBean_97a.getNsTAXE().getNsF97A()
								.getNsAccountNumber() != null
								|| tempBean_97a.getNsTAXE().getNsF97E()
										.getNsInternationalBankAccountNumber() != null) {
							tempBean.setAccountQualifier("TAXE");
							if (tempBean_97a.getNsTAXE().getNsF97A()
									.getNsAccountNumber() != null) {
								tempBean.setAccountOption("AccNo");
								tempBean.setAccount(tempBean_97a.getNsTAXE()
										.getNsF97A().getNsAccountNumber());
							} else if (tempBean_97a.getNsTAXE().getNsF97E()
									.getNsInternationalBankAccountNumber() != null) {
								tempBean.setAccountOption("IBAN");
								tempBean.setAccount(tempBean_97a.getNsTAXE()
										.getNsF97E()
										.getNsInternationalBankAccountNumber());

							}

						}

					}

				}

				TMCommon_docType_MT54x_docTypeRef_ns_SeqE2_F70a_Type[] temp_70a = temp
						.getNsF70a();

				if (temp_70a != null && temp_70a.length != 0) {
					TMCommon_docType_MT54x_docTypeRef_ns_SeqE2_F70a_Type tempBean_70a = temp_70a[0];

					if (tempBean_70a != null) {
						if (tempBean_70a.getNsDECL().getNsF70E()
								.getNsNarrative().getNsLine() != null) {
							tempBean.setNarrativeQualifier("DECL");

							String[] str = tempBean_70a.getNsDECL().getNsF70E()
									.getNsNarrative().getNsLine();

							for (int j = 0; j < str.length; j++) {
								if (str[j] != null) {
									if (j == 0) {
										tempBean.setNarrative1(str[j]);
									} else if (j == 1) {
										tempBean.setNarrative2(str[j]);
									} else if (j == 2) {
										tempBean.setNarrative3(str[j]);
									} else if (j == 3) {
										tempBean.setNarrative4(str[j]);
									} else if (j == 4) {
										tempBean.setNarrative5(str[j]);
									} else if (j == 5) {
										tempBean.setNarrative6(str[j]);
									} else if (j == 6) {
										tempBean.setNarrative7(str[j]);
									} else if (j == 7) {
										tempBean.setNarrative8(str[j]);
									} else if (j == 8) {
										tempBean.setNarrative9(str[j]);
									} else if (j == 9) {
										tempBean.setNarrative10(str[j]);
									}

								}
							}

						} else if (tempBean_70a.getNsPACO().getNsF70C()
								.getNsNarrative().getNsLine() != null) {

							tempBean.setNarrativeQualifier("PACO");

							String[] str = tempBean_70a.getNsPACO().getNsF70C()
									.getNsNarrative().getNsLine();

							for (int j = 0; j < str.length; j++) {

								if (str[j] != null) {
									if (j == 0) {
										tempBean.setNarrative1(str[j]);
									} else if (j == 1) {
										tempBean.setNarrative2(str[j]);
									} else if (j == 2) {
										tempBean.setNarrative3(str[j]);
									} else if (j == 3) {
										tempBean.setNarrative4(str[j]);
									}
								}

							}

						}

					}

				}

				tempCashPartyArr[i] = tempBean;
				

			}
		}

		return tempCashPartyArr;

	}

	
	public Amount_E3[] seqEE3_Initial(TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_Type[] amount,boolean isSettAmtExist) {
		
	Amount_E3[] amountArr = null;
	int id = 5000;
	int count = 0;
	if (amount != null && amount.length != 0) {

		amountArr = new Amount_E3[amount.length];
		if (isSettAmtExist) {
			amountArr = new Amount_E3[amount.length - 1];
		}

		for (TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_Type temp : amount) {

			if (temp != null) {
				Amount_E3 tempBean = new Amount_E3();
				TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F19a_Type[] temp_19a = temp.getNsF19a();

				id = id + 1;

				tempBean.setId(id + "");

				TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F17a_Type[] temp_17a = temp
						.getNsF17a();

				if (temp_17a != null && temp_17a.length != 0) {
					TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F17a_Type tempBean_17a = temp_17a[0];

					if (tempBean_17a.getNsACRU().getNsF17B().getNsFlag() != null) {

						tempBean.setFlagQualifier("ACRU");
						tempBean.setFlagValue(tempBean_17a.getNsACRU().getNsF17B().getNsFlag());

					} else if (tempBean_17a.getNsSTAM().getNsF17B().getNsFlag() != null) {

						tempBean.setFlagQualifier("STAM");
						tempBean.setFlagValue(tempBean_17a.getNsSTAM().getNsF17B().getNsFlag());
					}
					//added for SR14 upgrade
					
					else if (tempBean_17a.getNsEXEC().getNsF17B().getNsFlag()!= null){
						tempBean.setFlagQualifier("EXEC");
						tempBean.setFlagValue(tempBean_17a.getNsEXEC().getNsF17B().getNsFlag());
					}
				}

				if (temp_19a != null && temp_19a.length != 0) {
					TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F19a_Type tempBean_19a = temp_19a[0];

					if (tempBean_19a.getNsACCA().getNsF19A().getNsAmount() != null || tempBean_19a.getNsACCA().getNsF19A().getNsCurrencyCode() != null
							|| tempBean_19a.getNsACCA().getNsF19A().getNsSign() != null) {
						
						tempBean.setAmountQualifier("ACCA");
						tempBean.setAmountCurrencyCode(tempBean_19a.getNsACCA().getNsF19A().getNsCurrencyCode());
						tempBean.setAmountSign(tempBean_19a.getNsACCA().getNsF19A().getNsSign());
						tempBean.setAmountValue(tempBean_19a.getNsACCA().getNsF19A().getNsAmount());
						
					} else if (tempBean_19a.getNsACRU().getNsF19A().getNsAmount() != null || tempBean_19a.getNsACRU().getNsF19A().getNsCurrencyCode() != null
							|| tempBean_19a.getNsACRU().getNsF19A().getNsSign() != null) {
						
						tempBean.setAmountQualifier("ACRU");
						tempBean.setAmountCurrencyCode(tempBean_19a.getNsACRU().getNsF19A().getNsCurrencyCode());
						tempBean.setAmountSign(tempBean_19a.getNsACRU().getNsF19A().getNsSign());
						tempBean.setAmountValue(tempBean_19a.getNsACRU().getNsF19A().getNsAmount());
						
					} else if (tempBean_19a.getNsCHAR().getNsF19A().getNsAmount() != null || tempBean_19a.getNsCHAR().getNsF19A().getNsCurrencyCode() != null
							|| tempBean_19a.getNsCHAR().getNsF19A().getNsSign() != null) {
						
						tempBean.setAmountQualifier("CHAR");
						tempBean.setAmountCurrencyCode(tempBean_19a.getNsCHAR().getNsF19A().getNsCurrencyCode());
						tempBean.setAmountSign(tempBean_19a.getNsCHAR().getNsF19A().getNsSign());
						tempBean.setAmountValue(tempBean_19a.getNsCHAR().getNsF19A().getNsAmount());
						
					} else if (tempBean_19a.getNsCOUN().getNsF19A().getNsAmount() != null || tempBean_19a.getNsCOUN().getNsF19A().getNsCurrencyCode() != null
							|| tempBean_19a.getNsCOUN().getNsF19A().getNsSign() != null) {
						
						tempBean.setAmountQualifier("COUN");
						tempBean.setAmountCurrencyCode(tempBean_19a.getNsCOUN().getNsF19A().getNsCurrencyCode());
						tempBean.setAmountSign(tempBean_19a.getNsCOUN().getNsF19A().getNsSign());
						tempBean.setAmountValue(tempBean_19a.getNsCOUN().getNsF19A().getNsAmount());
						
					} else if (tempBean_19a.getNsDEAL().getNsF19A().getNsAmount() != null || tempBean_19a.getNsDEAL().getNsF19A().getNsCurrencyCode() != null
							|| tempBean_19a.getNsDEAL().getNsF19A().getNsSign() != null) {
						
						tempBean.setAmountQualifier("DEAL");
						tempBean.setAmountCurrencyCode(tempBean_19a.getNsDEAL().getNsF19A().getNsCurrencyCode());
						tempBean.setAmountSign(tempBean_19a.getNsDEAL().getNsF19A().getNsSign());
						tempBean.setAmountValue(tempBean_19a.getNsDEAL().getNsF19A().getNsAmount());
						
					} else if (tempBean_19a.getNsEXEC().getNsF19A().getNsAmount() != null || tempBean_19a.getNsEXEC().getNsF19A().getNsCurrencyCode() != null
							|| tempBean_19a.getNsEXEC().getNsF19A().getNsSign() != null) {
						
						tempBean.setAmountQualifier("EXEC");
						tempBean.setAmountCurrencyCode(tempBean_19a.getNsEXEC().getNsF19A().getNsCurrencyCode());
						tempBean.setAmountSign(tempBean_19a.getNsEXEC().getNsF19A().getNsSign());
						tempBean.setAmountValue(tempBean_19a.getNsEXEC().getNsF19A().getNsAmount());
						
					} else if (tempBean_19a.getNsISDI().getNsF19A().getNsAmount() != null || tempBean_19a.getNsISDI().getNsF19A().getNsCurrencyCode() != null
							|| tempBean_19a.getNsISDI().getNsF19A().getNsSign() != null) {
						
						tempBean.setAmountQualifier("ISDI");
						tempBean.setAmountCurrencyCode(tempBean_19a.getNsISDI().getNsF19A().getNsCurrencyCode());
						tempBean.setAmountSign(tempBean_19a.getNsISDI().getNsF19A().getNsSign());
						tempBean.setAmountValue(tempBean_19a.getNsISDI().getNsF19A().getNsAmount());
						
					} else if (tempBean_19a.getNsLADT().getNsF19A().getNsAmount() != null || tempBean_19a.getNsLADT().getNsF19A().getNsCurrencyCode() != null
							|| tempBean_19a.getNsLADT().getNsF19A().getNsSign() != null) {
						
						tempBean.setAmountQualifier("LADT");
						tempBean.setAmountCurrencyCode(tempBean_19a.getNsLADT().getNsF19A().getNsCurrencyCode());
						tempBean.setAmountSign(tempBean_19a.getNsLADT().getNsF19A().getNsSign());
						tempBean.setAmountValue(tempBean_19a.getNsLADT().getNsF19A().getNsAmount());
						
					} else if (tempBean_19a.getNsLEVY().getNsF19A().getNsAmount() != null || tempBean_19a.getNsLEVY().getNsF19A().getNsCurrencyCode() != null
							|| tempBean_19a.getNsLEVY().getNsF19A().getNsSign() != null) {
						
						tempBean.setAmountQualifier("LEVY");
						tempBean.setAmountCurrencyCode(tempBean_19a.getNsLEVY().getNsF19A().getNsCurrencyCode());
						tempBean.setAmountSign(tempBean_19a.getNsLEVY().getNsF19A().getNsSign());
						tempBean.setAmountValue(tempBean_19a.getNsLEVY().getNsF19A().getNsAmount());
						
					} else if (tempBean_19a.getNsLOCL().getNsF19A().getNsAmount() != null || tempBean_19a.getNsLOCL().getNsF19A().getNsCurrencyCode() != null
							|| tempBean_19a.getNsLOCL().getNsF19A().getNsSign() != null) {
						
						tempBean.setAmountQualifier("LOCL");
						tempBean.setAmountCurrencyCode(tempBean_19a.getNsLOCL().getNsF19A().getNsCurrencyCode());
						tempBean.setAmountSign(tempBean_19a.getNsLOCL().getNsF19A().getNsSign());
						tempBean.setAmountValue(tempBean_19a.getNsLOCL().getNsF19A().getNsAmount());
						
					} else if (tempBean_19a.getNsLOCO().getNsF19A().getNsAmount() != null || tempBean_19a.getNsLOCO().getNsF19A().getNsCurrencyCode() != null
							|| tempBean_19a.getNsLOCO().getNsF19A().getNsSign() != null) {
						
						tempBean.setAmountQualifier("LOCO");
						tempBean.setAmountCurrencyCode(tempBean_19a.getNsLOCO().getNsF19A().getNsCurrencyCode());
						tempBean.setAmountSign(tempBean_19a.getNsLOCO().getNsF19A().getNsSign());
						tempBean.setAmountValue(tempBean_19a.getNsLOCO().getNsF19A().getNsAmount());
						
					} else if (tempBean_19a.getNsMARG().getNsF19A().getNsAmount() != null || tempBean_19a.getNsMARG().getNsF19A().getNsCurrencyCode() != null
							|| tempBean_19a.getNsMARG().getNsF19A().getNsSign() != null) {
						
						tempBean.setAmountQualifier("MARG");
						tempBean.setAmountCurrencyCode(tempBean_19a.getNsMARG().getNsF19A().getNsCurrencyCode());
						tempBean.setAmountSign(tempBean_19a.getNsMARG().getNsF19A().getNsSign());
						tempBean.setAmountValue(tempBean_19a.getNsMARG().getNsF19A().getNsAmount());
						
					} else if (tempBean_19a.getNsOTHR().getNsF19A().getNsAmount() != null || tempBean_19a.getNsOTHR().getNsF19A().getNsCurrencyCode() != null
							|| tempBean_19a.getNsOTHR().getNsF19A().getNsSign() != null) {
						
						tempBean.setAmountQualifier("OTHR");
						tempBean.setAmountCurrencyCode(tempBean_19a.getNsOTHR().getNsF19A().getNsCurrencyCode());
						tempBean.setAmountSign(tempBean_19a.getNsOTHR().getNsF19A().getNsSign());
						tempBean.setAmountValue(tempBean_19a.getNsOTHR().getNsF19A().getNsAmount());
						
					} 
					
					/* Comment the code for SR2012 version - Start
					 
					else if (tempBean_19a.getNsPOST().getNsF19A()
							.getNsAmount() != null
							|| tempBean_19a.getNsPOST().getNsF19A()
									.getNsCurrencyCode() != null
							|| tempBean_19a.getNsPOST().getNsF19A()
									.getNsSign() != null) {
						tempBean.setAmountQualifier("POST");
						tempBean.setAmountCurrencyCode(tempBean_19a
								.getNsPOST().getNsF19A()
								.getNsCurrencyCode());
						tempBean.setAmountSign(tempBean_19a.getNsPOST()
								.getNsF19A().getNsSign());
						tempBean.setAmountValue(tempBean_19a.getNsPOST()
								.getNsF19A().getNsAmount());
					}
					
					 Comment the code for SR2012 version - End  */
					
					 else if (tempBean_19a.getNsREGF().getNsF19A().getNsAmount() != null || tempBean_19a.getNsREGF().getNsF19A().getNsCurrencyCode() != null
							|| tempBean_19a.getNsREGF().getNsF19A().getNsSign() != null) {
						 
						tempBean.setAmountQualifier("REGF");
						tempBean.setAmountCurrencyCode(tempBean_19a.getNsREGF().getNsF19A().getNsCurrencyCode());
						tempBean.setAmountSign(tempBean_19a.getNsREGF().getNsF19A().getNsSign());
						tempBean.setAmountValue(tempBean_19a.getNsREGF().getNsF19A().getNsAmount());
						
					} else if (tempBean_19a.getNsSETT().getNsF19A().getNsAmount() != null || tempBean_19a.getNsSETT().getNsF19A().getNsCurrencyCode() != null
							|| tempBean_19a.getNsSETT().getNsF19A().getNsSign() != null) {
						
						tempBean.setAmountQualifier("SETT");
						tempBean.setAmountCurrencyCode(tempBean_19a.getNsSETT().getNsF19A().getNsCurrencyCode());
						tempBean.setAmountSign(tempBean_19a.getNsSETT().getNsF19A().getNsSign());
						tempBean.setAmountValue(tempBean_19a.getNsSETT().getNsF19A().getNsAmount());
						
					} else if (tempBean_19a.getNsSHIP().getNsF19A().getNsAmount() != null || tempBean_19a.getNsSHIP().getNsF19A().getNsCurrencyCode() != null
							|| tempBean_19a.getNsSHIP().getNsF19A().getNsSign() != null) {
						
						tempBean.setAmountQualifier("SHIP");
						tempBean.setAmountCurrencyCode(tempBean_19a.getNsSHIP().getNsF19A().getNsCurrencyCode());
						tempBean.setAmountSign(tempBean_19a.getNsSHIP().getNsF19A().getNsSign());
						tempBean.setAmountValue(tempBean_19a.getNsSHIP().getNsF19A().getNsAmount());
						
					} else if (tempBean_19a.getNsSPCN().getNsF19A().getNsAmount() != null || tempBean_19a.getNsSPCN().getNsF19A().getNsCurrencyCode() != null
							|| tempBean_19a.getNsSPCN().getNsF19A().getNsSign() != null) {
						
						tempBean.setAmountQualifier("SPCN");
						tempBean.setAmountCurrencyCode(tempBean_19a.getNsSPCN().getNsF19A().getNsCurrencyCode());
						tempBean.setAmountSign(tempBean_19a.getNsSPCN().getNsF19A().getNsSign());
						tempBean.setAmountValue(tempBean_19a.getNsSPCN().getNsF19A().getNsAmount());
						
					} else if (tempBean_19a.getNsSTAM().getNsF19A().getNsAmount() != null || tempBean_19a.getNsSTAM().getNsF19A().getNsCurrencyCode() != null
							|| tempBean_19a.getNsSTAM().getNsF19A().getNsSign() != null) {
						
						tempBean.setAmountQualifier("STAM");
						tempBean.setAmountCurrencyCode(tempBean_19a.getNsSTAM().getNsF19A().getNsCurrencyCode());
						tempBean.setAmountSign(tempBean_19a.getNsSTAM().getNsF19A().getNsSign());
						tempBean.setAmountValue(tempBean_19a.getNsSTAM().getNsF19A().getNsAmount());
						
					} else if (tempBean_19a.getNsSTEX().getNsF19A().getNsAmount() != null || tempBean_19a.getNsSTEX().getNsF19A().getNsCurrencyCode() != null
							|| tempBean_19a.getNsSTEX().getNsF19A().getNsSign() != null) {
						
						tempBean.setAmountQualifier("STEX");
						tempBean.setAmountCurrencyCode(tempBean_19a.getNsSTEX().getNsF19A().getNsCurrencyCode());
						tempBean.setAmountSign(tempBean_19a.getNsSTEX().getNsF19A().getNsSign());
						tempBean.setAmountValue(tempBean_19a.getNsSTEX().getNsF19A().getNsAmount());
						
					} else if (tempBean_19a.getNsTRAN().getNsF19A().getNsAmount() != null || tempBean_19a.getNsTRAN().getNsF19A().getNsCurrencyCode() != null
							|| tempBean_19a.getNsTRAN().getNsF19A().getNsSign() != null) {
						
						tempBean.setAmountQualifier("TRAN");
						tempBean.setAmountCurrencyCode(tempBean_19a.getNsTRAN().getNsF19A().getNsCurrencyCode());
						tempBean.setAmountSign(tempBean_19a.getNsTRAN().getNsF19A().getNsSign());
						tempBean.setAmountValue(tempBean_19a.getNsTRAN().getNsF19A().getNsAmount());
						
					} else if (tempBean_19a.getNsTRAX().getNsF19A().getNsAmount() != null || tempBean_19a.getNsTRAX().getNsF19A().getNsCurrencyCode() != null
							|| tempBean_19a.getNsTRAX().getNsF19A().getNsSign() != null) {
						
						tempBean.setAmountQualifier("TRAX");
						tempBean.setAmountCurrencyCode(tempBean_19a.getNsTRAX().getNsF19A().getNsCurrencyCode());
						tempBean.setAmountSign(tempBean_19a.getNsTRAX().getNsF19A().getNsSign());
						tempBean.setAmountValue(tempBean_19a.getNsTRAX().getNsF19A().getNsAmount());
						
					} else if (tempBean_19a.getNsVATA().getNsF19A().getNsAmount() != null || tempBean_19a.getNsVATA().getNsF19A().getNsCurrencyCode() != null
							|| tempBean_19a.getNsVATA().getNsF19A().getNsSign() != null) {
						
						tempBean.setAmountQualifier("VATA");
						tempBean.setAmountCurrencyCode(tempBean_19a.getNsVATA().getNsF19A().getNsCurrencyCode());
						tempBean.setAmountSign(tempBean_19a.getNsVATA().getNsF19A().getNsSign());
						tempBean.setAmountValue(tempBean_19a.getNsVATA().getNsF19A().getNsAmount());
						
					} else if (tempBean_19a.getNsWITH().getNsF19A().getNsAmount() != null || tempBean_19a.getNsWITH().getNsF19A().getNsCurrencyCode() != null
							|| tempBean_19a.getNsWITH().getNsF19A().getNsSign() != null) {
						
						tempBean.setAmountQualifier("WITH");
						tempBean.setAmountCurrencyCode(tempBean_19a.getNsWITH().getNsF19A().getNsCurrencyCode());
						tempBean.setAmountSign(tempBean_19a.getNsWITH().getNsF19A().getNsSign());
						tempBean.setAmountValue(tempBean_19a.getNsWITH().getNsF19A().getNsAmount());
						
					} else if (tempBean_19a.getNsANTO().getNsF19A().getNsAmount() != null || tempBean_19a.getNsANTO().getNsF19A().getNsCurrencyCode() != null
							|| tempBean_19a.getNsANTO().getNsF19A().getNsSign() != null) {
						
						tempBean.setAmountQualifier("ANTO");
						tempBean.setAmountCurrencyCode(tempBean_19a.getNsANTO().getNsF19A().getNsCurrencyCode());
						tempBean.setAmountSign(tempBean_19a.getNsANTO().getNsF19A().getNsSign());
						tempBean.setAmountValue(tempBean_19a.getNsANTO().getNsF19A().getNsAmount());
						
					} else if (tempBean_19a.getNsBOOK().getNsF19A().getNsAmount() != null || tempBean_19a.getNsBOOK().getNsF19A().getNsCurrencyCode() != null
							|| tempBean_19a.getNsBOOK().getNsF19A().getNsSign() != null) {
						
						tempBean.setAmountQualifier("BOOK");
						tempBean.setAmountCurrencyCode(tempBean_19a.getNsBOOK().getNsF19A().getNsCurrencyCode());
						tempBean.setAmountSign(tempBean_19a.getNsBOOK().getNsF19A().getNsSign());
						tempBean.setAmountValue(tempBean_19a.getNsBOOK().getNsF19A().getNsAmount());
						
					} else if (tempBean_19a.getNsCOAX().getNsF19A().getNsAmount() != null || tempBean_19a.getNsCOAX().getNsF19A().getNsCurrencyCode() != null
							|| tempBean_19a.getNsCOAX().getNsF19A().getNsSign() != null) {
						
						tempBean.setAmountQualifier("COAX");
						tempBean.setAmountCurrencyCode(tempBean_19a.getNsCOAX().getNsF19A().getNsCurrencyCode());
						tempBean.setAmountSign(tempBean_19a.getNsCOAX().getNsF19A().getNsSign());
						tempBean.setAmountValue(tempBean_19a.getNsCOAX().getNsF19A().getNsAmount());
						
					} else if (tempBean_19a.getNsRESU().getNsF19A().getNsAmount() != null || tempBean_19a.getNsRESU().getNsF19A().getNsCurrencyCode() != null
							|| tempBean_19a.getNsRESU().getNsF19A().getNsSign() != null) {
						
						tempBean.setAmountQualifier("RESU");
						tempBean.setAmountCurrencyCode(tempBean_19a.getNsRESU().getNsF19A().getNsCurrencyCode());
						tempBean.setAmountSign(tempBean_19a.getNsRESU().getNsF19A().getNsSign());
						tempBean.setAmountValue(tempBean_19a.getNsRESU().getNsF19A().getNsAmount());
						
					} else if (tempBean_19a.getNsOCMT().getNsF19A().getNsAmount() != null || tempBean_19a.getNsOCMT().getNsF19A().getNsCurrencyCode() != null
							|| tempBean_19a.getNsOCMT().getNsF19A().getNsSign() != null) {
						
						tempBean.setAmountQualifier("OCMT");
						tempBean.setAmountCurrencyCode(tempBean_19a.getNsOCMT().getNsF19A().getNsCurrencyCode());
						tempBean.setAmountSign(tempBean_19a.getNsOCMT().getNsF19A().getNsSign());
						tempBean.setAmountValue(tempBean_19a.getNsOCMT().getNsF19A().getNsAmount());
					}
				}

				tempBean.setFirstCurrencyCode(temp.getNsF92a().getNsEXCH()
						.getNsF92B().getNsFirstCurrencyCode());
				tempBean.setSecondCurrencyCode(temp.getNsF92a().getNsEXCH()
						.getNsF92B().getNsSecondCurrencyCode());
				tempBean.setRate(temp.getNsF92a().getNsEXCH().getNsF92B()
						.getNsRate());

				amountArr[count++] = tempBean;
			}
		}
	}
	// }
	return amountArr;

	}
}