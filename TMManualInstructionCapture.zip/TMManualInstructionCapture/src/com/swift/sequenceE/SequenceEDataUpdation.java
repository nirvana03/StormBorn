package com.swift.sequenceE;

import com.webmethods.caf.faces.util.LogUtils;
import com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE2_F70a_Type;
import com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE2_F95a_Type;
import com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE2_F97a_Type;
import com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE2_Type;
import com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F17a_Type;
import com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F19a_Type;
import com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_Type;
import com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE_F22a_Type;

public class SequenceEDataUpdation {

	public TMCommon_docType_MT54x_docTypeRef_ns_SeqE_F22a_Type[] indicator_22F_Updation(
			Indicator_22F[] indicator) {
		TMCommon_docType_MT54x_docTypeRef_ns_SeqE_F22a_Type[] tempIndicatorArr = null;

		if (indicator != null && indicator.length != 0) {
			tempIndicatorArr = new TMCommon_docType_MT54x_docTypeRef_ns_SeqE_F22a_Type[indicator.length];

			for (int i = 0; i < indicator.length; i++) {

				TMCommon_docType_MT54x_docTypeRef_ns_SeqE_F22a_Type tempBean = new TMCommon_docType_MT54x_docTypeRef_ns_SeqE_F22a_Type();

				Indicator_22F temp = indicator[i];

				if (temp != null && temp.getQualifier() != null) {

					if (temp.getQualifier().equalsIgnoreCase("STCO")) {
						if (temp.getDataSourceScheme() != null
								&& temp.getDataSourceScheme().length() != 0) {
							tempBean.getNsSTCO().getNsF22F()
									.setNsDataSourceScheme(
											temp.getDataSourceSchemeValue());
						}

						tempBean.getNsSTCO().getNsF22F().setNsIndicator(
								temp.getIndicator());
					} else if (temp.getQualifier().equalsIgnoreCase("SETR")) {
						if (temp.getDataSourceScheme() != null
								&& temp.getDataSourceScheme().length() != 0) {
							tempBean.getNsSETR().getNsF22F()
									.setNsDataSourceScheme(
											temp.getDataSourceSchemeValue());
						}

						tempBean.getNsSETR().getNsF22F().setNsIndicator(
								temp.getIndicator());
					} else if (temp.getQualifier().equalsIgnoreCase("TRCA")) {
						if (temp.getDataSourceScheme() != null
								&& temp.getDataSourceScheme().length() != 0) {
							tempBean.getNsTRCA().getNsF22F()
									.setNsDataSourceScheme(
											temp.getDataSourceSchemeValue());
						}

						tempBean.getNsTRCA().getNsF22F().setNsIndicator(
								temp.getIndicator());
					} else if (temp.getQualifier().equalsIgnoreCase("STAM")) {
						if (temp.getDataSourceScheme() != null
								&& temp.getDataSourceScheme().length() != 0) {
							tempBean.getNsSTAM().getNsF22F()
									.setNsDataSourceScheme(
											temp.getDataSourceSchemeValue());
						}

						tempBean.getNsSTAM().getNsF22F().setNsIndicator(
								temp.getIndicator());
					} else if (temp.getQualifier().equalsIgnoreCase("RTGS")) {
						if (temp.getDataSourceScheme() != null
								&& temp.getDataSourceScheme().length() != 0) {
							tempBean.getNsRTGS().getNsF22F()
									.setNsDataSourceScheme(
											temp.getDataSourceSchemeValue());
						}

						tempBean.getNsRTGS().getNsF22F().setNsIndicator(
								temp.getIndicator());
					} else if (temp.getQualifier().equalsIgnoreCase("REGT")) {
						if (temp.getDataSourceScheme() != null
								&& temp.getDataSourceScheme().length() != 0) {
							tempBean.getNsREGT().getNsF22F()
									.setNsDataSourceScheme(
											temp.getDataSourceSchemeValue());
						}

						tempBean.getNsREGT().getNsF22F().setNsIndicator(
								temp.getIndicator());
					} else if (temp.getQualifier().equalsIgnoreCase("BENE")) {
						if (temp.getDataSourceScheme() != null
								&& temp.getDataSourceScheme().length() != 0) {
							tempBean.getNsBENE().getNsF22F()
									.setNsDataSourceScheme(
											temp.getDataSourceSchemeValue());
						}

						tempBean.getNsBENE().getNsF22F().setNsIndicator(
								temp.getIndicator());
					} else if (temp.getQualifier().equalsIgnoreCase("CASY")) {
						if (temp.getDataSourceScheme() != null
								&& temp.getDataSourceScheme().length() != 0) {
							tempBean.getNsCASY().getNsF22F()
									.setNsDataSourceScheme(
											temp.getDataSourceSchemeValue());
						}

						tempBean.getNsCASY().getNsF22F().setNsIndicator(
								temp.getIndicator());
					} else if (temp.getQualifier().equalsIgnoreCase("DBNM")) {
						if (temp.getDataSourceScheme() != null
								&& temp.getDataSourceScheme().length() != 0) {
							tempBean.getNsDBNM().getNsF22F()
									.setNsDataSourceScheme(
											temp.getDataSourceSchemeValue());
						}

						tempBean.getNsDBNM().getNsF22F().setNsIndicator(
								temp.getIndicator());
					} else if (temp.getQualifier().equalsIgnoreCase("TCPI")) {
						if (temp.getDataSourceScheme() != null
								&& temp.getDataSourceScheme().length() != 0) {
							tempBean.getNsTCPI().getNsF22F()
									.setNsDataSourceScheme(
											temp.getDataSourceSchemeValue());
						}

						tempBean.getNsTCPI().getNsF22F().setNsIndicator(
								temp.getIndicator());
					} else if (temp.getQualifier().equalsIgnoreCase("MACL")) {
						if (temp.getDataSourceScheme() != null
								&& temp.getDataSourceScheme().length() != 0) {
							tempBean.getNsMACL().getNsF22F()
									.setNsDataSourceScheme(
											temp.getDataSourceSchemeValue());
						}

						tempBean.getNsMACL().getNsF22F().setNsIndicator(
								temp.getIndicator());
					} else if (temp.getQualifier().equalsIgnoreCase("FXCX")) {
						if (temp.getDataSourceScheme() != null
								&& temp.getDataSourceScheme().length() != 0) {
							tempBean.getNsFXCX().getNsF22F()
									.setNsDataSourceScheme(
											temp.getDataSourceSchemeValue());
						}

						tempBean.getNsFXCX().getNsF22F().setNsIndicator(
								temp.getIndicator());
					} else if (temp.getQualifier().equalsIgnoreCase("BLOC")) {
						if (temp.getDataSourceScheme() != null
								&& temp.getDataSourceScheme().length() != 0) {
							tempBean.getNsBLOC().getNsF22F()
									.setNsDataSourceScheme(
											temp.getDataSourceSchemeValue());
						}

						tempBean.getNsBLOC().getNsF22F().setNsIndicator(
								temp.getIndicator());
					} else if (temp.getQualifier().equalsIgnoreCase("REST")) {
						if (temp.getDataSourceScheme() != null
								&& temp.getDataSourceScheme().length() != 0) {
							tempBean.getNsREST().getNsF22F()
									.setNsDataSourceScheme(
											temp.getDataSourceSchemeValue());
						}

						tempBean.getNsREST().getNsF22F().setNsIndicator(
								temp.getIndicator());
					} else if (temp.getQualifier().equalsIgnoreCase("SETS")) {
						if (temp.getDataSourceScheme() != null
								&& temp.getDataSourceScheme().length() != 0) {
							tempBean.getNsSETS().getNsF22F()
									.setNsDataSourceScheme(
											temp.getDataSourceSchemeValue());
						}

						tempBean.getNsSETS().getNsF22F().setNsIndicator(
								temp.getIndicator());
					} else if (temp.getQualifier().equalsIgnoreCase("NETT")) {
						if (temp.getDataSourceScheme() != null
								&& temp.getDataSourceScheme().length() != 0) {
							tempBean.getNsNETT().getNsF22F()
									.setNsDataSourceScheme(
											temp.getDataSourceSchemeValue());
						}

						tempBean.getNsNETT().getNsF22F().setNsIndicator(
								temp.getIndicator());
					} else if (temp.getQualifier().equalsIgnoreCase("CCPT")) {
						if (temp.getDataSourceScheme() != null
								&& temp.getDataSourceScheme().length() != 0) {
							tempBean.getNsCCPT().getNsF22F()
									.setNsDataSourceScheme(
											temp.getDataSourceSchemeValue());
						}

						tempBean.getNsCCPT().getNsF22F().setNsIndicator(
								temp.getIndicator());
					} else if (temp.getQualifier().equalsIgnoreCase("LEOG")) {
						if (temp.getDataSourceScheme() != null
								&& temp.getDataSourceScheme().length() != 0) {
							tempBean.getNsLEOG().getNsF22F()
									.setNsDataSourceScheme(
											temp.getDataSourceSchemeValue());
						}

						tempBean.getNsLEOG().getNsF22F().setNsIndicator(
								temp.getIndicator());
					} else if (temp.getQualifier().equalsIgnoreCase("COLA")) {
						if (temp.getDataSourceScheme() != null
								&& temp.getDataSourceScheme().length() != 0) {
							tempBean.getNsCOLA().getNsF22F()
									.setNsDataSourceScheme(
											temp.getDataSourceSchemeValue());
						}

						tempBean.getNsCOLA().getNsF22F().setNsIndicator(
								temp.getIndicator());
					} else if (temp.getQualifier().equalsIgnoreCase("TRAK")) {
						if (temp.getDataSourceScheme() != null
								&& temp.getDataSourceScheme().length() != 0) {
							tempBean.getNsTRAK().getNsF22F()
									.setNsDataSourceScheme(
											temp.getDataSourceSchemeValue());
						}

						tempBean.getNsTRAK().getNsF22F().setNsIndicator(
								temp.getIndicator());
					} else if (temp.getQualifier().equalsIgnoreCase("REPT")) {
						if (temp.getDataSourceScheme() != null
								&& temp.getDataSourceScheme().length() != 0) {
							tempBean.getNsREPT().getNsF22F()
									.setNsDataSourceScheme(
											temp.getDataSourceSchemeValue());
						}

						tempBean.getNsREPT().getNsF22F().setNsIndicator(
								temp.getIndicator());
					} else if (temp.getQualifier().equalsIgnoreCase("COLE")) {
						if (temp.getDataSourceScheme() != null
								&& temp.getDataSourceScheme().length() != 0) {
							tempBean.getNsCOLE().getNsF22F()
									.setNsDataSourceScheme(
											temp.getDataSourceSchemeValue());
						}

						tempBean.getNsCOLE().getNsF22F().setNsIndicator(
								temp.getIndicator());
					} else if (temp.getQualifier().equalsIgnoreCase("SSBT")) {

						if (temp.getDataSourceScheme() != null
								&& temp.getDataSourceScheme().length() != 0) {
							tempBean.getNsSSBT().getNsF22F()
									.setNsDataSourceScheme(
											temp.getDataSourceSchemeValue());
						}

						tempBean.getNsSSBT().getNsF22F().setNsIndicator(
								temp.getIndicator());

					} else if (temp.getQualifier().equalsIgnoreCase("CSBT")) {

						if (temp.getDataSourceScheme() != null
								&& temp.getDataSourceScheme().length() != 0) {
							tempBean.getNsCSBT().getNsF22F()
									.setNsDataSourceScheme(
											temp.getDataSourceSchemeValue());
						}

						tempBean.getNsCSBT().getNsF22F().setNsIndicator(
								temp.getIndicator());
					}
					tempIndicatorArr[i] = tempBean;
				}

			}

		}

		return tempIndicatorArr;

	}

	public TMCommon_docType_MT54x_docTypeRef_ns_SeqE2_Type[] seqEE2_Updation(
			CashParties_E2[] cashParties) {

		TMCommon_docType_MT54x_docTypeRef_ns_SeqE2_Type[] tempCashPartiesArr = null;
		
	//	LogUtils.log("Seq E data updation------------Cash parties length------"+cashParties.length);

		if (cashParties != null && cashParties.length != 0) {
			tempCashPartiesArr = new TMCommon_docType_MT54x_docTypeRef_ns_SeqE2_Type[cashParties.length];

			for (int i = 0; i < cashParties.length; i++) {
				
				
				TMCommon_docType_MT54x_docTypeRef_ns_SeqE2_Type tempBean = new TMCommon_docType_MT54x_docTypeRef_ns_SeqE2_Type();

				TMCommon_docType_MT54x_docTypeRef_ns_SeqE2_F95a_Type[] temp95a = new TMCommon_docType_MT54x_docTypeRef_ns_SeqE2_F95a_Type[2];//SR2016 changed size from 1 to 2
				TMCommon_docType_MT54x_docTypeRef_ns_SeqE2_F95a_Type tempBean95a = new TMCommon_docType_MT54x_docTypeRef_ns_SeqE2_F95a_Type();
				TMCommon_docType_MT54x_docTypeRef_ns_SeqE2_F95a_Type tempBean95a1 = new TMCommon_docType_MT54x_docTypeRef_ns_SeqE2_F95a_Type();//SR2016

				TMCommon_docType_MT54x_docTypeRef_ns_SeqE2_F97a_Type[] temp97a = new TMCommon_docType_MT54x_docTypeRef_ns_SeqE2_F97a_Type[1];
				TMCommon_docType_MT54x_docTypeRef_ns_SeqE2_F97a_Type tempBean97a = new TMCommon_docType_MT54x_docTypeRef_ns_SeqE2_F97a_Type();

				TMCommon_docType_MT54x_docTypeRef_ns_SeqE2_F70a_Type[] temp70a = new TMCommon_docType_MT54x_docTypeRef_ns_SeqE2_F70a_Type[1];
				TMCommon_docType_MT54x_docTypeRef_ns_SeqE2_F70a_Type tempBean70a = new TMCommon_docType_MT54x_docTypeRef_ns_SeqE2_F70a_Type();
				
				
				CashParties_E2 temp = cashParties[i];

				if (temp != null && temp.getCashPartyQualifier() != null) {

					if (temp.getCashPartyQualifier().equalsIgnoreCase("ACCW")
							&& temp.getCashPartyOption() != null) {
						if (temp.getCashPartyOption() != null
								&& temp.getCashPartyOption().equalsIgnoreCase(
										"Identifier Code")) {
							//LogUtils.log("SeqE Update---Cash----ACCW--Identifer code---");
							tempBean95a.getNsACCW().getNsF95P()
									.setNsIdentifierCode(
											temp.getCashPartyValue());
						} else if (temp.getCashPartyOption().equalsIgnoreCase(
								"Name and Address")) {
							String[] tempStr = new String[4];
							tempStr[0] = temp.getAddress1();
							tempStr[1] = temp.getAddress2();
							tempStr[2] = temp.getAddress3();
							tempStr[3] = temp.getAddress4();
							tempBean95a.getNsACCW().getNsF95Q()
									.getNsNameAndAddress().setNsLine(tempStr);
						} else if (temp.getCashPartyOption().equalsIgnoreCase(
								"Proprietary Code")) {
							tempBean95a.getNsACCW().getNsF95R()
									.setNsDataSourceScheme(
											temp.getDataSourceSchemeValue());
							tempBean95a.getNsACCW().getNsF95R()
									.setNsProprietaryCode(
											temp.getCashPartyValue());

						}
						
						//SR2016
						if(temp.getLegalEntityIdentifier()!=null){
							//LogUtils.log("SeqE Update---Cash----ACCW--LEI---");
							tempBean95a1.getNsALTE().getNsF95L().setNsLegalEntityIdentifier(temp.getLegalEntityIdentifier());
						}

					}
					// Coded Add Newly Qualifier INTM -------Rohit Gupta

					else if (temp.getCashPartyQualifier().equalsIgnoreCase("INTM")
								&& temp.getCashPartyOption() != null) {
							if (temp.getCashPartyOption() != null
									&& temp.getCashPartyOption().equalsIgnoreCase(
											"Identifier Code")) {
								tempBean95a.getNsINTM().getNsF95P()
										.setNsIdentifierCode(
												temp.getCashPartyValue());
							} else if (temp.getCashPartyOption().equalsIgnoreCase(
									"Name and Address")) {
								String[] tempStr = new String[4];
								tempStr[0] = temp.getAddress1();
								tempStr[1] = temp.getAddress2();
								tempStr[2] = temp.getAddress3();
								tempStr[3] = temp.getAddress4();
								tempBean95a.getNsINTM().getNsF95Q()
										.getNsNameAndAddress().setNsLine(tempStr);
							} else if (temp.getCashPartyOption().equalsIgnoreCase(
									"Proprietary Code")) {
								tempBean95a.getNsINTM().getNsF95R()
										.setNsDataSourceScheme(
												temp.getDataSourceSchemeValue());
								tempBean95a.getNsINTM().getNsF95R()
										.setNsProprietaryCode(
												temp.getCashPartyValue());

							}
							//SR2016
							if(temp.getLegalEntityIdentifier()!=null){
								
								tempBean95a1.getNsALTE().getNsF95L().setNsLegalEntityIdentifier(temp.getLegalEntityIdentifier());
							}

						}
						else if (temp.getCashPartyOption() != null
							&& temp.getCashPartyQualifier().equalsIgnoreCase(
									"BENM")) {
						if (temp.getCashPartyOption().equalsIgnoreCase(
								"Identifier Code")) {
							tempBean95a.getNsBENM().getNsF95P()
									.setNsIdentifierCode(
											temp.getCashPartyValue());
						} else if (temp.getCashPartyOption().equalsIgnoreCase(
								"Name and Address")) {
							String[] tempStr = new String[4];
							tempStr[0] = temp.getAddress1();
							tempStr[1] = temp.getAddress2();
							tempStr[2] = temp.getAddress3();
							tempStr[3] = temp.getAddress4();
							tempBean95a.getNsBENM().getNsF95Q()
									.getNsNameAndAddress().setNsLine(tempStr);
						} else if (temp.getCashPartyOption().equalsIgnoreCase(
								"Proprietary Code")) {
							tempBean95a.getNsBENM().getNsF95R()
									.setNsDataSourceScheme(
											temp.getDataSourceSchemeValue());
							tempBean95a.getNsBENM().getNsF95R()
									.setNsProprietaryCode(
											temp.getCashPartyValue());

						}
						
						if(temp.getLegalEntityIdentifier()!=null){
							//LogUtils.log("SeqE Update---Cash----BENM--LEI---");
							tempBean95a1.getNsALTE().getNsF95L().setNsLegalEntityIdentifier(temp.getLegalEntityIdentifier());
						}

					} 
				/*	
				 * //SR2016
						else if (temp.getCashPartyOption() != null
								&& temp.getCashPartyQualifier().equalsIgnoreCase(
										"ALTE1"))
						{
							if (temp.getCashPartyOption().equalsIgnoreCase(
									"LegalEntityIdentifier")) {
								tempBean95a.getNsALTE().getNsF95L().setNsLegalEntityIdentifier(
												temp.getCashPartyValue());
							}
						}
						//SR2016
						 * */
						 
						else if (temp.getCashPartyOption() != null
							&& temp.getCashPartyQualifier().equalsIgnoreCase(
									"DEBT")) {
						if (temp.getCashPartyOption().equalsIgnoreCase(
								"Identifier Code")) {
							tempBean95a.getNsDEBT().getNsF95P()
									.setNsIdentifierCode(
											temp.getCashPartyValue());
						} else if (temp.getCashPartyOption().equalsIgnoreCase(
								"Name and Address")) {
							String[] tempStr = new String[4];
							tempStr[0] = temp.getAddress1();
							tempStr[1] = temp.getAddress2();
							tempStr[2] = temp.getAddress3();
							tempStr[3] = temp.getAddress4();
							tempBean95a.getNsDEBT().getNsF95Q()
									.getNsNameAndAddress().setNsLine(tempStr);
						} else if (temp.getCashPartyOption().equalsIgnoreCase(
								"Proprietary Code")) {
							tempBean95a.getNsDEBT().getNsF95R()
									.setNsDataSourceScheme(
											temp.getDataSourceSchemeValue());
							tempBean95a.getNsDEBT().getNsF95R()
									.setNsProprietaryCode(
											temp.getCashPartyValue());

						}
						
						if(null!=temp.getLegalEntityIdentifier()){
							//LogUtils.log("SeqE Update---Cash----DEBT--LEI---");
							tempBean95a1.getNsALTE().getNsF95L().setNsLegalEntityIdentifier(temp.getLegalEntityIdentifier());
						}

					} else if (temp.getCashPartyOption() != null
							&& temp.getCashPartyQualifier().equalsIgnoreCase(
									"PAYE")) {
						if (temp.getCashPartyOption().equalsIgnoreCase(
								"Identifier Code")) {
							tempBean95a.getNsPAYE().getNsF95P()
									.setNsIdentifierCode(
											temp.getCashPartyValue());
						} else if (temp.getCashPartyOption().equalsIgnoreCase(
								"Name and Address")) {
							String[] tempStr = new String[4];
							tempStr[0] = temp.getAddress1();
							tempStr[1] = temp.getAddress2();
							tempStr[2] = temp.getAddress3();
							tempStr[3] = temp.getAddress4();
							tempBean95a.getNsPAYE().getNsF95Q()
									.getNsNameAndAddress().setNsLine(tempStr);
						} else if (temp.getCashPartyOption().equalsIgnoreCase(
								"Proprietary Code")) {
							tempBean95a.getNsPAYE().getNsF95R()
									.setNsDataSourceScheme(
											temp.getDataSourceSchemeValue());
							tempBean95a.getNsPAYE().getNsF95R()
									.setNsProprietaryCode(
											temp.getCashPartyValue());

						}
						if(null!=temp.getLegalEntityIdentifier()){
							//LogUtils.log("SeqE Update---Cash----PAYE--LEI---");
							tempBean95a1.getNsALTE().getNsF95L().setNsLegalEntityIdentifier(temp.getLegalEntityIdentifier());
						}

					}

					temp95a[0] = tempBean95a;
					if(null!=tempBean95a1){
					temp95a[1]=tempBean95a1;
					}
					tempBean.setNsF95a(temp95a);
					//LogUtils.log("Seq E update---setting tempBean----temp95a length>>>"+temp95a.length);

				}

				if (temp != null && temp.getAccountQualifier() != null) {

					if (temp.getAccountOption() != null
							&& temp.getAccountQualifier().equalsIgnoreCase(
									"CASH")) {
						if (temp.getAccountOption().equalsIgnoreCase("AccNo")) {
							tempBean97a.getNsCASH().getNsF97A()
									.setNsAccountNumber(temp.getAccount());
						} else if (temp.getAccountOption().equalsIgnoreCase(
								"IBAN")) {
							tempBean97a.getNsCASH().getNsF97E()
									.setNsInternationalBankAccountNumber(
											temp.getAccount());
						}
					} else if (temp.getAccountOption() != null
							&& temp.getAccountQualifier().equalsIgnoreCase(
									"CHAR")) {
						if (temp.getAccountOption().equalsIgnoreCase("AccNo")) {
							tempBean97a.getNsCHAR().getNsF97A()
									.setNsAccountNumber(temp.getAccount());
						} else if (temp.getAccountOption().equalsIgnoreCase(
								"IBAN")) {
							tempBean97a.getNsCHAR().getNsF97E()
									.setNsInternationalBankAccountNumber(
											temp.getAccount());
						}
					} else if (temp.getAccountOption() != null
							&& temp.getAccountQualifier().equalsIgnoreCase(
									"COMM")) {
						if (temp.getAccountOption().equalsIgnoreCase("AccNo")) {
							tempBean97a.getNsCOMM().getNsF97A()
									.setNsAccountNumber(temp.getAccount());
						} else if (temp.getAccountOption().equalsIgnoreCase(
								"IBAN")) {
							tempBean97a.getNsCOMM().getNsF97E()
									.setNsInternationalBankAccountNumber(
											temp.getAccount());
						}
					} else if (temp.getAccountOption() != null
							&& temp.getAccountQualifier().equalsIgnoreCase(
									"TAXE")) {
						if (temp.getAccountOption().equalsIgnoreCase("AccNo")) {
							tempBean97a.getNsTAXE().getNsF97A()
									.setNsAccountNumber(temp.getAccount());
						} else if (temp.getAccountOption().equalsIgnoreCase(
								"IBAN")) {
							tempBean97a.getNsTAXE().getNsF97E()
									.setNsInternationalBankAccountNumber(
											temp.getAccount());
						}
					}

					temp97a[0] = tempBean97a;
					tempBean.setNsF97a(temp97a);

				}

				if (temp != null && temp.getNarrativeQualifier() != null) {

					if (temp.getNarrativeQualifier().equalsIgnoreCase("DECL")) {
						String[] tempStr = new String[10];
						tempStr[0] = temp.getNarrative1();
						tempStr[1] = temp.getNarrative2();
						tempStr[2] = temp.getNarrative3();
						tempStr[3] = temp.getNarrative4();
						tempStr[4] = temp.getNarrative5();
						tempStr[5] = temp.getNarrative6();
						tempStr[6] = temp.getNarrative7();
						tempStr[7] = temp.getNarrative8();
						tempStr[8] = temp.getNarrative9();
						tempStr[9] = temp.getNarrative10();
						tempBean70a.getNsDECL().getNsF70E().getNsNarrative()
								.setNsLine(tempStr);

					} else if (temp.getNarrativeQualifier().equalsIgnoreCase(
							"PACO")) {
						String[] tempStr = new String[4];
						tempStr[0] = temp.getNarrative1();
						tempStr[1] = temp.getNarrative2();
						tempStr[2] = temp.getNarrative3();
						tempStr[3] = temp.getNarrative4();
						tempBean70a.getNsPACO().getNsF70C().getNsNarrative()
								.setNsLine(tempStr);
					}

					temp70a[0] = tempBean70a;
					tempBean.setNsF70a(temp70a);
				}
				tempBean.getNsF16a_1().setNsF16R("CSHPRTY");
				tempBean.getNsF16a_2().setNsF16S("CSHPRTY");
				tempCashPartiesArr[i] = tempBean;
		//		LogUtils.log("Seq E update---setting tempCashparty arrayp--length is "+tempCashPartiesArr.length+"---"+tempCashPartiesArr[0].getNsF95a()[0].getNsALTE().getNsF95L().getNsLegalEntityIdentifier());
		//		LogUtils.log("Seq E update---setting tempCashparty arrayp--length is "+tempCashPartiesArr.length+"---"+tempCashPartiesArr[0].getNsF95a()[0].getNsACCW().getNsF95P().getNsIdentifierCode());
				

			}

		}

		return tempCashPartiesArr;

	}

	public TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_Type[] seqEE3_Updation(Amount_E3[] amount) {
		
		TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_Type[] tempAmtArr = null;

			if (amount != null && amount.length != 0) {
				tempAmtArr = new TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_Type[amount.length];

				for (int i = 0; i < amount.length; i++) {
					TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_Type tempBean = new TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_Type();
					Amount_E3 temp = amount[i];

					TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F17a_Type[] temp17a = new TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F17a_Type[1];
					TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F17a_Type tempBean17a = new TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F17a_Type();

					TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F19a_Type[] temp19a = new TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F19a_Type[1];
					TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F19a_Type tempBean19a = new TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F19a_Type();

					if (temp != null && temp.getFlagQualifier() != null) {
						if (temp.getFlagQualifier() != null
								&& temp.getFlagQualifier().equalsIgnoreCase("ACRU")) {
							tempBean17a.getNsACRU().getNsF17B().setNsFlag(
									temp.getFlagValue());
						} else if (temp.getFlagQualifier() != null
								&& temp.getFlagQualifier().equalsIgnoreCase("STAM")) {
							tempBean17a.getNsSTAM().getNsF17B().setNsFlag(
									temp.getFlagValue());
						}else if (temp.getFlagQualifier() != null
								&& temp.getFlagQualifier().equalsIgnoreCase("EXEC")) {
							tempBean17a.getNsEXEC().getNsF17B().setNsFlag(temp.getFlagValue());
							
						}

						temp17a[0] = tempBean17a;
						tempBean.setNsF17a(temp17a);
					}

					if (temp != null && temp.getAmountQualifier() != null) {

						if (temp.getAmountQualifier().equalsIgnoreCase("ACRU")) {
							tempBean19a.getNsACRU().getNsF19A().setNsAmount(
									getUpdatedAmtValue(temp.getAmountValue()));
							tempBean19a.getNsACRU().getNsF19A().setNsCurrencyCode(
									temp.getAmountCurrencyCode());
							tempBean19a.getNsACRU().getNsF19A().setNsSign(
									temp.getAmountSign());
						} else if (temp.getAmountQualifier().equalsIgnoreCase(
								"CHAR")) {
							tempBean19a.getNsCHAR().getNsF19A().setNsAmount(
									getUpdatedAmtValue(temp.getAmountValue()));
							tempBean19a.getNsCHAR().getNsF19A().setNsCurrencyCode(
									temp.getAmountCurrencyCode());
							tempBean19a.getNsCHAR().getNsF19A().setNsSign(
									temp.getAmountSign());
						} else if (temp.getAmountQualifier().equalsIgnoreCase(
								"COUN")) {
							tempBean19a.getNsCOUN().getNsF19A().setNsAmount(
									getUpdatedAmtValue(temp.getAmountValue()));
							tempBean19a.getNsCOUN().getNsF19A().setNsCurrencyCode(
									temp.getAmountCurrencyCode());
							tempBean19a.getNsCOUN().getNsF19A().setNsSign(
									temp.getAmountSign());
						} else if (temp.getAmountQualifier().equalsIgnoreCase(
								"DEAL")) {
							tempBean19a.getNsDEAL().getNsF19A().setNsAmount(
									getUpdatedAmtValue(temp.getAmountValue()));
							tempBean19a.getNsDEAL().getNsF19A().setNsCurrencyCode(
									temp.getAmountCurrencyCode());
							tempBean19a.getNsDEAL().getNsF19A().setNsSign(
									temp.getAmountSign());
						} else if (temp.getAmountQualifier().equalsIgnoreCase(
								"EXEC")) {
							tempBean19a.getNsEXEC().getNsF19A().setNsAmount(
									getUpdatedAmtValue(temp.getAmountValue()));
							tempBean19a.getNsEXEC().getNsF19A().setNsCurrencyCode(
									temp.getAmountCurrencyCode());
							tempBean19a.getNsEXEC().getNsF19A().setNsSign(
									temp.getAmountSign());
						} else if (temp.getAmountQualifier().equalsIgnoreCase(
								"ISDI")) {
							tempBean19a.getNsISDI().getNsF19A().setNsAmount(
									getUpdatedAmtValue(temp.getAmountValue()));
							tempBean19a.getNsISDI().getNsF19A().setNsCurrencyCode(
									temp.getAmountCurrencyCode());
							tempBean19a.getNsISDI().getNsF19A().setNsSign(
									temp.getAmountSign());
						} else if (temp.getAmountQualifier().equalsIgnoreCase(
								"LADT")) {
							tempBean19a.getNsLADT().getNsF19A().setNsAmount(
									getUpdatedAmtValue(temp.getAmountValue()));
							tempBean19a.getNsLADT().getNsF19A().setNsCurrencyCode(
									temp.getAmountCurrencyCode());
							tempBean19a.getNsLADT().getNsF19A().setNsSign(
									temp.getAmountSign());
						} else if (temp.getAmountQualifier().equalsIgnoreCase(
								"LEVY")) {
							tempBean19a.getNsLEVY().getNsF19A().setNsAmount(
									getUpdatedAmtValue(temp.getAmountValue()));
							tempBean19a.getNsLEVY().getNsF19A().setNsCurrencyCode(
									temp.getAmountCurrencyCode());
							tempBean19a.getNsLEVY().getNsF19A().setNsSign(
									temp.getAmountSign());
						} else if (temp.getAmountQualifier().equalsIgnoreCase(
								"LOCL")) {
							tempBean19a.getNsLOCL().getNsF19A().setNsAmount(
									getUpdatedAmtValue(temp.getAmountValue()));
							tempBean19a.getNsLOCL().getNsF19A().setNsCurrencyCode(
									temp.getAmountCurrencyCode());
							tempBean19a.getNsLOCL().getNsF19A().setNsSign(
									temp.getAmountSign());
						} else if (temp.getAmountQualifier().equalsIgnoreCase(
								"LOCO")) {
							tempBean19a.getNsLOCO().getNsF19A().setNsAmount(
									getUpdatedAmtValue(temp.getAmountValue()));
							tempBean19a.getNsLOCO().getNsF19A().setNsCurrencyCode(
									temp.getAmountCurrencyCode());
							tempBean19a.getNsLOCO().getNsF19A().setNsSign(
									temp.getAmountSign());
						} else if (temp.getAmountQualifier().equalsIgnoreCase(
								"MARG")) {
							tempBean19a.getNsMARG().getNsF19A().setNsAmount(
									getUpdatedAmtValue(temp.getAmountValue()));
							tempBean19a.getNsMARG().getNsF19A().setNsCurrencyCode(
									temp.getAmountCurrencyCode());
							tempBean19a.getNsMARG().getNsF19A().setNsSign(
									temp.getAmountSign());
						} else if (temp.getAmountQualifier().equalsIgnoreCase(
								"OTHR")) {
							tempBean19a.getNsOTHR().getNsF19A().setNsAmount(
									getUpdatedAmtValue(temp.getAmountValue()));
							tempBean19a.getNsOTHR().getNsF19A().setNsCurrencyCode(
									temp.getAmountCurrencyCode());
							tempBean19a.getNsOTHR().getNsF19A().setNsSign(
									temp.getAmountSign());
						} 
						
						/* Comment the code for SR2012 version - Start
						 
						else if (temp.getAmountQualifier().equalsIgnoreCase(
								"POST")) {
							tempBean19a.getNsPOST().getNsF19A().setNsAmount(
									getUpdatedAmtValue(temp.getAmountValue()));
							tempBean19a.getNsPOST().getNsF19A().setNsCurrencyCode(
									temp.getAmountCurrencyCode());
							tempBean19a.getNsPOST().getNsF19A().setNsSign(
									temp.getAmountSign());
						} 
						
						Comment the code for SR2012 version - End */
						
						else if (temp.getAmountQualifier().equalsIgnoreCase(
								"REGF")) {
							tempBean19a.getNsREGF().getNsF19A().setNsAmount(
									getUpdatedAmtValue(temp.getAmountValue()));
							tempBean19a.getNsREGF().getNsF19A().setNsCurrencyCode(
									temp.getAmountCurrencyCode());
							tempBean19a.getNsREGF().getNsF19A().setNsSign(
									temp.getAmountSign());
						} else if (temp.getAmountQualifier().equalsIgnoreCase(
								"SETT")) {
							tempBean19a.getNsSETT().getNsF19A().setNsAmount(
									getUpdatedAmtValue(temp.getAmountValue()));
							tempBean19a.getNsSETT().getNsF19A().setNsCurrencyCode(
									temp.getAmountCurrencyCode());
							tempBean19a.getNsSETT().getNsF19A().setNsSign(
									temp.getAmountSign());
						} else if (temp.getAmountQualifier().equalsIgnoreCase(
								"SHIP")) {
							tempBean19a.getNsSHIP().getNsF19A().setNsAmount(
									getUpdatedAmtValue(temp.getAmountValue()));
							tempBean19a.getNsSHIP().getNsF19A().setNsCurrencyCode(
									temp.getAmountCurrencyCode());
							tempBean19a.getNsSHIP().getNsF19A().setNsSign(
									temp.getAmountSign());
						} else if (temp.getAmountQualifier().equalsIgnoreCase(
								"SPCN")) {
							tempBean19a.getNsSPCN().getNsF19A().setNsAmount(
									getUpdatedAmtValue(temp.getAmountValue()));
							tempBean19a.getNsSPCN().getNsF19A().setNsCurrencyCode(
									temp.getAmountCurrencyCode());
							tempBean19a.getNsSPCN().getNsF19A().setNsSign(
									temp.getAmountSign());
						} else if (temp.getAmountQualifier().equalsIgnoreCase(
								"STAM")) {
							tempBean19a.getNsSTAM().getNsF19A().setNsAmount(
									getUpdatedAmtValue(temp.getAmountValue()));
							tempBean19a.getNsSTAM().getNsF19A().setNsCurrencyCode(
									temp.getAmountCurrencyCode());
							tempBean19a.getNsSTAM().getNsF19A().setNsSign(
									temp.getAmountSign());
						} else if (temp.getAmountQualifier().equalsIgnoreCase(
								"STEX")) {
							tempBean19a.getNsSTEX().getNsF19A().setNsAmount(
									getUpdatedAmtValue(temp.getAmountValue()));
							tempBean19a.getNsSTEX().getNsF19A().setNsCurrencyCode(
									temp.getAmountCurrencyCode());
							tempBean19a.getNsSTEX().getNsF19A().setNsSign(
									temp.getAmountSign());
						} else if (temp.getAmountQualifier().equalsIgnoreCase(
								"TRAN")) {
							tempBean19a.getNsTRAN().getNsF19A().setNsAmount(
									getUpdatedAmtValue(temp.getAmountValue()));
							tempBean19a.getNsTRAN().getNsF19A().setNsCurrencyCode(
									temp.getAmountCurrencyCode());
							tempBean19a.getNsTRAN().getNsF19A().setNsSign(
									temp.getAmountSign());
						} else if (temp.getAmountQualifier().equalsIgnoreCase(
								"TRAX")) {
							tempBean19a.getNsTRAX().getNsF19A().setNsAmount(
									getUpdatedAmtValue(temp.getAmountValue()));
							tempBean19a.getNsTRAX().getNsF19A().setNsCurrencyCode(
									temp.getAmountCurrencyCode());
							tempBean19a.getNsTRAX().getNsF19A().setNsSign(
									temp.getAmountSign());
						} else if (temp.getAmountQualifier().equalsIgnoreCase(
								"VATA")) {
							tempBean19a.getNsVATA().getNsF19A().setNsAmount(
									getUpdatedAmtValue(temp.getAmountValue()));
							tempBean19a.getNsVATA().getNsF19A().setNsCurrencyCode(
									temp.getAmountCurrencyCode());
							tempBean19a.getNsVATA().getNsF19A().setNsSign(
									temp.getAmountSign());
						} else if (temp.getAmountQualifier().equalsIgnoreCase(
								"WITH")) {
							tempBean19a.getNsWITH().getNsF19A().setNsAmount(
									getUpdatedAmtValue(temp.getAmountValue()));
							tempBean19a.getNsWITH().getNsF19A().setNsCurrencyCode(
									temp.getAmountCurrencyCode());
							tempBean19a.getNsWITH().getNsF19A().setNsSign(
									temp.getAmountSign());
						} else if (temp.getAmountQualifier().equalsIgnoreCase(
								"ANTO")) {
							tempBean19a.getNsANTO().getNsF19A().setNsAmount(
									getUpdatedAmtValue(temp.getAmountValue()));
							tempBean19a.getNsANTO().getNsF19A().setNsCurrencyCode(
									temp.getAmountCurrencyCode());
							tempBean19a.getNsANTO().getNsF19A().setNsSign(
									temp.getAmountSign());
						} else if (temp.getAmountQualifier().equalsIgnoreCase(
								"BOOK")) {
							tempBean19a.getNsBOOK().getNsF19A().setNsAmount(
									getUpdatedAmtValue(temp.getAmountValue()));
							tempBean19a.getNsBOOK().getNsF19A().setNsCurrencyCode(
									temp.getAmountCurrencyCode());
							tempBean19a.getNsBOOK().getNsF19A().setNsSign(
									temp.getAmountSign());
						} else if (temp.getAmountQualifier().equalsIgnoreCase(
								"COAX")) {
							tempBean19a.getNsCOAX().getNsF19A().setNsAmount(
									getUpdatedAmtValue(temp.getAmountValue()));
							tempBean19a.getNsCOAX().getNsF19A().setNsCurrencyCode(
									temp.getAmountCurrencyCode());
							tempBean19a.getNsCOAX().getNsF19A().setNsSign(
									temp.getAmountSign());
						} else if (temp.getAmountQualifier().equalsIgnoreCase(
								"ACCA")) {
							tempBean19a.getNsACCA().getNsF19A().setNsAmount(
									getUpdatedAmtValue(temp.getAmountValue()));
							tempBean19a.getNsACCA().getNsF19A().setNsCurrencyCode(
									temp.getAmountCurrencyCode());
							tempBean19a.getNsACCA().getNsF19A().setNsSign(
									temp.getAmountSign());
						} else if (temp.getAmountQualifier().equalsIgnoreCase(
								"RESU")) {
							tempBean19a.getNsRESU().getNsF19A().setNsAmount(
									getUpdatedAmtValue(temp.getAmountValue()));
							tempBean19a.getNsRESU().getNsF19A().setNsCurrencyCode(
									temp.getAmountCurrencyCode());
							tempBean19a.getNsRESU().getNsF19A().setNsSign(
									temp.getAmountSign());
						} else if (temp.getAmountQualifier().equalsIgnoreCase(
								"OCMT")) {
							tempBean19a.getNsOCMT().getNsF19A().setNsAmount(
									getUpdatedAmtValue(temp.getAmountValue()));
							tempBean19a.getNsOCMT().getNsF19A().setNsCurrencyCode(
									temp.getAmountCurrencyCode());
							tempBean19a.getNsOCMT().getNsF19A().setNsSign(
									temp.getAmountSign());
						}

					}

					temp19a[0] = tempBean19a;
					tempBean.setNsF19a(temp19a);

					tempBean.getNsF92a().getNsEXCH().getNsF92B()
							.setNsFirstCurrencyCode(temp.getFirstCurrencyCode());
					tempBean.getNsF92a().getNsEXCH().getNsF92B()
							.setNsSecondCurrencyCode(temp.getSecondCurrencyCode());
					tempBean.getNsF92a().getNsEXCH().getNsF92B().setNsRate(
							getUpdatedAmtValue(temp.getRate()));

					tempBean.getNsF16a_1().setNsF16R("AMT");
					tempBean.getNsF16a_2().setNsF16S("AMT");

					tempAmtArr[i] = tempBean;

				}

			}

			return tempAmtArr;
	}

	public String getUpdatedAmtValue(String tempQuantityValue) {

		if (tempQuantityValue != null && tempQuantityValue.trim().length() != 0) {
			
			  tempQuantityValue = tempQuantityValue.replace(".", ",");
	          int index = tempQuantityValue.lastIndexOf(",");
	          if (index!=-1)
	        	  tempQuantityValue = tempQuantityValue.substring(0,index).replace(",", "").concat(tempQuantityValue.substring(index));
	
	           else
	        	   tempQuantityValue=tempQuantityValue+",";            
	    } 

		return tempQuantityValue;

	}

}
