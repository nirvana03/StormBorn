package com.swift.sequenceF;

public class Narrative_70A {
	
	private String id;
	
	private String qualifier;
	
	private String narrative1;
	
	private String narrative2;
	
	private String narrative3;
	
	private String narrative4;
	
	private String narrative5;
	
	private String narrative6;
	
	private String narrative7;
	
	private String narrative8;
	
	private String narrative9;
	
	private String narrative10;
	

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getQualifier() {
		return qualifier;
	}

	public void setQualifier(String qualifier) {
		this.qualifier = qualifier;
	}

	public String getNarrative1() {
		return narrative1;
	}

	public void setNarrative1(String narrative1) {
		this.narrative1 = narrative1;
	}

	public String getNarrative2() {
		return narrative2;
	}

	public void setNarrative2(String narrative2) {
		this.narrative2 = narrative2;
	}

	public String getNarrative3() {
		return narrative3;
	}

	public void setNarrative3(String narrative3) {
		this.narrative3 = narrative3;
	}

	public String getNarrative4() {
		return narrative4;
	}

	public void setNarrative4(String narrative4) {
		this.narrative4 = narrative4;
	}

	public String getNarrative5() {
		return narrative5;
	}

	public void setNarrative5(String narrative5) {
		this.narrative5 = narrative5;
	}

	public String getNarrative6() {
		return narrative6;
	}

	public void setNarrative6(String narrative6) {
		this.narrative6 = narrative6;
	}

	public String getNarrative7() {
		return narrative7;
	}

	public void setNarrative7(String narrative7) {
		this.narrative7 = narrative7;
	}

	public String getNarrative8() {
		return narrative8;
	}

	public void setNarrative8(String narrative8) {
		this.narrative8 = narrative8;
	}

	public String getNarrative9() {
		return narrative9;
	}

	public void setNarrative9(String narrative9) {
		this.narrative9 = narrative9;
	}

	public String getNarrative10() {
		return narrative10;
	}

	public void setNarrative10(String narrative10) {
		this.narrative10 = narrative10;
	}
	

}
