package com.swift.sequenceF;

public class Party_95A {

	private String id;
	
	private String qualifier;
	
	private String options;
	
	private String partyValue;
	
	private String dataSourceScheme;
	
	private String dataSourceSchemeValue;
	
	private String alternateID;
	
	private String address1;
	
	private String address2;
	
	private String address3;
	
	private String address4;
	
	private String typeOfID;
	
	private String countryCode;
	
	private String legalEntityIdentifier;//SR2016

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getQualifier() {
		return qualifier;
	}

	public void setQualifier(String qualifier) {
		this.qualifier = qualifier;
	}

	public String getOptions() {
		return options;
	}

	public void setOptions(String options) {
		this.options = options;
	}

	public String getPartyValue() {
		return partyValue;
	}

	public void setPartyValue(String partyValue) {
		this.partyValue = partyValue;
	}

	public String getDataSourceScheme() {
		return dataSourceScheme;
	}

	public void setDataSourceScheme(String dataSourceScheme) {
		this.dataSourceScheme = dataSourceScheme;
	}

	public String getDataSourceSchemeValue() {
		return dataSourceSchemeValue;
	}

	public void setDataSourceSchemeValue(String dataSourceSchemeValue) {
		this.dataSourceSchemeValue = dataSourceSchemeValue;
	}

	public String getAlternateID() {
		return alternateID;
	}

	public void setAlternateID(String alternateID) {
		this.alternateID = alternateID;
	}

	public String getAddress1() {
		return address1;
	}

	public void setAddress1(String address1) {
		this.address1 = address1;
	}

	public String getAddress2() {
		return address2;
	}

	public void setAddress2(String address2) {
		this.address2 = address2;
	}

	public String getAddress3() {
		return address3;
	}

	public void setAddress3(String address3) {
		this.address3 = address3;
	}

	public String getAddress4() {
		return address4;
	}

	public void setAddress4(String address4) {
		this.address4 = address4;
	}

	public String getTypeOfID() {
		return typeOfID;
	}

	public void setTypeOfID(String typeOfID) {
		this.typeOfID = typeOfID;
	}

	public String getCountryCode() {
		return countryCode;
	}

	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}

	public String getLegalEntityIdentifier() {
		return legalEntityIdentifier;
	}

	public void setLegalEntityIdentifier(String legalEntityIdentifier) {
		this.legalEntityIdentifier = legalEntityIdentifier;
	}
}
