package com.swift.sequenceF;

import com.webmethods.caf.faces.util.LogUtils;
import com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqF_F70a_Type;
import com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqF_F95a_Type;

public class SequenceFPopulate {
	
	
	public Narrative_70A[] populateNarrative70A(TMCommon_docType_MT54x_docTypeRef_ns_SeqF_F70a_Type[] tempSeqF70A) {
		
		Narrative_70A[] narrative70A = null;
		
		int tempNarrative = 768;
		
		if (null != tempSeqF70A && tempSeqF70A.length > 0) {
			
			narrative70A = new Narrative_70A[tempSeqF70A.length];
			
			for (int i = 0 ; i < tempSeqF70A.length ; i++) {
				
				Narrative_70A tempNarrative70ABean = new Narrative_70A();
				tempNarrative = tempNarrative +1;
				tempNarrative70ABean.setId(tempNarrative+"");
				
				// For DECL
				if (null != tempSeqF70A[i].getNsDECL().getNsF70E().getNsNarrative().getNsLine() && 
						tempSeqF70A[i].getNsDECL().getNsF70E().getNsNarrative().getNsLine().length > 0) {
					
					tempNarrative70ABean.setQualifier("DECL");
					
					for (int j =0 ; j< tempSeqF70A[i].getNsDECL().getNsF70E().getNsNarrative().getNsLine().length ; j++) {
						if (j == 0) {
							tempNarrative70ABean.setNarrative1(tempSeqF70A[i].getNsDECL().getNsF70E().getNsNarrative().getNsLine()[j]);
						} else if (j == 1) {
							tempNarrative70ABean.setNarrative2(tempSeqF70A[i].getNsDECL().getNsF70E().getNsNarrative().getNsLine()[j]);
						} else if (j == 2) {
							tempNarrative70ABean.setNarrative3(tempSeqF70A[i].getNsDECL().getNsF70E().getNsNarrative().getNsLine()[j]);
						} else if (j == 3) {
							tempNarrative70ABean.setNarrative4(tempSeqF70A[i].getNsDECL().getNsF70E().getNsNarrative().getNsLine()[j]);
						} else if (j == 4) {
							tempNarrative70ABean.setNarrative5(tempSeqF70A[i].getNsDECL().getNsF70E().getNsNarrative().getNsLine()[j]);
						} else if (j == 5) {
							tempNarrative70ABean.setNarrative6(tempSeqF70A[i].getNsDECL().getNsF70E().getNsNarrative().getNsLine()[j]);
						} else if (j == 6) {
							tempNarrative70ABean.setNarrative7(tempSeqF70A[i].getNsDECL().getNsF70E().getNsNarrative().getNsLine()[j]);
						} else if (j == 7) {
							tempNarrative70ABean.setNarrative8(tempSeqF70A[i].getNsDECL().getNsF70E().getNsNarrative().getNsLine()[j]);
						} else if (j == 8) {
							tempNarrative70ABean.setNarrative9(tempSeqF70A[i].getNsDECL().getNsF70E().getNsNarrative().getNsLine()[j]);
						} else if (j == 9) {
							tempNarrative70ABean.setNarrative10(tempSeqF70A[i].getNsDECL().getNsF70E().getNsNarrative().getNsLine()[j]);
						} 
					}
				}
				
				// For REGI
				if (null != tempSeqF70A[i].getNsREGI().getNsF70D().getNsNarrative().getNsLine() && 
						tempSeqF70A[i].getNsREGI().getNsF70D().getNsNarrative().getNsLine().length > 0) {
					
					tempNarrative70ABean.setQualifier("REGI");
					
					for (int j =0 ; j< tempSeqF70A[i].getNsREGI().getNsF70D().getNsNarrative().getNsLine().length ; j++) {
						if (j == 0) {
							tempNarrative70ABean.setNarrative5(tempSeqF70A[i].getNsREGI().getNsF70D().getNsNarrative().getNsLine()[j]);
						} else if (j == 1) {
							tempNarrative70ABean.setNarrative6(tempSeqF70A[i].getNsREGI().getNsF70D().getNsNarrative().getNsLine()[j]);
						} else if (j == 2) {
							tempNarrative70ABean.setNarrative7(tempSeqF70A[i].getNsREGI().getNsF70D().getNsNarrative().getNsLine()[j]);
						} else if (j == 3) {
							tempNarrative70ABean.setNarrative8(tempSeqF70A[i].getNsREGI().getNsF70D().getNsNarrative().getNsLine()[j]);
						} else if (j == 4) {
							tempNarrative70ABean.setNarrative9(tempSeqF70A[i].getNsREGI().getNsF70D().getNsNarrative().getNsLine()[j]);
						} else if (j == 5) {
							tempNarrative70ABean.setNarrative10(tempSeqF70A[i].getNsREGI().getNsF70D().getNsNarrative().getNsLine()[j]);
						} 
					}
				}
				
				// For PACO
				if (null != tempSeqF70A[i].getNsPACO().getNsF70C().getNsNarrative().getNsLine() && 
						tempSeqF70A[i].getNsPACO().getNsF70C().getNsNarrative().getNsLine().length > 0) {
					
					tempNarrative70ABean.setQualifier("PACO");
					
					for (int j =0 ; j< tempSeqF70A[i].getNsPACO().getNsF70C().getNsNarrative().getNsLine().length ; j++) {
						if (j == 0) {
							tempNarrative70ABean.setNarrative1(tempSeqF70A[i].getNsPACO().getNsF70C().getNsNarrative().getNsLine()[j]);
						} else if (j == 1) {
							tempNarrative70ABean.setNarrative2(tempSeqF70A[i].getNsPACO().getNsF70C().getNsNarrative().getNsLine()[j]);
						} else if (j == 2) {
							tempNarrative70ABean.setNarrative3(tempSeqF70A[i].getNsPACO().getNsF70C().getNsNarrative().getNsLine()[j]);
						} else if (j == 3) {
							tempNarrative70ABean.setNarrative4(tempSeqF70A[i].getNsPACO().getNsF70C().getNsNarrative().getNsLine()[j]);
						} 
					}
				}
				narrative70A[i]= tempNarrative70ABean;
			}
			
		}
		return narrative70A;
		
	}

	public Party_95A populateParty95A(TMCommon_docType_MT54x_docTypeRef_ns_SeqF_F95a_Type[] tempSeqF95A) {
		
		//changing return type from array to non array
		
		
		Party_95A[] tempParty95AArr = null;
		//LogUtils.log("SeqF Pop-----Party-----------------------------tempSeqF95A length---->");
		int tempParty = 456;
		
		if (null != tempSeqF95A && tempSeqF95A.length > 0) {
			
		//	tempParty95AArr = new Party_95A[tempSeqF95A.length];
			tempParty95AArr = new Party_95A[1];
		//	tempParty95AArr = new Party_95A[2];
			Party_95A tempParty95ABean = new Party_95A();	
			for (int i = 0 ; i< tempSeqF95A.length ; i++) {
				
		//		Party_95A tempParty95ABean = new Party_95A();
				//Party_95A tempParty95ABean1 = new Party_95A();
				//LogUtils.log("Seq  F---Populate--Iteration--i"+i);
				tempParty = tempParty + 1;
				tempParty95ABean.setId(tempParty+"");
				//LogUtils.log("Seq F---Populate----Checking for qual");
		//		Party_95A[] temp = new Party_95A[2];
				//For EXCH
				if (null != tempSeqF95A[i].getNsEXCH().getNsF95P().getNsIdentifierCode()) {
					//LogUtils.log("SeqF Pop-----Party-----EXCH------ID code");
					tempParty95ABean.setQualifier("EXCH");
					tempParty95ABean.setOptions("Identifier Code");
					tempParty95ABean.setPartyValue(tempSeqF95A[i].getNsEXCH().getNsF95P().getNsIdentifierCode());
					
				} else if (null != tempSeqF95A[i].getNsEXCH().getNsF95Q().getNsNameAndAddress().getNsLine() && 
									tempSeqF95A[i].getNsEXCH().getNsF95Q().getNsNameAndAddress().getNsLine().length > 0) {
					//LogUtils.log("SeqF Pop-----Party-----EXCH------N and A");
					tempParty95ABean.setQualifier("EXCH");
					tempParty95ABean.setOptions("Name and Address");
					
					for (int j = 0 ; j< tempSeqF95A[i].getNsEXCH().getNsF95Q().getNsNameAndAddress().getNsLine().length ; j++) {
						
						if (j == 0) {
							tempParty95ABean.setAddress1(tempSeqF95A[i].getNsEXCH().getNsF95Q().getNsNameAndAddress().getNsLine()[j]);
						} else if (j == 1) {
							tempParty95ABean.setAddress2(tempSeqF95A[i].getNsEXCH().getNsF95Q().getNsNameAndAddress().getNsLine()[j]);
						} else if (j == 2) {
							tempParty95ABean.setAddress3(tempSeqF95A[i].getNsEXCH().getNsF95Q().getNsNameAndAddress().getNsLine()[j]);
						} else if (j == 3) {
							tempParty95ABean.setAddress4(tempSeqF95A[i].getNsEXCH().getNsF95Q().getNsNameAndAddress().getNsLine()[j]);
						}
					}
				} else if (null != tempSeqF95A[i].getNsEXCH().getNsF95R().getNsDataSourceScheme() || 
								null != tempSeqF95A[i].getNsEXCH().getNsF95R().getNsProprietaryCode()) {
					//LogUtils.log("SeqF Pop-----Party-----EXCH-----Prop code");		
					tempParty95ABean.setQualifier("EXCH");
					tempParty95ABean.setOptions("Proprietary Code");
					tempParty95ABean.setPartyValue(tempSeqF95A[i].getNsEXCH().getNsF95R().getNsProprietaryCode());
					tempParty95ABean.setDataSourceSchemeValue(tempSeqF95A[i].getNsEXCH().getNsF95R().getNsDataSourceScheme());
					
				} 
				/*
				if(tempSeqF95A[i].getNsALTE().getNsF95L().getNsLegalEntityIdentifier() !=null){
					
					LogUtils.log("SeqF Pop-----Party-----EXCH------LEI code");
					tempParty95ABean.setLegalEntityIdentifier(tempSeqF95A[i].getNsALTE().getNsF95L().getNsLegalEntityIdentifier());
				}
				*/
				// For MEOR
				if (null != tempSeqF95A[i].getNsMEOR().getNsF95P().getNsIdentifierCode()) {
					
					tempParty95ABean.setQualifier("MEOR");
					tempParty95ABean.setOptions("Identifier Code");
					tempParty95ABean.setPartyValue(tempSeqF95A[i].getNsMEOR().getNsF95P().getNsIdentifierCode());
					
				} else if (null != tempSeqF95A[i].getNsMEOR().getNsF95Q().getNsNameAndAddress().getNsLine() && 
									tempSeqF95A[i].getNsMEOR().getNsF95Q().getNsNameAndAddress().getNsLine().length > 0) {
					
					tempParty95ABean.setQualifier("MEOR");
					tempParty95ABean.setOptions("Name and Address");
					
					for (int j = 0 ; j< tempSeqF95A[i].getNsMEOR().getNsF95Q().getNsNameAndAddress().getNsLine().length ; j++) {
						
						if (j == 0) {
							tempParty95ABean.setAddress1(tempSeqF95A[i].getNsMEOR().getNsF95Q().getNsNameAndAddress().getNsLine()[j]);
						} else if (j == 1) {
							tempParty95ABean.setAddress2(tempSeqF95A[i].getNsMEOR().getNsF95Q().getNsNameAndAddress().getNsLine()[j]);
						} else if (j == 2) {
							tempParty95ABean.setAddress3(tempSeqF95A[i].getNsMEOR().getNsF95Q().getNsNameAndAddress().getNsLine()[j]);
						} else if (j == 3) {
							tempParty95ABean.setAddress4(tempSeqF95A[i].getNsMEOR().getNsF95Q().getNsNameAndAddress().getNsLine()[j]);
						}
					}
				} else if (null != tempSeqF95A[i].getNsMEOR().getNsF95R().getNsDataSourceScheme() || 
									null != tempSeqF95A[i].getNsMEOR().getNsF95R().getNsProprietaryCode()) {
							
					tempParty95ABean.setQualifier("MEOR");
					tempParty95ABean.setOptions("Proprietary Code");
					tempParty95ABean.setDataSourceSchemeValue(tempSeqF95A[i].getNsMEOR().getNsF95R().getNsDataSourceScheme());
					tempParty95ABean.setPartyValue(tempSeqF95A[i].getNsMEOR().getNsF95R().getNsProprietaryCode());
					
				} 
				
				// For MERE
				if (null != tempSeqF95A[i].getNsMERE().getNsF95P().getNsIdentifierCode()) {
					
					tempParty95ABean.setQualifier("MERE");
					tempParty95ABean.setOptions("Identifier Code");
					tempParty95ABean.setPartyValue(tempSeqF95A[i].getNsMERE().getNsF95P().getNsIdentifierCode());
					
				} else if (null != tempSeqF95A[i].getNsMERE().getNsF95Q().getNsNameAndAddress().getNsLine() && 
									tempSeqF95A[i].getNsMERE().getNsF95Q().getNsNameAndAddress().getNsLine().length > 0) {
					
					tempParty95ABean.setQualifier("MERE");
					tempParty95ABean.setOptions("Name and Address");
					
					for (int j = 0 ; j< tempSeqF95A[i].getNsMERE().getNsF95Q().getNsNameAndAddress().getNsLine().length ; j++) {
						
						if (j == 0) {
							tempParty95ABean.setAddress1(tempSeqF95A[i].getNsMERE().getNsF95Q().getNsNameAndAddress().getNsLine()[j]);
						} else if (j == 1) {
							tempParty95ABean.setAddress2(tempSeqF95A[i].getNsMERE().getNsF95Q().getNsNameAndAddress().getNsLine()[j]);
						} else if (j == 2) {
							tempParty95ABean.setAddress3(tempSeqF95A[i].getNsMERE().getNsF95Q().getNsNameAndAddress().getNsLine()[j]);
						} else if (j == 3) {
							tempParty95ABean.setAddress4(tempSeqF95A[i].getNsMERE().getNsF95Q().getNsNameAndAddress().getNsLine()[j]);
						}
					}
				} else if (null != tempSeqF95A[i].getNsMERE().getNsF95R().getNsDataSourceScheme() || 
									null != tempSeqF95A[i].getNsMERE().getNsF95R().getNsProprietaryCode()) {
							
					tempParty95ABean.setQualifier("MERE");
					tempParty95ABean.setOptions("Proprietary Code");
					tempParty95ABean.setDataSourceSchemeValue(tempSeqF95A[i].getNsMERE().getNsF95R().getNsDataSourceScheme());
					tempParty95ABean.setPartyValue(tempSeqF95A[i].getNsMERE().getNsF95R().getNsProprietaryCode());
					
				} 
				
				//For TRRE
				if (null != tempSeqF95A[i].getNsTRRE().getNsF95P().getNsIdentifierCode()) {
					
					tempParty95ABean.setQualifier("TRRE");
					tempParty95ABean.setOptions("Identifier Code");
					tempParty95ABean.setPartyValue(tempSeqF95A[i].getNsTRRE().getNsF95P().getNsIdentifierCode());
					
				} else if (null != tempSeqF95A[i].getNsTRRE().getNsF95Q().getNsNameAndAddress().getNsLine() && 
									tempSeqF95A[i].getNsTRRE().getNsF95Q().getNsNameAndAddress().getNsLine().length > 0) {
					
					tempParty95ABean.setQualifier("TRRE");
					tempParty95ABean.setOptions("Name and Address");
					
					for (int j = 0 ; j< tempSeqF95A[i].getNsTRRE().getNsF95Q().getNsNameAndAddress().getNsLine().length ; j++) {
						
						if (j == 0) {
							tempParty95ABean.setAddress1(tempSeqF95A[i].getNsTRRE().getNsF95Q().getNsNameAndAddress().getNsLine()[j]);
						} else if (j == 1) {
							tempParty95ABean.setAddress2(tempSeqF95A[i].getNsTRRE().getNsF95Q().getNsNameAndAddress().getNsLine()[j]);
						} else if (j == 2) {
							tempParty95ABean.setAddress3(tempSeqF95A[i].getNsTRRE().getNsF95Q().getNsNameAndAddress().getNsLine()[j]);
						} else if (j == 3) {
							tempParty95ABean.setAddress4(tempSeqF95A[i].getNsTRRE().getNsF95Q().getNsNameAndAddress().getNsLine()[j]);
						}
					}
				} else if (null != tempSeqF95A[i].getNsTRRE().getNsF95R().getNsDataSourceScheme() || 
									null != tempSeqF95A[i].getNsTRRE().getNsF95R().getNsProprietaryCode()) {
							
					tempParty95ABean.setQualifier("TRRE");
					tempParty95ABean.setOptions("Proprietary Code");
					tempParty95ABean.setDataSourceSchemeValue(tempSeqF95A[i].getNsTRRE().getNsF95R().getNsDataSourceScheme());
					tempParty95ABean.setPartyValue(tempSeqF95A[i].getNsTRRE().getNsF95R().getNsProprietaryCode());
					
				} 
				/*
				//SR2016
					if(tempSeqF95A[i].getNsALTE().getNsF95L().getNsLegalEntityIdentifier() !=null){
					
					LogUtils.log("SeqF Pop-----Party-----EXCH------LEI code");
					tempParty95ABean.setLegalEntityIdentifier(tempSeqF95A[i].getNsALTE().getNsF95L().getNsLegalEntityIdentifier());
				}*/
				
				// For INVE
				if (null != tempSeqF95A[i].getNsINVE().getNsF95P().getNsIdentifierCode()) {
					
					tempParty95ABean.setQualifier("TRRE");
					tempParty95ABean.setOptions("Identifier Code");
					tempParty95ABean.setPartyValue(tempSeqF95A[i].getNsINVE().getNsF95P().getNsIdentifierCode());
					
				} else if (null != tempSeqF95A[i].getNsINVE().getNsF95Q().getNsNameAndAddress().getNsLine() && 
									tempSeqF95A[i].getNsINVE().getNsF95Q().getNsNameAndAddress().getNsLine().length > 0) {
					
					tempParty95ABean.setQualifier("INVE");
					tempParty95ABean.setOptions("Name and Address");
					
					for (int j = 0 ; j< tempSeqF95A[i].getNsINVE().getNsF95Q().getNsNameAndAddress().getNsLine().length ; j++) {
						
						if (j == 0) {
							tempParty95ABean.setAddress1(tempSeqF95A[i].getNsINVE().getNsF95Q().getNsNameAndAddress().getNsLine()[j]);
						} else if (j == 1) {
							tempParty95ABean.setAddress2(tempSeqF95A[i].getNsINVE().getNsF95Q().getNsNameAndAddress().getNsLine()[j]);
						} else if (j == 2) {
							tempParty95ABean.setAddress3(tempSeqF95A[i].getNsINVE().getNsF95Q().getNsNameAndAddress().getNsLine()[j]);
						} else if (j == 3) {
							tempParty95ABean.setAddress4(tempSeqF95A[i].getNsINVE().getNsF95Q().getNsNameAndAddress().getNsLine()[j]);
						}
					}
				} else if (null != tempSeqF95A[i].getNsINVE().getNsF95R().getNsDataSourceScheme() || 
								null != tempSeqF95A[i].getNsINVE().getNsF95R().getNsProprietaryCode()) {
							
					tempParty95ABean.setQualifier("INVE");
					tempParty95ABean.setOptions("Proprietary Code");
					tempParty95ABean.setDataSourceSchemeValue(tempSeqF95A[i].getNsINVE().getNsF95R().getNsDataSourceScheme());
					tempParty95ABean.setPartyValue(tempSeqF95A[i].getNsINVE().getNsF95R().getNsProprietaryCode());
					
				} else if (null != tempSeqF95A[i].getNsINVE().getNsF95C().getNsCountryCode()) {
					
					tempParty95ABean.setQualifier("INVE");
					tempParty95ABean.setOptions("Country Code");
					tempParty95ABean.setCountryCode(tempSeqF95A[i].getNsINVE().getNsF95C().getNsCountryCode());
				}
				/*
				//SR2016
				if(tempSeqF95A[i].getNsALTE().getNsF95L().getNsLegalEntityIdentifier() !=null){
					
					LogUtils.log("SeqF Pop-----Party-----EXCH------LEI code");
					tempParty95ABean.setLegalEntityIdentifier(tempSeqF95A[i].getNsALTE().getNsF95L().getNsLegalEntityIdentifier());
				}*/
				// For VEND
				if (null != tempSeqF95A[i].getNsVEND().getNsF95P().getNsIdentifierCode()) {
					
					tempParty95ABean.setQualifier("VEND");
					tempParty95ABean.setOptions("Identifier Code");
					tempParty95ABean.setPartyValue(tempSeqF95A[i].getNsVEND().getNsF95P().getNsIdentifierCode());
					
				} else if (null != tempSeqF95A[i].getNsVEND().getNsF95Q().getNsNameAndAddress().getNsLine() && 
									tempSeqF95A[i].getNsVEND().getNsF95Q().getNsNameAndAddress().getNsLine().length > 0) {
					
					tempParty95ABean.setQualifier("VEND");
					tempParty95ABean.setOptions("Name and Address");
					
					for (int j = 0 ; j< tempSeqF95A[i].getNsVEND().getNsF95Q().getNsNameAndAddress().getNsLine().length ; j++) {
						
						if (j == 0) {
							tempParty95ABean.setAddress1(tempSeqF95A[i].getNsVEND().getNsF95Q().getNsNameAndAddress().getNsLine()[j]);
						} else if (j == 1) {
							tempParty95ABean.setAddress2(tempSeqF95A[i].getNsVEND().getNsF95Q().getNsNameAndAddress().getNsLine()[j]);
						} else if (j == 2) {
							tempParty95ABean.setAddress3(tempSeqF95A[i].getNsVEND().getNsF95Q().getNsNameAndAddress().getNsLine()[j]);
						} else if (j == 3) {
							tempParty95ABean.setAddress4(tempSeqF95A[i].getNsVEND().getNsF95Q().getNsNameAndAddress().getNsLine()[j]);
						}
					}
				} else if (null != tempSeqF95A[i].getNsVEND().getNsF95R().getNsDataSourceScheme() ||
								null != tempSeqF95A[i].getNsVEND().getNsF95R().getNsProprietaryCode()) {
							
					tempParty95ABean.setQualifier("VEND");
					tempParty95ABean.setOptions("Proprietary Code");
					tempParty95ABean.setDataSourceSchemeValue(tempSeqF95A[i].getNsVEND().getNsF95R().getNsDataSourceScheme());
					tempParty95ABean.setPartyValue(tempSeqF95A[i].getNsVEND().getNsF95R().getNsProprietaryCode());
					
				} 
				/*
				//SR2016
					if(tempSeqF95A[i].getNsALTE().getNsF95L().getNsLegalEntityIdentifier() !=null){
					
					LogUtils.log("SeqF Pop-----Party-----EXCH------LEI code");
					tempParty95ABean.setLegalEntityIdentifier(tempSeqF95A[i].getNsALTE().getNsF95L().getNsLegalEntityIdentifier());
				}
				*/
				// For TRAG
				if (null != tempSeqF95A[i].getNsTRAG().getNsF95P().getNsIdentifierCode()) {
					
					tempParty95ABean.setQualifier("TRAG");
					tempParty95ABean.setOptions("Identifier Code");
					tempParty95ABean.setPartyValue(tempSeqF95A[i].getNsTRAG().getNsF95P().getNsIdentifierCode());
					
				} else if (null != tempSeqF95A[i].getNsTRAG().getNsF95Q().getNsNameAndAddress().getNsLine() && 
									tempSeqF95A[i].getNsTRAG().getNsF95Q().getNsNameAndAddress().getNsLine().length > 0) {
					
					tempParty95ABean.setQualifier("TRAG");
					tempParty95ABean.setOptions("Name and Address");
					
					for (int j = 0 ; j< tempSeqF95A[i].getNsTRAG().getNsF95Q().getNsNameAndAddress().getNsLine().length ; j++) {
						
						if (j == 0) {
							tempParty95ABean.setAddress1(tempSeqF95A[i].getNsTRAG().getNsF95Q().getNsNameAndAddress().getNsLine()[j]);
						} else if (j == 1) {
							tempParty95ABean.setAddress2(tempSeqF95A[i].getNsTRAG().getNsF95Q().getNsNameAndAddress().getNsLine()[j]);
						} else if (j == 2) {
							tempParty95ABean.setAddress3(tempSeqF95A[i].getNsTRAG().getNsF95Q().getNsNameAndAddress().getNsLine()[j]);
						} else if (j == 3) {
							tempParty95ABean.setAddress4(tempSeqF95A[i].getNsTRAG().getNsF95Q().getNsNameAndAddress().getNsLine()[j]);
						}
					}
				} else if (null != tempSeqF95A[i].getNsTRAG().getNsF95R().getNsDataSourceScheme() ||
								null != tempSeqF95A[i].getNsTRAG().getNsF95R().getNsProprietaryCode()) {
							
					tempParty95ABean.setQualifier("TRAG");
					tempParty95ABean.setOptions("Proprietary Code");
					tempParty95ABean.setDataSourceSchemeValue(tempSeqF95A[i].getNsTRAG().getNsF95R().getNsDataSourceScheme());
					tempParty95ABean.setPartyValue(tempSeqF95A[i].getNsTRAG().getNsF95R().getNsProprietaryCode());
					
				} 
				/*
				//SR2016
					if(tempSeqF95A[i].getNsALTE().getNsF95L().getNsLegalEntityIdentifier() !=null){
					
					LogUtils.log("SeqF Pop-----Party-----EXCH------LEI code");
					tempParty95ABean.setLegalEntityIdentifier(tempSeqF95A[i].getNsALTE().getNsF95L().getNsLegalEntityIdentifier());
				}
				*/
				// For SR 2011 and qualifier 2011
				if (null != tempSeqF95A[i].getNsBRKR().getNsF95P().getNsIdentifierCode()) {
					
					tempParty95ABean.setQualifier("BRKR");
					tempParty95ABean.setOptions("Identifier Code");
					tempParty95ABean.setPartyValue(tempSeqF95A[i].getNsBRKR().getNsF95P().getNsIdentifierCode());
					
				} else if (null != tempSeqF95A[i].getNsBRKR().getNsF95Q().getNsNameAndAddress().getNsLine() && 
									tempSeqF95A[i].getNsBRKR().getNsF95Q().getNsNameAndAddress().getNsLine().length > 0) {
					
					tempParty95ABean.setQualifier("BRKR");
					tempParty95ABean.setOptions("Name and Address");
					
					for (int j = 0 ; j< tempSeqF95A[i].getNsBRKR().getNsF95Q().getNsNameAndAddress().getNsLine().length ; j++) {
						
						if (j == 0) {
							tempParty95ABean.setAddress1(tempSeqF95A[i].getNsBRKR().getNsF95Q().getNsNameAndAddress().getNsLine()[j]);
						} else if (j == 1) {
							tempParty95ABean.setAddress2(tempSeqF95A[i].getNsBRKR().getNsF95Q().getNsNameAndAddress().getNsLine()[j]);
						} else if (j == 2) {
							tempParty95ABean.setAddress3(tempSeqF95A[i].getNsBRKR().getNsF95Q().getNsNameAndAddress().getNsLine()[j]);
						} else if (j == 3) {
							tempParty95ABean.setAddress4(tempSeqF95A[i].getNsBRKR().getNsF95Q().getNsNameAndAddress().getNsLine()[j]);
						}
					}
				} else if (null != tempSeqF95A[i].getNsBRKR().getNsF95R().getNsDataSourceScheme() ||
								null != tempSeqF95A[i].getNsBRKR().getNsF95R().getNsProprietaryCode()) {
							
					tempParty95ABean.setQualifier("BRKR");
					tempParty95ABean.setOptions("Proprietary Code");
					tempParty95ABean.setDataSourceSchemeValue(tempSeqF95A[i].getNsBRKR().getNsF95R().getNsDataSourceScheme());
					tempParty95ABean.setPartyValue(tempSeqF95A[i].getNsBRKR().getNsF95R().getNsProprietaryCode());
					
				} 
				/*
				//SR2016
				if(tempSeqF95A[i].getNsALTE().getNsF95L().getNsLegalEntityIdentifier() !=null){
					
					LogUtils.log("SeqF Pop-----Party-----EXCH------LEI code");
					tempParty95ABean.setLegalEntityIdentifier(tempSeqF95A[i].getNsALTE().getNsF95L().getNsLegalEntityIdentifier());
				}
				*/
				
				/* commenting for earlier SR2016 changes
				//For ALTE
				if (null != tempSeqF95A[i].getNsALTE().getNsF95S().getNsDataSourceScheme()) {
					
						tempParty95ABean.setQualifier("ALTE");
						tempParty95ABean.setOptions("Country Code");
						tempParty95ABean.setDataSourceScheme("Data Source Scheme");
						tempParty95ABean.setDataSourceSchemeValue(tempSeqF95A[i].getNsALTE().getNsF95S().getNsDataSourceScheme());
						tempParty95ABean.setCountryCode(tempSeqF95A[i].getNsALTE().getNsF95S().getNsCountryCode());
						tempParty95ABean.setAlternateID(tempSeqF95A[i].getNsALTE().getNsF95S().getNsAlternateID());
						
				} else if (null != tempSeqF95A[i].getNsALTE().getNsF95S().getNsTypeOfID()){
					
						tempParty95ABean.setQualifier("ALTE");
						tempParty95ABean.setOptions("Country Code");
						tempParty95ABean.setTypeOfID(tempSeqF95A[i].getNsALTE().getNsF95S().getNsTypeOfID());
						tempParty95ABean.setCountryCode(tempSeqF95A[i].getNsALTE().getNsF95S().getNsCountryCode());
						tempParty95ABean.setAlternateID(tempSeqF95A[i].getNsALTE().getNsF95S().getNsAlternateID());
				}
				//SR2016
				if (null != tempSeqF95A[i].getNsALTE().getNsF95L().getNsLegalEntityIdentifier()) {
					
					tempParty95ABean.setQualifier("ALTE1");
					tempParty95ABean.setOptions("LegalEntityIdentifier");
					tempParty95ABean.setPartyValue(tempSeqF95A[i].getNsALTE().getNsF95L().getNsLegalEntityIdentifier());
					
			}
				//SR2016
				 * 
				 * 
				 */
			//	LogUtils.log("length of the bean "+tempSeqF95A.length+i);
				if(tempSeqF95A.length>1)
				{
					
				if(tempSeqF95A[i].getNsALTE().getNsF95L().getNsLegalEntityIdentifier() !=null){
					
					//LogUtils.log("SeqF Pop----Common ----LEI code");
			tempParty95ABean.setLegalEntityIdentifier(tempSeqF95A[i].getNsALTE().getNsF95L().getNsLegalEntityIdentifier());
				//LogUtils.log("SeqF Pop-----setting bean into array-----");
				
				
				 }
				}	
				//SR2016
		//		if(tempParty95ABean1.getLegalEntityIdentifier()!=null){
		//		tempParty95AArr[0]=tempParty95ABean;
		//		}
				
			/*	if(tempParty95ABean!=null){
					//LogUtils.log("Seq F--Populate---Null check before setting----iteration"+i);
					tempParty95AArr[i] = tempParty95ABean;
				}*/
				
			//	LogUtils.log(">>>>>> Legal Odentifier"+tempParty95AArr[i].getLegalEntityIdentifier());
			/*
				if(tempParty95ABean1!=null){
					LogUtils.log("Seq F--Populate---Null check before setting for ALTE----iteration"+i);
				//	tempParty95AArr[0].setLegalEntityIdentifier(tempParty95ABean1.getLegalEntityIdentifier());
					temp[1]=tempParty95ABean1;
				}*/
			//	*/
				
			//	tempParty95AArr=temp;
		}
			
			if(tempParty95ABean!=null){
				//LogUtils.log("Seq F--Populate---Null check before setting----iteration"+i);
				tempParty95AArr[0] = tempParty95ABean;
			}
	}
		
		return tempParty95AArr[0];
	}
	}
