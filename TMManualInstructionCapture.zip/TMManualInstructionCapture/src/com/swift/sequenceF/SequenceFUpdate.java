package com.swift.sequenceF;

import com.webmethods.caf.faces.util.LogUtils;
import com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqF_F70a_Type;
import com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqF_F95a_Type;

public class SequenceFUpdate {
	
	public TMCommon_docType_MT54x_docTypeRef_ns_SeqF_F70a_Type[] updateNarrative70A(Narrative_70A[] tempNarrative70AArr) {
		
		TMCommon_docType_MT54x_docTypeRef_ns_SeqF_F70a_Type[] tempSeqF70A = null;
		
		if (null != tempNarrative70AArr && tempNarrative70AArr.length > 0) {
			
			tempSeqF70A = new TMCommon_docType_MT54x_docTypeRef_ns_SeqF_F70a_Type[tempNarrative70AArr.length];
			
			for (int i =0; i< tempNarrative70AArr.length ; i++) {
				
				TMCommon_docType_MT54x_docTypeRef_ns_SeqF_F70a_Type tempSeqF70ABean = new TMCommon_docType_MT54x_docTypeRef_ns_SeqF_F70a_Type();
				
				// For DECL
				if (null != tempNarrative70AArr[i].getQualifier() && "DECL".equalsIgnoreCase(tempNarrative70AArr[i].getQualifier())) {
						
					tempSeqF70ABean.getNsDECL().getNsF70E().getNsNarrative().setNsLine(new String[10]);
					
					tempSeqF70ABean.getNsDECL().getNsF70E().getNsNarrative().getNsLine()[0] = tempNarrative70AArr[i].getNarrative1();
					tempSeqF70ABean.getNsDECL().getNsF70E().getNsNarrative().getNsLine()[1] = tempNarrative70AArr[i].getNarrative2();
					tempSeqF70ABean.getNsDECL().getNsF70E().getNsNarrative().getNsLine()[2] = tempNarrative70AArr[i].getNarrative3();
					tempSeqF70ABean.getNsDECL().getNsF70E().getNsNarrative().getNsLine()[3] = tempNarrative70AArr[i].getNarrative4();
					tempSeqF70ABean.getNsDECL().getNsF70E().getNsNarrative().getNsLine()[4] = tempNarrative70AArr[i].getNarrative5();
					tempSeqF70ABean.getNsDECL().getNsF70E().getNsNarrative().getNsLine()[5] = tempNarrative70AArr[i].getNarrative6();
					tempSeqF70ABean.getNsDECL().getNsF70E().getNsNarrative().getNsLine()[6] = tempNarrative70AArr[i].getNarrative7();
					tempSeqF70ABean.getNsDECL().getNsF70E().getNsNarrative().getNsLine()[7] = tempNarrative70AArr[i].getNarrative8();
					tempSeqF70ABean.getNsDECL().getNsF70E().getNsNarrative().getNsLine()[8] = tempNarrative70AArr[i].getNarrative9();
					tempSeqF70ABean.getNsDECL().getNsF70E().getNsNarrative().getNsLine()[9] = tempNarrative70AArr[i].getNarrative10();
				}
				
				// For REGI
				if (null != tempNarrative70AArr[i].getQualifier() && "REGI".equalsIgnoreCase(tempNarrative70AArr[i].getQualifier())) {
						
					tempSeqF70ABean.getNsREGI().getNsF70D().getNsNarrative().setNsLine(new String[6]);
					
					tempSeqF70ABean.getNsREGI().getNsF70D().getNsNarrative().getNsLine()[0] = tempNarrative70AArr[i].getNarrative5();
					tempSeqF70ABean.getNsREGI().getNsF70D().getNsNarrative().getNsLine()[1] = tempNarrative70AArr[i].getNarrative6();
					tempSeqF70ABean.getNsREGI().getNsF70D().getNsNarrative().getNsLine()[2] = tempNarrative70AArr[i].getNarrative7();
					tempSeqF70ABean.getNsREGI().getNsF70D().getNsNarrative().getNsLine()[3] = tempNarrative70AArr[i].getNarrative8();
					tempSeqF70ABean.getNsREGI().getNsF70D().getNsNarrative().getNsLine()[4] = tempNarrative70AArr[i].getNarrative9();
					tempSeqF70ABean.getNsREGI().getNsF70D().getNsNarrative().getNsLine()[5] = tempNarrative70AArr[i].getNarrative10();
				}
				
				// For PACO
				if (null != tempNarrative70AArr[i].getQualifier() && "PACO".equalsIgnoreCase(tempNarrative70AArr[i].getQualifier())) {
					
					tempSeqF70ABean.getNsPACO().getNsF70C().getNsNarrative().setNsLine(new String[4]);
					
					tempSeqF70ABean.getNsPACO().getNsF70C().getNsNarrative().getNsLine()[0] = tempNarrative70AArr[i].getNarrative1();
					tempSeqF70ABean.getNsPACO().getNsF70C().getNsNarrative().getNsLine()[1] = tempNarrative70AArr[i].getNarrative2();
					tempSeqF70ABean.getNsPACO().getNsF70C().getNsNarrative().getNsLine()[2] = tempNarrative70AArr[i].getNarrative3();
					tempSeqF70ABean.getNsPACO().getNsF70C().getNsNarrative().getNsLine()[3] = tempNarrative70AArr[i].getNarrative4();
				}
				tempSeqF70A[i] = tempSeqF70ABean;
			}
		}
		return tempSeqF70A;
	}

	public TMCommon_docType_MT54x_docTypeRef_ns_SeqF_F95a_Type[] updateParty95A(Party_95A tempParty) {
		
		TMCommon_docType_MT54x_docTypeRef_ns_SeqF_F95a_Type[] tempSeqF95aArr = null;
	//	TMCommon_docType_MT54x_docTypeRef_ns_SeqF_F95a_Type[] tempSeqF95aArr1 = null;
		
		
		if (null != tempParty) {
			
		//	tempSeqF95aArr = new TMCommon_docType_MT54x_docTypeRef_ns_SeqF_F95a_Type [tempParty_95AArr.length];
			tempSeqF95aArr = new TMCommon_docType_MT54x_docTypeRef_ns_SeqF_F95a_Type [2];
		//	tempSeqF95aArr1 = new TMCommon_docType_MT54x_docTypeRef_ns_SeqF_F95a_Type [tempParty_95AArr.length];
		//	LogUtils.log("SeqF Update---array length---tempParty_95Arr-----"+tempParty_95AArr.length);
			
			
			
			
			TMCommon_docType_MT54x_docTypeRef_ns_SeqF_F95a_Type tempSeqF95aBean = new TMCommon_docType_MT54x_docTypeRef_ns_SeqF_F95a_Type();
			TMCommon_docType_MT54x_docTypeRef_ns_SeqF_F95a_Type tempSeqF95aBean1 = new TMCommon_docType_MT54x_docTypeRef_ns_SeqF_F95a_Type();//SR2016
			
			//int i=0;
			//Commenting for SR2016
			
			if (null != tempParty.getQualifier() && "EXCH".equalsIgnoreCase(tempParty.getQualifier())) {
				
				if (null != tempParty.getOptions() && "Identifier Code".equalsIgnoreCase(tempParty.getOptions())) {
					
					//LogUtils.log("SeqF Update-----Party-----EXCH------ID code");
					tempSeqF95aBean.getNsEXCH().getNsF95P().setNsIdentifierCode(tempParty.getPartyValue());
					
				} else if (null != tempParty.getOptions() && "Name and Address".equalsIgnoreCase(tempParty.getOptions())) {
					//LogUtils.log("SeqF Update-----Party-----EXCH------N and A");
					tempSeqF95aBean.getNsEXCH().getNsF95Q().getNsNameAndAddress().setNsLine(new String[4]);
					
					tempSeqF95aBean.getNsEXCH().getNsF95Q().getNsNameAndAddress().getNsLine()[0] = tempParty.getAddress1();
					tempSeqF95aBean.getNsEXCH().getNsF95Q().getNsNameAndAddress().getNsLine()[1] = tempParty.getAddress2();
					tempSeqF95aBean.getNsEXCH().getNsF95Q().getNsNameAndAddress().getNsLine()[2] = tempParty.getAddress3();
					tempSeqF95aBean.getNsEXCH().getNsF95Q().getNsNameAndAddress().getNsLine()[3] = tempParty.getAddress4();
					
				} else if (null != tempParty.getOptions() && "Proprietary Code".equalsIgnoreCase(tempParty.getOptions())) {
					
					//LogUtils.log("SeqF Update-----Party-----EXCH-----Prop code");
					tempSeqF95aBean.getNsEXCH().getNsF95R().setNsProprietaryCode(tempParty.getPartyValue());
					tempSeqF95aBean.getNsEXCH().getNsF95R().setNsDataSourceScheme(tempParty.getDataSourceSchemeValue());
					
				} 
				
				//SR2016
				if( null != tempParty.getLegalEntityIdentifier()){
					
					//LogUtils.log("SeqF Update-----Party-----EXCH------LEI code");
				tempSeqF95aBean1.getNsALTE().getNsF95L().setNsLegalEntityIdentifier(tempParty.getLegalEntityIdentifier());
				//}
			}
			}
			
			// For MEOR
			if (null != tempParty.getQualifier() && "MEOR".equalsIgnoreCase(tempParty.getQualifier())) {
				
				if (null != tempParty.getOptions() && "Identifier Code".equalsIgnoreCase(tempParty.getOptions())) {
					
					//LogUtils.log("SeqF Update-----Party-----MEOR------ID code");
					
					tempSeqF95aBean.getNsMEOR().getNsF95P().setNsIdentifierCode(tempParty.getPartyValue());
					
				} else if (null != tempParty.getOptions() && "Name and Address".equalsIgnoreCase(tempParty.getOptions())) {
					//LogUtils.log("SeqF Update-----Party-----MEOR------N and A");
					
					tempSeqF95aBean.getNsMEOR().getNsF95Q().getNsNameAndAddress().setNsLine(new String[4]);
					
					tempSeqF95aBean.getNsMEOR().getNsF95Q().getNsNameAndAddress().getNsLine()[0] = tempParty.getAddress1();
					tempSeqF95aBean.getNsMEOR().getNsF95Q().getNsNameAndAddress().getNsLine()[1] = tempParty.getAddress2();
					tempSeqF95aBean.getNsMEOR().getNsF95Q().getNsNameAndAddress().getNsLine()[2] = tempParty.getAddress3();
					tempSeqF95aBean.getNsMEOR().getNsF95Q().getNsNameAndAddress().getNsLine()[3] = tempParty.getAddress4();
					
				} else if (null != tempParty.getOptions() && "Proprietary Code".equalsIgnoreCase(tempParty.getOptions())) {
					
					//LogUtils.log("SeqF Update-----Party-----MEOR------Prop code");
					tempSeqF95aBean.getNsMEOR().getNsF95R().setNsProprietaryCode(tempParty.getPartyValue());
					tempSeqF95aBean.getNsMEOR().getNsF95R().setNsDataSourceScheme(tempParty.getDataSourceSchemeValue());
					
				} 
			}
			
			// For MERE
			if (null != tempParty.getQualifier() && "MERE".equalsIgnoreCase(tempParty.getQualifier())) {
				
				if (null != tempParty.getOptions() && "Identifier Code".equalsIgnoreCase(tempParty.getOptions())) {
					
					//LogUtils.log("SeqF Update-----Party-----MERE------ID code");
					
					tempSeqF95aBean.getNsMERE().getNsF95P().setNsIdentifierCode(tempParty.getPartyValue());
					
				} else if (null != tempParty.getOptions() && "Name and Address".equalsIgnoreCase(tempParty.getOptions())) {
					
					//LogUtils.log("SeqF Update-----Party-----MERE------N and A");
					
					tempSeqF95aBean.getNsMERE().getNsF95Q().getNsNameAndAddress().setNsLine(new String[4]);
					
					tempSeqF95aBean.getNsMERE().getNsF95Q().getNsNameAndAddress().getNsLine()[0] = tempParty.getAddress1();
					tempSeqF95aBean.getNsMERE().getNsF95Q().getNsNameAndAddress().getNsLine()[1] = tempParty.getAddress2();
					tempSeqF95aBean.getNsMERE().getNsF95Q().getNsNameAndAddress().getNsLine()[2] = tempParty.getAddress3();
					tempSeqF95aBean.getNsMERE().getNsF95Q().getNsNameAndAddress().getNsLine()[3] = tempParty.getAddress4();
					
				} else if (null != tempParty.getOptions() && "Proprietary Code".equalsIgnoreCase(tempParty.getOptions())) {
					
					//LogUtils.log("SeqF Update-----Party-----MERE------Prop code");
					tempSeqF95aBean.getNsMERE().getNsF95R().setNsProprietaryCode(tempParty.getPartyValue());
					tempSeqF95aBean.getNsMERE().getNsF95R().setNsDataSourceScheme(tempParty.getDataSourceSchemeValue());
					
				} 
			}
			
			//For TRRE
			if (null != tempParty.getQualifier() && "TRRE".equalsIgnoreCase(tempParty.getQualifier())) {
				
				if (null != tempParty.getOptions() && "Identifier Code".equalsIgnoreCase(tempParty.getOptions())) {
					
					//LogUtils.log("SeqF Update-----Party-----TRRE------ID code");
					tempSeqF95aBean.getNsTRRE().getNsF95P().setNsIdentifierCode(tempParty.getPartyValue());
					
				} else if (null != tempParty.getOptions() && "Name and Address".equalsIgnoreCase(tempParty.getOptions())) {
					
					//LogUtils.log("SeqF Update-----Party-----TRRE------N and A");
					tempSeqF95aBean.getNsTRRE().getNsF95Q().getNsNameAndAddress().setNsLine(new String[4]);
					
					tempSeqF95aBean.getNsTRRE().getNsF95Q().getNsNameAndAddress().getNsLine()[0] = tempParty.getAddress1();
					tempSeqF95aBean.getNsTRRE().getNsF95Q().getNsNameAndAddress().getNsLine()[1] = tempParty.getAddress2();
					tempSeqF95aBean.getNsTRRE().getNsF95Q().getNsNameAndAddress().getNsLine()[2] = tempParty.getAddress3();
					tempSeqF95aBean.getNsTRRE().getNsF95Q().getNsNameAndAddress().getNsLine()[3] = tempParty.getAddress4();
					
				} else if (null != tempParty.getOptions() && "Proprietary Code".equalsIgnoreCase(tempParty.getOptions())) {
					
					//LogUtils.log("SeqF Update-----Party-----TRRE------Prop code");
					tempSeqF95aBean.getNsTRRE().getNsF95R().setNsProprietaryCode(tempParty.getPartyValue());
					tempSeqF95aBean.getNsTRRE().getNsF95R().setNsDataSourceScheme(tempParty.getDataSourceSchemeValue());
					
				} 
				//SR2016
				if(null!= tempParty.getLegalEntityIdentifier()){
					//LogUtils.log("SeqF Update-----Party-----TRRE------ALTE code");
				tempSeqF95aBean1.getNsALTE().getNsF95L().setNsLegalEntityIdentifier(tempParty.getLegalEntityIdentifier());
			}
			}
			
			// For INVE
			if (null != tempParty.getQualifier() && "INVE".equalsIgnoreCase(tempParty.getQualifier())) {
				
				if (null != tempParty.getOptions() && "Identifier Code".equalsIgnoreCase(tempParty.getOptions())) {
					//LogUtils.log("SeqF Update-----Party-----INVE------ID code");
					tempSeqF95aBean.getNsINVE().getNsF95P().setNsIdentifierCode(tempParty.getPartyValue());
					
				} else if (null != tempParty.getOptions() && "Name and Address".equalsIgnoreCase(tempParty.getOptions())) {
					
					tempSeqF95aBean.getNsINVE().getNsF95Q().getNsNameAndAddress().setNsLine(new String[4]);
					
					tempSeqF95aBean.getNsINVE().getNsF95Q().getNsNameAndAddress().getNsLine()[0] = tempParty.getAddress1();
					tempSeqF95aBean.getNsINVE().getNsF95Q().getNsNameAndAddress().getNsLine()[1] = tempParty.getAddress2();
					tempSeqF95aBean.getNsINVE().getNsF95Q().getNsNameAndAddress().getNsLine()[2] = tempParty.getAddress3();
					tempSeqF95aBean.getNsINVE().getNsF95Q().getNsNameAndAddress().getNsLine()[3] = tempParty.getAddress4();
					
				} else if (null != tempParty.getOptions() && "Proprietary Code".equalsIgnoreCase(tempParty.getOptions())) {
					
					tempSeqF95aBean.getNsINVE().getNsF95R().setNsProprietaryCode(tempParty.getPartyValue());
					tempSeqF95aBean.getNsINVE().getNsF95R().setNsDataSourceScheme(tempParty.getDataSourceSchemeValue());
					
				} else if (null != tempParty.getOptions() && "Country Code".equalsIgnoreCase(tempParty.getOptions())) {
					
					tempSeqF95aBean.getNsINVE().getNsF95C().setNsCountryCode(tempParty.getCountryCode());
				}
				//SR2016
				if(null!= tempParty.getLegalEntityIdentifier()){
					//LogUtils.log("SeqF Update-----Party-----INVE------ALTE code");
					tempSeqF95aBean1.getNsALTE().getNsF95L().setNsLegalEntityIdentifier(tempParty.getLegalEntityIdentifier());
				}
			}
			
			// For VEND
			if (null != tempParty.getQualifier() && "VEND".equalsIgnoreCase(tempParty.getQualifier())) {
				
				if (null != tempParty.getOptions() && "Identifier Code".equalsIgnoreCase(tempParty.getOptions())) {
					
					tempSeqF95aBean.getNsVEND().getNsF95P().setNsIdentifierCode(tempParty.getPartyValue());
					
				} else if (null != tempParty.getOptions() && "Name and Address".equalsIgnoreCase(tempParty.getOptions())) {
					
					tempSeqF95aBean.getNsVEND().getNsF95Q().getNsNameAndAddress().setNsLine(new String[4]);
					
					tempSeqF95aBean.getNsVEND().getNsF95Q().getNsNameAndAddress().getNsLine()[0] = tempParty.getAddress1();
					tempSeqF95aBean.getNsVEND().getNsF95Q().getNsNameAndAddress().getNsLine()[1] = tempParty.getAddress2();
					tempSeqF95aBean.getNsVEND().getNsF95Q().getNsNameAndAddress().getNsLine()[2] = tempParty.getAddress3();
					tempSeqF95aBean.getNsVEND().getNsF95Q().getNsNameAndAddress().getNsLine()[3] = tempParty.getAddress4();
					
				} else if (null != tempParty.getOptions() && "Proprietary Code".equalsIgnoreCase(tempParty.getOptions())) {
					
					tempSeqF95aBean.getNsVEND().getNsF95R().setNsProprietaryCode(tempParty.getPartyValue());
					tempSeqF95aBean.getNsVEND().getNsF95R().setNsDataSourceScheme(tempParty.getDataSourceSchemeValue());
					
				} 
				//SR2016
				if(null!= tempParty.getLegalEntityIdentifier()){
					//LogUtils.log("SeqF Update-----Party-----VEND------ALTE code");
				tempSeqF95aBean1.getNsALTE().getNsF95L().setNsLegalEntityIdentifier(tempParty.getLegalEntityIdentifier());
		}
			}
			
			// For TRAG
			if (null != tempParty.getQualifier() && "TRAG".equalsIgnoreCase(tempParty.getQualifier())) {
				
				if (null != tempParty.getOptions() && "Identifier Code".equalsIgnoreCase(tempParty.getOptions())) {
					
					tempSeqF95aBean.getNsTRAG().getNsF95P().setNsIdentifierCode(tempParty.getPartyValue());
					
				} else if (null != tempParty.getOptions() && "Name and Address".equalsIgnoreCase(tempParty.getOptions())) {
					
					tempSeqF95aBean.getNsTRAG().getNsF95Q().getNsNameAndAddress().setNsLine(new String[4]);
					
					tempSeqF95aBean.getNsTRAG().getNsF95Q().getNsNameAndAddress().getNsLine()[0] = tempParty.getAddress1();
					tempSeqF95aBean.getNsTRAG().getNsF95Q().getNsNameAndAddress().getNsLine()[1] = tempParty.getAddress2();
					tempSeqF95aBean.getNsTRAG().getNsF95Q().getNsNameAndAddress().getNsLine()[2] = tempParty.getAddress3();
					tempSeqF95aBean.getNsTRAG().getNsF95Q().getNsNameAndAddress().getNsLine()[3] = tempParty.getAddress4();
					
				} else if (null != tempParty.getOptions() && "Proprietary Code".equalsIgnoreCase(tempParty.getOptions())) {
					
					tempSeqF95aBean.getNsTRAG().getNsF95R().setNsProprietaryCode(tempParty.getPartyValue());
					tempSeqF95aBean.getNsTRAG().getNsF95R().setNsDataSourceScheme(tempParty.getDataSourceSchemeValue());
				} 
				//SR2016
			if(null!= tempParty.getLegalEntityIdentifier()){
				//LogUtils.log("SeqF Update-----Party-----TRAG------ALTE code");
					tempSeqF95aBean1.getNsALTE().getNsF95L().setNsLegalEntityIdentifier(tempParty.getLegalEntityIdentifier());
				}
			}
			
			// BRKR
			if (null != tempParty.getQualifier() && "BRKR".equalsIgnoreCase(tempParty.getQualifier())) {
				
				if (null != tempParty.getOptions() && "Identifier Code".equalsIgnoreCase(tempParty.getOptions())) {
					
					tempSeqF95aBean.getNsBRKR().getNsF95P().setNsIdentifierCode(tempParty.getPartyValue());
					
				} else if (null != tempParty.getOptions() && "Name and Address".equalsIgnoreCase(tempParty.getOptions())) {
					
					tempSeqF95aBean.getNsBRKR().getNsF95Q().getNsNameAndAddress().setNsLine(new String[4]);
					
					tempSeqF95aBean.getNsBRKR().getNsF95Q().getNsNameAndAddress().getNsLine()[0] = tempParty.getAddress1();
					tempSeqF95aBean.getNsBRKR().getNsF95Q().getNsNameAndAddress().getNsLine()[1] = tempParty.getAddress2();
					tempSeqF95aBean.getNsBRKR().getNsF95Q().getNsNameAndAddress().getNsLine()[2] = tempParty.getAddress3();
					tempSeqF95aBean.getNsBRKR().getNsF95Q().getNsNameAndAddress().getNsLine()[3] = tempParty.getAddress4();
					
				} else if (null != tempParty.getOptions() && "Proprietary Code".equalsIgnoreCase(tempParty.getOptions())) {
					
					tempSeqF95aBean.getNsBRKR().getNsF95R().setNsProprietaryCode(tempParty.getPartyValue());
					tempSeqF95aBean.getNsBRKR().getNsF95R().setNsDataSourceScheme(tempParty.getDataSourceSchemeValue());
				} 
				//SR2016
			if(null!= tempParty.getLegalEntityIdentifier()){
			tempSeqF95aBean1.getNsALTE().getNsF95L().setNsLegalEntityIdentifier(tempParty.getLegalEntityIdentifier());
			}
			}
			
			//LogUtils.log("Seq F update----setting bean to the array------->");
			
			tempSeqF95aArr[0] = tempSeqF95aBean;
			//SR2016
			if(null != tempSeqF95aBean1){
				tempSeqF95aArr[1] = tempSeqF95aBean1;
			
		//	tempSeqF95aArr1=tempSeqF95aArr;
			}
			
			}//if
			
		
	return tempSeqF95aArr;
	}//method
}
			/*
			for (int i =0 ; i<tempParty_95AArr.length ; i++) {
				
			//	if(i==0){
				
				TMCommon_docType_MT54x_docTypeRef_ns_SeqF_F95a_Type tempSeqF95aBean = new TMCommon_docType_MT54x_docTypeRef_ns_SeqF_F95a_Type();
				TMCommon_docType_MT54x_docTypeRef_ns_SeqF_F95a_Type tempSeqF95aBean1 = new TMCommon_docType_MT54x_docTypeRef_ns_SeqF_F95a_Type();//SR2016
			/*	
				//SR2016
				if(tempParty_95AArr[i].getLegalEntityIdentifier()!=null){
					tempSeqF95aArr = new TMCommon_docType_MT54x_docTypeRef_ns_SeqF_F95a_Type [2];
				}
				
				//For EXCH
				if (null != tempParty_95AArr[i].getQualifier() && "EXCH".equalsIgnoreCase(tempParty_95AArr[i].getQualifier())) {
					
					if (null != tempParty_95AArr[i].getOptions() && "Identifier Code".equalsIgnoreCase(tempParty_95AArr[i].getOptions())) {
						
						LogUtils.log("SeqF Update-----Party-----EXCH------ID code");
						tempSeqF95aBean.getNsEXCH().getNsF95P().setNsIdentifierCode(tempParty_95AArr[i].getPartyValue());
						
					} else if (null != tempParty_95AArr[i].getOptions() && "Name and Address".equalsIgnoreCase(tempParty_95AArr[i].getOptions())) {
						LogUtils.log("SeqF Update-----Party-----EXCH------N and A");
						tempSeqF95aBean.getNsEXCH().getNsF95Q().getNsNameAndAddress().setNsLine(new String[4]);
						
						tempSeqF95aBean.getNsEXCH().getNsF95Q().getNsNameAndAddress().getNsLine()[0] = tempParty_95AArr[i].getAddress1();
						tempSeqF95aBean.getNsEXCH().getNsF95Q().getNsNameAndAddress().getNsLine()[1] = tempParty_95AArr[i].getAddress2();
						tempSeqF95aBean.getNsEXCH().getNsF95Q().getNsNameAndAddress().getNsLine()[2] = tempParty_95AArr[i].getAddress3();
						tempSeqF95aBean.getNsEXCH().getNsF95Q().getNsNameAndAddress().getNsLine()[3] = tempParty_95AArr[i].getAddress4();
						
					} else if (null != tempParty_95AArr[i].getOptions() && "Proprietary Code".equalsIgnoreCase(tempParty_95AArr[i].getOptions())) {
						
						LogUtils.log("SeqF Update-----Party-----EXCH-----Prop code");
						tempSeqF95aBean.getNsEXCH().getNsF95R().setNsProprietaryCode(tempParty_95AArr[i].getPartyValue());
						tempSeqF95aBean.getNsEXCH().getNsF95R().setNsDataSourceScheme(tempParty_95AArr[i].getDataSourceSchemeValue());
						
					} 
					
					//SR2016
					if( null != tempParty_95AArr[i].getLegalEntityIdentifier()){
						
						LogUtils.log("SeqF Update-----Party-----EXCH------LEI code");
					tempSeqF95aBean1.getNsALTE().getNsF95L().setNsLegalEntityIdentifier(tempParty_95AArr[i].getLegalEntityIdentifier());
					//}
				}
				
				// For MEOR
				if (null != tempParty_95AArr[i].getQualifier() && "MEOR".equalsIgnoreCase(tempParty_95AArr[i].getQualifier())) {
					
					if (null != tempParty_95AArr[i].getOptions() && "Identifier Code".equalsIgnoreCase(tempParty_95AArr[i].getOptions())) {
						
						LogUtils.log("SeqF Update-----Party-----MEOR------ID code");
						
						tempSeqF95aBean.getNsMEOR().getNsF95P().setNsIdentifierCode(tempParty_95AArr[i].getPartyValue());
						
					} else if (null != tempParty_95AArr[i].getOptions() && "Name and Address".equalsIgnoreCase(tempParty_95AArr[i].getOptions())) {
						LogUtils.log("SeqF Update-----Party-----MEOR------N and A");
						
						tempSeqF95aBean.getNsMEOR().getNsF95Q().getNsNameAndAddress().setNsLine(new String[4]);
						
						tempSeqF95aBean.getNsMEOR().getNsF95Q().getNsNameAndAddress().getNsLine()[0] = tempParty_95AArr[i].getAddress1();
						tempSeqF95aBean.getNsMEOR().getNsF95Q().getNsNameAndAddress().getNsLine()[1] = tempParty_95AArr[i].getAddress2();
						tempSeqF95aBean.getNsMEOR().getNsF95Q().getNsNameAndAddress().getNsLine()[2] = tempParty_95AArr[i].getAddress3();
						tempSeqF95aBean.getNsMEOR().getNsF95Q().getNsNameAndAddress().getNsLine()[3] = tempParty_95AArr[i].getAddress4();
						
					} else if (null != tempParty_95AArr[i].getOptions() && "Proprietary Code".equalsIgnoreCase(tempParty_95AArr[i].getOptions())) {
						
						LogUtils.log("SeqF Update-----Party-----MEOR------Prop code");
						tempSeqF95aBean.getNsMEOR().getNsF95R().setNsProprietaryCode(tempParty_95AArr[i].getPartyValue());
						tempSeqF95aBean.getNsMEOR().getNsF95R().setNsDataSourceScheme(tempParty_95AArr[i].getDataSourceSchemeValue());
						
					} 
				}
				
				// For MERE
				if (null != tempParty_95AArr[i].getQualifier() && "MERE".equalsIgnoreCase(tempParty_95AArr[i].getQualifier())) {
					
					if (null != tempParty_95AArr[i].getOptions() && "Identifier Code".equalsIgnoreCase(tempParty_95AArr[i].getOptions())) {
						
						LogUtils.log("SeqF Update-----Party-----MERE------ID code");
						
						tempSeqF95aBean.getNsMERE().getNsF95P().setNsIdentifierCode(tempParty_95AArr[i].getPartyValue());
						
					} else if (null != tempParty_95AArr[i].getOptions() && "Name and Address".equalsIgnoreCase(tempParty_95AArr[i].getOptions())) {
						
						LogUtils.log("SeqF Update-----Party-----MERE------N and A");
						
						tempSeqF95aBean.getNsMERE().getNsF95Q().getNsNameAndAddress().setNsLine(new String[4]);
						
						tempSeqF95aBean.getNsMERE().getNsF95Q().getNsNameAndAddress().getNsLine()[0] = tempParty_95AArr[i].getAddress1();
						tempSeqF95aBean.getNsMERE().getNsF95Q().getNsNameAndAddress().getNsLine()[1] = tempParty_95AArr[i].getAddress2();
						tempSeqF95aBean.getNsMERE().getNsF95Q().getNsNameAndAddress().getNsLine()[2] = tempParty_95AArr[i].getAddress3();
						tempSeqF95aBean.getNsMERE().getNsF95Q().getNsNameAndAddress().getNsLine()[3] = tempParty_95AArr[i].getAddress4();
						
					} else if (null != tempParty_95AArr[i].getOptions() && "Proprietary Code".equalsIgnoreCase(tempParty_95AArr[i].getOptions())) {
						
						LogUtils.log("SeqF Update-----Party-----MERE------Prop code");
						tempSeqF95aBean.getNsMERE().getNsF95R().setNsProprietaryCode(tempParty_95AArr[i].getPartyValue());
						tempSeqF95aBean.getNsMERE().getNsF95R().setNsDataSourceScheme(tempParty_95AArr[i].getDataSourceSchemeValue());
						
					} 
				}
				
				//For TRRE
				if (null != tempParty_95AArr[i].getQualifier() && "TRRE".equalsIgnoreCase(tempParty_95AArr[i].getQualifier())) {
					
					if (null != tempParty_95AArr[i].getOptions() && "Identifier Code".equalsIgnoreCase(tempParty_95AArr[i].getOptions())) {
						
						LogUtils.log("SeqF Update-----Party-----TRRE------ID code");
						tempSeqF95aBean.getNsTRRE().getNsF95P().setNsIdentifierCode(tempParty_95AArr[i].getPartyValue());
						
					} else if (null != tempParty_95AArr[i].getOptions() && "Name and Address".equalsIgnoreCase(tempParty_95AArr[i].getOptions())) {
						
						LogUtils.log("SeqF Update-----Party-----TRRE------N and A");
						tempSeqF95aBean.getNsTRRE().getNsF95Q().getNsNameAndAddress().setNsLine(new String[4]);
						
						tempSeqF95aBean.getNsTRRE().getNsF95Q().getNsNameAndAddress().getNsLine()[0] = tempParty_95AArr[i].getAddress1();
						tempSeqF95aBean.getNsTRRE().getNsF95Q().getNsNameAndAddress().getNsLine()[1] = tempParty_95AArr[i].getAddress2();
						tempSeqF95aBean.getNsTRRE().getNsF95Q().getNsNameAndAddress().getNsLine()[2] = tempParty_95AArr[i].getAddress3();
						tempSeqF95aBean.getNsTRRE().getNsF95Q().getNsNameAndAddress().getNsLine()[3] = tempParty_95AArr[i].getAddress4();
						
					} else if (null != tempParty_95AArr[i].getOptions() && "Proprietary Code".equalsIgnoreCase(tempParty_95AArr[i].getOptions())) {
						
						LogUtils.log("SeqF Update-----Party-----TRRE------Prop code");
						tempSeqF95aBean.getNsTRRE().getNsF95R().setNsProprietaryCode(tempParty_95AArr[i].getPartyValue());
						tempSeqF95aBean.getNsTRRE().getNsF95R().setNsDataSourceScheme(tempParty_95AArr[i].getDataSourceSchemeValue());
						
					} 
					//SR2016
					if(null!= tempParty_95AArr[i].getLegalEntityIdentifier()){
					tempSeqF95aBean1.getNsALTE().getNsF95L().setNsLegalEntityIdentifier(tempParty_95AArr[i].getLegalEntityIdentifier());
				}
				}
				
				// For INVE
				if (null != tempParty_95AArr[i].getQualifier() && "INVE".equalsIgnoreCase(tempParty_95AArr[i].getQualifier())) {
					
					if (null != tempParty_95AArr[i].getOptions() && "Identifier Code".equalsIgnoreCase(tempParty_95AArr[i].getOptions())) {
						
						tempSeqF95aBean.getNsINVE().getNsF95P().setNsIdentifierCode(tempParty_95AArr[i].getPartyValue());
						
					} else if (null != tempParty_95AArr[i].getOptions() && "Name and Address".equalsIgnoreCase(tempParty_95AArr[i].getOptions())) {
						
						tempSeqF95aBean.getNsINVE().getNsF95Q().getNsNameAndAddress().setNsLine(new String[4]);
						
						tempSeqF95aBean.getNsINVE().getNsF95Q().getNsNameAndAddress().getNsLine()[0] = tempParty_95AArr[i].getAddress1();
						tempSeqF95aBean.getNsINVE().getNsF95Q().getNsNameAndAddress().getNsLine()[1] = tempParty_95AArr[i].getAddress2();
						tempSeqF95aBean.getNsINVE().getNsF95Q().getNsNameAndAddress().getNsLine()[2] = tempParty_95AArr[i].getAddress3();
						tempSeqF95aBean.getNsINVE().getNsF95Q().getNsNameAndAddress().getNsLine()[3] = tempParty_95AArr[i].getAddress4();
						
					} else if (null != tempParty_95AArr[i].getOptions() && "Proprietary Code".equalsIgnoreCase(tempParty_95AArr[i].getOptions())) {
						
						tempSeqF95aBean.getNsINVE().getNsF95R().setNsProprietaryCode(tempParty_95AArr[i].getPartyValue());
						tempSeqF95aBean.getNsINVE().getNsF95R().setNsDataSourceScheme(tempParty_95AArr[i].getDataSourceSchemeValue());
						
					} else if (null != tempParty_95AArr[i].getOptions() && "Country Code".equalsIgnoreCase(tempParty_95AArr[i].getOptions())) {
						
						tempSeqF95aBean.getNsINVE().getNsF95C().setNsCountryCode(tempParty_95AArr[i].getCountryCode());
					}
					//SR2016
					if(null!= tempParty_95AArr[i].getLegalEntityIdentifier()){
						tempSeqF95aBean1.getNsALTE().getNsF95L().setNsLegalEntityIdentifier(tempParty_95AArr[i].getLegalEntityIdentifier());
					}
				}
				
				// For VEND
				if (null != tempParty_95AArr[i].getQualifier() && "VEND".equalsIgnoreCase(tempParty_95AArr[i].getQualifier())) {
					
					if (null != tempParty_95AArr[i].getOptions() && "Identifier Code".equalsIgnoreCase(tempParty_95AArr[i].getOptions())) {
						
						tempSeqF95aBean.getNsVEND().getNsF95P().setNsIdentifierCode(tempParty_95AArr[i].getPartyValue());
						
					} else if (null != tempParty_95AArr[i].getOptions() && "Name and Address".equalsIgnoreCase(tempParty_95AArr[i].getOptions())) {
						
						tempSeqF95aBean.getNsVEND().getNsF95Q().getNsNameAndAddress().setNsLine(new String[4]);
						
						tempSeqF95aBean.getNsVEND().getNsF95Q().getNsNameAndAddress().getNsLine()[0] = tempParty_95AArr[i].getAddress1();
						tempSeqF95aBean.getNsVEND().getNsF95Q().getNsNameAndAddress().getNsLine()[1] = tempParty_95AArr[i].getAddress2();
						tempSeqF95aBean.getNsVEND().getNsF95Q().getNsNameAndAddress().getNsLine()[2] = tempParty_95AArr[i].getAddress3();
						tempSeqF95aBean.getNsVEND().getNsF95Q().getNsNameAndAddress().getNsLine()[3] = tempParty_95AArr[i].getAddress4();
						
					} else if (null != tempParty_95AArr[i].getOptions() && "Proprietary Code".equalsIgnoreCase(tempParty_95AArr[i].getOptions())) {
						
						tempSeqF95aBean.getNsVEND().getNsF95R().setNsProprietaryCode(tempParty_95AArr[i].getPartyValue());
						tempSeqF95aBean.getNsVEND().getNsF95R().setNsDataSourceScheme(tempParty_95AArr[i].getDataSourceSchemeValue());
						
					} 
					//SR2016
					if(null!= tempParty_95AArr[i].getLegalEntityIdentifier()){
					tempSeqF95aBean1.getNsALTE().getNsF95L().setNsLegalEntityIdentifier(tempParty_95AArr[i].getLegalEntityIdentifier());
			}
				}
				
				// For TRAG
				if (null != tempParty_95AArr[i].getQualifier() && "TRAG".equalsIgnoreCase(tempParty_95AArr[i].getQualifier())) {
					
					if (null != tempParty_95AArr[i].getOptions() && "Identifier Code".equalsIgnoreCase(tempParty_95AArr[i].getOptions())) {
						
						tempSeqF95aBean.getNsTRAG().getNsF95P().setNsIdentifierCode(tempParty_95AArr[i].getPartyValue());
						
					} else if (null != tempParty_95AArr[i].getOptions() && "Name and Address".equalsIgnoreCase(tempParty_95AArr[i].getOptions())) {
						
						tempSeqF95aBean.getNsTRAG().getNsF95Q().getNsNameAndAddress().setNsLine(new String[4]);
						
						tempSeqF95aBean.getNsTRAG().getNsF95Q().getNsNameAndAddress().getNsLine()[0] = tempParty_95AArr[i].getAddress1();
						tempSeqF95aBean.getNsTRAG().getNsF95Q().getNsNameAndAddress().getNsLine()[1] = tempParty_95AArr[i].getAddress2();
						tempSeqF95aBean.getNsTRAG().getNsF95Q().getNsNameAndAddress().getNsLine()[2] = tempParty_95AArr[i].getAddress3();
						tempSeqF95aBean.getNsTRAG().getNsF95Q().getNsNameAndAddress().getNsLine()[3] = tempParty_95AArr[i].getAddress4();
						
					} else if (null != tempParty_95AArr[i].getOptions() && "Proprietary Code".equalsIgnoreCase(tempParty_95AArr[i].getOptions())) {
						
						tempSeqF95aBean.getNsTRAG().getNsF95R().setNsProprietaryCode(tempParty_95AArr[i].getPartyValue());
						tempSeqF95aBean.getNsTRAG().getNsF95R().setNsDataSourceScheme(tempParty_95AArr[i].getDataSourceSchemeValue());
					} 
					//SR2016
				if(null!= tempParty_95AArr[i].getLegalEntityIdentifier()){
						tempSeqF95aBean1.getNsALTE().getNsF95L().setNsLegalEntityIdentifier(tempParty_95AArr[i].getLegalEntityIdentifier());
					}
				}
				
				// Chnages For SR 2011
				
				if (null != tempParty_95AArr[i].getQualifier() && "BRKR".equalsIgnoreCase(tempParty_95AArr[i].getQualifier())) {
					
					if (null != tempParty_95AArr[i].getOptions() && "Identifier Code".equalsIgnoreCase(tempParty_95AArr[i].getOptions())) {
						
						tempSeqF95aBean.getNsBRKR().getNsF95P().setNsIdentifierCode(tempParty_95AArr[i].getPartyValue());
						
					} else if (null != tempParty_95AArr[i].getOptions() && "Name and Address".equalsIgnoreCase(tempParty_95AArr[i].getOptions())) {
						
						tempSeqF95aBean.getNsBRKR().getNsF95Q().getNsNameAndAddress().setNsLine(new String[4]);
						
						tempSeqF95aBean.getNsBRKR().getNsF95Q().getNsNameAndAddress().getNsLine()[0] = tempParty_95AArr[i].getAddress1();
						tempSeqF95aBean.getNsBRKR().getNsF95Q().getNsNameAndAddress().getNsLine()[1] = tempParty_95AArr[i].getAddress2();
						tempSeqF95aBean.getNsBRKR().getNsF95Q().getNsNameAndAddress().getNsLine()[2] = tempParty_95AArr[i].getAddress3();
						tempSeqF95aBean.getNsBRKR().getNsF95Q().getNsNameAndAddress().getNsLine()[3] = tempParty_95AArr[i].getAddress4();
						
					} else if (null != tempParty_95AArr[i].getOptions() && "Proprietary Code".equalsIgnoreCase(tempParty_95AArr[i].getOptions())) {
						
						tempSeqF95aBean.getNsBRKR().getNsF95R().setNsProprietaryCode(tempParty_95AArr[i].getPartyValue());
						tempSeqF95aBean.getNsBRKR().getNsF95R().setNsDataSourceScheme(tempParty_95AArr[i].getDataSourceSchemeValue());
					} 
					//SR2016
				if(null!= tempParty_95AArr[i].getLegalEntityIdentifier()){
				tempSeqF95aBean1.getNsALTE().getNsF95L().setNsLegalEntityIdentifier(tempParty_95AArr[i].getLegalEntityIdentifier());
				}
				}
				
				/* Commenting for earlier changes for SR2016
				// For ALTE
				if (null != tempParty_95AArr[i].getQualifier() && "ALTE".equalsIgnoreCase(tempParty_95AArr[i].getQualifier())) {
					
					if (null != tempParty_95AArr[i].getOptions() && "Country Code".equalsIgnoreCase(tempParty_95AArr[i].getOptions())) {
					
						if (null != tempParty_95AArr[i].getDataSourceScheme() && "Data Source Scheme".equalsIgnoreCase(tempParty_95AArr[i].getDataSourceScheme())) {
							
							tempSeqF95aBean.getNsALTE().getNsF95S().setNsDataSourceScheme(tempParty_95AArr[i].getDataSourceSchemeValue());
							tempSeqF95aBean.getNsALTE().getNsF95S().setNsCountryCode(tempParty_95AArr[i].getCountryCode());
							tempSeqF95aBean.getNsALTE().getNsF95S().setNsAlternateID(tempParty_95AArr[i].getAlternateID());
							
						} else if (null != tempParty_95AArr[i].getTypeOfID()) {
							
							tempSeqF95aBean.getNsALTE().getNsF95S().setNsCountryCode(tempParty_95AArr[i].getCountryCode());
							tempSeqF95aBean.getNsALTE().getNsF95S().setNsAlternateID(tempParty_95AArr[i].getAlternateID());
							tempSeqF95aBean.getNsALTE().getNsF95S().setNsTypeOfID(tempParty_95AArr[i].getTypeOfID());
							
						} 
					}
				}
				//SR2016
				if (null != tempParty_95AArr[i].getQualifier() && "ALTE1".equalsIgnoreCase(tempParty_95AArr[i].getQualifier())) {
					
					if (null != tempParty_95AArr[i].getOptions() && "LegalEntityIdentifier".equalsIgnoreCase(tempParty_95AArr[i].getOptions())) {

						//	tempSeqF95aBean.getNsALTE().getNsF95L().setNsLegalEntityIdentifier(tempParty_95AArr[i].getAlternateID());
						tempSeqF95aBean.getNsALTE().getNsF95L().setNsLegalEntityIdentifier(tempParty_95AArr[i].getPartyValue());
 
					}
				}
				//SR2016
				 * */
			
			/*
				LogUtils.log("Seq F update----setting bean to the array------->");
				
				tempSeqF95aArr[0] = tempSeqF95aBean;
				//SR2016
				if(null != tempSeqF95aBean1){
					tempSeqF95aArr[1] = tempSeqF95aBean1;
				
			//	tempSeqF95aArr1=tempSeqF95aArr;
				}
				
			}
			
				
			//her we
			}
		}
	
		//}
		
			return tempSeqF95aArr;
	
}}*/
