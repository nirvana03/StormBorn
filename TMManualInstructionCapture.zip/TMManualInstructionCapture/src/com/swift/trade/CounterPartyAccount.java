package com.swift.trade;

public class CounterPartyAccount {
	
	private String id;
	private String qualifier;
	private String qualifierType;
	private String qualifierValue;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getQualifier() {
		return qualifier;
	}
	public void setQualifier(String qualifier) {
		this.qualifier = qualifier;
	}
	public String getQualifierType() {
		return qualifierType;
	}
	public void setQualifierType(String qualifierType) {
		this.qualifierType = qualifierType;
	}
	public String getQualifierValue() {
		return qualifierValue;
	}
	public void setQualifierValue(String qualifierValue) {
		this.qualifierValue = qualifierValue;
	}
	

}
