package com.swift.trade;

public class SecurityName {
	
	private String securityName;

	public String getSecurityName() {
		return securityName;
	}

	public void setSecurityName(String securityName) {
		this.securityName = securityName;
	}

}
