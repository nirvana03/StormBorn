package com.swift.trade;

public class SettlementLink {
	
	private String id="";
	private String indicator="";
	private String numberIndicator="";
	private String referenceType="";
	private String qualifier="";
	private String quantityType="";
	private String quantity="";
	private String referenceValue="";
	private String indicator_DataSourceScheme;
	private String indicator_DataSourceScheme_value="";
	private String numberIdType="";
	private String numberId="";
	private String number_DataSourceScheme_value="";
	
	
	
	
	public String getNumberIdType() {
		return numberIdType;
	}
	public void setNumberIdType(String numberIdType) {
		this.numberIdType = numberIdType;
	}
	public String getNumberId() {
		return numberId;
	}
	public void setNumberId(String numberId) {
		this.numberId = numberId;
	}
	public String getNumber_DataSourceScheme_value() {
		return number_DataSourceScheme_value;
	}
	public void setNumber_DataSourceScheme_value(
			String number_DataSourceScheme_value) {
		this.number_DataSourceScheme_value = number_DataSourceScheme_value;
	}

	
	
	
	
	public String getIndicator_DataSourceScheme() {
		return indicator_DataSourceScheme;
	}
	public void setIndicator_DataSourceScheme(String indicator_DataSourceScheme) {
		this.indicator_DataSourceScheme = indicator_DataSourceScheme;
	}
	public String getIndicator_DataSourceScheme_value() {
		return indicator_DataSourceScheme_value;
	}
	public void setIndicator_DataSourceScheme_value(
			String indicator_DataSourceScheme_value) {
		this.indicator_DataSourceScheme_value = indicator_DataSourceScheme_value;
	}
	
	
	
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getIndicator() {
		return indicator;
	}
	public void setIndicator(String indicator) {
		this.indicator = indicator;
	}
	public String getNumberIndicator() {
		return numberIndicator;
	}
	public void setNumberIndicator(String numberIndicator) {
		this.numberIndicator = numberIndicator;
	}
	public String getReferenceType() {
		return referenceType;
	}
	public void setReferenceType(String referenceType) {
		this.referenceType = referenceType;
	}
	public String getQualifier() {
		return qualifier;
	}
	public void setQualifier(String qualifier) {
		this.qualifier = qualifier;
	}
	public String getQuantityType() {
		return quantityType;
	}
	public void setQuantityType(String quantityType) {
		this.quantityType = quantityType;
	}
	public String getQuantity() {
		return quantity;
	}
	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}
	public String getReferenceValue() {
		return referenceValue;
	}
	public void setReferenceValue(String referenceValue) {
		this.referenceValue = referenceValue;
	}
	
	
	

}
