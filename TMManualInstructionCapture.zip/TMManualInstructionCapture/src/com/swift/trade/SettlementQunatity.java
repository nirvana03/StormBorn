package com.swift.trade;

public class SettlementQunatity {
	private String id;
	private String quantityTypeCode;
	public String getQuantityTypeCode() {
		return quantityTypeCode;
	}
	public void setQuantityTypeCode(String quantityTypeCode) {
		this.quantityTypeCode = quantityTypeCode;
	}
	public String getQuantityValue() {
		return quantityValue;
	}
	public void setQuantityValue(String quantityValue) {
		this.quantityValue = quantityValue;
	}
	private String quantityValue;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	
	
	

}
