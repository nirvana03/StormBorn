package com.swift.trade;

public class TradeInfoMasterBean {
	
	private String transactionType;
	private String tradeDate;
	private String settlementDate;
	private String securityCode;
	private String securityCodeValue;
	private String placeOfTradeCode;
	private String placeOfTradeCodeValue;
	private String tradeDesc;
	private String placeOfClearingCode;
	private String clearingDesc;
	private String settCurrencyCode;
	private String settCurrencyAmt;
	private String safeAccount;
	private String registrarAccount;
	private String cashAccountType;
	private String cashAccount;
	private String dealPriceType;
	private String dealPriceCode;
	private String dealPriceCurrency;
	private String dealPriceValue;
	private String placeOfSafeKeepingOpt;
	private String placeOfSafeKeepingCode;
	private String placeOfSafeKeepingNarrative;
	private String placeOfSafeKeepingBIC;
	private String placeOfSafeKeepingCountryCode;
	private String settCount;
	private String dateTimeReceived;
	private String settSign;
	private String placeSafeKeeping_DataSourceScheme;
	private String placeSafeKeeping_DataSourceScheme_value;
	private String placeOfTradeCode_DataSourceScheme;
	private String placeOfListing_DataSourceScheme;
	private String seqBCurrency;
	private String seqBCurrencyQualifier;
	private String sourceChannel;
	private String relatedTMInstructionID;
	
	
	
	public String getRelatedTMInstructionID() {
		return relatedTMInstructionID;
	}
	public void setRelatedTMInstructionID(String relatedTMInstructionID) {
		this.relatedTMInstructionID = relatedTMInstructionID;
	}
	/**
	 * @return the sourceChannel
	 */
	public String getSourceChannel() {
		return sourceChannel;
	}
	/**
	 * @param sourceChannel the sourceChannel to set
	 */
	public void setSourceChannel(String sourceChannel) {
		this.sourceChannel = sourceChannel;
	}
	public String getPlaceOfListing_DataSourceScheme() {
		return placeOfListing_DataSourceScheme;
	}
	public void setPlaceOfListing_DataSourceScheme(
			String placeOfListing_DataSourceScheme) {
		this.placeOfListing_DataSourceScheme = placeOfListing_DataSourceScheme;
	}
	public String getPlaceOfTradeCode_DataSourceScheme() {
		return placeOfTradeCode_DataSourceScheme;
	}
	public void setPlaceOfTradeCode_DataSourceScheme(
			String placeOfTradeCode_DataSourceScheme) {
		this.placeOfTradeCode_DataSourceScheme = placeOfTradeCode_DataSourceScheme;
	}
	public String getPlaceOfTradeCode_DataSourceScheme_value() {
		return placeOfTradeCode_DataSourceScheme_value;
	}
	public void setPlaceOfTradeCode_DataSourceScheme_value(
			String placeOfTradeCode_DataSourceScheme_value) {
		this.placeOfTradeCode_DataSourceScheme_value = placeOfTradeCode_DataSourceScheme_value;
	}
	private String placeOfTradeCode_DataSourceScheme_value;
	
	
	
	
	
	public String getPlaceSafeKeeping_DataSourceScheme_value() {
		return placeSafeKeeping_DataSourceScheme_value;
	}
	public void setPlaceSafeKeeping_DataSourceScheme_value(
			String placeSafeKeeping_DataSourceScheme_value) {
		this.placeSafeKeeping_DataSourceScheme_value = placeSafeKeeping_DataSourceScheme_value;
	}
	public String getPlaceSafeKeeping_DataSourceScheme() {
		return placeSafeKeeping_DataSourceScheme;
	}
	public void setPlaceSafeKeeping_DataSourceScheme(
			String placeSafeKeeping_DataSourceScheme) {
		this.placeSafeKeeping_DataSourceScheme = placeSafeKeeping_DataSourceScheme;
	}
	public String getSettCount() {
		return settCount;
	}
	public void setSettCount(String settCount) {
		this.settCount = settCount;
	}
	public String getToseCount() {
		return toseCount;
	}
	public void setToseCount(String toseCount) {
		this.toseCount = toseCount;
	}
	private String toseCount;
	
	private SettlementQunatity[] settlementQunatity ;
	private SettlementParites[] settlementParties;
	private SettlementLink[] settlementLink;
	private CounterPartyAccount[] counterPartyAccount;
	private String[] securityName = new String[4];
	private java.lang.String dealPriceSign;
	private java.lang.String placeOfSafeKeeping_LEI;
	private java.lang.String placeOfTrading_LEI;
	private java.lang.String placeOfClearing_LEI;
	
	public String[] getSecurityName() {
		return securityName;
	}
	public void setSecurityName(String[] securityName) {
		this.securityName = securityName;
	}
	public SettlementParites[] getSettlementParties() {
		return settlementParties;
	}
	public void setSettlementParties(SettlementParites[] settlementParties) {
		this.settlementParties = settlementParties;
	}
	public SettlementQunatity[] getSettlementQunatity() {
		return settlementQunatity;
	}
	public void setSettlementQunatity(SettlementQunatity[] settlementQunatity) {
		this.settlementQunatity = settlementQunatity;
	}
	public String getTransactionType() {
		return transactionType;
	}
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}
	public String getSeqBCurrencyQualifier() {
		return seqBCurrencyQualifier;
	}
	public void setSeqBCurrencyQualifier(String seqBCurrencyQualifier) {
		this.seqBCurrencyQualifier = seqBCurrencyQualifier;
	}
	public String getSeqBCurrency() {
		return seqBCurrency;
	}
	public void setSeqBCurrency(String seqBCurrency) {
		this.seqBCurrency = seqBCurrency;
	}
	public String getTradeDate() {
		return tradeDate;
	}
	public void setTradeDate(String tradeDate) {
		this.tradeDate = tradeDate;
	}
	public String getSettlementDate() {
		return settlementDate;
	}
	public void setSettlementDate(String settlementDate) {
		this.settlementDate = settlementDate;
	}
	public String getSecurityCode() {
		return securityCode;
	}
	public void setSecurityCode(String securityCode) {
		this.securityCode = securityCode;
	}
	public String getSecurityCodeValue() {
		return securityCodeValue;
	}
	public void setSecurityCodeValue(String securityCodeValue) {
		this.securityCodeValue = securityCodeValue;
	}
	public String getPlaceOfTradeCode() {
		return placeOfTradeCode;
	}
	public void setPlaceOfTradeCode(String placeOfTradeCode) {
		this.placeOfTradeCode = placeOfTradeCode;
	}
	public String getPlaceOfTradeCodeValue() {
		return placeOfTradeCodeValue;
	}
	public void setPlaceOfTradeCodeValue(String placeOfTradeCodeValue) {
		this.placeOfTradeCodeValue = placeOfTradeCodeValue;
	}
	public String getTradeDesc() {
		return tradeDesc;
	}
	public void setTradeDesc(String tradeDesc) {
		this.tradeDesc = tradeDesc;
	}
	public String getPlaceOfClearingCode() {
		return placeOfClearingCode;
	}
	public void setPlaceOfClearingCode(String placeOfClearingCode) {
		this.placeOfClearingCode = placeOfClearingCode;
	}

	public String getClearingDesc() {
		return clearingDesc;
	}
	public void setClearingDesc(String clearingDesc) {
		this.clearingDesc = clearingDesc;
	}
	public String getSettCurrencyCode() {
		return settCurrencyCode;
	}
	public void setSettCurrencyCode(String settCurrencyCode) {
		this.settCurrencyCode = settCurrencyCode;
	}
	public String getSettCurrencyAmt() {
		return settCurrencyAmt;
	}
	public void setSettCurrencyAmt(String settCurrencyAmt) {
		this.settCurrencyAmt = settCurrencyAmt;
	}
	public String getSafeAccount() {
		return safeAccount;
	}
	public void setSafeAccount(String safeAccount) {
		this.safeAccount = safeAccount;
	}
	public String getRegistrarAccount() {
		return registrarAccount;
	}
	public void setRegistrarAccount(String registrarAccount) {
		this.registrarAccount = registrarAccount;
	}
	public String getCashAccountType() {
		return cashAccountType;
	}
	public void setCashAccountType(String cashAccountType) {
		this.cashAccountType = cashAccountType;
	}
	public String getCashAccount() {
		return cashAccount;
	}
	public void setCashAccount(String cashAccount) {
		this.cashAccount = cashAccount;
	}
	public String getDealPriceType() {
		return dealPriceType;
	}
	public void setDealPriceType(String dealPriceType) {
		this.dealPriceType = dealPriceType;
	}
	public String getDealPriceCode() {
		return dealPriceCode;
	}
	public void setDealPriceCode(String dealPriceCode) {
		this.dealPriceCode = dealPriceCode;
	}
	public String getDealPriceCurrency() {
		return dealPriceCurrency;
	}
	public void setDealPriceCurrency(String dealPriceCurrency) {
		this.dealPriceCurrency = dealPriceCurrency;
	}
	public String getDealPriceValue() {
		return dealPriceValue;
	}
	public void setDealPriceValue(String dealPriceValue) {
		this.dealPriceValue = dealPriceValue;
	}
	public SettlementLink[] getSettlementLink() {
		return settlementLink;
	}
	public String getDateTimeReceived() {
		return dateTimeReceived;
	}
	public void setDateTimeReceived(String dateTimeReceived) {
		this.dateTimeReceived = dateTimeReceived;
	}
	public String getSettSign() {
		return settSign;
	}
	public void setSettSign(String settSign) {
		this.settSign = settSign;
	}
	public void setSettlementLink(SettlementLink[] settlementLink) {
		this.settlementLink = settlementLink;
	}
	public String getPlaceOfSafeKeepingOpt() {
		return placeOfSafeKeepingOpt;
	}
	public void setPlaceOfSafeKeepingOpt(String placeOfSafeKeepingOpt) {
		this.placeOfSafeKeepingOpt = placeOfSafeKeepingOpt;
	}
	public String getPlaceOfSafeKeepingCode() {
		return placeOfSafeKeepingCode;
	}
	public void setPlaceOfSafeKeepingCode(String placeOfSafeKeepingCode) {
		this.placeOfSafeKeepingCode = placeOfSafeKeepingCode;
	}
	public String getPlaceOfSafeKeepingNarrative() {
		return placeOfSafeKeepingNarrative;
	}
	public void setPlaceOfSafeKeepingNarrative(String placeOfSafeKeepingNarrative) {
		this.placeOfSafeKeepingNarrative = placeOfSafeKeepingNarrative;
	}
	public String getPlaceOfSafeKeepingBIC() {
		return placeOfSafeKeepingBIC;
	}
	public void setPlaceOfSafeKeepingBIC(String placeOfSafeKeepingBIC) {
		this.placeOfSafeKeepingBIC = placeOfSafeKeepingBIC;
	}
	public String getPlaceOfSafeKeepingCountryCode() {
		return placeOfSafeKeepingCountryCode;
	}
	public void setPlaceOfSafeKeepingCountryCode(
			String placeOfSafeKeepingCountryCode) {
		this.placeOfSafeKeepingCountryCode = placeOfSafeKeepingCountryCode;
	}
	public CounterPartyAccount[] getCounterPartyAccount() {
		return counterPartyAccount;
	}
	public void setCounterPartyAccount(CounterPartyAccount[] counterPartyAccount) {
		this.counterPartyAccount = counterPartyAccount;
	}
	public java.lang.String getDealPriceSign()  {
		
		return dealPriceSign;
	}
	public void setDealPriceSign(java.lang.String dealPriceSign)  {
		this.dealPriceSign = dealPriceSign;
	}
	public java.lang.String getPlaceOfSafeKeeping_LEI()  {
		
		return placeOfSafeKeeping_LEI;
	}
	public void setPlaceOfSafeKeeping_LEI(java.lang.String placeOfSafeKeeping_LEI)  {
		this.placeOfSafeKeeping_LEI = placeOfSafeKeeping_LEI;
	}
	public java.lang.String getPlaceOfTrading_LEI()  {
		
		return placeOfTrading_LEI;
	}
	public void setPlaceOfTrading_LEI(java.lang.String placeOfTrading_LEI)  {
		this.placeOfTrading_LEI = placeOfTrading_LEI;
	}
	public java.lang.String getPlaceOfClearing_LEI()  {
		
		return placeOfClearing_LEI;
	}
	public void setPlaceOfClearing_LEI(java.lang.String placeOfClearing_LEI)  {
		this.placeOfClearing_LEI = placeOfClearing_LEI;
	}


}
