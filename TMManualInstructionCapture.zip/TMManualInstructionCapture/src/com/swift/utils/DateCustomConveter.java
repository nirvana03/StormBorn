package com.swift.utils;

import java.text.SimpleDateFormat;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;

import com.webmethods.caf.faces.component.standard.HtmlOutputText;
import com.webmethods.caf.faces.util.LogUtils;
//import com.webmethods.optimize.logging.LoggingUtil;

public class DateCustomConveter implements Converter {

	public Object getAsObject(FacesContext arg0, UIComponent arg1, String arg2) {
		// TODO Auto-generated method stub
		return null;
	}

	public String getAsString(FacesContext arg0, UIComponent arg1, Object arg2) {

		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
		SimpleDateFormat dateFormat1 = new SimpleDateFormat("yyMMdd");
		SimpleDateFormat dateFormat2 = new SimpleDateFormat("yyyy-MM-dd");
		
		
		SimpleDateFormat finalConvert = new SimpleDateFormat("dd-MMM-yyyy");
		
		String tempDate = (String)arg2;
		String converStr = tempDate;
		
		
		if ((arg1 instanceof HtmlOutputText) && (tempDate!=null))
		{
	                HtmlOutputText tempOutText = (HtmlOutputText) arg1;
	                try{
	               
	                if (tempOutText.getId().equalsIgnoreCase("faxReceiverDate") ||tempOutText.getId().equalsIgnoreCase("faxTMReceiverDate") || tempOutText.getId().equalsIgnoreCase("mt599TMReceiverDate"))
	                	 converStr = finalConvert.format(dateFormat2.parse(tempDate));
	                 else if (tempOutText.getId().equalsIgnoreCase("MT599ReceiverDate"))
	                	 converStr = finalConvert.format(dateFormat1.parse(tempDate));
	                 else if (tempOutText.getId().equalsIgnoreCase("swiftReceiverDate"))
	                	 converStr = finalConvert.format(dateFormat1.parse(tempDate));
	                
	                 else if (tempOutText.getId().equalsIgnoreCase("faxSettlementDate") ||tempOutText.getId().equalsIgnoreCase("mt599SettlementDate")||tempOutText.getId().equalsIgnoreCase("swiftSettlementDate") )
	                	 converStr = finalConvert.format(dateFormat.parse(tempDate));
	                 else if ( tempOutText.getId().equalsIgnoreCase("swiftTMReceiverDate"))
	                	 converStr = finalConvert.format(dateFormat1.parse(tempDate));
	                }
	                catch(Exception e){}
			
			
		}
		
		
		/*	try{
				converStr = finalConvert.format(dateFormat.parse(tempDate));
				LogUtils.log("dateFormat =  "+tempDate+" = "+converStr);
		   }
			catch(Exception e){
			
				try{
					converStr = finalConvert.format(dateFormat1.parse(tempDate));
					LogUtils.log("dateFormat1 =  "+tempDate+" = "+converStr);
					
				}
				catch (Exception e1) {
					
					try{
						converStr = finalConvert.format(dateFormat2.parse(tempDate));
						LogUtils.log("dateFormat2 =  "+tempDate+" = "+converStr);
						
					}
					catch (Exception e2) {
						//handle exception
					}
				}
			}
			*/
			
	
		
		
		return 	converStr;

}
	
}
