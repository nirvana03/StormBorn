/**
 * 
 */
package com.webmethods.caf;

/**
 * @author insabh
 *
 */
public class Tmmanualinstructioncapture extends com.webmethods.caf.faces.bean.BaseApplicationBean 
{
	public Tmmanualinstructioncapture()
	{
		super();
		setCategoryName( "CafApplication" );
		setSubCategoryName( "TMManualInstructionCapture" );
	}
}