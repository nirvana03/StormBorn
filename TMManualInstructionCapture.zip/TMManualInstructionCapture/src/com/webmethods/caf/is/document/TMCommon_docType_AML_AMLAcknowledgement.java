package com.webmethods.caf.is.document;

import java.io.Serializable;

/**
 * IS document wrapper
 */
public  class TMCommon_docType_AML_AMLAcknowledgement extends java.lang.Object implements Serializable {

	
	private static final long serialVersionUID = 1L;
	// IS Document type used to generate this class
	public static final String DOCUMENT_TYPE = "TMCommon.docType.AML:AMLAcknowledgement";
	private static final String DOCUMENT_SRC = "http://10.20.165.29:3003";
	private com.webmethods.caf.is.document.Wm_fin_doc_header_BasicHeader b1 = null;
	public static String[][] FIELD_NAMES = new String[][] {{"b1", "B1"},{"b4", "B4"},
	};
	private com.webmethods.caf.is.document.Wm_fin_doc_catF_MTF21 b4 = null;
	

	public TMCommon_docType_AML_AMLAcknowledgement() {
	}


	public com.webmethods.caf.is.document.Wm_fin_doc_header_BasicHeader getB1()  {
		if (b1 == null) {
			b1 = new com.webmethods.caf.is.document.Wm_fin_doc_header_BasicHeader();
		}
		return b1;
	}


	public void setB1(com.webmethods.caf.is.document.Wm_fin_doc_header_BasicHeader b1)  {
		this.b1 = b1;
	}


	public com.webmethods.caf.is.document.Wm_fin_doc_catF_MTF21 getB4()  {
		if (b4 == null) {
			b4 = new com.webmethods.caf.is.document.Wm_fin_doc_catF_MTF21();
		}
		return b4;
	}


	public void setB4(com.webmethods.caf.is.document.Wm_fin_doc_catF_MTF21 b4)  {
		this.b4 = b4;
	}

}