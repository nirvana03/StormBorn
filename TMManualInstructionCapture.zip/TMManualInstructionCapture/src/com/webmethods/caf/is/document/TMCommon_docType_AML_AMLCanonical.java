package com.webmethods.caf.is.document;

import java.io.Serializable;

/**
 * IS document wrapper
 */
public  class TMCommon_docType_AML_AMLCanonical extends java.lang.Object implements Serializable {

	
	private static final long serialVersionUID = 1L;
	// IS Document type used to generate this class
	public static final String DOCUMENT_TYPE = "TMCommon.docType.AML:AMLCanonical";
	private static final String DOCUMENT_SRC = "http://10.20.165.29:3004";
	private com.webmethods.caf.is.document.TMCommon_docType_MTMsg_MTMsg mtmsg = null;
	public static String[][] FIELD_NAMES = new String[][] {{"mtmsg", "MTMsg"},{"amlcontroldata", "AMLControlData"},
	};
	private com.webmethods.caf.is.document.TMCommon_docType_AML_AMLControlData amlcontroldata = null;
	

	public TMCommon_docType_AML_AMLCanonical() {
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MTMsg_MTMsg getMtmsg()  {
		if (mtmsg == null) {
			mtmsg = new com.webmethods.caf.is.document.TMCommon_docType_MTMsg_MTMsg();
		}
		return mtmsg;
	}


	public void setMtmsg(com.webmethods.caf.is.document.TMCommon_docType_MTMsg_MTMsg mtmsg)  {
		this.mtmsg = mtmsg;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_AML_AMLControlData getAmlcontroldata()  {
		if (amlcontroldata == null) {
			amlcontroldata = new com.webmethods.caf.is.document.TMCommon_docType_AML_AMLControlData();
		}
		return amlcontroldata;
	}


	public void setAmlcontroldata(com.webmethods.caf.is.document.TMCommon_docType_AML_AMLControlData amlcontroldata)  {
		this.amlcontroldata = amlcontroldata;
	}

}