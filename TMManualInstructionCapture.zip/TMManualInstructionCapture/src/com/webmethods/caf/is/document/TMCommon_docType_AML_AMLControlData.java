package com.webmethods.caf.is.document;

import java.io.Serializable;

/**
 * IS document wrapper
 */
public  class TMCommon_docType_AML_AMLControlData extends java.lang.Object implements Serializable {

	
	private static final long serialVersionUID = 1L;
	// IS Document type used to generate this class
	public static final String DOCUMENT_TYPE = "TMCommon.docType.AML:AMLControlData";
	private java.lang.String settlementInstructionID;
	private java.lang.String status;
	private java.lang.String sent_timestamp;
	private java.lang.String acknowledged_timestamp;
	public static String[][] FIELD_NAMES = new String[][] {{"amlacktaskcontrolattributes", "AMLAckTaskControlAttributes"},
	};
	private com.webmethods.caf.is.document.TMCommon_docType_AML_AMLControlData.AMLAckTaskControlAttributes amlacktaskcontrolattributes = null;
	

	public TMCommon_docType_AML_AMLControlData() {
	}


	public java.lang.String getSettlementInstructionID()  {
		
		return settlementInstructionID;
	}


	public void setSettlementInstructionID(java.lang.String settlementInstructionID)  {
		this.settlementInstructionID = settlementInstructionID;
	}


	public java.lang.String getStatus()  {
		
		return status;
	}


	public void setStatus(java.lang.String status)  {
		this.status = status;
	}


	public java.lang.String getSent_timestamp()  {
		
		return sent_timestamp;
	}


	public void setSent_timestamp(java.lang.String sent_timestamp)  {
		this.sent_timestamp = sent_timestamp;
	}


	public java.lang.String getAcknowledged_timestamp()  {
		
		return acknowledged_timestamp;
	}


	public void setAcknowledged_timestamp(java.lang.String acknowledged_timestamp)  {
		this.acknowledged_timestamp = acknowledged_timestamp;
	}


	/**
	 * IS document wrapper
	 */
	public static class AMLAckTaskControlAttributes extends java.lang.Object implements Serializable {
	
		
		private static final long serialVersionUID = 1L;
		// IS Document type used to generate this class
		private java.lang.String taskID;
		private java.lang.String amlacktaskchecker;
		public static String[][] FIELD_NAMES = new String[][] {{"amlacktaskchecker", "AMLAckTaskChecker"},{"amlacktaskmaker", "AMLAckTaskMaker"},
		};
		private java.lang.String amlacktaskmaker;
		private java.lang.String makerStatus;
		private java.lang.String checkerStatus;
		private java.lang.String makerComments;
		private java.lang.String checkerComments;
		private java.lang.String activity;
		
	
		public AMLAckTaskControlAttributes() {
		}


		public java.lang.String getTaskID()  {
			
			return taskID;
		}


		public void setTaskID(java.lang.String taskID)  {
			this.taskID = taskID;
		}


		public java.lang.String getAmlacktaskchecker()  {
			
			return amlacktaskchecker;
		}


		public void setAmlacktaskchecker(java.lang.String amlacktaskchecker)  {
			this.amlacktaskchecker = amlacktaskchecker;
		}


		public java.lang.String getAmlacktaskmaker()  {
			
			return amlacktaskmaker;
		}


		public void setAmlacktaskmaker(java.lang.String amlacktaskmaker)  {
			this.amlacktaskmaker = amlacktaskmaker;
		}


		public java.lang.String getMakerStatus()  {
			
			return makerStatus;
		}


		public void setMakerStatus(java.lang.String makerStatus)  {
			this.makerStatus = makerStatus;
		}


		public java.lang.String getCheckerStatus()  {
			
			return checkerStatus;
		}


		public void setCheckerStatus(java.lang.String checkerStatus)  {
			this.checkerStatus = checkerStatus;
		}


		public java.lang.String getMakerComments()  {
			
			return makerComments;
		}


		public void setMakerComments(java.lang.String makerComments)  {
			this.makerComments = makerComments;
		}


		public java.lang.String getCheckerComments()  {
			
			return checkerComments;
		}


		public void setCheckerComments(java.lang.String checkerComments)  {
			this.checkerComments = checkerComments;
		}


		public java.lang.String getActivity()  {
			
			return activity;
		}


		public void setActivity(java.lang.String activity)  {
			this.activity = activity;
		}
	
	}


	public com.webmethods.caf.is.document.TMCommon_docType_AML_AMLControlData.AMLAckTaskControlAttributes getAmlacktaskcontrolattributes()  {
		if (amlacktaskcontrolattributes == null) {
			amlacktaskcontrolattributes = new com.webmethods.caf.is.document.TMCommon_docType_AML_AMLControlData.AMLAckTaskControlAttributes();
		}
		return amlacktaskcontrolattributes;
	}


	public void setAmlacktaskcontrolattributes(com.webmethods.caf.is.document.TMCommon_docType_AML_AMLControlData.AMLAckTaskControlAttributes amlacktaskcontrolattributes)  {
		this.amlacktaskcontrolattributes = amlacktaskcontrolattributes;
	}

}