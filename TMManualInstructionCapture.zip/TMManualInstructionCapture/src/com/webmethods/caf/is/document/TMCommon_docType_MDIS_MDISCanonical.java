package com.webmethods.caf.is.document;

import java.io.Serializable;

/**
 * IS document wrapper
 */
public  class TMCommon_docType_MDIS_MDISCanonical extends java.lang.Object implements Serializable {

	
	private static final long serialVersionUID = 1L;
	// IS Document type used to generate this class
	public static final String DOCUMENT_TYPE = "TMCommon.docType.MDIS:MDISCanonical";
	private static final String DOCUMENT_SRC = "http://10.20.165.29:30036";
	private com.webmethods.caf.is.document.TMCommon_docType_MDIS_MDISRequest mdisrequest = null;
	public static String[][] FIELD_NAMES = new String[][] {{"mdisrequest", "MDISRequest"},{"mdiscontroldata", "MDISControlData"},
	};
	private com.webmethods.caf.is.document.TMCommon_docType_MDIS_MDISControlData mdiscontroldata = null;
	

	public TMCommon_docType_MDIS_MDISCanonical() {
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MDIS_MDISRequest getMdisrequest()  {
		if (mdisrequest == null) {
			mdisrequest = new com.webmethods.caf.is.document.TMCommon_docType_MDIS_MDISRequest();
		}
		return mdisrequest;
	}


	public void setMdisrequest(com.webmethods.caf.is.document.TMCommon_docType_MDIS_MDISRequest mdisrequest)  {
		this.mdisrequest = mdisrequest;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MDIS_MDISControlData getMdiscontroldata()  {
		if (mdiscontroldata == null) {
			mdiscontroldata = new com.webmethods.caf.is.document.TMCommon_docType_MDIS_MDISControlData();
		}
		return mdiscontroldata;
	}


	public void setMdiscontroldata(com.webmethods.caf.is.document.TMCommon_docType_MDIS_MDISControlData mdiscontroldata)  {
		this.mdiscontroldata = mdiscontroldata;
	}

}