package com.webmethods.caf.is.document;

import java.io.Serializable;

/**
 * IS document wrapper
 */
public  class TMCommon_docType_MDIS_MDISControlData extends java.lang.Object implements Serializable {

	
	private static final long serialVersionUID = 1L;
	// IS Document type used to generate this class
	public static final String DOCUMENT_TYPE = "TMCommon.docType.MDIS:MDISControlData";
	private java.lang.String processInstanceID;
	private java.lang.String deferredCallBackProcessInstanceID;
	private java.lang.String sourceChannel;
	private java.lang.String initialFilenetDocID;
	private java.lang.String annotatedFilenetDocID;
	private java.lang.String childInstructionID;
	private java.lang.String annotatedFilename;
	private java.lang.String sourceReference;
	private java.lang.String typeOfInstruction;
	private java.lang.String forwardTo;
	private java.lang.String messageFunction;
	private java.lang.String tmInstructionID;
	private java.lang.String senderID;
	private java.lang.String receiverEntity;
	private java.lang.String placeOfSettlement;
	private java.lang.String faxContentMakerComments;
	private java.lang.String faxContentCheckerComments;
	private java.lang.String uploadAnnotatedFaxFile;
	private java.lang.String indemnityProcessingAction;
	private java.lang.String uploadSupportDoc;
	private java.lang.String indemnityCompletedAt;
	private java.lang.String indemnityMakerComments;
	private java.lang.String indemnityCheckerComments;
	private java.lang.String signatureVerfiedStatus;
	private java.lang.String signatureInstructionMandate;
	private java.lang.String signatureMakerComments;
	private java.lang.String isInstructionWithinMandate;
	private java.lang.String signatureCheckerComments;
	private java.lang.String signatureCompletedAt;
	private java.lang.String signatureProcessAction;
	private java.lang.String isCallBackRequired;
	private java.lang.String calledNumber;
	private java.lang.String customerDesignatedContact;
	private java.lang.String callBackCompletedAt;
	private java.lang.String callBackMakerComments;
	private java.lang.String callBackCheckerComments;
	private java.lang.String isMultipleInstructions;
	private java.lang.String makerStatus;
	private java.lang.String checkerStatus;
	private java.lang.String senderIdNumber;
	private java.lang.String receiverNumber;
	private java.lang.String posnumber;
	private java.lang.String makerAssignUserId;
	private java.lang.String callBackStatus;
	private java.lang.String isIndemnityCheckRequired;
	private java.lang.String checkerAssignUserId;
	private java.lang.String settlementInstructionsCount;
	private java.lang.String nonSettlementInstructionsCount;
	private java.lang.String totalInstructionsCount;
	private java.lang.String makerDate;
	private java.lang.String parentSettlementInstructionID;
	private java.lang.String annotatedFileContentType;
	private java.lang.String uploadSupportFileName;
	private java.lang.String uploadSupportFileContentType;
	private java.lang.String notificationURL;
	private java.lang.String relatedInstructionID;
	private java.lang.String indemnityandCallBackMakerID;
	private java.lang.String securityAccount;
	private java.lang.String receivedDate;
	private java.lang.String tmreceiveddate;
	private java.lang.String isDFP;
	private java.lang.String isNCBO;
	private java.lang.String messageType;
	private java.lang.String settlementDate;
	private java.lang.String isAmendable;
	private java.lang.String bulkFileFormat;
	private com.webmethods.caf.is.document.TMCommon_docType_MDIS_MDISControlData.PriorityIndicatorAttributes priorityIndicatorAttributes = null;
	public static String[][] FIELD_NAMES = new String[][] {{"posnumber", "POSNumber"},{"tmreceiveddate", "TMReceivedDate"},{"id", "ID"},{"multipleInstructions", "MultipleInstructions"},
	};
	private com.webmethods.caf.is.document.TMCommon_docType_MDIS_MDISControlData.MultipleInstructions[] multipleInstructions = null;
	

	public TMCommon_docType_MDIS_MDISControlData() {
	}


	public java.lang.String getProcessInstanceID()  {
		
		return processInstanceID;
	}


	public void setProcessInstanceID(java.lang.String processInstanceID)  {
		this.processInstanceID = processInstanceID;
	}


	public java.lang.String getDeferredCallBackProcessInstanceID()  {
		
		return deferredCallBackProcessInstanceID;
	}


	public void setDeferredCallBackProcessInstanceID(java.lang.String deferredCallBackProcessInstanceID)  {
		this.deferredCallBackProcessInstanceID = deferredCallBackProcessInstanceID;
	}


	public java.lang.String getSourceChannel()  {
		
		return sourceChannel;
	}


	public void setSourceChannel(java.lang.String sourceChannel)  {
		this.sourceChannel = sourceChannel;
	}


	public java.lang.String getInitialFilenetDocID()  {
		
		return initialFilenetDocID;
	}


	public void setInitialFilenetDocID(java.lang.String initialFilenetDocID)  {
		this.initialFilenetDocID = initialFilenetDocID;
	}


	public java.lang.String getAnnotatedFilenetDocID()  {
		
		return annotatedFilenetDocID;
	}


	public void setAnnotatedFilenetDocID(java.lang.String annotatedFilenetDocID)  {
		this.annotatedFilenetDocID = annotatedFilenetDocID;
	}


	public java.lang.String getChildInstructionID()  {
		
		return childInstructionID;
	}


	public void setChildInstructionID(java.lang.String childInstructionID)  {
		this.childInstructionID = childInstructionID;
	}


	public java.lang.String getAnnotatedFilename()  {
		
		return annotatedFilename;
	}


	public void setAnnotatedFilename(java.lang.String annotatedFilename)  {
		this.annotatedFilename = annotatedFilename;
	}


	public java.lang.String getSourceReference()  {
		
		return sourceReference;
	}


	public void setSourceReference(java.lang.String sourceReference)  {
		this.sourceReference = sourceReference;
	}


	public java.lang.String getTypeOfInstruction()  {
		
		return typeOfInstruction;
	}


	public void setTypeOfInstruction(java.lang.String typeOfInstruction)  {
		this.typeOfInstruction = typeOfInstruction;
	}


	public java.lang.String getForwardTo()  {
		
		return forwardTo;
	}


	public void setForwardTo(java.lang.String forwardTo)  {
		this.forwardTo = forwardTo;
	}


	public java.lang.String getMessageFunction()  {
		
		return messageFunction;
	}


	public void setMessageFunction(java.lang.String messageFunction)  {
		this.messageFunction = messageFunction;
	}


	public java.lang.String getTmInstructionID()  {
		
		return tmInstructionID;
	}


	public void setTmInstructionID(java.lang.String tmInstructionID)  {
		this.tmInstructionID = tmInstructionID;
	}


	public java.lang.String getSenderID()  {
		
		return senderID;
	}


	public void setSenderID(java.lang.String senderID)  {
		this.senderID = senderID;
	}


	public java.lang.String getReceiverEntity()  {
		
		return receiverEntity;
	}


	public void setReceiverEntity(java.lang.String receiverEntity)  {
		this.receiverEntity = receiverEntity;
	}


	public java.lang.String getPlaceOfSettlement()  {
		
		return placeOfSettlement;
	}


	public void setPlaceOfSettlement(java.lang.String placeOfSettlement)  {
		this.placeOfSettlement = placeOfSettlement;
	}


	public java.lang.String getFaxContentMakerComments()  {
		
		return faxContentMakerComments;
	}


	public void setFaxContentMakerComments(java.lang.String faxContentMakerComments)  {
		this.faxContentMakerComments = faxContentMakerComments;
	}


	public java.lang.String getFaxContentCheckerComments()  {
		
		return faxContentCheckerComments;
	}


	public void setFaxContentCheckerComments(java.lang.String faxContentCheckerComments)  {
		this.faxContentCheckerComments = faxContentCheckerComments;
	}


	public java.lang.String getUploadAnnotatedFaxFile()  {
		
		return uploadAnnotatedFaxFile;
	}


	public void setUploadAnnotatedFaxFile(java.lang.String uploadAnnotatedFaxFile)  {
		this.uploadAnnotatedFaxFile = uploadAnnotatedFaxFile;
	}


	public java.lang.String getIndemnityProcessingAction()  {
		
		return indemnityProcessingAction;
	}


	public void setIndemnityProcessingAction(java.lang.String indemnityProcessingAction)  {
		this.indemnityProcessingAction = indemnityProcessingAction;
	}


	public java.lang.String getUploadSupportDoc()  {
		
		return uploadSupportDoc;
	}


	public void setUploadSupportDoc(java.lang.String uploadSupportDoc)  {
		this.uploadSupportDoc = uploadSupportDoc;
	}


	public java.lang.String getIndemnityCompletedAt()  {
		
		return indemnityCompletedAt;
	}


	public void setIndemnityCompletedAt(java.lang.String indemnityCompletedAt)  {
		this.indemnityCompletedAt = indemnityCompletedAt;
	}


	public java.lang.String getIndemnityMakerComments()  {
		
		return indemnityMakerComments;
	}


	public void setIndemnityMakerComments(java.lang.String indemnityMakerComments)  {
		this.indemnityMakerComments = indemnityMakerComments;
	}


	public java.lang.String getIndemnityCheckerComments()  {
		
		return indemnityCheckerComments;
	}


	public void setIndemnityCheckerComments(java.lang.String indemnityCheckerComments)  {
		this.indemnityCheckerComments = indemnityCheckerComments;
	}


	public java.lang.String getSignatureVerfiedStatus()  {
		
		return signatureVerfiedStatus;
	}


	public void setSignatureVerfiedStatus(java.lang.String signatureVerfiedStatus)  {
		this.signatureVerfiedStatus = signatureVerfiedStatus;
	}


	public java.lang.String getSignatureInstructionMandate()  {
		
		return signatureInstructionMandate;
	}


	public void setSignatureInstructionMandate(java.lang.String signatureInstructionMandate)  {
		this.signatureInstructionMandate = signatureInstructionMandate;
	}


	public java.lang.String getSignatureMakerComments()  {
		
		return signatureMakerComments;
	}


	public void setSignatureMakerComments(java.lang.String signatureMakerComments)  {
		this.signatureMakerComments = signatureMakerComments;
	}


	public java.lang.String getIsInstructionWithinMandate()  {
		
		return isInstructionWithinMandate;
	}


	public void setIsInstructionWithinMandate(java.lang.String isInstructionWithinMandate)  {
		this.isInstructionWithinMandate = isInstructionWithinMandate;
	}


	public java.lang.String getSignatureCheckerComments()  {
		
		return signatureCheckerComments;
	}


	public void setSignatureCheckerComments(java.lang.String signatureCheckerComments)  {
		this.signatureCheckerComments = signatureCheckerComments;
	}


	public java.lang.String getSignatureCompletedAt()  {
		
		return signatureCompletedAt;
	}


	public void setSignatureCompletedAt(java.lang.String signatureCompletedAt)  {
		this.signatureCompletedAt = signatureCompletedAt;
	}


	public java.lang.String getSignatureProcessAction()  {
		
		return signatureProcessAction;
	}


	public void setSignatureProcessAction(java.lang.String signatureProcessAction)  {
		this.signatureProcessAction = signatureProcessAction;
	}


	public java.lang.String getIsCallBackRequired()  {
		
		return isCallBackRequired;
	}


	public void setIsCallBackRequired(java.lang.String isCallBackRequired)  {
		this.isCallBackRequired = isCallBackRequired;
	}


	public java.lang.String getCalledNumber()  {
		
		return calledNumber;
	}


	public void setCalledNumber(java.lang.String calledNumber)  {
		this.calledNumber = calledNumber;
	}


	public java.lang.String getCustomerDesignatedContact()  {
		
		return customerDesignatedContact;
	}


	public void setCustomerDesignatedContact(java.lang.String customerDesignatedContact)  {
		this.customerDesignatedContact = customerDesignatedContact;
	}


	public java.lang.String getCallBackCompletedAt()  {
		
		return callBackCompletedAt;
	}


	public void setCallBackCompletedAt(java.lang.String callBackCompletedAt)  {
		this.callBackCompletedAt = callBackCompletedAt;
	}


	public java.lang.String getCallBackMakerComments()  {
		
		return callBackMakerComments;
	}


	public void setCallBackMakerComments(java.lang.String callBackMakerComments)  {
		this.callBackMakerComments = callBackMakerComments;
	}


	public java.lang.String getCallBackCheckerComments()  {
		
		return callBackCheckerComments;
	}


	public void setCallBackCheckerComments(java.lang.String callBackCheckerComments)  {
		this.callBackCheckerComments = callBackCheckerComments;
	}


	public java.lang.String getIsMultipleInstructions()  {
		
		return isMultipleInstructions;
	}


	public void setIsMultipleInstructions(java.lang.String isMultipleInstructions)  {
		this.isMultipleInstructions = isMultipleInstructions;
	}


	public java.lang.String getMakerStatus()  {
		
		return makerStatus;
	}


	public void setMakerStatus(java.lang.String makerStatus)  {
		this.makerStatus = makerStatus;
	}


	public java.lang.String getCheckerStatus()  {
		
		return checkerStatus;
	}


	public void setCheckerStatus(java.lang.String checkerStatus)  {
		this.checkerStatus = checkerStatus;
	}


	public java.lang.String getSenderIdNumber()  {
		
		return senderIdNumber;
	}


	public void setSenderIdNumber(java.lang.String senderIdNumber)  {
		this.senderIdNumber = senderIdNumber;
	}


	public java.lang.String getReceiverNumber()  {
		
		return receiverNumber;
	}


	public void setReceiverNumber(java.lang.String receiverNumber)  {
		this.receiverNumber = receiverNumber;
	}


	public java.lang.String getPosnumber()  {
		
		return posnumber;
	}


	public void setPosnumber(java.lang.String posnumber)  {
		this.posnumber = posnumber;
	}


	public java.lang.String getMakerAssignUserId()  {
		
		return makerAssignUserId;
	}


	public void setMakerAssignUserId(java.lang.String makerAssignUserId)  {
		this.makerAssignUserId = makerAssignUserId;
	}


	public java.lang.String getCallBackStatus()  {
		
		return callBackStatus;
	}


	public void setCallBackStatus(java.lang.String callBackStatus)  {
		this.callBackStatus = callBackStatus;
	}


	public java.lang.String getIsIndemnityCheckRequired()  {
		
		return isIndemnityCheckRequired;
	}


	public void setIsIndemnityCheckRequired(java.lang.String isIndemnityCheckRequired)  {
		this.isIndemnityCheckRequired = isIndemnityCheckRequired;
	}


	public java.lang.String getCheckerAssignUserId()  {
		
		return checkerAssignUserId;
	}


	public void setCheckerAssignUserId(java.lang.String checkerAssignUserId)  {
		this.checkerAssignUserId = checkerAssignUserId;
	}


	public java.lang.String getSettlementInstructionsCount()  {
		
		return settlementInstructionsCount;
	}


	public void setSettlementInstructionsCount(java.lang.String settlementInstructionsCount)  {
		this.settlementInstructionsCount = settlementInstructionsCount;
	}


	public java.lang.String getNonSettlementInstructionsCount()  {
		
		return nonSettlementInstructionsCount;
	}


	public void setNonSettlementInstructionsCount(java.lang.String nonSettlementInstructionsCount)  {
		this.nonSettlementInstructionsCount = nonSettlementInstructionsCount;
	}


	public java.lang.String getTotalInstructionsCount()  {
		
		return totalInstructionsCount;
	}


	public void setTotalInstructionsCount(java.lang.String totalInstructionsCount)  {
		this.totalInstructionsCount = totalInstructionsCount;
	}


	public java.lang.String getMakerDate()  {
		
		return makerDate;
	}


	public void setMakerDate(java.lang.String makerDate)  {
		this.makerDate = makerDate;
	}


	public java.lang.String getParentSettlementInstructionID()  {
		
		return parentSettlementInstructionID;
	}


	public void setParentSettlementInstructionID(java.lang.String parentSettlementInstructionID)  {
		this.parentSettlementInstructionID = parentSettlementInstructionID;
	}


	public java.lang.String getAnnotatedFileContentType()  {
		
		return annotatedFileContentType;
	}


	public void setAnnotatedFileContentType(java.lang.String annotatedFileContentType)  {
		this.annotatedFileContentType = annotatedFileContentType;
	}


	public java.lang.String getUploadSupportFileName()  {
		
		return uploadSupportFileName;
	}


	public void setUploadSupportFileName(java.lang.String uploadSupportFileName)  {
		this.uploadSupportFileName = uploadSupportFileName;
	}


	public java.lang.String getUploadSupportFileContentType()  {
		
		return uploadSupportFileContentType;
	}


	public void setUploadSupportFileContentType(java.lang.String uploadSupportFileContentType)  {
		this.uploadSupportFileContentType = uploadSupportFileContentType;
	}


	public java.lang.String getNotificationURL()  {
		
		return notificationURL;
	}


	public void setNotificationURL(java.lang.String notificationURL)  {
		this.notificationURL = notificationURL;
	}


	public java.lang.String getRelatedInstructionID()  {
		
		return relatedInstructionID;
	}


	public void setRelatedInstructionID(java.lang.String relatedInstructionID)  {
		this.relatedInstructionID = relatedInstructionID;
	}


	public java.lang.String getIndemnityandCallBackMakerID()  {
		
		return indemnityandCallBackMakerID;
	}


	public void setIndemnityandCallBackMakerID(java.lang.String indemnityandCallBackMakerID)  {
		this.indemnityandCallBackMakerID = indemnityandCallBackMakerID;
	}


	public java.lang.String getSecurityAccount()  {
		
		return securityAccount;
	}


	public void setSecurityAccount(java.lang.String securityAccount)  {
		this.securityAccount = securityAccount;
	}


	public java.lang.String getReceivedDate()  {
		
		return receivedDate;
	}


	public void setReceivedDate(java.lang.String receivedDate)  {
		this.receivedDate = receivedDate;
	}


	public java.lang.String getTmreceiveddate()  {
		
		return tmreceiveddate;
	}


	public void setTmreceiveddate(java.lang.String tmreceiveddate)  {
		this.tmreceiveddate = tmreceiveddate;
	}


	public java.lang.String getIsDFP()  {
		
		return isDFP;
	}


	public void setIsDFP(java.lang.String isDFP)  {
		this.isDFP = isDFP;
	}


	public java.lang.String getIsNCBO()  {
		
		return isNCBO;
	}


	public void setIsNCBO(java.lang.String isNCBO)  {
		this.isNCBO = isNCBO;
	}


	public java.lang.String getMessageType()  {
		
		return messageType;
	}


	public void setMessageType(java.lang.String messageType)  {
		this.messageType = messageType;
	}


	public java.lang.String getSettlementDate()  {
		
		return settlementDate;
	}


	public void setSettlementDate(java.lang.String settlementDate)  {
		this.settlementDate = settlementDate;
	}


	public java.lang.String getIsAmendable()  {
		
		return isAmendable;
	}


	public void setIsAmendable(java.lang.String isAmendable)  {
		this.isAmendable = isAmendable;
	}


	public java.lang.String getBulkFileFormat()  {
		
		return bulkFileFormat;
	}


	public void setBulkFileFormat(java.lang.String bulkFileFormat)  {
		this.bulkFileFormat = bulkFileFormat;
	}


	/**
	 * IS document wrapper
	 */
	public static class PriorityIndicatorAttributes extends java.lang.Object implements Serializable {
	
		
		private static final long serialVersionUID = 1L;
		// IS Document type used to generate this class
		private java.lang.String clientID;
		private java.lang.String legalEntity;
		private java.lang.String placeOfSettlement;
		private java.lang.String clientCategory;
		private java.lang.String marketCutOffTime;
		private java.lang.String proximityToMarketCutOffTimeInterval;
		private java.lang.String priority;
		private java.lang.String ruleIDAppliedForPriority;
		private java.lang.String ruleVersionAppliedForPriority;
		
	
		public PriorityIndicatorAttributes() {
		}


		public java.lang.String getClientID()  {
			
			return clientID;
		}


		public void setClientID(java.lang.String clientID)  {
			this.clientID = clientID;
		}


		public java.lang.String getLegalEntity()  {
			
			return legalEntity;
		}


		public void setLegalEntity(java.lang.String legalEntity)  {
			this.legalEntity = legalEntity;
		}


		public java.lang.String getPlaceOfSettlement()  {
			
			return placeOfSettlement;
		}


		public void setPlaceOfSettlement(java.lang.String placeOfSettlement)  {
			this.placeOfSettlement = placeOfSettlement;
		}


		public java.lang.String getClientCategory()  {
			
			return clientCategory;
		}


		public void setClientCategory(java.lang.String clientCategory)  {
			this.clientCategory = clientCategory;
		}


		public java.lang.String getMarketCutOffTime()  {
			
			return marketCutOffTime;
		}


		public void setMarketCutOffTime(java.lang.String marketCutOffTime)  {
			this.marketCutOffTime = marketCutOffTime;
		}


		public java.lang.String getProximityToMarketCutOffTimeInterval()  {
			
			return proximityToMarketCutOffTimeInterval;
		}


		public void setProximityToMarketCutOffTimeInterval(java.lang.String proximityToMarketCutOffTimeInterval)  {
			this.proximityToMarketCutOffTimeInterval = proximityToMarketCutOffTimeInterval;
		}


		public java.lang.String getPriority()  {
			
			return priority;
		}


		public void setPriority(java.lang.String priority)  {
			this.priority = priority;
		}


		public java.lang.String getRuleIDAppliedForPriority()  {
			
			return ruleIDAppliedForPriority;
		}


		public void setRuleIDAppliedForPriority(java.lang.String ruleIDAppliedForPriority)  {
			this.ruleIDAppliedForPriority = ruleIDAppliedForPriority;
		}


		public java.lang.String getRuleVersionAppliedForPriority()  {
			
			return ruleVersionAppliedForPriority;
		}


		public void setRuleVersionAppliedForPriority(java.lang.String ruleVersionAppliedForPriority)  {
			this.ruleVersionAppliedForPriority = ruleVersionAppliedForPriority;
		}
	
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MDIS_MDISControlData.PriorityIndicatorAttributes getPriorityIndicatorAttributes()  {
		if (priorityIndicatorAttributes == null) {
			priorityIndicatorAttributes = new com.webmethods.caf.is.document.TMCommon_docType_MDIS_MDISControlData.PriorityIndicatorAttributes();
		}
		return priorityIndicatorAttributes;
	}


	public void setPriorityIndicatorAttributes(com.webmethods.caf.is.document.TMCommon_docType_MDIS_MDISControlData.PriorityIndicatorAttributes priorityIndicatorAttributes)  {
		this.priorityIndicatorAttributes = priorityIndicatorAttributes;
	}


	/**
	 * IS document wrapper
	 */
	public static class MultipleInstructions extends java.lang.Object implements Serializable {
	
		
		private static final long serialVersionUID = 1L;
		// IS Document type used to generate this class
		public static String[][] FIELD_NAMES = new String[][] {{"id", "ID"},
		};
		private java.lang.String id;
		private java.lang.String isNCBO;
		private java.lang.String purpose;
		private java.lang.String forwardTo;
		private java.lang.String messageFunction;
		private java.lang.String tmInstructionID;
		private java.lang.String placeOfSettlement;
		private java.lang.String sourceReference;
		private java.lang.String receiverNumber;
		private java.lang.String securityAccount;
		private java.lang.String messageType;
		private java.lang.String settlementDate;
		private java.lang.String isCallBackRequired;
		private java.lang.String placeOfSettOption;
		
	
		public MultipleInstructions() {
		}


		public java.lang.String getId()  {
			
			return id;
		}


		public void setId(java.lang.String id)  {
			this.id = id;
		}


		public java.lang.String getIsNCBO()  {
			
			return isNCBO;
		}


		public void setIsNCBO(java.lang.String isNCBO)  {
			this.isNCBO = isNCBO;
		}


		public java.lang.String getPurpose()  {
			
			return purpose;
		}


		public void setPurpose(java.lang.String purpose)  {
			this.purpose = purpose;
		}


		public java.lang.String getForwardTo()  {
			
			return forwardTo;
		}


		public void setForwardTo(java.lang.String forwardTo)  {
			this.forwardTo = forwardTo;
		}


		public java.lang.String getMessageFunction()  {
			
			return messageFunction;
		}


		public void setMessageFunction(java.lang.String messageFunction)  {
			this.messageFunction = messageFunction;
		}


		public java.lang.String getTmInstructionID()  {
			
			return tmInstructionID;
		}


		public void setTmInstructionID(java.lang.String tmInstructionID)  {
			this.tmInstructionID = tmInstructionID;
		}


		public java.lang.String getPlaceOfSettlement()  {
			
			return placeOfSettlement;
		}


		public void setPlaceOfSettlement(java.lang.String placeOfSettlement)  {
			this.placeOfSettlement = placeOfSettlement;
		}


		public java.lang.String getSourceReference()  {
			
			return sourceReference;
		}


		public void setSourceReference(java.lang.String sourceReference)  {
			this.sourceReference = sourceReference;
		}


		public java.lang.String getReceiverNumber()  {
			
			return receiverNumber;
		}


		public void setReceiverNumber(java.lang.String receiverNumber)  {
			this.receiverNumber = receiverNumber;
		}


		public java.lang.String getSecurityAccount()  {
			
			return securityAccount;
		}


		public void setSecurityAccount(java.lang.String securityAccount)  {
			this.securityAccount = securityAccount;
		}


		public java.lang.String getMessageType()  {
			
			return messageType;
		}


		public void setMessageType(java.lang.String messageType)  {
			this.messageType = messageType;
		}


		public java.lang.String getSettlementDate()  {
			
			return settlementDate;
		}


		public void setSettlementDate(java.lang.String settlementDate)  {
			this.settlementDate = settlementDate;
		}


		public java.lang.String getIsCallBackRequired()  {
			
			return isCallBackRequired;
		}


		public void setIsCallBackRequired(java.lang.String isCallBackRequired)  {
			this.isCallBackRequired = isCallBackRequired;
		}


		public java.lang.String getPlaceOfSettOption()  {
			
			return placeOfSettOption;
		}


		public void setPlaceOfSettOption(java.lang.String placeOfSettOption)  {
			this.placeOfSettOption = placeOfSettOption;
		}
	
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MDIS_MDISControlData.MultipleInstructions[] getMultipleInstructions()  {
		if (multipleInstructions == null) {
			//TODO: create/set default value here
		}
		return multipleInstructions;
	}


	public void setMultipleInstructions(com.webmethods.caf.is.document.TMCommon_docType_MDIS_MDISControlData.MultipleInstructions[] multipleInstructions)  {
		this.multipleInstructions = multipleInstructions;
	}

}