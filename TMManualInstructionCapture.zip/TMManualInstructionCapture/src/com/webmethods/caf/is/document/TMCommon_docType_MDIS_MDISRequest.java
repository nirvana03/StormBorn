package com.webmethods.caf.is.document;

import java.io.Serializable;

/**
 * IS document wrapper
 */
public  class TMCommon_docType_MDIS_MDISRequest extends java.lang.Object implements Serializable {

	
	private static final long serialVersionUID = 1L;
	// IS Document type used to generate this class
	public static final String DOCUMENT_TYPE = "TMCommon.docType.MDIS:MDISRequest";
	public static String[][] FIELD_NAMES = new String[][] {{"mdisrequest", "MDISRequest"},
	};
	private com.webmethods.caf.is.document.TMCommon_docType_MDIS_MDISRequest.MDISRequest mdisrequest = null;
	

	public TMCommon_docType_MDIS_MDISRequest() {
	}


	/**
	 * IS document wrapper
	 */
	public static class MDISRequest extends java.lang.Object implements Serializable {
	
		
		private static final long serialVersionUID = 1L;
		private java.lang.String _version;
		private com.webmethods.caf.is.document.TMCommon_docType_MDIS_MDISRequest.MDISRequest.RequestHeader requestHeader = null;
		public static String[][] FIELD_NAMES = new String[][] {{"_version", "@Version"},{"sourceApp", "SourceApp"},{"sourceCtry", "SourceCtry"},{"sourceRef", "SourceRef"},{"priority", "Priority"},{"providerAccount", "ProviderAccount"},{"altProviderAccount", "AltProviderAccount"},{"fieldValue", "FieldValue"},{"trackInfo", "TrackInfo"},{"dateTimeStamp", "DateTimeStamp"},{"requestHeader", "RequestHeader"},{"dstChannelInfo", "DstChannelInfo"},{"email", "Email"},{"mime", "MIME"},{"language", "Language"},{"toAddress", "ToAddress"},{"fromAddress", "FromAddress"},{"ccaddress", "CCAddress"},{"bccaddress", "BCCAddress"},{"bodyTmplFlag", "BodyTmplFlag"},{"subject", "Subject"},{"emailBody", "EmailBody"},{"passphrase", "Passphrase"},{"faxNumber", "FaxNumber"},{"fromFaxAddress", "FromFaxAddress"},{"fax", "Fax"},{"mobileNumber", "MobileNumber"},{"smsbody", "SMSBody"},{"sms", "SMS"},{"attachment", "Attachment"},{"fileType", "FileType"},{"fileContent", "FileContent"},{"fileName", "FileName"},{"attachments", "Attachments"},{"templateName", "TemplateName"},{"rptData", "RptData"},{"addOnServiceInfo", "AddOnServiceInfo"},{"requestManifest", "RequestManifest"},
		};
		private com.webmethods.caf.is.document.TMCommon_docType_MDIS_MDISRequest.MDISRequest.RequestManifest requestManifest = null;
		
	
		public MDISRequest() {
		}


		public java.lang.String get_version()  {
			
			return _version;
		}


		public void set_version(java.lang.String _version)  {
			this._version = _version;
		}


		/**
		 * IS document wrapper
		 */
		public static class RequestHeader extends java.lang.Object implements Serializable {
		
			
			private static final long serialVersionUID = 1L;
			private java.lang.String sourceApp;
			private java.lang.String sourceCtry;
			private java.lang.String sourceRef;
			private java.lang.String priority;
			private java.lang.String providerAccount;
			private java.lang.String altProviderAccount;
			private com.webmethods.caf.is.document.TMCommon_docType_MDIS_MDISRequest.MDISRequest.RequestHeader.TrackInfo trackInfo = null;
			public static String[][] FIELD_NAMES = new String[][] {{"sourceApp", "SourceApp"},{"sourceCtry", "SourceCtry"},{"sourceRef", "SourceRef"},{"priority", "Priority"},{"providerAccount", "ProviderAccount"},{"altProviderAccount", "AltProviderAccount"},{"fieldValue", "FieldValue"},{"trackInfo", "TrackInfo"},{"dateTimeStamp", "DateTimeStamp"},
			};
			private java.lang.String dateTimeStamp;
			
		
			public RequestHeader() {
			}


			public java.lang.String getSourceApp()  {
				
				return sourceApp;
			}


			public void setSourceApp(java.lang.String sourceApp)  {
				this.sourceApp = sourceApp;
			}


			public java.lang.String getSourceCtry()  {
				
				return sourceCtry;
			}


			public void setSourceCtry(java.lang.String sourceCtry)  {
				this.sourceCtry = sourceCtry;
			}


			public java.lang.String getSourceRef()  {
				
				return sourceRef;
			}


			public void setSourceRef(java.lang.String sourceRef)  {
				this.sourceRef = sourceRef;
			}


			public java.lang.String getPriority()  {
				
				return priority;
			}


			public void setPriority(java.lang.String priority)  {
				this.priority = priority;
			}


			public java.lang.String getProviderAccount()  {
				
				return providerAccount;
			}


			public void setProviderAccount(java.lang.String providerAccount)  {
				this.providerAccount = providerAccount;
			}


			public java.lang.String getAltProviderAccount()  {
				
				return altProviderAccount;
			}


			public void setAltProviderAccount(java.lang.String altProviderAccount)  {
				this.altProviderAccount = altProviderAccount;
			}


			/**
			 * IS document wrapper
			 */
			public static class TrackInfo extends java.lang.Object implements Serializable {
			
				
				private static final long serialVersionUID = 1L;
				// IS Document type used to generate this class
				public static String[][] FIELD_NAMES = new String[][] {{"fieldValue", "FieldValue"},
				};
				private java.lang.String[] fieldValue = null;
				
			
				public TrackInfo() {
				}


				public java.lang.String[] getFieldValue()  {
					if (fieldValue == null) {
						//TODO: create/set default value here
					}
					return fieldValue;
				}


				public void setFieldValue(java.lang.String[] fieldValue)  {
					this.fieldValue = fieldValue;
				}
			
			}


			public com.webmethods.caf.is.document.TMCommon_docType_MDIS_MDISRequest.MDISRequest.RequestHeader.TrackInfo getTrackInfo()  {
				if (trackInfo == null) {
					trackInfo = new com.webmethods.caf.is.document.TMCommon_docType_MDIS_MDISRequest.MDISRequest.RequestHeader.TrackInfo();
				}
				return trackInfo;
			}


			public void setTrackInfo(com.webmethods.caf.is.document.TMCommon_docType_MDIS_MDISRequest.MDISRequest.RequestHeader.TrackInfo trackInfo)  {
				this.trackInfo = trackInfo;
			}


			public java.lang.String getDateTimeStamp()  {
				
				return dateTimeStamp;
			}


			public void setDateTimeStamp(java.lang.String dateTimeStamp)  {
				this.dateTimeStamp = dateTimeStamp;
			}
		
		}


		public com.webmethods.caf.is.document.TMCommon_docType_MDIS_MDISRequest.MDISRequest.RequestHeader getRequestHeader()  {
			if (requestHeader == null) {
				requestHeader = new com.webmethods.caf.is.document.TMCommon_docType_MDIS_MDISRequest.MDISRequest.RequestHeader();
			}
			return requestHeader;
		}


		public void setRequestHeader(com.webmethods.caf.is.document.TMCommon_docType_MDIS_MDISRequest.MDISRequest.RequestHeader requestHeader)  {
			this.requestHeader = requestHeader;
		}


		/**
		 * IS document wrapper
		 */
		public static class RequestManifest extends java.lang.Object implements Serializable {
		
			
			private static final long serialVersionUID = 1L;
			private com.webmethods.caf.is.document.TMCommon_docType_MDIS_MDISRequest.MDISRequest.RequestManifest.DstChannelInfo dstChannelInfo = null;
			private com.webmethods.caf.is.document.TMCommon_docType_MDIS_MDISRequest.MDISRequest.RequestManifest.Attachments attachments = null;
			public static String[][] FIELD_NAMES = new String[][] {{"dstChannelInfo", "DstChannelInfo"},{"email", "Email"},{"mime", "MIME"},{"language", "Language"},{"toAddress", "ToAddress"},{"fromAddress", "FromAddress"},{"ccaddress", "CCAddress"},{"bccaddress", "BCCAddress"},{"bodyTmplFlag", "BodyTmplFlag"},{"subject", "Subject"},{"emailBody", "EmailBody"},{"passphrase", "Passphrase"},{"faxNumber", "FaxNumber"},{"fromFaxAddress", "FromFaxAddress"},{"fax", "Fax"},{"mobileNumber", "MobileNumber"},{"smsbody", "SMSBody"},{"sms", "SMS"},{"attachment", "Attachment"},{"fileType", "FileType"},{"fileContent", "FileContent"},{"fileName", "FileName"},{"attachments", "Attachments"},{"templateName", "TemplateName"},{"rptData", "RptData"},{"addOnServiceInfo", "AddOnServiceInfo"},
			};
			private com.webmethods.caf.is.document.TMCommon_docType_MDIS_MDISRequest.MDISRequest.RequestManifest.AddOnServiceInfo addOnServiceInfo = null;
			
		
			public RequestManifest() {
			}


			/**
			 * IS document wrapper
			 */
			public static class DstChannelInfo extends java.lang.Object implements Serializable {
			
				
				private static final long serialVersionUID = 1L;
				private com.webmethods.caf.is.document.TMCommon_docType_MDIS_MDISRequest.MDISRequest.RequestManifest.DstChannelInfo.Email[] email = null;
				private com.webmethods.caf.is.document.TMCommon_docType_MDIS_MDISRequest.MDISRequest.RequestManifest.DstChannelInfo.Fax[] fax = null;
				public static String[][] FIELD_NAMES = new String[][] {{"email", "Email"},{"mime", "MIME"},{"language", "Language"},{"toAddress", "ToAddress"},{"fromAddress", "FromAddress"},{"ccaddress", "CCAddress"},{"bccaddress", "BCCAddress"},{"bodyTmplFlag", "BodyTmplFlag"},{"subject", "Subject"},{"emailBody", "EmailBody"},{"passphrase", "Passphrase"},{"faxNumber", "FaxNumber"},{"fromFaxAddress", "FromFaxAddress"},{"fax", "Fax"},{"mobileNumber", "MobileNumber"},{"smsbody", "SMSBody"},{"sms", "SMS"},
				};
				private com.webmethods.caf.is.document.TMCommon_docType_MDIS_MDISRequest.MDISRequest.RequestManifest.DstChannelInfo.SMS[] sms = null;
				
			
				public DstChannelInfo() {
				}


				/**
				 * IS document wrapper
				 */
				public static class Email extends java.lang.Object implements Serializable {
				
					
					private static final long serialVersionUID = 1L;
					private java.lang.String mime;
					private java.lang.String language;
					private java.lang.String[] toAddress = null;
					private java.lang.String fromAddress;
					private java.lang.String ccaddress;
					private java.lang.String bccaddress;
					private java.lang.String bodyTmplFlag;
					private java.lang.String subject;
					private java.lang.String emailBody;
					public static String[][] FIELD_NAMES = new String[][] {{"mime", "MIME"},{"language", "Language"},{"toAddress", "ToAddress"},{"fromAddress", "FromAddress"},{"ccaddress", "CCAddress"},{"bccaddress", "BCCAddress"},{"bodyTmplFlag", "BodyTmplFlag"},{"subject", "Subject"},{"emailBody", "EmailBody"},{"passphrase", "Passphrase"},
					};
					private java.lang.String passphrase;
					
				
					public Email() {
					}


					public java.lang.String getMime()  {
						
						return mime;
					}


					public void setMime(java.lang.String mime)  {
						this.mime = mime;
					}


					public java.lang.String getLanguage()  {
						
						return language;
					}


					public void setLanguage(java.lang.String language)  {
						this.language = language;
					}


					public java.lang.String[] getToAddress()  {
						if (toAddress == null) {
							//TODO: create/set default value here
						}
						return toAddress;
					}


					public void setToAddress(java.lang.String[] toAddress)  {
						this.toAddress = toAddress;
					}


					public java.lang.String getFromAddress()  {
						
						return fromAddress;
					}


					public void setFromAddress(java.lang.String fromAddress)  {
						this.fromAddress = fromAddress;
					}


					public java.lang.String getCcaddress()  {
						
						return ccaddress;
					}


					public void setCcaddress(java.lang.String ccaddress)  {
						this.ccaddress = ccaddress;
					}


					public java.lang.String getBccaddress()  {
						
						return bccaddress;
					}


					public void setBccaddress(java.lang.String bccaddress)  {
						this.bccaddress = bccaddress;
					}


					public java.lang.String getBodyTmplFlag()  {
						
						return bodyTmplFlag;
					}


					public void setBodyTmplFlag(java.lang.String bodyTmplFlag)  {
						this.bodyTmplFlag = bodyTmplFlag;
					}


					public java.lang.String getSubject()  {
						
						return subject;
					}


					public void setSubject(java.lang.String subject)  {
						this.subject = subject;
					}


					public java.lang.String getEmailBody()  {
						
						return emailBody;
					}


					public void setEmailBody(java.lang.String emailBody)  {
						this.emailBody = emailBody;
					}


					public java.lang.String getPassphrase()  {
						
						return passphrase;
					}


					public void setPassphrase(java.lang.String passphrase)  {
						this.passphrase = passphrase;
					}
				
				}


				public com.webmethods.caf.is.document.TMCommon_docType_MDIS_MDISRequest.MDISRequest.RequestManifest.DstChannelInfo.Email[] getEmail()  {
					if (email == null) {
						//TODO: create/set default value here
					}
					return email;
				}


				public void setEmail(com.webmethods.caf.is.document.TMCommon_docType_MDIS_MDISRequest.MDISRequest.RequestManifest.DstChannelInfo.Email[] email)  {
					this.email = email;
				}


				/**
				 * IS document wrapper
				 */
				public static class Fax extends java.lang.Object implements Serializable {
				
					
					private static final long serialVersionUID = 1L;
					private java.lang.String[] faxNumber = null;
					public static String[][] FIELD_NAMES = new String[][] {{"faxNumber", "FaxNumber"},{"fromFaxAddress", "FromFaxAddress"},
					};
					private java.lang.String fromFaxAddress;
					
				
					public Fax() {
					}


					public java.lang.String[] getFaxNumber()  {
						if (faxNumber == null) {
							//TODO: create/set default value here
						}
						return faxNumber;
					}


					public void setFaxNumber(java.lang.String[] faxNumber)  {
						this.faxNumber = faxNumber;
					}


					public java.lang.String getFromFaxAddress()  {
						
						return fromFaxAddress;
					}


					public void setFromFaxAddress(java.lang.String fromFaxAddress)  {
						this.fromFaxAddress = fromFaxAddress;
					}
				
				}


				public com.webmethods.caf.is.document.TMCommon_docType_MDIS_MDISRequest.MDISRequest.RequestManifest.DstChannelInfo.Fax[] getFax()  {
					if (fax == null) {
						//TODO: create/set default value here
					}
					return fax;
				}


				public void setFax(com.webmethods.caf.is.document.TMCommon_docType_MDIS_MDISRequest.MDISRequest.RequestManifest.DstChannelInfo.Fax[] fax)  {
					this.fax = fax;
				}


				/**
				 * IS document wrapper
				 */
				public static class SMS extends java.lang.Object implements Serializable {
				
					
					private static final long serialVersionUID = 1L;
					private java.lang.String mime;
					private java.lang.String language;
					private java.lang.String[] mobileNumber = null;
					private java.lang.String bodyTmplFlag;
					public static String[][] FIELD_NAMES = new String[][] {{"mime", "MIME"},{"language", "Language"},{"mobileNumber", "MobileNumber"},{"bodyTmplFlag", "BodyTmplFlag"},{"smsbody", "SMSBody"},
					};
					private java.lang.String smsbody;
					
				
					public SMS() {
					}


					public java.lang.String getMime()  {
						
						return mime;
					}


					public void setMime(java.lang.String mime)  {
						this.mime = mime;
					}


					public java.lang.String getLanguage()  {
						
						return language;
					}


					public void setLanguage(java.lang.String language)  {
						this.language = language;
					}


					public java.lang.String[] getMobileNumber()  {
						if (mobileNumber == null) {
							//TODO: create/set default value here
						}
						return mobileNumber;
					}


					public void setMobileNumber(java.lang.String[] mobileNumber)  {
						this.mobileNumber = mobileNumber;
					}


					public java.lang.String getBodyTmplFlag()  {
						
						return bodyTmplFlag;
					}


					public void setBodyTmplFlag(java.lang.String bodyTmplFlag)  {
						this.bodyTmplFlag = bodyTmplFlag;
					}


					public java.lang.String getSmsbody()  {
						
						return smsbody;
					}


					public void setSmsbody(java.lang.String smsbody)  {
						this.smsbody = smsbody;
					}
				
				}


				public com.webmethods.caf.is.document.TMCommon_docType_MDIS_MDISRequest.MDISRequest.RequestManifest.DstChannelInfo.SMS[] getSms()  {
					if (sms == null) {
						//TODO: create/set default value here
					}
					return sms;
				}


				public void setSms(com.webmethods.caf.is.document.TMCommon_docType_MDIS_MDISRequest.MDISRequest.RequestManifest.DstChannelInfo.SMS[] sms)  {
					this.sms = sms;
				}
			
			}


			public com.webmethods.caf.is.document.TMCommon_docType_MDIS_MDISRequest.MDISRequest.RequestManifest.DstChannelInfo getDstChannelInfo()  {
				if (dstChannelInfo == null) {
					dstChannelInfo = new com.webmethods.caf.is.document.TMCommon_docType_MDIS_MDISRequest.MDISRequest.RequestManifest.DstChannelInfo();
				}
				return dstChannelInfo;
			}


			public void setDstChannelInfo(com.webmethods.caf.is.document.TMCommon_docType_MDIS_MDISRequest.MDISRequest.RequestManifest.DstChannelInfo dstChannelInfo)  {
				this.dstChannelInfo = dstChannelInfo;
			}


			/**
			 * IS document wrapper
			 */
			public static class Attachments extends java.lang.Object implements Serializable {
			
				
				private static final long serialVersionUID = 1L;
				// IS Document type used to generate this class
				public static String[][] FIELD_NAMES = new String[][] {{"attachment", "Attachment"},
				};
				private com.webmethods.caf.is.document.TMCommon_docType_MDIS_MDISRequest.MDISRequest.RequestManifest.Attachments.Attachment[] attachment = null;
				
			
				public Attachments() {
				}


				/**
				 * IS document wrapper
				 */
				public static class Attachment extends java.lang.Object implements Serializable {
				
					
					private static final long serialVersionUID = 1L;
					private java.lang.String fileType;
					private java.lang.String fileContent;
					public static String[][] FIELD_NAMES = new String[][] {{"fileType", "FileType"},{"fileContent", "FileContent"},{"fileName", "FileName"},
					};
					private java.lang.String fileName;
					
				
					public Attachment() {
					}


					public java.lang.String getFileType()  {
						
						return fileType;
					}


					public void setFileType(java.lang.String fileType)  {
						this.fileType = fileType;
					}


					public java.lang.String getFileContent()  {
						
						return fileContent;
					}


					public void setFileContent(java.lang.String fileContent)  {
						this.fileContent = fileContent;
					}


					public java.lang.String getFileName()  {
						
						return fileName;
					}


					public void setFileName(java.lang.String fileName)  {
						this.fileName = fileName;
					}
				
				}


				public com.webmethods.caf.is.document.TMCommon_docType_MDIS_MDISRequest.MDISRequest.RequestManifest.Attachments.Attachment[] getAttachment()  {
					if (attachment == null) {
						//TODO: create/set default value here
					}
					return attachment;
				}


				public void setAttachment(com.webmethods.caf.is.document.TMCommon_docType_MDIS_MDISRequest.MDISRequest.RequestManifest.Attachments.Attachment[] attachment)  {
					this.attachment = attachment;
				}
			
			}


			public com.webmethods.caf.is.document.TMCommon_docType_MDIS_MDISRequest.MDISRequest.RequestManifest.Attachments getAttachments()  {
				if (attachments == null) {
					attachments = new com.webmethods.caf.is.document.TMCommon_docType_MDIS_MDISRequest.MDISRequest.RequestManifest.Attachments();
				}
				return attachments;
			}


			public void setAttachments(com.webmethods.caf.is.document.TMCommon_docType_MDIS_MDISRequest.MDISRequest.RequestManifest.Attachments attachments)  {
				this.attachments = attachments;
			}


			/**
			 * IS document wrapper
			 */
			public static class AddOnServiceInfo extends java.lang.Object implements Serializable {
			
				
				private static final long serialVersionUID = 1L;
				private java.lang.String templateName;
				public static String[][] FIELD_NAMES = new String[][] {{"templateName", "TemplateName"},{"rptData", "RptData"},
				};
				private java.lang.String rptData;
				
			
				public AddOnServiceInfo() {
				}


				public java.lang.String getTemplateName()  {
					
					return templateName;
				}


				public void setTemplateName(java.lang.String templateName)  {
					this.templateName = templateName;
				}


				public java.lang.String getRptData()  {
					
					return rptData;
				}


				public void setRptData(java.lang.String rptData)  {
					this.rptData = rptData;
				}
			
			}


			public com.webmethods.caf.is.document.TMCommon_docType_MDIS_MDISRequest.MDISRequest.RequestManifest.AddOnServiceInfo getAddOnServiceInfo()  {
				if (addOnServiceInfo == null) {
					addOnServiceInfo = new com.webmethods.caf.is.document.TMCommon_docType_MDIS_MDISRequest.MDISRequest.RequestManifest.AddOnServiceInfo();
				}
				return addOnServiceInfo;
			}


			public void setAddOnServiceInfo(com.webmethods.caf.is.document.TMCommon_docType_MDIS_MDISRequest.MDISRequest.RequestManifest.AddOnServiceInfo addOnServiceInfo)  {
				this.addOnServiceInfo = addOnServiceInfo;
			}
		
		}


		public com.webmethods.caf.is.document.TMCommon_docType_MDIS_MDISRequest.MDISRequest.RequestManifest getRequestManifest()  {
			if (requestManifest == null) {
				requestManifest = new com.webmethods.caf.is.document.TMCommon_docType_MDIS_MDISRequest.MDISRequest.RequestManifest();
			}
			return requestManifest;
		}


		public void setRequestManifest(com.webmethods.caf.is.document.TMCommon_docType_MDIS_MDISRequest.MDISRequest.RequestManifest requestManifest)  {
			this.requestManifest = requestManifest;
		}
	
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MDIS_MDISRequest.MDISRequest getMdisrequest()  {
		if (mdisrequest == null) {
			mdisrequest = new com.webmethods.caf.is.document.TMCommon_docType_MDIS_MDISRequest.MDISRequest();
		}
		return mdisrequest;
	}


	public void setMdisrequest(com.webmethods.caf.is.document.TMCommon_docType_MDIS_MDISRequest.MDISRequest mdisrequest)  {
		this.mdisrequest = mdisrequest;
	}

}