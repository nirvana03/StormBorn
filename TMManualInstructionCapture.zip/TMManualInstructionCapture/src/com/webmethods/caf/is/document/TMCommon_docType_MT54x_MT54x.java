package com.webmethods.caf.is.document;

import java.io.Serializable;

/**
 * IS document wrapper
 */
public  class TMCommon_docType_MT54x_MT54x extends java.lang.Object implements Serializable {

	
	private static final long serialVersionUID = 1L;
	// IS Document type used to generate this class
	public static final String DOCUMENT_TYPE = "TMCommon.docType.MT54x:MT54x";
	public static String[][] FIELD_NAMES = new String[][] {{"nsDocument", "ns:Document"},
	};
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_Document nsDocument = null;
	

	public TMCommon_docType_MT54x_MT54x() {
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_Document getNsDocument()  {
		if (nsDocument == null) {
			nsDocument = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_Document();
		}
		return nsDocument;
	}


	public void setNsDocument(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_Document nsDocument)  {
		this.nsDocument = nsDocument;
	}

}