package com.webmethods.caf.is.document;

import java.io.Serializable;

/**
 * IS document wrapper
 */
public  class TMCommon_docType_MT54x_docTypeRef_ns_F11A_Type extends java.lang.Object implements Serializable {

	
	private static final long serialVersionUID = 1L;
	// IS Document type used to generate this class
	public static final String DOCUMENT_TYPE = "TMCommon.docType.MT54x:docTypeRef_ns_F11A_Type";
	public static String[][] FIELD_NAMES = new String[][] {{"nsCurrencyCode", "ns:CurrencyCode"},
	};
	private java.lang.String nsCurrencyCode;
	

	public TMCommon_docType_MT54x_docTypeRef_ns_F11A_Type() {
	}


	public java.lang.String getNsCurrencyCode()  {
		
		return nsCurrencyCode;
	}


	public void setNsCurrencyCode(java.lang.String nsCurrencyCode)  {
		this.nsCurrencyCode = nsCurrencyCode;
	}

}