package com.webmethods.caf.is.document;

import java.io.Serializable;

/**
 * IS document wrapper
 */
public  class TMCommon_docType_MT54x_docTypeRef_ns_F12C_Type extends java.lang.Object implements Serializable {

	
	private static final long serialVersionUID = 1L;
	// IS Document type used to generate this class
	public static final String DOCUMENT_TYPE = "TMCommon.docType.MT54x:docTypeRef_ns_F12C_Type";
	public static String[][] FIELD_NAMES = new String[][] {{"nsCFICode", "ns:CFICode"},
	};
	private java.lang.String nsCFICode;
	

	public TMCommon_docType_MT54x_docTypeRef_ns_F12C_Type() {
	}


	public java.lang.String getNsCFICode()  {
		
		return nsCFICode;
	}


	public void setNsCFICode(java.lang.String nsCFICode)  {
		this.nsCFICode = nsCFICode;
	}

}