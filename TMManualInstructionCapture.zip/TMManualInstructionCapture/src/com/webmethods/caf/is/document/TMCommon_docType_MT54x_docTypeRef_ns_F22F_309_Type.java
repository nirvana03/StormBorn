package com.webmethods.caf.is.document;

import java.io.Serializable;

/**
 * IS document wrapper
 */
public  class TMCommon_docType_MT54x_docTypeRef_ns_F22F_309_Type extends java.lang.Object implements Serializable {

	
	private static final long serialVersionUID = 1L;
	// IS Document type used to generate this class
	public static final String DOCUMENT_TYPE = "TMCommon.docType.MT54x:docTypeRef_ns_F22F_309_Type";
	private java.lang.String nsDataSourceScheme;
	public static String[][] FIELD_NAMES = new String[][] {{"nsDataSourceScheme", "ns:DataSourceScheme"},{"nsIndicator", "ns:Indicator"},
	};
	private java.lang.String nsIndicator;
	

	public TMCommon_docType_MT54x_docTypeRef_ns_F22F_309_Type() {
	}


	public java.lang.String getNsDataSourceScheme()  {
		
		return nsDataSourceScheme;
	}


	public void setNsDataSourceScheme(java.lang.String nsDataSourceScheme)  {
		this.nsDataSourceScheme = nsDataSourceScheme;
	}


	public java.lang.String getNsIndicator()  {
		
		return nsIndicator;
	}


	public void setNsIndicator(java.lang.String nsIndicator)  {
		this.nsIndicator = nsIndicator;
	}

}