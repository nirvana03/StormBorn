package com.webmethods.caf.is.document;

import java.io.Serializable;

/**
 * IS document wrapper
 */
public  class TMCommon_docType_MT54x_docTypeRef_ns_F35B_Type extends java.lang.Object implements Serializable {

	
	private static final long serialVersionUID = 1L;
	// IS Document type used to generate this class
	public static final String DOCUMENT_TYPE = "TMCommon.docType.MT54x:docTypeRef_ns_F35B_Type";
	private java.lang.String nsIdentificationOfSecurity;
	public static String[][] FIELD_NAMES = new String[][] {{"nsIdentificationOfSecurity", "ns:IdentificationOfSecurity"},{"nsDescriptionOfSecurity", "ns:DescriptionOfSecurity"},
	};
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_Text_FIN_4M35x_Type nsDescriptionOfSecurity = null;
	

	public TMCommon_docType_MT54x_docTypeRef_ns_F35B_Type() {
	}


	public java.lang.String getNsIdentificationOfSecurity()  {
		
		return nsIdentificationOfSecurity;
	}


	public void setNsIdentificationOfSecurity(java.lang.String nsIdentificationOfSecurity)  {
		this.nsIdentificationOfSecurity = nsIdentificationOfSecurity;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_Text_FIN_4M35x_Type getNsDescriptionOfSecurity()  {
		if (nsDescriptionOfSecurity == null) {
			nsDescriptionOfSecurity = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_Text_FIN_4M35x_Type();
		}
		return nsDescriptionOfSecurity;
	}


	public void setNsDescriptionOfSecurity(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_Text_FIN_4M35x_Type nsDescriptionOfSecurity)  {
		this.nsDescriptionOfSecurity = nsDescriptionOfSecurity;
	}

}