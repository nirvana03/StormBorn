package com.webmethods.caf.is.document;

import java.io.Serializable;

/**
 * IS document wrapper
 */
public  class TMCommon_docType_MT54x_docTypeRef_ns_F70C_Type extends java.lang.Object implements Serializable {

	
	private static final long serialVersionUID = 1L;
	// IS Document type used to generate this class
	public static final String DOCUMENT_TYPE = "TMCommon.docType.MT54x:docTypeRef_ns_F70C_Type";
	public static String[][] FIELD_NAMES = new String[][] {{"nsNarrative", "ns:Narrative"},
	};
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_Text_FIN_4M35x_Type nsNarrative = null;
	

	public TMCommon_docType_MT54x_docTypeRef_ns_F70C_Type() {
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_Text_FIN_4M35x_Type getNsNarrative()  {
		if (nsNarrative == null) {
			nsNarrative = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_Text_FIN_4M35x_Type();
		}
		return nsNarrative;
	}


	public void setNsNarrative(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_Text_FIN_4M35x_Type nsNarrative)  {
		this.nsNarrative = nsNarrative;
	}

}