package com.webmethods.caf.is.document;

import java.io.Serializable;

/**
 * IS document wrapper
 */
public  class TMCommon_docType_MT54x_docTypeRef_ns_F90A_2_Type extends java.lang.Object implements Serializable {

	
	private static final long serialVersionUID = 1L;
	// IS Document type used to generate this class
	public static final String DOCUMENT_TYPE = "TMCommon.docType.MT54x:docTypeRef_ns_F90A_2_Type";
	private java.lang.String nsPercentageTypeCode;
	private java.lang.String nsSign;
	public static String[][] FIELD_NAMES = new String[][] {{"nsPercentageTypeCode", "ns:PercentageTypeCode"},{"nsSign", "ns:Sign"},{"nsPrice", "ns:Price"},
	};
	private java.lang.String nsPrice;
	

	public TMCommon_docType_MT54x_docTypeRef_ns_F90A_2_Type() {
	}


	public java.lang.String getNsPercentageTypeCode()  {
		
		return nsPercentageTypeCode;
	}


	public void setNsPercentageTypeCode(java.lang.String nsPercentageTypeCode)  {
		this.nsPercentageTypeCode = nsPercentageTypeCode;
	}


	public java.lang.String getNsSign()  {
		
		return nsSign;
	}


	public void setNsSign(java.lang.String nsSign)  {
		this.nsSign = nsSign;
	}


	public java.lang.String getNsPrice()  {
		
		return nsPrice;
	}


	public void setNsPrice(java.lang.String nsPrice)  {
		this.nsPrice = nsPrice;
	}

}