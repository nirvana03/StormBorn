package com.webmethods.caf.is.document;

import java.io.Serializable;

/**
 * IS document wrapper
 */
public  class TMCommon_docType_MT54x_docTypeRef_ns_F90B_4_Type extends java.lang.Object implements Serializable {

	
	private static final long serialVersionUID = 1L;
	// IS Document type used to generate this class
	public static final String DOCUMENT_TYPE = "TMCommon.docType.MT54x:docTypeRef_ns_F90B_4_Type";
	private java.lang.String nsAmountTypeCode;
	private java.lang.String nsCurrencyCode;
	public static String[][] FIELD_NAMES = new String[][] {{"nsAmountTypeCode", "ns:AmountTypeCode"},{"nsCurrencyCode", "ns:CurrencyCode"},{"nsPrice", "ns:Price"},
	};
	private java.lang.String nsPrice;
	

	public TMCommon_docType_MT54x_docTypeRef_ns_F90B_4_Type() {
	}


	public java.lang.String getNsAmountTypeCode()  {
		
		return nsAmountTypeCode;
	}


	public void setNsAmountTypeCode(java.lang.String nsAmountTypeCode)  {
		this.nsAmountTypeCode = nsAmountTypeCode;
	}


	public java.lang.String getNsCurrencyCode()  {
		
		return nsCurrencyCode;
	}


	public void setNsCurrencyCode(java.lang.String nsCurrencyCode)  {
		this.nsCurrencyCode = nsCurrencyCode;
	}


	public java.lang.String getNsPrice()  {
		
		return nsPrice;
	}


	public void setNsPrice(java.lang.String nsPrice)  {
		this.nsPrice = nsPrice;
	}

}