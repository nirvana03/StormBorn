package com.webmethods.caf.is.document;

import java.io.Serializable;

/**
 * IS document wrapper
 */
public  class TMCommon_docType_MT54x_docTypeRef_ns_F92A_Type extends java.lang.Object implements Serializable {

	
	private static final long serialVersionUID = 1L;
	// IS Document type used to generate this class
	public static final String DOCUMENT_TYPE = "TMCommon.docType.MT54x:docTypeRef_ns_F92A_Type";
	private java.lang.String nsSign;
	public static String[][] FIELD_NAMES = new String[][] {{"nsSign", "ns:Sign"},{"nsRate", "ns:Rate"},
	};
	private java.lang.String nsRate;
	

	public TMCommon_docType_MT54x_docTypeRef_ns_F92A_Type() {
	}


	public java.lang.String getNsSign()  {
		
		return nsSign;
	}


	public void setNsSign(java.lang.String nsSign)  {
		this.nsSign = nsSign;
	}


	public java.lang.String getNsRate()  {
		
		return nsRate;
	}


	public void setNsRate(java.lang.String nsRate)  {
		this.nsRate = nsRate;
	}

}