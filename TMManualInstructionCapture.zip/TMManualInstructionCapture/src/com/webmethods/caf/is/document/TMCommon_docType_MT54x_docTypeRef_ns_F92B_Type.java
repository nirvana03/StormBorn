package com.webmethods.caf.is.document;

import java.io.Serializable;

/**
 * IS document wrapper
 */
public  class TMCommon_docType_MT54x_docTypeRef_ns_F92B_Type extends java.lang.Object implements Serializable {

	
	private static final long serialVersionUID = 1L;
	// IS Document type used to generate this class
	public static final String DOCUMENT_TYPE = "TMCommon.docType.MT54x:docTypeRef_ns_F92B_Type";
	private java.lang.String nsFirstCurrencyCode;
	private java.lang.String nsSecondCurrencyCode;
	public static String[][] FIELD_NAMES = new String[][] {{"nsFirstCurrencyCode", "ns:FirstCurrencyCode"},{"nsSecondCurrencyCode", "ns:SecondCurrencyCode"},{"nsRate", "ns:Rate"},
	};
	private java.lang.String nsRate;
	

	public TMCommon_docType_MT54x_docTypeRef_ns_F92B_Type() {
	}


	public java.lang.String getNsFirstCurrencyCode()  {
		
		return nsFirstCurrencyCode;
	}


	public void setNsFirstCurrencyCode(java.lang.String nsFirstCurrencyCode)  {
		this.nsFirstCurrencyCode = nsFirstCurrencyCode;
	}


	public java.lang.String getNsSecondCurrencyCode()  {
		
		return nsSecondCurrencyCode;
	}


	public void setNsSecondCurrencyCode(java.lang.String nsSecondCurrencyCode)  {
		this.nsSecondCurrencyCode = nsSecondCurrencyCode;
	}


	public java.lang.String getNsRate()  {
		
		return nsRate;
	}


	public void setNsRate(java.lang.String nsRate)  {
		this.nsRate = nsRate;
	}

}