package com.webmethods.caf.is.document;

import java.io.Serializable;

/**
 * IS document wrapper
 */
public  class TMCommon_docType_MT54x_docTypeRef_ns_F94F_3_Type extends java.lang.Object implements Serializable {

	
	private static final long serialVersionUID = 1L;
	// IS Document type used to generate this class
	public static final String DOCUMENT_TYPE = "TMCommon.docType.MT54x:docTypeRef_ns_F94F_3_Type";
	private java.lang.String nsPlaceCode;
	public static String[][] FIELD_NAMES = new String[][] {{"nsPlaceCode", "ns:PlaceCode"},{"nsIdentifierCode", "ns:IdentifierCode"},
	};
	private java.lang.String nsIdentifierCode;
	

	public TMCommon_docType_MT54x_docTypeRef_ns_F94F_3_Type() {
	}


	public java.lang.String getNsPlaceCode()  {
		
		return nsPlaceCode;
	}


	public void setNsPlaceCode(java.lang.String nsPlaceCode)  {
		this.nsPlaceCode = nsPlaceCode;
	}


	public java.lang.String getNsIdentifierCode()  {
		
		return nsIdentifierCode;
	}


	public void setNsIdentifierCode(java.lang.String nsIdentifierCode)  {
		this.nsIdentifierCode = nsIdentifierCode;
	}

}