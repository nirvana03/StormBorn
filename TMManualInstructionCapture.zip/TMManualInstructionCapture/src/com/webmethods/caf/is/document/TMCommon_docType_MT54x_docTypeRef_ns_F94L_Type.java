package com.webmethods.caf.is.document;

import java.io.Serializable;

/**
 * IS document wrapper
 */
public  class TMCommon_docType_MT54x_docTypeRef_ns_F94L_Type extends java.lang.Object implements Serializable {

	
	private static final long serialVersionUID = 1L;
	// IS Document type used to generate this class
	public static final String DOCUMENT_TYPE = "TMCommon.docType.MT54x:docTypeRef_ns_F94L_Type";
	public static String[][] FIELD_NAMES = new String[][] {{"nsLegalEntityIdentifier", "ns:LegalEntityIdentifier"},
	};
	private java.lang.String nsLegalEntityIdentifier;
	

	public TMCommon_docType_MT54x_docTypeRef_ns_F94L_Type() {
	}


	public java.lang.String getNsLegalEntityIdentifier()  {
		
		return nsLegalEntityIdentifier;
	}


	public void setNsLegalEntityIdentifier(java.lang.String nsLegalEntityIdentifier)  {
		this.nsLegalEntityIdentifier = nsLegalEntityIdentifier;
	}

}