package com.webmethods.caf.is.document;

import java.io.Serializable;

/**
 * IS document wrapper
 */
public  class TMCommon_docType_MT54x_docTypeRef_ns_F95C_2_Type extends java.lang.Object implements Serializable {

	
	private static final long serialVersionUID = 1L;
	// IS Document type used to generate this class
	public static final String DOCUMENT_TYPE = "TMCommon.docType.MT54x:docTypeRef_ns_F95C_2_Type";
	public static String[][] FIELD_NAMES = new String[][] {{"nsCountryCode", "ns:CountryCode"},
	};
	private java.lang.String nsCountryCode;
	

	public TMCommon_docType_MT54x_docTypeRef_ns_F95C_2_Type() {
	}


	public java.lang.String getNsCountryCode()  {
		
		return nsCountryCode;
	}


	public void setNsCountryCode(java.lang.String nsCountryCode)  {
		this.nsCountryCode = nsCountryCode;
	}

}