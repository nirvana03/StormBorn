package com.webmethods.caf.is.document;

import java.io.Serializable;

/**
 * IS document wrapper
 */
public  class TMCommon_docType_MT54x_docTypeRef_ns_F95Q_Type extends java.lang.Object implements Serializable {

	
	private static final long serialVersionUID = 1L;
	// IS Document type used to generate this class
	public static final String DOCUMENT_TYPE = "TMCommon.docType.MT54x:docTypeRef_ns_F95Q_Type";
	public static String[][] FIELD_NAMES = new String[][] {{"nsNameAndAddress", "ns:NameAndAddress"},
	};
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_Text_FIN_4M35x_Type nsNameAndAddress = null;
	

	public TMCommon_docType_MT54x_docTypeRef_ns_F95Q_Type() {
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_Text_FIN_4M35x_Type getNsNameAndAddress()  {
		if (nsNameAndAddress == null) {
			nsNameAndAddress = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_Text_FIN_4M35x_Type();
		}
		return nsNameAndAddress;
	}


	public void setNsNameAndAddress(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_Text_FIN_4M35x_Type nsNameAndAddress)  {
		this.nsNameAndAddress = nsNameAndAddress;
	}

}