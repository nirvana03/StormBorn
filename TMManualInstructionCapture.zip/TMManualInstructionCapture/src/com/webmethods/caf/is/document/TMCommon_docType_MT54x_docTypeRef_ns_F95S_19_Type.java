package com.webmethods.caf.is.document;

import java.io.Serializable;

/**
 * IS document wrapper
 */
public  class TMCommon_docType_MT54x_docTypeRef_ns_F95S_19_Type extends java.lang.Object implements Serializable {

	
	private static final long serialVersionUID = 1L;
	// IS Document type used to generate this class
	public static final String DOCUMENT_TYPE = "TMCommon.docType.MT54x:docTypeRef_ns_F95S_19_Type";
	private java.lang.String nsDataSourceScheme;
	private java.lang.String nsTypeOfID;
	private java.lang.String nsCountryCode;
	public static String[][] FIELD_NAMES = new String[][] {{"nsDataSourceScheme", "ns:DataSourceScheme"},{"nsTypeOfID", "ns:TypeOfID"},{"nsCountryCode", "ns:CountryCode"},{"nsAlternateID", "ns:AlternateID"},
	};
	private java.lang.String nsAlternateID;
	

	public TMCommon_docType_MT54x_docTypeRef_ns_F95S_19_Type() {
	}


	public java.lang.String getNsDataSourceScheme()  {
		
		return nsDataSourceScheme;
	}


	public void setNsDataSourceScheme(java.lang.String nsDataSourceScheme)  {
		this.nsDataSourceScheme = nsDataSourceScheme;
	}


	public java.lang.String getNsTypeOfID()  {
		
		return nsTypeOfID;
	}


	public void setNsTypeOfID(java.lang.String nsTypeOfID)  {
		this.nsTypeOfID = nsTypeOfID;
	}


	public java.lang.String getNsCountryCode()  {
		
		return nsCountryCode;
	}


	public void setNsCountryCode(java.lang.String nsCountryCode)  {
		this.nsCountryCode = nsCountryCode;
	}


	public java.lang.String getNsAlternateID()  {
		
		return nsAlternateID;
	}


	public void setNsAlternateID(java.lang.String nsAlternateID)  {
		this.nsAlternateID = nsAlternateID;
	}

}