package com.webmethods.caf.is.document;

import java.io.Serializable;

/**
 * IS document wrapper
 */
public  class TMCommon_docType_MT54x_docTypeRef_ns_F98C_Type extends java.lang.Object implements Serializable {

	
	private static final long serialVersionUID = 1L;
	// IS Document type used to generate this class
	public static final String DOCUMENT_TYPE = "TMCommon.docType.MT54x:docTypeRef_ns_F98C_Type";
	private java.lang.String nsDate;
	public static String[][] FIELD_NAMES = new String[][] {{"nsDate", "ns:Date"},{"nsTime", "ns:Time"},
	};
	private java.lang.String nsTime;
	

	public TMCommon_docType_MT54x_docTypeRef_ns_F98C_Type() {
	}


	public java.lang.String getNsDate()  {
		
		return nsDate;
	}


	public void setNsDate(java.lang.String nsDate)  {
		this.nsDate = nsDate;
	}


	public java.lang.String getNsTime()  {
		
		return nsTime;
	}


	public void setNsTime(java.lang.String nsTime)  {
		this.nsTime = nsTime;
	}

}