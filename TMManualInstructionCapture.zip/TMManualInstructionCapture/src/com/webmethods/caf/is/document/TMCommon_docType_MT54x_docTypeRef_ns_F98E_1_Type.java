package com.webmethods.caf.is.document;

import java.io.Serializable;

/**
 * IS document wrapper
 */
public  class TMCommon_docType_MT54x_docTypeRef_ns_F98E_1_Type extends java.lang.Object implements Serializable {

	
	private static final long serialVersionUID = 1L;
	// IS Document type used to generate this class
	public static final String DOCUMENT_TYPE = "TMCommon.docType.MT54x:docTypeRef_ns_F98E_1_Type";
	private java.lang.String nsDate;
	private java.lang.String nsTime;
	private java.lang.String nsDecimals;
	public static String[][] FIELD_NAMES = new String[][] {{"nsDate", "ns:Date"},{"nsTime", "ns:Time"},{"nsDecimals", "ns:Decimals"},{"nsUTCIndicator", "ns:UTCIndicator"},
	};
	private java.lang.String nsUTCIndicator;
	

	public TMCommon_docType_MT54x_docTypeRef_ns_F98E_1_Type() {
	}


	public java.lang.String getNsDate()  {
		
		return nsDate;
	}


	public void setNsDate(java.lang.String nsDate)  {
		this.nsDate = nsDate;
	}


	public java.lang.String getNsTime()  {
		
		return nsTime;
	}


	public void setNsTime(java.lang.String nsTime)  {
		this.nsTime = nsTime;
	}


	public java.lang.String getNsDecimals()  {
		
		return nsDecimals;
	}


	public void setNsDecimals(java.lang.String nsDecimals)  {
		this.nsDecimals = nsDecimals;
	}


	public java.lang.String getNsUTCIndicator()  {
		
		return nsUTCIndicator;
	}


	public void setNsUTCIndicator(java.lang.String nsUTCIndicator)  {
		this.nsUTCIndicator = nsUTCIndicator;
	}

}