package com.webmethods.caf.is.document;

import java.io.Serializable;

/**
 * IS document wrapper
 */
public  class TMCommon_docType_MT54x_docTypeRef_ns_MT54x_Type extends java.lang.Object implements Serializable {

	
	private static final long serialVersionUID = 1L;
	// IS Document type used to generate this class
	public static final String DOCUMENT_TYPE = "TMCommon.docType.MT54x:docTypeRef_ns_MT54x_Type";
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqA_Type nsSeqA = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_Type nsSeqB = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqC_Type nsSeqC = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqD_Type nsSeqD = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE_Type nsSeqE = null;
	public static String[][] FIELD_NAMES = new String[][] {{"nsSeqA", "ns:SeqA"},{"nsSeqB", "ns:SeqB"},{"nsSeqC", "ns:SeqC"},{"nsSeqD", "ns:SeqD"},{"nsSeqE", "ns:SeqE"},{"nsSeqF", "ns:SeqF"},
	};
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqF_Type[] nsSeqF = null;
	

	public TMCommon_docType_MT54x_docTypeRef_ns_MT54x_Type() {
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqA_Type getNsSeqA()  {
		if (nsSeqA == null) {
			nsSeqA = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqA_Type();
		}
		return nsSeqA;
	}


	public void setNsSeqA(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqA_Type nsSeqA)  {
		this.nsSeqA = nsSeqA;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_Type getNsSeqB()  {
		if (nsSeqB == null) {
			nsSeqB = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_Type();
		}
		return nsSeqB;
	}


	public void setNsSeqB(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_Type nsSeqB)  {
		this.nsSeqB = nsSeqB;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqC_Type getNsSeqC()  {
		if (nsSeqC == null) {
			nsSeqC = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqC_Type();
		}
		return nsSeqC;
	}


	public void setNsSeqC(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqC_Type nsSeqC)  {
		this.nsSeqC = nsSeqC;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqD_Type getNsSeqD()  {
		if (nsSeqD == null) {
			nsSeqD = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqD_Type();
		}
		return nsSeqD;
	}


	public void setNsSeqD(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqD_Type nsSeqD)  {
		this.nsSeqD = nsSeqD;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE_Type getNsSeqE()  {
		if (nsSeqE == null) {
			nsSeqE = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE_Type();
		}
		return nsSeqE;
	}


	public void setNsSeqE(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE_Type nsSeqE)  {
		this.nsSeqE = nsSeqE;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqF_Type[] getNsSeqF()  {
		if (nsSeqF == null) {
			//TODO: create/set default value here
		}
		return nsSeqF;
	}


	public void setNsSeqF(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqF_Type[] nsSeqF)  {
		this.nsSeqF = nsSeqF;
	}

}