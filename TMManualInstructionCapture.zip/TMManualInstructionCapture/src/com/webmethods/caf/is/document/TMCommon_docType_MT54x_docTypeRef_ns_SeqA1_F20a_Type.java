package com.webmethods.caf.is.document;

import java.io.Serializable;

/**
 * IS document wrapper
 */
public  class TMCommon_docType_MT54x_docTypeRef_ns_SeqA1_F20a_Type extends java.lang.Object implements Serializable {

	
	private static final long serialVersionUID = 1L;
	// IS Document type used to generate this class
	public static final String DOCUMENT_TYPE = "TMCommon.docType.MT54x:docTypeRef_ns_SeqA1_F20a_Type";
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqA1_F20a_POOL_Type nsPOOL = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqA1_F20a_PREA_Type nsPREA = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqA1_F20a_PREV_Type nsPREV = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqA1_F20a_RELA_Type nsRELA = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqA1_F20a_TRRF_Type nsTRRF = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqA1_F20a_COMM_Type nsCOMM = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqA1_F20a_COLR_Type nsCOLR = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqA1_F20a_CERT_Type nsCERT = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqA1_F20a_CORP_Type nsCORP = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqA1_F20a_CLCI_Type nsCLCI = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqA1_F20a_CLTR_Type nsCLTR = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqA1_F20a_PCTI_Type nsPCTI = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqA1_F20a_TRCI_Type nsTRCI = null;
	public static String[][] FIELD_NAMES = new String[][] {{"nsPOOL", "ns:POOL"},{"nsPREA", "ns:PREA"},{"nsPREV", "ns:PREV"},{"nsRELA", "ns:RELA"},{"nsTRRF", "ns:TRRF"},{"nsCOMM", "ns:COMM"},{"nsCOLR", "ns:COLR"},{"nsCERT", "ns:CERT"},{"nsCORP", "ns:CORP"},{"nsCLCI", "ns:CLCI"},{"nsCLTR", "ns:CLTR"},{"nsPCTI", "ns:PCTI"},{"nsTRCI", "ns:TRCI"},{"nsTCTR", "ns:TCTR"},
	};
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqA1_F20a_TCTR_Type nsTCTR = null;
	

	public TMCommon_docType_MT54x_docTypeRef_ns_SeqA1_F20a_Type() {
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqA1_F20a_POOL_Type getNsPOOL()  {
		if (nsPOOL == null) {
			nsPOOL = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqA1_F20a_POOL_Type();
		}
		return nsPOOL;
	}


	public void setNsPOOL(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqA1_F20a_POOL_Type nsPOOL)  {
		this.nsPOOL = nsPOOL;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqA1_F20a_PREA_Type getNsPREA()  {
		if (nsPREA == null) {
			nsPREA = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqA1_F20a_PREA_Type();
		}
		return nsPREA;
	}


	public void setNsPREA(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqA1_F20a_PREA_Type nsPREA)  {
		this.nsPREA = nsPREA;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqA1_F20a_PREV_Type getNsPREV()  {
		if (nsPREV == null) {
			nsPREV = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqA1_F20a_PREV_Type();
		}
		return nsPREV;
	}


	public void setNsPREV(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqA1_F20a_PREV_Type nsPREV)  {
		this.nsPREV = nsPREV;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqA1_F20a_RELA_Type getNsRELA()  {
		if (nsRELA == null) {
			nsRELA = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqA1_F20a_RELA_Type();
		}
		return nsRELA;
	}


	public void setNsRELA(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqA1_F20a_RELA_Type nsRELA)  {
		this.nsRELA = nsRELA;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqA1_F20a_TRRF_Type getNsTRRF()  {
		if (nsTRRF == null) {
			nsTRRF = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqA1_F20a_TRRF_Type();
		}
		return nsTRRF;
	}


	public void setNsTRRF(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqA1_F20a_TRRF_Type nsTRRF)  {
		this.nsTRRF = nsTRRF;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqA1_F20a_COMM_Type getNsCOMM()  {
		if (nsCOMM == null) {
			nsCOMM = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqA1_F20a_COMM_Type();
		}
		return nsCOMM;
	}


	public void setNsCOMM(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqA1_F20a_COMM_Type nsCOMM)  {
		this.nsCOMM = nsCOMM;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqA1_F20a_COLR_Type getNsCOLR()  {
		if (nsCOLR == null) {
			nsCOLR = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqA1_F20a_COLR_Type();
		}
		return nsCOLR;
	}


	public void setNsCOLR(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqA1_F20a_COLR_Type nsCOLR)  {
		this.nsCOLR = nsCOLR;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqA1_F20a_CERT_Type getNsCERT()  {
		if (nsCERT == null) {
			nsCERT = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqA1_F20a_CERT_Type();
		}
		return nsCERT;
	}


	public void setNsCERT(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqA1_F20a_CERT_Type nsCERT)  {
		this.nsCERT = nsCERT;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqA1_F20a_CORP_Type getNsCORP()  {
		if (nsCORP == null) {
			nsCORP = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqA1_F20a_CORP_Type();
		}
		return nsCORP;
	}


	public void setNsCORP(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqA1_F20a_CORP_Type nsCORP)  {
		this.nsCORP = nsCORP;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqA1_F20a_CLCI_Type getNsCLCI()  {
		if (nsCLCI == null) {
			nsCLCI = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqA1_F20a_CLCI_Type();
		}
		return nsCLCI;
	}


	public void setNsCLCI(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqA1_F20a_CLCI_Type nsCLCI)  {
		this.nsCLCI = nsCLCI;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqA1_F20a_CLTR_Type getNsCLTR()  {
		if (nsCLTR == null) {
			nsCLTR = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqA1_F20a_CLTR_Type();
		}
		return nsCLTR;
	}


	public void setNsCLTR(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqA1_F20a_CLTR_Type nsCLTR)  {
		this.nsCLTR = nsCLTR;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqA1_F20a_PCTI_Type getNsPCTI()  {
		if (nsPCTI == null) {
			nsPCTI = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqA1_F20a_PCTI_Type();
		}
		return nsPCTI;
	}


	public void setNsPCTI(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqA1_F20a_PCTI_Type nsPCTI)  {
		this.nsPCTI = nsPCTI;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqA1_F20a_TRCI_Type getNsTRCI()  {
		if (nsTRCI == null) {
			nsTRCI = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqA1_F20a_TRCI_Type();
		}
		return nsTRCI;
	}


	public void setNsTRCI(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqA1_F20a_TRCI_Type nsTRCI)  {
		this.nsTRCI = nsTRCI;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqA1_F20a_TCTR_Type getNsTCTR()  {
		if (nsTCTR == null) {
			nsTCTR = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqA1_F20a_TCTR_Type();
		}
		return nsTCTR;
	}


	public void setNsTCTR(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqA1_F20a_TCTR_Type nsTCTR)  {
		this.nsTCTR = nsTCTR;
	}

}