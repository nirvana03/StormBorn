package com.webmethods.caf.is.document;

import java.io.Serializable;

/**
 * IS document wrapper
 */
public  class TMCommon_docType_MT54x_docTypeRef_ns_SeqA1_F36a_Type extends java.lang.Object implements Serializable {

	
	private static final long serialVersionUID = 1L;
	// IS Document type used to generate this class
	public static final String DOCUMENT_TYPE = "TMCommon.docType.MT54x:docTypeRef_ns_SeqA1_F36a_Type";
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqA1_F36a_PAIR_Type nsPAIR = null;
	public static String[][] FIELD_NAMES = new String[][] {{"nsPAIR", "ns:PAIR"},{"nsTURN", "ns:TURN"},
	};
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqA1_F36a_TURN_Type nsTURN = null;
	

	public TMCommon_docType_MT54x_docTypeRef_ns_SeqA1_F36a_Type() {
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqA1_F36a_PAIR_Type getNsPAIR()  {
		if (nsPAIR == null) {
			nsPAIR = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqA1_F36a_PAIR_Type();
		}
		return nsPAIR;
	}


	public void setNsPAIR(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqA1_F36a_PAIR_Type nsPAIR)  {
		this.nsPAIR = nsPAIR;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqA1_F36a_TURN_Type getNsTURN()  {
		if (nsTURN == null) {
			nsTURN = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqA1_F36a_TURN_Type();
		}
		return nsTURN;
	}


	public void setNsTURN(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqA1_F36a_TURN_Type nsTURN)  {
		this.nsTURN = nsTURN;
	}

}