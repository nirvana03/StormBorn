package com.webmethods.caf.is.document;

import java.io.Serializable;

/**
 * IS document wrapper
 */
public  class TMCommon_docType_MT54x_docTypeRef_ns_SeqA_F20a_SEME_Type extends java.lang.Object implements Serializable {

	
	private static final long serialVersionUID = 1L;
	// IS Document type used to generate this class
	public static final String DOCUMENT_TYPE = "TMCommon.docType.MT54x:docTypeRef_ns_SeqA_F20a_SEME_Type";
	public static String[][] FIELD_NAMES = new String[][] {{"nsF20C", "ns:F20C"},
	};
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F20C_Type nsF20C = null;
	

	public TMCommon_docType_MT54x_docTypeRef_ns_SeqA_F20a_SEME_Type() {
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F20C_Type getNsF20C()  {
		if (nsF20C == null) {
			nsF20C = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F20C_Type();
		}
		return nsF20C;
	}


	public void setNsF20C(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F20C_Type nsF20C)  {
		this.nsF20C = nsF20C;
	}

}