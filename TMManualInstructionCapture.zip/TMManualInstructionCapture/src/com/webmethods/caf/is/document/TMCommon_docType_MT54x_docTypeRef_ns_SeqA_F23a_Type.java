package com.webmethods.caf.is.document;

import java.io.Serializable;

/**
 * IS document wrapper
 */
public  class TMCommon_docType_MT54x_docTypeRef_ns_SeqA_F23a_Type extends java.lang.Object implements Serializable {

	
	private static final long serialVersionUID = 1L;
	// IS Document type used to generate this class
	public static final String DOCUMENT_TYPE = "TMCommon.docType.MT54x:docTypeRef_ns_SeqA_F23a_Type";
	public static String[][] FIELD_NAMES = new String[][] {{"nsF23G", "ns:F23G"},
	};
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F23G_72_Type nsF23G = null;
	

	public TMCommon_docType_MT54x_docTypeRef_ns_SeqA_F23a_Type() {
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F23G_72_Type getNsF23G()  {
		if (nsF23G == null) {
			nsF23G = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F23G_72_Type();
		}
		return nsF23G;
	}


	public void setNsF23G(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F23G_72_Type nsF23G)  {
		this.nsF23G = nsF23G;
	}

}