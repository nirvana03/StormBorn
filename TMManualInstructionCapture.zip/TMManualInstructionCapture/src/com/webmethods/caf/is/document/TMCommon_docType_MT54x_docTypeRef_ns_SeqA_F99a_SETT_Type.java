package com.webmethods.caf.is.document;

import java.io.Serializable;

/**
 * IS document wrapper
 */
public  class TMCommon_docType_MT54x_docTypeRef_ns_SeqA_F99a_SETT_Type extends java.lang.Object implements Serializable {

	
	private static final long serialVersionUID = 1L;
	// IS Document type used to generate this class
	public static final String DOCUMENT_TYPE = "TMCommon.docType.MT54x:docTypeRef_ns_SeqA_F99a_SETT_Type";
	public static String[][] FIELD_NAMES = new String[][] {{"nsF99B", "ns:F99B"},
	};
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F99B_1_Type nsF99B = null;
	

	public TMCommon_docType_MT54x_docTypeRef_ns_SeqA_F99a_SETT_Type() {
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F99B_1_Type getNsF99B()  {
		if (nsF99B == null) {
			nsF99B = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F99B_1_Type();
		}
		return nsF99B;
	}


	public void setNsF99B(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F99B_1_Type nsF99B)  {
		this.nsF99B = nsF99B;
	}

}