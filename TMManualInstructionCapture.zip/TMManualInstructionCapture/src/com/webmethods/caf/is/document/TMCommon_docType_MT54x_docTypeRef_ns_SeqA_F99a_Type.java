package com.webmethods.caf.is.document;

import java.io.Serializable;

/**
 * IS document wrapper
 */
public  class TMCommon_docType_MT54x_docTypeRef_ns_SeqA_F99a_Type extends java.lang.Object implements Serializable {

	
	private static final long serialVersionUID = 1L;
	// IS Document type used to generate this class
	public static final String DOCUMENT_TYPE = "TMCommon.docType.MT54x:docTypeRef_ns_SeqA_F99a_Type";
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqA_F99a_SETT_Type nsSETT = null;
	public static String[][] FIELD_NAMES = new String[][] {{"nsSETT", "ns:SETT"},{"nsTOSE", "ns:TOSE"},
	};
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqA_F99a_TOSE_Type nsTOSE = null;
	

	public TMCommon_docType_MT54x_docTypeRef_ns_SeqA_F99a_Type() {
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqA_F99a_SETT_Type getNsSETT()  {
		if (nsSETT == null) {
			nsSETT = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqA_F99a_SETT_Type();
		}
		return nsSETT;
	}


	public void setNsSETT(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqA_F99a_SETT_Type nsSETT)  {
		this.nsSETT = nsSETT;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqA_F99a_TOSE_Type getNsTOSE()  {
		if (nsTOSE == null) {
			nsTOSE = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqA_F99a_TOSE_Type();
		}
		return nsTOSE;
	}


	public void setNsTOSE(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqA_F99a_TOSE_Type nsTOSE)  {
		this.nsTOSE = nsTOSE;
	}

}