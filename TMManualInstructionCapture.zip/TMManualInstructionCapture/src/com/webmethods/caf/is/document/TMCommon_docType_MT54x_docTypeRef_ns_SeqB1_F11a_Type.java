package com.webmethods.caf.is.document;

import java.io.Serializable;

/**
 * IS document wrapper
 */
public  class TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F11a_Type extends java.lang.Object implements Serializable {

	
	private static final long serialVersionUID = 1L;
	// IS Document type used to generate this class
	public static final String DOCUMENT_TYPE = "TMCommon.docType.MT54x:docTypeRef_ns_SeqB1_F11a_Type";
	public static String[][] FIELD_NAMES = new String[][] {{"nsDENO", "ns:DENO"},
	};
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F11a_DENO_Type nsDENO = null;
	

	public TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F11a_Type() {
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F11a_DENO_Type getNsDENO()  {
		if (nsDENO == null) {
			nsDENO = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F11a_DENO_Type();
		}
		return nsDENO;
	}


	public void setNsDENO(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F11a_DENO_Type nsDENO)  {
		this.nsDENO = nsDENO;
	}

}