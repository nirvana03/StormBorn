package com.webmethods.caf.is.document;

import java.io.Serializable;

/**
 * IS document wrapper
 */
public  class TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F12a_CLAS_Type extends java.lang.Object implements Serializable {

	
	private static final long serialVersionUID = 1L;
	// IS Document type used to generate this class
	public static final String DOCUMENT_TYPE = "TMCommon.docType.MT54x:docTypeRef_ns_SeqB1_F12a_CLAS_Type";
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F12A_Type nsF12A = null;
	public static String[][] FIELD_NAMES = new String[][] {{"nsF12A", "ns:F12A"},{"nsF12C", "ns:F12C"},
	};
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F12C_Type nsF12C = null;
	

	public TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F12a_CLAS_Type() {
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F12A_Type getNsF12A()  {
		if (nsF12A == null) {
			nsF12A = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F12A_Type();
		}
		return nsF12A;
	}


	public void setNsF12A(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F12A_Type nsF12A)  {
		this.nsF12A = nsF12A;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F12C_Type getNsF12C()  {
		if (nsF12C == null) {
			nsF12C = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F12C_Type();
		}
		return nsF12C;
	}


	public void setNsF12C(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F12C_Type nsF12C)  {
		this.nsF12C = nsF12C;
	}

}