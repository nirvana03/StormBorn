package com.webmethods.caf.is.document;

import java.io.Serializable;

/**
 * IS document wrapper
 */
public  class TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F12a_OPST_Type extends java.lang.Object implements Serializable {

	
	private static final long serialVersionUID = 1L;
	// IS Document type used to generate this class
	public static final String DOCUMENT_TYPE = "TMCommon.docType.MT54x:docTypeRef_ns_SeqB1_F12a_OPST_Type";
	public static String[][] FIELD_NAMES = new String[][] {{"nsF12B", "ns:F12B"},
	};
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F12B_7_Type nsF12B = null;
	

	public TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F12a_OPST_Type() {
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F12B_7_Type getNsF12B()  {
		if (nsF12B == null) {
			nsF12B = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F12B_7_Type();
		}
		return nsF12B;
	}


	public void setNsF12B(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F12B_7_Type nsF12B)  {
		this.nsF12B = nsF12B;
	}

}