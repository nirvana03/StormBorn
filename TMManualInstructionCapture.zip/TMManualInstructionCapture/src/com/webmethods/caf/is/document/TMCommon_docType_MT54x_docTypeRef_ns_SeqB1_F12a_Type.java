package com.webmethods.caf.is.document;

import java.io.Serializable;

/**
 * IS document wrapper
 */
public  class TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F12a_Type extends java.lang.Object implements Serializable {

	
	private static final long serialVersionUID = 1L;
	// IS Document type used to generate this class
	public static final String DOCUMENT_TYPE = "TMCommon.docType.MT54x:docTypeRef_ns_SeqB1_F12a_Type";
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F12a_CLAS_Type nsCLAS = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F12a_OPST_Type nsOPST = null;
	public static String[][] FIELD_NAMES = new String[][] {{"nsCLAS", "ns:CLAS"},{"nsOPST", "ns:OPST"},{"nsOPTI", "ns:OPTI"},
	};
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F12a_OPTI_Type nsOPTI = null;
	

	public TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F12a_Type() {
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F12a_CLAS_Type getNsCLAS()  {
		if (nsCLAS == null) {
			nsCLAS = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F12a_CLAS_Type();
		}
		return nsCLAS;
	}


	public void setNsCLAS(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F12a_CLAS_Type nsCLAS)  {
		this.nsCLAS = nsCLAS;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F12a_OPST_Type getNsOPST()  {
		if (nsOPST == null) {
			nsOPST = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F12a_OPST_Type();
		}
		return nsOPST;
	}


	public void setNsOPST(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F12a_OPST_Type nsOPST)  {
		this.nsOPST = nsOPST;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F12a_OPTI_Type getNsOPTI()  {
		if (nsOPTI == null) {
			nsOPTI = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F12a_OPTI_Type();
		}
		return nsOPTI;
	}


	public void setNsOPTI(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F12a_OPTI_Type nsOPTI)  {
		this.nsOPTI = nsOPTI;
	}

}