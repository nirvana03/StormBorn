package com.webmethods.caf.is.document;

import java.io.Serializable;

/**
 * IS document wrapper
 */
public  class TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F13a_COUP_Type extends java.lang.Object implements Serializable {

	
	private static final long serialVersionUID = 1L;
	// IS Document type used to generate this class
	public static final String DOCUMENT_TYPE = "TMCommon.docType.MT54x:docTypeRef_ns_SeqB1_F13a_COUP_Type";
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F13A_Type nsF13A = null;
	public static String[][] FIELD_NAMES = new String[][] {{"nsF13A", "ns:F13A"},{"nsF13B", "ns:F13B"},
	};
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F13B_Type nsF13B = null;
	

	public TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F13a_COUP_Type() {
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F13A_Type getNsF13A()  {
		if (nsF13A == null) {
			nsF13A = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F13A_Type();
		}
		return nsF13A;
	}


	public void setNsF13A(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F13A_Type nsF13A)  {
		this.nsF13A = nsF13A;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F13B_Type getNsF13B()  {
		if (nsF13B == null) {
			nsF13B = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F13B_Type();
		}
		return nsF13B;
	}


	public void setNsF13B(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F13B_Type nsF13B)  {
		this.nsF13B = nsF13B;
	}

}