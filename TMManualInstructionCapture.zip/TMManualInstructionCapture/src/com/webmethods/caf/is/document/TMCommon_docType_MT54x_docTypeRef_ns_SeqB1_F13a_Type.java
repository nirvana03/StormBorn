package com.webmethods.caf.is.document;

import java.io.Serializable;

/**
 * IS document wrapper
 */
public  class TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F13a_Type extends java.lang.Object implements Serializable {

	
	private static final long serialVersionUID = 1L;
	// IS Document type used to generate this class
	public static final String DOCUMENT_TYPE = "TMCommon.docType.MT54x:docTypeRef_ns_SeqB1_F13a_Type";
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F13a_COUP_Type nsCOUP = null;
	public static String[][] FIELD_NAMES = new String[][] {{"nsCOUP", "ns:COUP"},{"nsPOOL", "ns:POOL"},
	};
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F13a_POOL_Type nsPOOL = null;
	

	public TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F13a_Type() {
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F13a_COUP_Type getNsCOUP()  {
		if (nsCOUP == null) {
			nsCOUP = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F13a_COUP_Type();
		}
		return nsCOUP;
	}


	public void setNsCOUP(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F13a_COUP_Type nsCOUP)  {
		this.nsCOUP = nsCOUP;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F13a_POOL_Type getNsPOOL()  {
		if (nsPOOL == null) {
			nsPOOL = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F13a_POOL_Type();
		}
		return nsPOOL;
	}


	public void setNsPOOL(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F13a_POOL_Type nsPOOL)  {
		this.nsPOOL = nsPOOL;
	}

}