package com.webmethods.caf.is.document;

import java.io.Serializable;

/**
 * IS document wrapper
 */
public  class TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F17a_Type extends java.lang.Object implements Serializable {

	
	private static final long serialVersionUID = 1L;
	// IS Document type used to generate this class
	public static final String DOCUMENT_TYPE = "TMCommon.docType.MT54x:docTypeRef_ns_SeqB1_F17a_Type";
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F17a_FRNF_Type nsFRNF = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F17a_CALL_Type nsCALL = null;
	public static String[][] FIELD_NAMES = new String[][] {{"nsFRNF", "ns:FRNF"},{"nsCALL", "ns:CALL"},{"nsPUTT", "ns:PUTT"},
	};
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F17a_PUTT_Type nsPUTT = null;
	

	public TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F17a_Type() {
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F17a_FRNF_Type getNsFRNF()  {
		if (nsFRNF == null) {
			nsFRNF = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F17a_FRNF_Type();
		}
		return nsFRNF;
	}


	public void setNsFRNF(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F17a_FRNF_Type nsFRNF)  {
		this.nsFRNF = nsFRNF;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F17a_CALL_Type getNsCALL()  {
		if (nsCALL == null) {
			nsCALL = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F17a_CALL_Type();
		}
		return nsCALL;
	}


	public void setNsCALL(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F17a_CALL_Type nsCALL)  {
		this.nsCALL = nsCALL;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F17a_PUTT_Type getNsPUTT()  {
		if (nsPUTT == null) {
			nsPUTT = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F17a_PUTT_Type();
		}
		return nsPUTT;
	}


	public void setNsPUTT(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F17a_PUTT_Type nsPUTT)  {
		this.nsPUTT = nsPUTT;
	}

}