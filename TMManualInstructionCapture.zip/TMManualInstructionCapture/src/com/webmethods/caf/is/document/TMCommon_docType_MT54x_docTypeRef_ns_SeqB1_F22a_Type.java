package com.webmethods.caf.is.document;

import java.io.Serializable;

/**
 * IS document wrapper
 */
public  class TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F22a_Type extends java.lang.Object implements Serializable {

	
	private static final long serialVersionUID = 1L;
	// IS Document type used to generate this class
	public static final String DOCUMENT_TYPE = "TMCommon.docType.MT54x:docTypeRef_ns_SeqB1_F22a_Type";
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F22a_MICO_Type nsMICO = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F22a_FORM_Type nsFORM = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F22a_PFRE_Type nsPFRE = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F22a_PAYS_Type nsPAYS = null;
	public static String[][] FIELD_NAMES = new String[][] {{"nsMICO", "ns:MICO"},{"nsFORM", "ns:FORM"},{"nsPFRE", "ns:PFRE"},{"nsPAYS", "ns:PAYS"},{"nsCFRE", "ns:CFRE"},
	};
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F22a_CFRE_Type nsCFRE = null;
	

	public TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F22a_Type() {
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F22a_MICO_Type getNsMICO()  {
		if (nsMICO == null) {
			nsMICO = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F22a_MICO_Type();
		}
		return nsMICO;
	}


	public void setNsMICO(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F22a_MICO_Type nsMICO)  {
		this.nsMICO = nsMICO;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F22a_FORM_Type getNsFORM()  {
		if (nsFORM == null) {
			nsFORM = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F22a_FORM_Type();
		}
		return nsFORM;
	}


	public void setNsFORM(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F22a_FORM_Type nsFORM)  {
		this.nsFORM = nsFORM;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F22a_PFRE_Type getNsPFRE()  {
		if (nsPFRE == null) {
			nsPFRE = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F22a_PFRE_Type();
		}
		return nsPFRE;
	}


	public void setNsPFRE(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F22a_PFRE_Type nsPFRE)  {
		this.nsPFRE = nsPFRE;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F22a_PAYS_Type getNsPAYS()  {
		if (nsPAYS == null) {
			nsPAYS = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F22a_PAYS_Type();
		}
		return nsPAYS;
	}


	public void setNsPAYS(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F22a_PAYS_Type nsPAYS)  {
		this.nsPAYS = nsPAYS;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F22a_CFRE_Type getNsCFRE()  {
		if (nsCFRE == null) {
			nsCFRE = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F22a_CFRE_Type();
		}
		return nsCFRE;
	}


	public void setNsCFRE(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F22a_CFRE_Type nsCFRE)  {
		this.nsCFRE = nsCFRE;
	}

}