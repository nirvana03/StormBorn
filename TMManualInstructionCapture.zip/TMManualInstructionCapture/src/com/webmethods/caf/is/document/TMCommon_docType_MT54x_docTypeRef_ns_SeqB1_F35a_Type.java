package com.webmethods.caf.is.document;

import java.io.Serializable;

/**
 * IS document wrapper
 */
public  class TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F35a_Type extends java.lang.Object implements Serializable {

	
	private static final long serialVersionUID = 1L;
	// IS Document type used to generate this class
	public static final String DOCUMENT_TYPE = "TMCommon.docType.MT54x:docTypeRef_ns_SeqB1_F35a_Type";
	public static String[][] FIELD_NAMES = new String[][] {{"nsF35B", "ns:F35B"},
	};
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F35B_Type nsF35B = null;
	

	public TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F35a_Type() {
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F35B_Type getNsF35B()  {
		if (nsF35B == null) {
			nsF35B = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F35B_Type();
		}
		return nsF35B;
	}


	public void setNsF35B(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F35B_Type nsF35B)  {
		this.nsF35B = nsF35B;
	}

}