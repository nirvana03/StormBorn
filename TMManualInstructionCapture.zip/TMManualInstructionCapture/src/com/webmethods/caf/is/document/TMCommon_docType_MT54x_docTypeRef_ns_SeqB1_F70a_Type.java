package com.webmethods.caf.is.document;

import java.io.Serializable;

/**
 * IS document wrapper
 */
public  class TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F70a_Type extends java.lang.Object implements Serializable {

	
	private static final long serialVersionUID = 1L;
	// IS Document type used to generate this class
	public static final String DOCUMENT_TYPE = "TMCommon.docType.MT54x:docTypeRef_ns_SeqB1_F70a_Type";
	public static String[][] FIELD_NAMES = new String[][] {{"nsFIAN", "ns:FIAN"},
	};
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F70a_FIAN_Type nsFIAN = null;
	

	public TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F70a_Type() {
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F70a_FIAN_Type getNsFIAN()  {
		if (nsFIAN == null) {
			nsFIAN = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F70a_FIAN_Type();
		}
		return nsFIAN;
	}


	public void setNsFIAN(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F70a_FIAN_Type nsFIAN)  {
		this.nsFIAN = nsFIAN;
	}

}