package com.webmethods.caf.is.document;

import java.io.Serializable;

/**
 * IS document wrapper
 */
public  class TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F90a_Type extends java.lang.Object implements Serializable {

	
	private static final long serialVersionUID = 1L;
	// IS Document type used to generate this class
	public static final String DOCUMENT_TYPE = "TMCommon.docType.MT54x:docTypeRef_ns_SeqB1_F90a_Type";
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F90a_INDC_Type nsINDC = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F90a_MRKT_Type nsMRKT = null;
	public static String[][] FIELD_NAMES = new String[][] {{"nsINDC", "ns:INDC"},{"nsMRKT", "ns:MRKT"},{"nsEXER", "ns:EXER"},
	};
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F90a_EXER_Type nsEXER = null;
	

	public TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F90a_Type() {
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F90a_INDC_Type getNsINDC()  {
		if (nsINDC == null) {
			nsINDC = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F90a_INDC_Type();
		}
		return nsINDC;
	}


	public void setNsINDC(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F90a_INDC_Type nsINDC)  {
		this.nsINDC = nsINDC;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F90a_MRKT_Type getNsMRKT()  {
		if (nsMRKT == null) {
			nsMRKT = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F90a_MRKT_Type();
		}
		return nsMRKT;
	}


	public void setNsMRKT(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F90a_MRKT_Type nsMRKT)  {
		this.nsMRKT = nsMRKT;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F90a_EXER_Type getNsEXER()  {
		if (nsEXER == null) {
			nsEXER = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F90a_EXER_Type();
		}
		return nsEXER;
	}


	public void setNsEXER(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F90a_EXER_Type nsEXER)  {
		this.nsEXER = nsEXER;
	}

}