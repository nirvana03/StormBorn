package com.webmethods.caf.is.document;

import java.io.Serializable;

/**
 * IS document wrapper
 */
public  class TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F92a_Type extends java.lang.Object implements Serializable {

	
	private static final long serialVersionUID = 1L;
	// IS Document type used to generate this class
	public static final String DOCUMENT_TYPE = "TMCommon.docType.MT54x:docTypeRef_ns_SeqB1_F92a_Type";
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F92a_PRFC_Type nsPRFC = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F92a_CUFC_Type nsCUFC = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F92a_NWFC_Type nsNWFC = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F92a_INTR_Type nsINTR = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F92a_NXRT_Type nsNXRT = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F92a_INDX_Type nsINDX = null;
	public static String[][] FIELD_NAMES = new String[][] {{"nsPRFC", "ns:PRFC"},{"nsCUFC", "ns:CUFC"},{"nsNWFC", "ns:NWFC"},{"nsINTR", "ns:INTR"},{"nsNXRT", "ns:NXRT"},{"nsINDX", "ns:INDX"},{"nsYTMR", "ns:YTMR"},
	};
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F92a_YTMR_Type nsYTMR = null;
	

	public TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F92a_Type() {
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F92a_PRFC_Type getNsPRFC()  {
		if (nsPRFC == null) {
			nsPRFC = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F92a_PRFC_Type();
		}
		return nsPRFC;
	}


	public void setNsPRFC(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F92a_PRFC_Type nsPRFC)  {
		this.nsPRFC = nsPRFC;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F92a_CUFC_Type getNsCUFC()  {
		if (nsCUFC == null) {
			nsCUFC = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F92a_CUFC_Type();
		}
		return nsCUFC;
	}


	public void setNsCUFC(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F92a_CUFC_Type nsCUFC)  {
		this.nsCUFC = nsCUFC;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F92a_NWFC_Type getNsNWFC()  {
		if (nsNWFC == null) {
			nsNWFC = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F92a_NWFC_Type();
		}
		return nsNWFC;
	}


	public void setNsNWFC(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F92a_NWFC_Type nsNWFC)  {
		this.nsNWFC = nsNWFC;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F92a_INTR_Type getNsINTR()  {
		if (nsINTR == null) {
			nsINTR = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F92a_INTR_Type();
		}
		return nsINTR;
	}


	public void setNsINTR(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F92a_INTR_Type nsINTR)  {
		this.nsINTR = nsINTR;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F92a_NXRT_Type getNsNXRT()  {
		if (nsNXRT == null) {
			nsNXRT = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F92a_NXRT_Type();
		}
		return nsNXRT;
	}


	public void setNsNXRT(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F92a_NXRT_Type nsNXRT)  {
		this.nsNXRT = nsNXRT;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F92a_INDX_Type getNsINDX()  {
		if (nsINDX == null) {
			nsINDX = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F92a_INDX_Type();
		}
		return nsINDX;
	}


	public void setNsINDX(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F92a_INDX_Type nsINDX)  {
		this.nsINDX = nsINDX;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F92a_YTMR_Type getNsYTMR()  {
		if (nsYTMR == null) {
			nsYTMR = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F92a_YTMR_Type();
		}
		return nsYTMR;
	}


	public void setNsYTMR(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F92a_YTMR_Type nsYTMR)  {
		this.nsYTMR = nsYTMR;
	}

}