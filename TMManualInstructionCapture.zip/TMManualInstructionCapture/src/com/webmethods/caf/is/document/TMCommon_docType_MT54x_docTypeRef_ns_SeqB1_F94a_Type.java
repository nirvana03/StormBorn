package com.webmethods.caf.is.document;

import java.io.Serializable;

/**
 * IS document wrapper
 */
public  class TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F94a_Type extends java.lang.Object implements Serializable {

	
	private static final long serialVersionUID = 1L;
	// IS Document type used to generate this class
	public static final String DOCUMENT_TYPE = "TMCommon.docType.MT54x:docTypeRef_ns_SeqB1_F94a_Type";
	public static String[][] FIELD_NAMES = new String[][] {{"nsPLIS", "ns:PLIS"},
	};
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F94a_PLIS_Type nsPLIS = null;
	

	public TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F94a_Type() {
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F94a_PLIS_Type getNsPLIS()  {
		if (nsPLIS == null) {
			nsPLIS = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F94a_PLIS_Type();
		}
		return nsPLIS;
	}


	public void setNsPLIS(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F94a_PLIS_Type nsPLIS)  {
		this.nsPLIS = nsPLIS;
	}

}