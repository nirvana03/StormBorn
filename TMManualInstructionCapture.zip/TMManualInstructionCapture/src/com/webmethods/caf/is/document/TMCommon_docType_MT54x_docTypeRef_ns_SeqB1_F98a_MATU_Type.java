package com.webmethods.caf.is.document;

import java.io.Serializable;

/**
 * IS document wrapper
 */
public  class TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F98a_MATU_Type extends java.lang.Object implements Serializable {

	
	private static final long serialVersionUID = 1L;
	// IS Document type used to generate this class
	public static final String DOCUMENT_TYPE = "TMCommon.docType.MT54x:docTypeRef_ns_SeqB1_F98a_MATU_Type";
	public static String[][] FIELD_NAMES = new String[][] {{"nsF98A", "ns:F98A"},
	};
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F98A_Type nsF98A = null;
	

	public TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F98a_MATU_Type() {
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F98A_Type getNsF98A()  {
		if (nsF98A == null) {
			nsF98A = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F98A_Type();
		}
		return nsF98A;
	}


	public void setNsF98A(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F98A_Type nsF98A)  {
		this.nsF98A = nsF98A;
	}

}