package com.webmethods.caf.is.document;

import java.io.Serializable;

/**
 * IS document wrapper
 */
public  class TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F98a_Type extends java.lang.Object implements Serializable {

	
	private static final long serialVersionUID = 1L;
	// IS Document type used to generate this class
	public static final String DOCUMENT_TYPE = "TMCommon.docType.MT54x:docTypeRef_ns_SeqB1_F98a_Type";
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F98a_COUP_Type nsCOUP = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F98a_EXPI_Type nsEXPI = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F98a_FRNR_Type nsFRNR = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F98a_MATU_Type nsMATU = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F98a_ISSU_Type nsISSU = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F98a_CALD_Type nsCALD = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F98a_PUTT_Type nsPUTT = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F98a_DDTE_Type nsDDTE = null;
	public static String[][] FIELD_NAMES = new String[][] {{"nsCOUP", "ns:COUP"},{"nsEXPI", "ns:EXPI"},{"nsFRNR", "ns:FRNR"},{"nsMATU", "ns:MATU"},{"nsISSU", "ns:ISSU"},{"nsCALD", "ns:CALD"},{"nsPUTT", "ns:PUTT"},{"nsDDTE", "ns:DDTE"},{"nsFCOU", "ns:FCOU"},
	};
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F98a_FCOU_Type nsFCOU = null;
	

	public TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F98a_Type() {
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F98a_COUP_Type getNsCOUP()  {
		if (nsCOUP == null) {
			nsCOUP = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F98a_COUP_Type();
		}
		return nsCOUP;
	}


	public void setNsCOUP(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F98a_COUP_Type nsCOUP)  {
		this.nsCOUP = nsCOUP;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F98a_EXPI_Type getNsEXPI()  {
		if (nsEXPI == null) {
			nsEXPI = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F98a_EXPI_Type();
		}
		return nsEXPI;
	}


	public void setNsEXPI(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F98a_EXPI_Type nsEXPI)  {
		this.nsEXPI = nsEXPI;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F98a_FRNR_Type getNsFRNR()  {
		if (nsFRNR == null) {
			nsFRNR = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F98a_FRNR_Type();
		}
		return nsFRNR;
	}


	public void setNsFRNR(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F98a_FRNR_Type nsFRNR)  {
		this.nsFRNR = nsFRNR;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F98a_MATU_Type getNsMATU()  {
		if (nsMATU == null) {
			nsMATU = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F98a_MATU_Type();
		}
		return nsMATU;
	}


	public void setNsMATU(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F98a_MATU_Type nsMATU)  {
		this.nsMATU = nsMATU;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F98a_ISSU_Type getNsISSU()  {
		if (nsISSU == null) {
			nsISSU = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F98a_ISSU_Type();
		}
		return nsISSU;
	}


	public void setNsISSU(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F98a_ISSU_Type nsISSU)  {
		this.nsISSU = nsISSU;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F98a_CALD_Type getNsCALD()  {
		if (nsCALD == null) {
			nsCALD = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F98a_CALD_Type();
		}
		return nsCALD;
	}


	public void setNsCALD(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F98a_CALD_Type nsCALD)  {
		this.nsCALD = nsCALD;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F98a_PUTT_Type getNsPUTT()  {
		if (nsPUTT == null) {
			nsPUTT = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F98a_PUTT_Type();
		}
		return nsPUTT;
	}


	public void setNsPUTT(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F98a_PUTT_Type nsPUTT)  {
		this.nsPUTT = nsPUTT;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F98a_DDTE_Type getNsDDTE()  {
		if (nsDDTE == null) {
			nsDDTE = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F98a_DDTE_Type();
		}
		return nsDDTE;
	}


	public void setNsDDTE(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F98a_DDTE_Type nsDDTE)  {
		this.nsDDTE = nsDDTE;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F98a_FCOU_Type getNsFCOU()  {
		if (nsFCOU == null) {
			nsFCOU = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F98a_FCOU_Type();
		}
		return nsFCOU;
	}


	public void setNsFCOU(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F98a_FCOU_Type nsFCOU)  {
		this.nsFCOU = nsFCOU;
	}

}