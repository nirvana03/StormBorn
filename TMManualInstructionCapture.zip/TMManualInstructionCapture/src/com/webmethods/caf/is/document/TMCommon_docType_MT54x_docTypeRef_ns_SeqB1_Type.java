package com.webmethods.caf.is.document;

import java.io.Serializable;

/**
 * IS document wrapper
 */
public  class TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_Type extends java.lang.Object implements Serializable {

	
	private static final long serialVersionUID = 1L;
	// IS Document type used to generate this class
	public static final String DOCUMENT_TYPE = "TMCommon.docType.MT54x:docTypeRef_ns_SeqB1_Type";
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F16a_1_Type nsF16a_1 = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F94a_Type nsF94a = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F22a_Type[] nsF22a = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F12a_Type[] nsF12a = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F11a_Type nsF11a = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F98a_Type[] nsF98a = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F92a_Type[] nsF92a = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F13a_Type[] nsF13a = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F17a_Type[] nsF17a = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F90a_Type[] nsF90a = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F36a_Type[] nsF36a = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F35a_Type[] nsF35a = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F70a_Type nsF70a = null;
	public static String[][] FIELD_NAMES = new String[][] {{"nsF16a_1", "ns:F16a_1"},{"nsF94a", "ns:F94a"},{"nsF22a", "ns:F22a"},{"nsF12a", "ns:F12a"},{"nsF11a", "ns:F11a"},{"nsF98a", "ns:F98a"},{"nsF92a", "ns:F92a"},{"nsF13a", "ns:F13a"},{"nsF17a", "ns:F17a"},{"nsF90a", "ns:F90a"},{"nsF36a", "ns:F36a"},{"nsF35a", "ns:F35a"},{"nsF70a", "ns:F70a"},{"nsF16a_2", "ns:F16a_2"},
	};
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F16a_2_Type nsF16a_2 = null;
	

	public TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_Type() {
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F16a_1_Type getNsF16a_1()  {
		if (nsF16a_1 == null) {
			nsF16a_1 = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F16a_1_Type();
		}
		return nsF16a_1;
	}


	public void setNsF16a_1(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F16a_1_Type nsF16a_1)  {
		this.nsF16a_1 = nsF16a_1;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F94a_Type getNsF94a()  {
		if (nsF94a == null) {
			nsF94a = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F94a_Type();
		}
		return nsF94a;
	}


	public void setNsF94a(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F94a_Type nsF94a)  {
		this.nsF94a = nsF94a;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F22a_Type[] getNsF22a()  {
		if (nsF22a == null) {
			//TODO: create/set default value here
		}
		return nsF22a;
	}


	public void setNsF22a(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F22a_Type[] nsF22a)  {
		this.nsF22a = nsF22a;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F12a_Type[] getNsF12a()  {
		if (nsF12a == null) {
			//TODO: create/set default value here
		}
		return nsF12a;
	}


	public void setNsF12a(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F12a_Type[] nsF12a)  {
		this.nsF12a = nsF12a;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F11a_Type getNsF11a()  {
		if (nsF11a == null) {
			nsF11a = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F11a_Type();
		}
		return nsF11a;
	}


	public void setNsF11a(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F11a_Type nsF11a)  {
		this.nsF11a = nsF11a;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F98a_Type[] getNsF98a()  {
		if (nsF98a == null) {
			//TODO: create/set default value here
		}
		return nsF98a;
	}


	public void setNsF98a(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F98a_Type[] nsF98a)  {
		this.nsF98a = nsF98a;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F92a_Type[] getNsF92a()  {
		if (nsF92a == null) {
			//TODO: create/set default value here
		}
		return nsF92a;
	}


	public void setNsF92a(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F92a_Type[] nsF92a)  {
		this.nsF92a = nsF92a;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F13a_Type[] getNsF13a()  {
		if (nsF13a == null) {
			//TODO: create/set default value here
		}
		return nsF13a;
	}


	public void setNsF13a(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F13a_Type[] nsF13a)  {
		this.nsF13a = nsF13a;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F17a_Type[] getNsF17a()  {
		if (nsF17a == null) {
			//TODO: create/set default value here
		}
		return nsF17a;
	}


	public void setNsF17a(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F17a_Type[] nsF17a)  {
		this.nsF17a = nsF17a;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F90a_Type[] getNsF90a()  {
		if (nsF90a == null) {
			//TODO: create/set default value here
		}
		return nsF90a;
	}


	public void setNsF90a(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F90a_Type[] nsF90a)  {
		this.nsF90a = nsF90a;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F36a_Type[] getNsF36a()  {
		if (nsF36a == null) {
			//TODO: create/set default value here
		}
		return nsF36a;
	}


	public void setNsF36a(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F36a_Type[] nsF36a)  {
		this.nsF36a = nsF36a;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F35a_Type[] getNsF35a()  {
		if (nsF35a == null) {
			//TODO: create/set default value here
		}
		return nsF35a;
	}


	public void setNsF35a(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F35a_Type[] nsF35a)  {
		this.nsF35a = nsF35a;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F70a_Type getNsF70a()  {
		if (nsF70a == null) {
			nsF70a = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F70a_Type();
		}
		return nsF70a;
	}


	public void setNsF70a(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F70a_Type nsF70a)  {
		this.nsF70a = nsF70a;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F16a_2_Type getNsF16a_2()  {
		if (nsF16a_2 == null) {
			nsF16a_2 = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F16a_2_Type();
		}
		return nsF16a_2;
	}


	public void setNsF16a_2(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_F16a_2_Type nsF16a_2)  {
		this.nsF16a_2 = nsF16a_2;
	}

}