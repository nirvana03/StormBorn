package com.webmethods.caf.is.document;

import java.io.Serializable;

/**
 * IS document wrapper
 */
public  class TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F11a_FXIB_Type extends java.lang.Object implements Serializable {

	
	private static final long serialVersionUID = 1L;
	// IS Document type used to generate this class
	public static final String DOCUMENT_TYPE = "TMCommon.docType.MT54x:docTypeRef_ns_SeqB_F11a_FXIB_Type";
	public static String[][] FIELD_NAMES = new String[][] {{"nsF11A", "ns:F11A"},
	};
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F11A_Type nsF11A = null;
	

	public TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F11a_FXIB_Type() {
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F11A_Type getNsF11A()  {
		if (nsF11A == null) {
			nsF11A = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F11A_Type();
		}
		return nsF11A;
	}


	public void setNsF11A(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F11A_Type nsF11A)  {
		this.nsF11A = nsF11A;
	}

}