package com.webmethods.caf.is.document;

import java.io.Serializable;

/**
 * IS document wrapper
 */
public  class TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F11a_Type extends java.lang.Object implements Serializable {

	
	private static final long serialVersionUID = 1L;
	// IS Document type used to generate this class
	public static final String DOCUMENT_TYPE = "TMCommon.docType.MT54x:docTypeRef_ns_SeqB_F11a_Type";
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F11a_FXIS_Type nsFXIS = null;
	public static String[][] FIELD_NAMES = new String[][] {{"nsFXIS", "ns:FXIS"},{"nsFXIB", "ns:FXIB"},
	};
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F11a_FXIB_Type nsFXIB = null;
	

	public TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F11a_Type() {
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F11a_FXIS_Type getNsFXIS()  {
		if (nsFXIS == null) {
			nsFXIS = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F11a_FXIS_Type();
		}
		return nsFXIS;
	}


	public void setNsFXIS(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F11a_FXIS_Type nsFXIS)  {
		this.nsFXIS = nsFXIS;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F11a_FXIB_Type getNsFXIB()  {
		if (nsFXIB == null) {
			nsFXIB = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F11a_FXIB_Type();
		}
		return nsFXIB;
	}


	public void setNsFXIB(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F11a_FXIB_Type nsFXIB)  {
		this.nsFXIB = nsFXIB;
	}

}