package com.webmethods.caf.is.document;

import java.io.Serializable;

/**
 * IS document wrapper
 */
public  class TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F16a_2_Type extends java.lang.Object implements Serializable {

	
	private static final long serialVersionUID = 1L;
	// IS Document type used to generate this class
	public static final String DOCUMENT_TYPE = "TMCommon.docType.MT54x:docTypeRef_ns_SeqB_F16a_2_Type";
	public static String[][] FIELD_NAMES = new String[][] {{"nsF16S", "ns:F16S"},
	};
	private java.lang.String nsF16S;
	

	public TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F16a_2_Type() {
	}


	public java.lang.String getNsF16S()  {
		
		return nsF16S;
	}


	public void setNsF16S(java.lang.String nsF16S)  {
		this.nsF16S = nsF16S;
	}

}