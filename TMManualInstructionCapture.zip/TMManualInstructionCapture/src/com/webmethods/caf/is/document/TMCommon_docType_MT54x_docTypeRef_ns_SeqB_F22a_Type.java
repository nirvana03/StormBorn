package com.webmethods.caf.is.document;

import java.io.Serializable;

/**
 * IS document wrapper
 */
public  class TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F22a_Type extends java.lang.Object implements Serializable {

	
	private static final long serialVersionUID = 1L;
	// IS Document type used to generate this class
	public static final String DOCUMENT_TYPE = "TMCommon.docType.MT54x:docTypeRef_ns_SeqB_F22a_Type";
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F22a_PROC_Type nsPROC = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F22a_RPOR_Type nsRPOR = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F22a_PRIR_Type nsPRIR = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F22a_BORR_Type nsBORR = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F22a_TTCO_Type nsTTCO = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F22a_INCA_Type nsINCA = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F22a_TRCA_Type nsTRCA = null;
	public static String[][] FIELD_NAMES = new String[][] {{"nsPROC", "ns:PROC"},{"nsRPOR", "ns:RPOR"},{"nsPRIR", "ns:PRIR"},{"nsBORR", "ns:BORR"},{"nsTTCO", "ns:TTCO"},{"nsINCA", "ns:INCA"},{"nsTRCA", "ns:TRCA"},{"nsPRIC", "ns:PRIC"},
	};
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F22a_PRIC_Type nsPRIC = null;
	

	public TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F22a_Type() {
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F22a_PROC_Type getNsPROC()  {
		if (nsPROC == null) {
			nsPROC = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F22a_PROC_Type();
		}
		return nsPROC;
	}


	public void setNsPROC(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F22a_PROC_Type nsPROC)  {
		this.nsPROC = nsPROC;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F22a_RPOR_Type getNsRPOR()  {
		if (nsRPOR == null) {
			nsRPOR = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F22a_RPOR_Type();
		}
		return nsRPOR;
	}


	public void setNsRPOR(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F22a_RPOR_Type nsRPOR)  {
		this.nsRPOR = nsRPOR;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F22a_PRIR_Type getNsPRIR()  {
		if (nsPRIR == null) {
			nsPRIR = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F22a_PRIR_Type();
		}
		return nsPRIR;
	}


	public void setNsPRIR(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F22a_PRIR_Type nsPRIR)  {
		this.nsPRIR = nsPRIR;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F22a_BORR_Type getNsBORR()  {
		if (nsBORR == null) {
			nsBORR = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F22a_BORR_Type();
		}
		return nsBORR;
	}


	public void setNsBORR(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F22a_BORR_Type nsBORR)  {
		this.nsBORR = nsBORR;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F22a_TTCO_Type getNsTTCO()  {
		if (nsTTCO == null) {
			nsTTCO = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F22a_TTCO_Type();
		}
		return nsTTCO;
	}


	public void setNsTTCO(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F22a_TTCO_Type nsTTCO)  {
		this.nsTTCO = nsTTCO;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F22a_INCA_Type getNsINCA()  {
		if (nsINCA == null) {
			nsINCA = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F22a_INCA_Type();
		}
		return nsINCA;
	}


	public void setNsINCA(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F22a_INCA_Type nsINCA)  {
		this.nsINCA = nsINCA;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F22a_TRCA_Type getNsTRCA()  {
		if (nsTRCA == null) {
			nsTRCA = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F22a_TRCA_Type();
		}
		return nsTRCA;
	}


	public void setNsTRCA(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F22a_TRCA_Type nsTRCA)  {
		this.nsTRCA = nsTRCA;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F22a_PRIC_Type getNsPRIC()  {
		if (nsPRIC == null) {
			nsPRIC = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F22a_PRIC_Type();
		}
		return nsPRIC;
	}


	public void setNsPRIC(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F22a_PRIC_Type nsPRIC)  {
		this.nsPRIC = nsPRIC;
	}

}