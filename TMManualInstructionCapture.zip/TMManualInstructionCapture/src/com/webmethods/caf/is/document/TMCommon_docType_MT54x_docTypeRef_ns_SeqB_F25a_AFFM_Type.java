package com.webmethods.caf.is.document;

import java.io.Serializable;

/**
 * IS document wrapper
 */
public  class TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F25a_AFFM_Type extends java.lang.Object implements Serializable {

	
	private static final long serialVersionUID = 1L;
	// IS Document type used to generate this class
	public static final String DOCUMENT_TYPE = "TMCommon.docType.MT54x:docTypeRef_ns_SeqB_F25a_AFFM_Type";
	public static String[][] FIELD_NAMES = new String[][] {{"nsF25D", "ns:F25D"},
	};
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F25D_68_Type nsF25D = null;
	

	public TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F25a_AFFM_Type() {
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F25D_68_Type getNsF25D()  {
		if (nsF25D == null) {
			nsF25D = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F25D_68_Type();
		}
		return nsF25D;
	}


	public void setNsF25D(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F25D_68_Type nsF25D)  {
		this.nsF25D = nsF25D;
	}

}