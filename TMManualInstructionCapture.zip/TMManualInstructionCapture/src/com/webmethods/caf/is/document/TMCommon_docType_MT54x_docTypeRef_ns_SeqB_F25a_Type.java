package com.webmethods.caf.is.document;

import java.io.Serializable;

/**
 * IS document wrapper
 */
public  class TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F25a_Type extends java.lang.Object implements Serializable {

	
	private static final long serialVersionUID = 1L;
	// IS Document type used to generate this class
	public static final String DOCUMENT_TYPE = "TMCommon.docType.MT54x:docTypeRef_ns_SeqB_F25a_Type";
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F25a_MTCH_Type nsMTCH = null;
	public static String[][] FIELD_NAMES = new String[][] {{"nsMTCH", "ns:MTCH"},{"nsAFFM", "ns:AFFM"},
	};
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F25a_AFFM_Type nsAFFM = null;
	

	public TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F25a_Type() {
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F25a_MTCH_Type getNsMTCH()  {
		if (nsMTCH == null) {
			nsMTCH = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F25a_MTCH_Type();
		}
		return nsMTCH;
	}


	public void setNsMTCH(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F25a_MTCH_Type nsMTCH)  {
		this.nsMTCH = nsMTCH;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F25a_AFFM_Type getNsAFFM()  {
		if (nsAFFM == null) {
			nsAFFM = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F25a_AFFM_Type();
		}
		return nsAFFM;
	}


	public void setNsAFFM(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F25a_AFFM_Type nsAFFM)  {
		this.nsAFFM = nsAFFM;
	}

}