package com.webmethods.caf.is.document;

import java.io.Serializable;

/**
 * IS document wrapper
 */
public  class TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F70a_Type extends java.lang.Object implements Serializable {

	
	private static final long serialVersionUID = 1L;
	// IS Document type used to generate this class
	public static final String DOCUMENT_TYPE = "TMCommon.docType.MT54x:docTypeRef_ns_SeqB_F70a_Type";
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F70a_FXIN_Type nsFXIN = null;
	public static String[][] FIELD_NAMES = new String[][] {{"nsFXIN", "ns:FXIN"},{"nsSPRO", "ns:SPRO"},
	};
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F70a_SPRO_Type nsSPRO = null;
	

	public TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F70a_Type() {
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F70a_FXIN_Type getNsFXIN()  {
		if (nsFXIN == null) {
			nsFXIN = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F70a_FXIN_Type();
		}
		return nsFXIN;
	}


	public void setNsFXIN(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F70a_FXIN_Type nsFXIN)  {
		this.nsFXIN = nsFXIN;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F70a_SPRO_Type getNsSPRO()  {
		if (nsSPRO == null) {
			nsSPRO = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F70a_SPRO_Type();
		}
		return nsSPRO;
	}


	public void setNsSPRO(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F70a_SPRO_Type nsSPRO)  {
		this.nsSPRO = nsSPRO;
	}

}