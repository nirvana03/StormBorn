package com.webmethods.caf.is.document;

import java.io.Serializable;

/**
 * IS document wrapper
 */
public  class TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F90a_DEAL_Type extends java.lang.Object implements Serializable {

	
	private static final long serialVersionUID = 1L;
	// IS Document type used to generate this class
	public static final String DOCUMENT_TYPE = "TMCommon.docType.MT54x:docTypeRef_ns_SeqB_F90a_DEAL_Type";
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F90A_2_Type nsF90A = null;
	public static String[][] FIELD_NAMES = new String[][] {{"nsF90A", "ns:F90A"},{"nsF90B", "ns:F90B"},
	};
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F90B_4_Type nsF90B = null;
	

	public TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F90a_DEAL_Type() {
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F90A_2_Type getNsF90A()  {
		if (nsF90A == null) {
			nsF90A = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F90A_2_Type();
		}
		return nsF90A;
	}


	public void setNsF90A(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F90A_2_Type nsF90A)  {
		this.nsF90A = nsF90A;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F90B_4_Type getNsF90B()  {
		if (nsF90B == null) {
			nsF90B = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F90B_4_Type();
		}
		return nsF90B;
	}


	public void setNsF90B(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F90B_4_Type nsF90B)  {
		this.nsF90B = nsF90B;
	}

}