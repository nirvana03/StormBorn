package com.webmethods.caf.is.document;

import java.io.Serializable;

/**
 * IS document wrapper
 */
public  class TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F94a_CLEA_Type extends java.lang.Object implements Serializable {

	
	private static final long serialVersionUID = 1L;
	// IS Document type used to generate this class
	public static final String DOCUMENT_TYPE = "TMCommon.docType.MT54x:docTypeRef_ns_SeqB_F94a_CLEA_Type";
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F94H_1_Type nsF94H = null;
	public static String[][] FIELD_NAMES = new String[][] {{"nsF94H", "ns:F94H"},{"nsF94L", "ns:F94L"},
	};
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F94L_Type nsF94L = null;
	

	public TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F94a_CLEA_Type() {
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F94H_1_Type getNsF94H()  {
		if (nsF94H == null) {
			nsF94H = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F94H_1_Type();
		}
		return nsF94H;
	}


	public void setNsF94H(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F94H_1_Type nsF94H)  {
		this.nsF94H = nsF94H;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F94L_Type getNsF94L()  {
		if (nsF94L == null) {
			nsF94L = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F94L_Type();
		}
		return nsF94L;
	}


	public void setNsF94L(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F94L_Type nsF94L)  {
		this.nsF94L = nsF94L;
	}

}