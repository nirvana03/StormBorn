package com.webmethods.caf.is.document;

import java.io.Serializable;

/**
 * IS document wrapper
 */
public  class TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F94a_TRAD_Type extends java.lang.Object implements Serializable {

	
	private static final long serialVersionUID = 1L;
	// IS Document type used to generate this class
	public static final String DOCUMENT_TYPE = "TMCommon.docType.MT54x:docTypeRef_ns_SeqB_F94a_TRAD_Type";
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F94B_29_Type nsF94B = null;
	public static String[][] FIELD_NAMES = new String[][] {{"nsF94B", "ns:F94B"},{"nsF94L", "ns:F94L"},
	};
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F94L_Type nsF94L = null;
	

	public TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F94a_TRAD_Type() {
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F94B_29_Type getNsF94B()  {
		if (nsF94B == null) {
			nsF94B = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F94B_29_Type();
		}
		return nsF94B;
	}


	public void setNsF94B(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F94B_29_Type nsF94B)  {
		this.nsF94B = nsF94B;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F94L_Type getNsF94L()  {
		if (nsF94L == null) {
			nsF94L = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F94L_Type();
		}
		return nsF94L;
	}


	public void setNsF94L(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F94L_Type nsF94L)  {
		this.nsF94L = nsF94L;
	}

}