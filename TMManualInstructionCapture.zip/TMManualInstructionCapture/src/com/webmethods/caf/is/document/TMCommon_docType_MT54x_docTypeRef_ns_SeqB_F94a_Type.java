package com.webmethods.caf.is.document;

import java.io.Serializable;

/**
 * IS document wrapper
 */
public  class TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F94a_Type extends java.lang.Object implements Serializable {

	
	private static final long serialVersionUID = 1L;
	// IS Document type used to generate this class
	public static final String DOCUMENT_TYPE = "TMCommon.docType.MT54x:docTypeRef_ns_SeqB_F94a_Type";
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F94a_CLEA_Type nsCLEA = null;
	public static String[][] FIELD_NAMES = new String[][] {{"nsCLEA", "ns:CLEA"},{"nsTRAD", "ns:TRAD"},
	};
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F94a_TRAD_Type nsTRAD = null;
	

	public TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F94a_Type() {
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F94a_CLEA_Type getNsCLEA()  {
		if (nsCLEA == null) {
			nsCLEA = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F94a_CLEA_Type();
		}
		return nsCLEA;
	}


	public void setNsCLEA(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F94a_CLEA_Type nsCLEA)  {
		this.nsCLEA = nsCLEA;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F94a_TRAD_Type getNsTRAD()  {
		if (nsTRAD == null) {
			nsTRAD = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F94a_TRAD_Type();
		}
		return nsTRAD;
	}


	public void setNsTRAD(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F94a_TRAD_Type nsTRAD)  {
		this.nsTRAD = nsTRAD;
	}

}