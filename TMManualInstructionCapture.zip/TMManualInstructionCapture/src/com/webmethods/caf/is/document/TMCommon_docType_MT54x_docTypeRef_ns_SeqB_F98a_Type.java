package com.webmethods.caf.is.document;

import java.io.Serializable;

/**
 * IS document wrapper
 */
public  class TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F98a_Type extends java.lang.Object implements Serializable {

	
	private static final long serialVersionUID = 1L;
	// IS Document type used to generate this class
	public static final String DOCUMENT_TYPE = "TMCommon.docType.MT54x:docTypeRef_ns_SeqB_F98a_Type";
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F98a_SETT_Type nsSETT = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F98a_TRAD_Type nsTRAD = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F98a_ADEL_Type nsADEL = null;
	public static String[][] FIELD_NAMES = new String[][] {{"nsSETT", "ns:SETT"},{"nsTRAD", "ns:TRAD"},{"nsADEL", "ns:ADEL"},{"nsCERT", "ns:CERT"},
	};
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F98a_CERT_Type nsCERT = null;
	

	public TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F98a_Type() {
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F98a_SETT_Type getNsSETT()  {
		if (nsSETT == null) {
			nsSETT = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F98a_SETT_Type();
		}
		return nsSETT;
	}


	public void setNsSETT(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F98a_SETT_Type nsSETT)  {
		this.nsSETT = nsSETT;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F98a_TRAD_Type getNsTRAD()  {
		if (nsTRAD == null) {
			nsTRAD = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F98a_TRAD_Type();
		}
		return nsTRAD;
	}


	public void setNsTRAD(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F98a_TRAD_Type nsTRAD)  {
		this.nsTRAD = nsTRAD;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F98a_ADEL_Type getNsADEL()  {
		if (nsADEL == null) {
			nsADEL = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F98a_ADEL_Type();
		}
		return nsADEL;
	}


	public void setNsADEL(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F98a_ADEL_Type nsADEL)  {
		this.nsADEL = nsADEL;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F98a_CERT_Type getNsCERT()  {
		if (nsCERT == null) {
			nsCERT = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F98a_CERT_Type();
		}
		return nsCERT;
	}


	public void setNsCERT(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F98a_CERT_Type nsCERT)  {
		this.nsCERT = nsCERT;
	}

}