package com.webmethods.caf.is.document;

import java.io.Serializable;

/**
 * IS document wrapper
 */
public  class TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F99a_DAAC_Type extends java.lang.Object implements Serializable {

	
	private static final long serialVersionUID = 1L;
	// IS Document type used to generate this class
	public static final String DOCUMENT_TYPE = "TMCommon.docType.MT54x:docTypeRef_ns_SeqB_F99a_DAAC_Type";
	public static String[][] FIELD_NAMES = new String[][] {{"nsF99A", "ns:F99A"},
	};
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F99A_Type nsF99A = null;
	

	public TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F99a_DAAC_Type() {
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F99A_Type getNsF99A()  {
		if (nsF99A == null) {
			nsF99A = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F99A_Type();
		}
		return nsF99A;
	}


	public void setNsF99A(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F99A_Type nsF99A)  {
		this.nsF99A = nsF99A;
	}

}