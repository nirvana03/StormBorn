package com.webmethods.caf.is.document;

import java.io.Serializable;

/**
 * IS document wrapper
 */
public  class TMCommon_docType_MT54x_docTypeRef_ns_SeqB_Type extends java.lang.Object implements Serializable {

	
	private static final long serialVersionUID = 1L;
	// IS Document type used to generate this class
	public static final String DOCUMENT_TYPE = "TMCommon.docType.MT54x:docTypeRef_ns_SeqB_Type";
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F16a_1_Type nsF16a_1 = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F94a_Type[] nsF94a = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F98a_Type[] nsF98a = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F90a_Type nsF90a = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F99a_Type nsF99a = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F35a_Type nsF35a = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_Type nsSeqB1 = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F22a_Type[] nsF22a = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F11a_Type nsF11a = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F25a_Type[] nsF25a = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F70a_Type[] nsF70a = null;
	public static String[][] FIELD_NAMES = new String[][] {{"nsF16a_1", "ns:F16a_1"},{"nsF94a", "ns:F94a"},{"nsF98a", "ns:F98a"},{"nsF90a", "ns:F90a"},{"nsF99a", "ns:F99a"},{"nsF35a", "ns:F35a"},{"nsSeqB1", "ns:SeqB1"},{"nsF22a", "ns:F22a"},{"nsF11a", "ns:F11a"},{"nsF25a", "ns:F25a"},{"nsF70a", "ns:F70a"},{"nsF16a_2", "ns:F16a_2"},
	};
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F16a_2_Type nsF16a_2 = null;
	

	public TMCommon_docType_MT54x_docTypeRef_ns_SeqB_Type() {
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F16a_1_Type getNsF16a_1()  {
		if (nsF16a_1 == null) {
			nsF16a_1 = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F16a_1_Type();
		}
		return nsF16a_1;
	}


	public void setNsF16a_1(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F16a_1_Type nsF16a_1)  {
		this.nsF16a_1 = nsF16a_1;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F94a_Type[] getNsF94a()  {
		if (nsF94a == null) {
			//TODO: create/set default value here
		}
		return nsF94a;
	}


	public void setNsF94a(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F94a_Type[] nsF94a)  {
		this.nsF94a = nsF94a;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F98a_Type[] getNsF98a()  {
		if (nsF98a == null) {
			//TODO: create/set default value here
		}
		return nsF98a;
	}


	public void setNsF98a(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F98a_Type[] nsF98a)  {
		this.nsF98a = nsF98a;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F90a_Type getNsF90a()  {
		if (nsF90a == null) {
			nsF90a = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F90a_Type();
		}
		return nsF90a;
	}


	public void setNsF90a(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F90a_Type nsF90a)  {
		this.nsF90a = nsF90a;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F99a_Type getNsF99a()  {
		if (nsF99a == null) {
			nsF99a = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F99a_Type();
		}
		return nsF99a;
	}


	public void setNsF99a(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F99a_Type nsF99a)  {
		this.nsF99a = nsF99a;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F35a_Type getNsF35a()  {
		if (nsF35a == null) {
			nsF35a = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F35a_Type();
		}
		return nsF35a;
	}


	public void setNsF35a(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F35a_Type nsF35a)  {
		this.nsF35a = nsF35a;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_Type getNsSeqB1()  {
		if (nsSeqB1 == null) {
			nsSeqB1 = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_Type();
		}
		return nsSeqB1;
	}


	public void setNsSeqB1(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB1_Type nsSeqB1)  {
		this.nsSeqB1 = nsSeqB1;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F22a_Type[] getNsF22a()  {
		if (nsF22a == null) {
			//TODO: create/set default value here
		}
		return nsF22a;
	}


	public void setNsF22a(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F22a_Type[] nsF22a)  {
		this.nsF22a = nsF22a;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F11a_Type getNsF11a()  {
		if (nsF11a == null) {
			nsF11a = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F11a_Type();
		}
		return nsF11a;
	}


	public void setNsF11a(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F11a_Type nsF11a)  {
		this.nsF11a = nsF11a;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F25a_Type[] getNsF25a()  {
		if (nsF25a == null) {
			//TODO: create/set default value here
		}
		return nsF25a;
	}


	public void setNsF25a(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F25a_Type[] nsF25a)  {
		this.nsF25a = nsF25a;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F70a_Type[] getNsF70a()  {
		if (nsF70a == null) {
			//TODO: create/set default value here
		}
		return nsF70a;
	}


	public void setNsF70a(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F70a_Type[] nsF70a)  {
		this.nsF70a = nsF70a;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F16a_2_Type getNsF16a_2()  {
		if (nsF16a_2 == null) {
			nsF16a_2 = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F16a_2_Type();
		}
		return nsF16a_2;
	}


	public void setNsF16a_2(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqB_F16a_2_Type nsF16a_2)  {
		this.nsF16a_2 = nsF16a_2;
	}

}