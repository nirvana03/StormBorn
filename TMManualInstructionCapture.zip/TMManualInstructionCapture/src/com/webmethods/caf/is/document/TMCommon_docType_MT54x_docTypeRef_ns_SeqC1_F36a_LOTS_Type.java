package com.webmethods.caf.is.document;

import java.io.Serializable;

/**
 * IS document wrapper
 */
public  class TMCommon_docType_MT54x_docTypeRef_ns_SeqC1_F36a_LOTS_Type extends java.lang.Object implements Serializable {

	
	private static final long serialVersionUID = 1L;
	// IS Document type used to generate this class
	public static final String DOCUMENT_TYPE = "TMCommon.docType.MT54x:docTypeRef_ns_SeqC1_F36a_LOTS_Type";
	public static String[][] FIELD_NAMES = new String[][] {{"nsF36B", "ns:F36B"},
	};
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F36B_4_Type nsF36B = null;
	

	public TMCommon_docType_MT54x_docTypeRef_ns_SeqC1_F36a_LOTS_Type() {
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F36B_4_Type getNsF36B()  {
		if (nsF36B == null) {
			nsF36B = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F36B_4_Type();
		}
		return nsF36B;
	}


	public void setNsF36B(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F36B_4_Type nsF36B)  {
		this.nsF36B = nsF36B;
	}

}