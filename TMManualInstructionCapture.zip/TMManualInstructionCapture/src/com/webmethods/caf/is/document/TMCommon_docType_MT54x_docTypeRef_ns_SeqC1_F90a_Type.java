package com.webmethods.caf.is.document;

import java.io.Serializable;

/**
 * IS document wrapper
 */
public  class TMCommon_docType_MT54x_docTypeRef_ns_SeqC1_F90a_Type extends java.lang.Object implements Serializable {

	
	private static final long serialVersionUID = 1L;
	// IS Document type used to generate this class
	public static final String DOCUMENT_TYPE = "TMCommon.docType.MT54x:docTypeRef_ns_SeqC1_F90a_Type";
	public static String[][] FIELD_NAMES = new String[][] {{"nsLOTS", "ns:LOTS"},
	};
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqC1_F90a_LOTS_Type nsLOTS = null;
	

	public TMCommon_docType_MT54x_docTypeRef_ns_SeqC1_F90a_Type() {
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqC1_F90a_LOTS_Type getNsLOTS()  {
		if (nsLOTS == null) {
			nsLOTS = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqC1_F90a_LOTS_Type();
		}
		return nsLOTS;
	}


	public void setNsLOTS(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqC1_F90a_LOTS_Type nsLOTS)  {
		this.nsLOTS = nsLOTS;
	}

}