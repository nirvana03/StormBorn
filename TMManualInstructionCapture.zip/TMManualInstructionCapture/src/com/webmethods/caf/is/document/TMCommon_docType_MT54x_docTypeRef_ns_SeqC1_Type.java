package com.webmethods.caf.is.document;

import java.io.Serializable;

/**
 * IS document wrapper
 */
public  class TMCommon_docType_MT54x_docTypeRef_ns_SeqC1_Type extends java.lang.Object implements Serializable {

	
	private static final long serialVersionUID = 1L;
	// IS Document type used to generate this class
	public static final String DOCUMENT_TYPE = "TMCommon.docType.MT54x:docTypeRef_ns_SeqC1_Type";
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqC1_F16a_1_Type nsF16a_1 = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqC1_F13a_Type nsF13a = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqC1_F36a_Type nsF36a = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqC1_F98a_Type nsF98a = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqC1_F90a_Type nsF90a = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqC1_F22a_Type nsF22a = null;
	public static String[][] FIELD_NAMES = new String[][] {{"nsF16a_1", "ns:F16a_1"},{"nsF13a", "ns:F13a"},{"nsF36a", "ns:F36a"},{"nsF98a", "ns:F98a"},{"nsF90a", "ns:F90a"},{"nsF22a", "ns:F22a"},{"nsF16a_2", "ns:F16a_2"},
	};
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqC1_F16a_2_Type nsF16a_2 = null;
	

	public TMCommon_docType_MT54x_docTypeRef_ns_SeqC1_Type() {
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqC1_F16a_1_Type getNsF16a_1()  {
		if (nsF16a_1 == null) {
			nsF16a_1 = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqC1_F16a_1_Type();
		}
		return nsF16a_1;
	}


	public void setNsF16a_1(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqC1_F16a_1_Type nsF16a_1)  {
		this.nsF16a_1 = nsF16a_1;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqC1_F13a_Type getNsF13a()  {
		if (nsF13a == null) {
			nsF13a = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqC1_F13a_Type();
		}
		return nsF13a;
	}


	public void setNsF13a(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqC1_F13a_Type nsF13a)  {
		this.nsF13a = nsF13a;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqC1_F36a_Type getNsF36a()  {
		if (nsF36a == null) {
			nsF36a = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqC1_F36a_Type();
		}
		return nsF36a;
	}


	public void setNsF36a(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqC1_F36a_Type nsF36a)  {
		this.nsF36a = nsF36a;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqC1_F98a_Type getNsF98a()  {
		if (nsF98a == null) {
			nsF98a = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqC1_F98a_Type();
		}
		return nsF98a;
	}


	public void setNsF98a(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqC1_F98a_Type nsF98a)  {
		this.nsF98a = nsF98a;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqC1_F90a_Type getNsF90a()  {
		if (nsF90a == null) {
			nsF90a = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqC1_F90a_Type();
		}
		return nsF90a;
	}


	public void setNsF90a(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqC1_F90a_Type nsF90a)  {
		this.nsF90a = nsF90a;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqC1_F22a_Type getNsF22a()  {
		if (nsF22a == null) {
			nsF22a = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqC1_F22a_Type();
		}
		return nsF22a;
	}


	public void setNsF22a(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqC1_F22a_Type nsF22a)  {
		this.nsF22a = nsF22a;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqC1_F16a_2_Type getNsF16a_2()  {
		if (nsF16a_2 == null) {
			nsF16a_2 = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqC1_F16a_2_Type();
		}
		return nsF16a_2;
	}


	public void setNsF16a_2(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqC1_F16a_2_Type nsF16a_2)  {
		this.nsF16a_2 = nsF16a_2;
	}

}