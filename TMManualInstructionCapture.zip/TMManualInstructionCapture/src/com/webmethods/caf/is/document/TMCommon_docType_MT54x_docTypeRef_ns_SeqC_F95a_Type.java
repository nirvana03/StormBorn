package com.webmethods.caf.is.document;

import java.io.Serializable;

/**
 * IS document wrapper
 */
public  class TMCommon_docType_MT54x_docTypeRef_ns_SeqC_F95a_Type extends java.lang.Object implements Serializable {

	
	private static final long serialVersionUID = 1L;
	// IS Document type used to generate this class
	public static final String DOCUMENT_TYPE = "TMCommon.docType.MT54x:docTypeRef_ns_SeqC_F95a_Type";
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqC_F95a_ACOW_Type nsACOW = null;
	public static String[][] FIELD_NAMES = new String[][] {{"nsACOW", "ns:ACOW"},{"nsALTE", "ns:ALTE"},
	};
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqC_F95a_ALTE_Type nsALTE = null;
	

	public TMCommon_docType_MT54x_docTypeRef_ns_SeqC_F95a_Type() {
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqC_F95a_ACOW_Type getNsACOW()  {
		if (nsACOW == null) {
			nsACOW = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqC_F95a_ACOW_Type();
		}
		return nsACOW;
	}


	public void setNsACOW(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqC_F95a_ACOW_Type nsACOW)  {
		this.nsACOW = nsACOW;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqC_F95a_ALTE_Type getNsALTE()  {
		if (nsALTE == null) {
			nsALTE = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqC_F95a_ALTE_Type();
		}
		return nsALTE;
	}


	public void setNsALTE(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqC_F95a_ALTE_Type nsALTE)  {
		this.nsALTE = nsALTE;
	}

}