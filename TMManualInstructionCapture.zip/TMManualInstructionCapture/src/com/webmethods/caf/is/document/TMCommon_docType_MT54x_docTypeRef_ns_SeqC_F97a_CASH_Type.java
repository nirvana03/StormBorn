package com.webmethods.caf.is.document;

import java.io.Serializable;

/**
 * IS document wrapper
 */
public  class TMCommon_docType_MT54x_docTypeRef_ns_SeqC_F97a_CASH_Type extends java.lang.Object implements Serializable {

	
	private static final long serialVersionUID = 1L;
	// IS Document type used to generate this class
	public static final String DOCUMENT_TYPE = "TMCommon.docType.MT54x:docTypeRef_ns_SeqC_F97a_CASH_Type";
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F97A_Type nsF97A = null;
	public static String[][] FIELD_NAMES = new String[][] {{"nsF97A", "ns:F97A"},{"nsF97E", "ns:F97E"},
	};
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F97E_Type nsF97E = null;
	

	public TMCommon_docType_MT54x_docTypeRef_ns_SeqC_F97a_CASH_Type() {
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F97A_Type getNsF97A()  {
		if (nsF97A == null) {
			nsF97A = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F97A_Type();
		}
		return nsF97A;
	}


	public void setNsF97A(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F97A_Type nsF97A)  {
		this.nsF97A = nsF97A;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F97E_Type getNsF97E()  {
		if (nsF97E == null) {
			nsF97E = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F97E_Type();
		}
		return nsF97E;
	}


	public void setNsF97E(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F97E_Type nsF97E)  {
		this.nsF97E = nsF97E;
	}

}