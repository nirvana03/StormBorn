package com.webmethods.caf.is.document;

import java.io.Serializable;

/**
 * IS document wrapper
 */
public  class TMCommon_docType_MT54x_docTypeRef_ns_SeqC_F97a_SAFE_Type extends java.lang.Object implements Serializable {

	
	private static final long serialVersionUID = 1L;
	// IS Document type used to generate this class
	public static final String DOCUMENT_TYPE = "TMCommon.docType.MT54x:docTypeRef_ns_SeqC_F97a_SAFE_Type";
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F97A_Type nsF97A = null;
	public static String[][] FIELD_NAMES = new String[][] {{"nsF97A", "ns:F97A"},{"nsF97B", "ns:F97B"},
	};
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F97B_9_Type nsF97B = null;
	

	public TMCommon_docType_MT54x_docTypeRef_ns_SeqC_F97a_SAFE_Type() {
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F97A_Type getNsF97A()  {
		if (nsF97A == null) {
			nsF97A = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F97A_Type();
		}
		return nsF97A;
	}


	public void setNsF97A(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F97A_Type nsF97A)  {
		this.nsF97A = nsF97A;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F97B_9_Type getNsF97B()  {
		if (nsF97B == null) {
			nsF97B = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F97B_9_Type();
		}
		return nsF97B;
	}


	public void setNsF97B(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F97B_9_Type nsF97B)  {
		this.nsF97B = nsF97B;
	}

}