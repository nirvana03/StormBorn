package com.webmethods.caf.is.document;

import java.io.Serializable;

/**
 * IS document wrapper
 */
public  class TMCommon_docType_MT54x_docTypeRef_ns_SeqC_F97a_Type extends java.lang.Object implements Serializable {

	
	private static final long serialVersionUID = 1L;
	// IS Document type used to generate this class
	public static final String DOCUMENT_TYPE = "TMCommon.docType.MT54x:docTypeRef_ns_SeqC_F97a_Type";
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqC_F97a_SAFE_Type nsSAFE = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqC_F97a_CASH_Type nsCASH = null;
	public static String[][] FIELD_NAMES = new String[][] {{"nsSAFE", "ns:SAFE"},{"nsCASH", "ns:CASH"},{"nsREGI", "ns:REGI"},
	};
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqC_F97a_REGI_Type nsREGI = null;
	

	public TMCommon_docType_MT54x_docTypeRef_ns_SeqC_F97a_Type() {
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqC_F97a_SAFE_Type getNsSAFE()  {
		if (nsSAFE == null) {
			nsSAFE = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqC_F97a_SAFE_Type();
		}
		return nsSAFE;
	}


	public void setNsSAFE(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqC_F97a_SAFE_Type nsSAFE)  {
		this.nsSAFE = nsSAFE;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqC_F97a_CASH_Type getNsCASH()  {
		if (nsCASH == null) {
			nsCASH = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqC_F97a_CASH_Type();
		}
		return nsCASH;
	}


	public void setNsCASH(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqC_F97a_CASH_Type nsCASH)  {
		this.nsCASH = nsCASH;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqC_F97a_REGI_Type getNsREGI()  {
		if (nsREGI == null) {
			nsREGI = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqC_F97a_REGI_Type();
		}
		return nsREGI;
	}


	public void setNsREGI(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqC_F97a_REGI_Type nsREGI)  {
		this.nsREGI = nsREGI;
	}

}