package com.webmethods.caf.is.document;

import java.io.Serializable;

/**
 * IS document wrapper
 */
public  class TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F19a_ACRU_Type extends java.lang.Object implements Serializable {

	
	private static final long serialVersionUID = 1L;
	// IS Document type used to generate this class
	public static final String DOCUMENT_TYPE = "TMCommon.docType.MT54x:docTypeRef_ns_SeqD_F19a_ACRU_Type";
	public static String[][] FIELD_NAMES = new String[][] {{"nsF19A", "ns:F19A"},
	};
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F19A_Type nsF19A = null;
	

	public TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F19a_ACRU_Type() {
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F19A_Type getNsF19A()  {
		if (nsF19A == null) {
			nsF19A = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F19A_Type();
		}
		return nsF19A;
	}


	public void setNsF19A(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F19A_Type nsF19A)  {
		this.nsF19A = nsF19A;
	}

}