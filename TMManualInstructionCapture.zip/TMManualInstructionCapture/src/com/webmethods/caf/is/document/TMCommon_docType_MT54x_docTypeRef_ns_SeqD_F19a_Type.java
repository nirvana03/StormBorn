package com.webmethods.caf.is.document;

import java.io.Serializable;

/**
 * IS document wrapper
 */
public  class TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F19a_Type extends java.lang.Object implements Serializable {

	
	private static final long serialVersionUID = 1L;
	// IS Document type used to generate this class
	public static final String DOCUMENT_TYPE = "TMCommon.docType.MT54x:docTypeRef_ns_SeqD_F19a_Type";
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F19a_FORF_Type nsFORF = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F19a_TRTE_Type nsTRTE = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F19a_REPP_Type nsREPP = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F19a_ACRU_Type nsACRU = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F19a_DEAL_Type nsDEAL = null;
	public static String[][] FIELD_NAMES = new String[][] {{"nsFORF", "ns:FORF"},{"nsTRTE", "ns:TRTE"},{"nsREPP", "ns:REPP"},{"nsACRU", "ns:ACRU"},{"nsDEAL", "ns:DEAL"},{"nsTAPC", "ns:TAPC"},
	};
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F19a_TAPC_Type nsTAPC = null;
	

	public TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F19a_Type() {
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F19a_FORF_Type getNsFORF()  {
		if (nsFORF == null) {
			nsFORF = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F19a_FORF_Type();
		}
		return nsFORF;
	}


	public void setNsFORF(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F19a_FORF_Type nsFORF)  {
		this.nsFORF = nsFORF;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F19a_TRTE_Type getNsTRTE()  {
		if (nsTRTE == null) {
			nsTRTE = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F19a_TRTE_Type();
		}
		return nsTRTE;
	}


	public void setNsTRTE(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F19a_TRTE_Type nsTRTE)  {
		this.nsTRTE = nsTRTE;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F19a_REPP_Type getNsREPP()  {
		if (nsREPP == null) {
			nsREPP = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F19a_REPP_Type();
		}
		return nsREPP;
	}


	public void setNsREPP(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F19a_REPP_Type nsREPP)  {
		this.nsREPP = nsREPP;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F19a_ACRU_Type getNsACRU()  {
		if (nsACRU == null) {
			nsACRU = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F19a_ACRU_Type();
		}
		return nsACRU;
	}


	public void setNsACRU(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F19a_ACRU_Type nsACRU)  {
		this.nsACRU = nsACRU;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F19a_DEAL_Type getNsDEAL()  {
		if (nsDEAL == null) {
			nsDEAL = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F19a_DEAL_Type();
		}
		return nsDEAL;
	}


	public void setNsDEAL(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F19a_DEAL_Type nsDEAL)  {
		this.nsDEAL = nsDEAL;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F19a_TAPC_Type getNsTAPC()  {
		if (nsTAPC == null) {
			nsTAPC = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F19a_TAPC_Type();
		}
		return nsTAPC;
	}


	public void setNsTAPC(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F19a_TAPC_Type nsTAPC)  {
		this.nsTAPC = nsTAPC;
	}

}