package com.webmethods.caf.is.document;

import java.io.Serializable;

/**
 * IS document wrapper
 */
public  class TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F20a_Type extends java.lang.Object implements Serializable {

	
	private static final long serialVersionUID = 1L;
	// IS Document type used to generate this class
	public static final String DOCUMENT_TYPE = "TMCommon.docType.MT54x:docTypeRef_ns_SeqD_F20a_Type";
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F20a_SECO_Type nsSECO = null;
	public static String[][] FIELD_NAMES = new String[][] {{"nsSECO", "ns:SECO"},{"nsREPO", "ns:REPO"},
	};
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F20a_REPO_Type nsREPO = null;
	

	public TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F20a_Type() {
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F20a_SECO_Type getNsSECO()  {
		if (nsSECO == null) {
			nsSECO = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F20a_SECO_Type();
		}
		return nsSECO;
	}


	public void setNsSECO(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F20a_SECO_Type nsSECO)  {
		this.nsSECO = nsSECO;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F20a_REPO_Type getNsREPO()  {
		if (nsREPO == null) {
			nsREPO = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F20a_REPO_Type();
		}
		return nsREPO;
	}


	public void setNsREPO(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F20a_REPO_Type nsREPO)  {
		this.nsREPO = nsREPO;
	}

}