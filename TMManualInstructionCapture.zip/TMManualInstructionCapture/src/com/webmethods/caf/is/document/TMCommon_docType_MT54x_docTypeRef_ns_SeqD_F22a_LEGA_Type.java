package com.webmethods.caf.is.document;

import java.io.Serializable;

/**
 * IS document wrapper
 */
public  class TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F22a_LEGA_Type extends java.lang.Object implements Serializable {

	
	private static final long serialVersionUID = 1L;
	// IS Document type used to generate this class
	public static final String DOCUMENT_TYPE = "TMCommon.docType.MT54x:docTypeRef_ns_SeqD_F22a_LEGA_Type";
	public static String[][] FIELD_NAMES = new String[][] {{"nsF22F", "ns:F22F"},
	};
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F22F_313_Type nsF22F = null;
	

	public TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F22a_LEGA_Type() {
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F22F_313_Type getNsF22F()  {
		if (nsF22F == null) {
			nsF22F = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F22F_313_Type();
		}
		return nsF22F;
	}


	public void setNsF22F(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F22F_313_Type nsF22F)  {
		this.nsF22F = nsF22F;
	}

}