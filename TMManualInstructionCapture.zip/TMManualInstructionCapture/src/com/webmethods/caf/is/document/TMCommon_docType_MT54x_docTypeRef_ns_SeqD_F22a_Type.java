package com.webmethods.caf.is.document;

import java.io.Serializable;

/**
 * IS document wrapper
 */
public  class TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F22a_Type extends java.lang.Object implements Serializable {

	
	private static final long serialVersionUID = 1L;
	// IS Document type used to generate this class
	public static final String DOCUMENT_TYPE = "TMCommon.docType.MT54x:docTypeRef_ns_SeqD_F22a_Type";
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F22a_RERT_Type nsRERT = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F22a_MICO_Type nsMICO = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F22a_REVA_Type nsREVA = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F22a_LEGA_Type nsLEGA = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F22a_OMAT_Type nsOMAT = null;
	public static String[][] FIELD_NAMES = new String[][] {{"nsRERT", "ns:RERT"},{"nsMICO", "ns:MICO"},{"nsREVA", "ns:REVA"},{"nsLEGA", "ns:LEGA"},{"nsOMAT", "ns:OMAT"},{"nsINTR", "ns:INTR"},
	};
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F22a_INTR_Type nsINTR = null;
	

	public TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F22a_Type() {
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F22a_RERT_Type getNsRERT()  {
		if (nsRERT == null) {
			nsRERT = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F22a_RERT_Type();
		}
		return nsRERT;
	}


	public void setNsRERT(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F22a_RERT_Type nsRERT)  {
		this.nsRERT = nsRERT;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F22a_MICO_Type getNsMICO()  {
		if (nsMICO == null) {
			nsMICO = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F22a_MICO_Type();
		}
		return nsMICO;
	}


	public void setNsMICO(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F22a_MICO_Type nsMICO)  {
		this.nsMICO = nsMICO;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F22a_REVA_Type getNsREVA()  {
		if (nsREVA == null) {
			nsREVA = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F22a_REVA_Type();
		}
		return nsREVA;
	}


	public void setNsREVA(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F22a_REVA_Type nsREVA)  {
		this.nsREVA = nsREVA;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F22a_LEGA_Type getNsLEGA()  {
		if (nsLEGA == null) {
			nsLEGA = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F22a_LEGA_Type();
		}
		return nsLEGA;
	}


	public void setNsLEGA(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F22a_LEGA_Type nsLEGA)  {
		this.nsLEGA = nsLEGA;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F22a_OMAT_Type getNsOMAT()  {
		if (nsOMAT == null) {
			nsOMAT = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F22a_OMAT_Type();
		}
		return nsOMAT;
	}


	public void setNsOMAT(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F22a_OMAT_Type nsOMAT)  {
		this.nsOMAT = nsOMAT;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F22a_INTR_Type getNsINTR()  {
		if (nsINTR == null) {
			nsINTR = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F22a_INTR_Type();
		}
		return nsINTR;
	}


	public void setNsINTR(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F22a_INTR_Type nsINTR)  {
		this.nsINTR = nsINTR;
	}

}