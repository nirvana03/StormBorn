package com.webmethods.caf.is.document;

import java.io.Serializable;

/**
 * IS document wrapper
 */
public  class TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F92a_SHAI_Type extends java.lang.Object implements Serializable {

	
	private static final long serialVersionUID = 1L;
	// IS Document type used to generate this class
	public static final String DOCUMENT_TYPE = "TMCommon.docType.MT54x:docTypeRef_ns_SeqD_F92a_SHAI_Type";
	public static String[][] FIELD_NAMES = new String[][] {{"nsF92A", "ns:F92A"},
	};
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F92A_Type nsF92A = null;
	

	public TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F92a_SHAI_Type() {
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F92A_Type getNsF92A()  {
		if (nsF92A == null) {
			nsF92A = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F92A_Type();
		}
		return nsF92A;
	}


	public void setNsF92A(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F92A_Type nsF92A)  {
		this.nsF92A = nsF92A;
	}

}