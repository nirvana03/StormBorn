package com.webmethods.caf.is.document;

import java.io.Serializable;

/**
 * IS document wrapper
 */
public  class TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F92a_Type extends java.lang.Object implements Serializable {

	
	private static final long serialVersionUID = 1L;
	// IS Document type used to generate this class
	public static final String DOCUMENT_TYPE = "TMCommon.docType.MT54x:docTypeRef_ns_SeqD_F92a_Type";
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F92a_VASU_Type nsVASU = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F92a_REPO_Type nsREPO = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F92a_RSPR_Type nsRSPR = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F92a_PRIC_Type nsPRIC = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F92a_SLMG_Type nsSLMG = null;
	public static String[][] FIELD_NAMES = new String[][] {{"nsVASU", "ns:VASU"},{"nsREPO", "ns:REPO"},{"nsRSPR", "ns:RSPR"},{"nsPRIC", "ns:PRIC"},{"nsSLMG", "ns:SLMG"},{"nsSHAI", "ns:SHAI"},
	};
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F92a_SHAI_Type nsSHAI = null;
	

	public TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F92a_Type() {
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F92a_VASU_Type getNsVASU()  {
		if (nsVASU == null) {
			nsVASU = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F92a_VASU_Type();
		}
		return nsVASU;
	}


	public void setNsVASU(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F92a_VASU_Type nsVASU)  {
		this.nsVASU = nsVASU;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F92a_REPO_Type getNsREPO()  {
		if (nsREPO == null) {
			nsREPO = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F92a_REPO_Type();
		}
		return nsREPO;
	}


	public void setNsREPO(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F92a_REPO_Type nsREPO)  {
		this.nsREPO = nsREPO;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F92a_RSPR_Type getNsRSPR()  {
		if (nsRSPR == null) {
			nsRSPR = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F92a_RSPR_Type();
		}
		return nsRSPR;
	}


	public void setNsRSPR(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F92a_RSPR_Type nsRSPR)  {
		this.nsRSPR = nsRSPR;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F92a_PRIC_Type getNsPRIC()  {
		if (nsPRIC == null) {
			nsPRIC = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F92a_PRIC_Type();
		}
		return nsPRIC;
	}


	public void setNsPRIC(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F92a_PRIC_Type nsPRIC)  {
		this.nsPRIC = nsPRIC;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F92a_SLMG_Type getNsSLMG()  {
		if (nsSLMG == null) {
			nsSLMG = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F92a_SLMG_Type();
		}
		return nsSLMG;
	}


	public void setNsSLMG(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F92a_SLMG_Type nsSLMG)  {
		this.nsSLMG = nsSLMG;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F92a_SHAI_Type getNsSHAI()  {
		if (nsSHAI == null) {
			nsSHAI = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F92a_SHAI_Type();
		}
		return nsSHAI;
	}


	public void setNsSHAI(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F92a_SHAI_Type nsSHAI)  {
		this.nsSHAI = nsSHAI;
	}

}