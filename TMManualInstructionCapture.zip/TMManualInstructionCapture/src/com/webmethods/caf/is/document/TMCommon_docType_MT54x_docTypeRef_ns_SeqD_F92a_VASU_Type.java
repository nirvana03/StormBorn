package com.webmethods.caf.is.document;

import java.io.Serializable;

/**
 * IS document wrapper
 */
public  class TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F92a_VASU_Type extends java.lang.Object implements Serializable {

	
	private static final long serialVersionUID = 1L;
	// IS Document type used to generate this class
	public static final String DOCUMENT_TYPE = "TMCommon.docType.MT54x:docTypeRef_ns_SeqD_F92a_VASU_Type";
	public static String[][] FIELD_NAMES = new String[][] {{"nsF92C", "ns:F92C"},
	};
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F92C_2_Type nsF92C = null;
	

	public TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F92a_VASU_Type() {
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F92C_2_Type getNsF92C()  {
		if (nsF92C == null) {
			nsF92C = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F92C_2_Type();
		}
		return nsF92C;
	}


	public void setNsF92C(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F92C_2_Type nsF92C)  {
		this.nsF92C = nsF92C;
	}

}