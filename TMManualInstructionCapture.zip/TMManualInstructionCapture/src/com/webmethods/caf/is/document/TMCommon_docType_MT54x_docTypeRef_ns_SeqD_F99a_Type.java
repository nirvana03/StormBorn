package com.webmethods.caf.is.document;

import java.io.Serializable;

/**
 * IS document wrapper
 */
public  class TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F99a_Type extends java.lang.Object implements Serializable {

	
	private static final long serialVersionUID = 1L;
	// IS Document type used to generate this class
	public static final String DOCUMENT_TYPE = "TMCommon.docType.MT54x:docTypeRef_ns_SeqD_F99a_Type";
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F99a_CADE_Type nsCADE = null;
	public static String[][] FIELD_NAMES = new String[][] {{"nsCADE", "ns:CADE"},{"nsTOCO", "ns:TOCO"},
	};
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F99a_TOCO_Type nsTOCO = null;
	

	public TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F99a_Type() {
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F99a_CADE_Type getNsCADE()  {
		if (nsCADE == null) {
			nsCADE = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F99a_CADE_Type();
		}
		return nsCADE;
	}


	public void setNsCADE(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F99a_CADE_Type nsCADE)  {
		this.nsCADE = nsCADE;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F99a_TOCO_Type getNsTOCO()  {
		if (nsTOCO == null) {
			nsTOCO = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F99a_TOCO_Type();
		}
		return nsTOCO;
	}


	public void setNsTOCO(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqD_F99a_TOCO_Type nsTOCO)  {
		this.nsTOCO = nsTOCO;
	}

}