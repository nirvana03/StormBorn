package com.webmethods.caf.is.document;

import java.io.Serializable;

/**
 * IS document wrapper
 */
public  class TMCommon_docType_MT54x_docTypeRef_ns_SeqE1_F20a_Type extends java.lang.Object implements Serializable {

	
	private static final long serialVersionUID = 1L;
	// IS Document type used to generate this class
	public static final String DOCUMENT_TYPE = "TMCommon.docType.MT54x:docTypeRef_ns_SeqE1_F20a_Type";
	public static String[][] FIELD_NAMES = new String[][] {{"nsPROC", "ns:PROC"},
	};
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE1_F20a_PROC_Type nsPROC = null;
	

	public TMCommon_docType_MT54x_docTypeRef_ns_SeqE1_F20a_Type() {
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE1_F20a_PROC_Type getNsPROC()  {
		if (nsPROC == null) {
			nsPROC = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE1_F20a_PROC_Type();
		}
		return nsPROC;
	}


	public void setNsPROC(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE1_F20a_PROC_Type nsPROC)  {
		this.nsPROC = nsPROC;
	}

}