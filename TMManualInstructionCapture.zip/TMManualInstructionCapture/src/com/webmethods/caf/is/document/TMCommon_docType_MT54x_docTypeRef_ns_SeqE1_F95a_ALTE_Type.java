package com.webmethods.caf.is.document;

import java.io.Serializable;

/**
 * IS document wrapper
 */
public  class TMCommon_docType_MT54x_docTypeRef_ns_SeqE1_F95a_ALTE_Type extends java.lang.Object implements Serializable {

	
	private static final long serialVersionUID = 1L;
	// IS Document type used to generate this class
	public static final String DOCUMENT_TYPE = "TMCommon.docType.MT54x:docTypeRef_ns_SeqE1_F95a_ALTE_Type";
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F95L_Type nsF95L = null;
	public static String[][] FIELD_NAMES = new String[][] {{"nsF95L", "ns:F95L"},{"nsF95S", "ns:F95S"},
	};
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F95S_19_Type nsF95S = null;
	

	public TMCommon_docType_MT54x_docTypeRef_ns_SeqE1_F95a_ALTE_Type() {
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F95L_Type getNsF95L()  {
		if (nsF95L == null) {
			nsF95L = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F95L_Type();
		}
		return nsF95L;
	}


	public void setNsF95L(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F95L_Type nsF95L)  {
		this.nsF95L = nsF95L;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F95S_19_Type getNsF95S()  {
		if (nsF95S == null) {
			nsF95S = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F95S_19_Type();
		}
		return nsF95S;
	}


	public void setNsF95S(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F95S_19_Type nsF95S)  {
		this.nsF95S = nsF95S;
	}

}