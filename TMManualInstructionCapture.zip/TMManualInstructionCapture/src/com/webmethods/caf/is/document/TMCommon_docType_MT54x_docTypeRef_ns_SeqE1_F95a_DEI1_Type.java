package com.webmethods.caf.is.document;

import java.io.Serializable;

/**
 * IS document wrapper
 */
public  class TMCommon_docType_MT54x_docTypeRef_ns_SeqE1_F95a_DEI1_Type extends java.lang.Object implements Serializable {

	
	private static final long serialVersionUID = 1L;
	// IS Document type used to generate this class
	public static final String DOCUMENT_TYPE = "TMCommon.docType.MT54x:docTypeRef_ns_SeqE1_F95a_DEI1_Type";
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F95P_12_Type nsF95P = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F95Q_Type nsF95Q = null;
	public static String[][] FIELD_NAMES = new String[][] {{"nsF95P", "ns:F95P"},{"nsF95Q", "ns:F95Q"},{"nsF95R", "ns:F95R"},
	};
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F95R_4_Type nsF95R = null;
	

	public TMCommon_docType_MT54x_docTypeRef_ns_SeqE1_F95a_DEI1_Type() {
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F95P_12_Type getNsF95P()  {
		if (nsF95P == null) {
			nsF95P = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F95P_12_Type();
		}
		return nsF95P;
	}


	public void setNsF95P(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F95P_12_Type nsF95P)  {
		this.nsF95P = nsF95P;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F95Q_Type getNsF95Q()  {
		if (nsF95Q == null) {
			nsF95Q = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F95Q_Type();
		}
		return nsF95Q;
	}


	public void setNsF95Q(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F95Q_Type nsF95Q)  {
		this.nsF95Q = nsF95Q;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F95R_4_Type getNsF95R()  {
		if (nsF95R == null) {
			nsF95R = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F95R_4_Type();
		}
		return nsF95R;
	}


	public void setNsF95R(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F95R_4_Type nsF95R)  {
		this.nsF95R = nsF95R;
	}

}