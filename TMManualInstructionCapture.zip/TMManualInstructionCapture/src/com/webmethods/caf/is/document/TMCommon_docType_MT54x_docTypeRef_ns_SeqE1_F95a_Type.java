package com.webmethods.caf.is.document;

import java.io.Serializable;

/**
 * IS document wrapper
 */
public  class TMCommon_docType_MT54x_docTypeRef_ns_SeqE1_F95a_Type extends java.lang.Object implements Serializable {

	
	private static final long serialVersionUID = 1L;
	// IS Document type used to generate this class
	public static final String DOCUMENT_TYPE = "TMCommon.docType.MT54x:docTypeRef_ns_SeqE1_F95a_Type";
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE1_F95a_BUYR_Type nsBUYR = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE1_F95a_DEAG_Type nsDEAG = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE1_F95a_DECU_Type nsDECU = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE1_F95a_DEI1_Type nsDEI1 = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE1_F95a_DEI2_Type nsDEI2 = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE1_F95a_PSET_Type nsPSET = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE1_F95a_REAG_Type nsREAG = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE1_F95a_RECU_Type nsRECU = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE1_F95a_REI1_Type nsREI1 = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE1_F95a_REI2_Type nsREI2 = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE1_F95a_SELL_Type nsSELL = null;
	public static String[][] FIELD_NAMES = new String[][] {{"nsBUYR", "ns:BUYR"},{"nsDEAG", "ns:DEAG"},{"nsDECU", "ns:DECU"},{"nsDEI1", "ns:DEI1"},{"nsDEI2", "ns:DEI2"},{"nsPSET", "ns:PSET"},{"nsREAG", "ns:REAG"},{"nsRECU", "ns:RECU"},{"nsREI1", "ns:REI1"},{"nsREI2", "ns:REI2"},{"nsSELL", "ns:SELL"},{"nsALTE", "ns:ALTE"},
	};
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE1_F95a_ALTE_Type nsALTE = null;
	

	public TMCommon_docType_MT54x_docTypeRef_ns_SeqE1_F95a_Type() {
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE1_F95a_BUYR_Type getNsBUYR()  {
		if (nsBUYR == null) {
			nsBUYR = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE1_F95a_BUYR_Type();
		}
		return nsBUYR;
	}


	public void setNsBUYR(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE1_F95a_BUYR_Type nsBUYR)  {
		this.nsBUYR = nsBUYR;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE1_F95a_DEAG_Type getNsDEAG()  {
		if (nsDEAG == null) {
			nsDEAG = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE1_F95a_DEAG_Type();
		}
		return nsDEAG;
	}


	public void setNsDEAG(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE1_F95a_DEAG_Type nsDEAG)  {
		this.nsDEAG = nsDEAG;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE1_F95a_DECU_Type getNsDECU()  {
		if (nsDECU == null) {
			nsDECU = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE1_F95a_DECU_Type();
		}
		return nsDECU;
	}


	public void setNsDECU(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE1_F95a_DECU_Type nsDECU)  {
		this.nsDECU = nsDECU;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE1_F95a_DEI1_Type getNsDEI1()  {
		if (nsDEI1 == null) {
			nsDEI1 = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE1_F95a_DEI1_Type();
		}
		return nsDEI1;
	}


	public void setNsDEI1(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE1_F95a_DEI1_Type nsDEI1)  {
		this.nsDEI1 = nsDEI1;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE1_F95a_DEI2_Type getNsDEI2()  {
		if (nsDEI2 == null) {
			nsDEI2 = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE1_F95a_DEI2_Type();
		}
		return nsDEI2;
	}


	public void setNsDEI2(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE1_F95a_DEI2_Type nsDEI2)  {
		this.nsDEI2 = nsDEI2;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE1_F95a_PSET_Type getNsPSET()  {
		if (nsPSET == null) {
			nsPSET = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE1_F95a_PSET_Type();
		}
		return nsPSET;
	}


	public void setNsPSET(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE1_F95a_PSET_Type nsPSET)  {
		this.nsPSET = nsPSET;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE1_F95a_REAG_Type getNsREAG()  {
		if (nsREAG == null) {
			nsREAG = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE1_F95a_REAG_Type();
		}
		return nsREAG;
	}


	public void setNsREAG(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE1_F95a_REAG_Type nsREAG)  {
		this.nsREAG = nsREAG;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE1_F95a_RECU_Type getNsRECU()  {
		if (nsRECU == null) {
			nsRECU = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE1_F95a_RECU_Type();
		}
		return nsRECU;
	}


	public void setNsRECU(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE1_F95a_RECU_Type nsRECU)  {
		this.nsRECU = nsRECU;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE1_F95a_REI1_Type getNsREI1()  {
		if (nsREI1 == null) {
			nsREI1 = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE1_F95a_REI1_Type();
		}
		return nsREI1;
	}


	public void setNsREI1(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE1_F95a_REI1_Type nsREI1)  {
		this.nsREI1 = nsREI1;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE1_F95a_REI2_Type getNsREI2()  {
		if (nsREI2 == null) {
			nsREI2 = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE1_F95a_REI2_Type();
		}
		return nsREI2;
	}


	public void setNsREI2(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE1_F95a_REI2_Type nsREI2)  {
		this.nsREI2 = nsREI2;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE1_F95a_SELL_Type getNsSELL()  {
		if (nsSELL == null) {
			nsSELL = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE1_F95a_SELL_Type();
		}
		return nsSELL;
	}


	public void setNsSELL(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE1_F95a_SELL_Type nsSELL)  {
		this.nsSELL = nsSELL;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE1_F95a_ALTE_Type getNsALTE()  {
		if (nsALTE == null) {
			nsALTE = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE1_F95a_ALTE_Type();
		}
		return nsALTE;
	}


	public void setNsALTE(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE1_F95a_ALTE_Type nsALTE)  {
		this.nsALTE = nsALTE;
	}

}