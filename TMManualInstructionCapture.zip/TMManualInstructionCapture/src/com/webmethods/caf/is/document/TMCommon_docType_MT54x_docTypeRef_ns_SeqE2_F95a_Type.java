package com.webmethods.caf.is.document;

import java.io.Serializable;

/**
 * IS document wrapper
 */
public  class TMCommon_docType_MT54x_docTypeRef_ns_SeqE2_F95a_Type extends java.lang.Object implements Serializable {

	
	private static final long serialVersionUID = 1L;
	// IS Document type used to generate this class
	public static final String DOCUMENT_TYPE = "TMCommon.docType.MT54x:docTypeRef_ns_SeqE2_F95a_Type";
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE2_F95a_ACCW_Type nsACCW = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE2_F95a_BENM_Type nsBENM = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE2_F95a_DEBT_Type nsDEBT = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE2_F95a_INTM_Type nsINTM = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE2_F95a_PAYE_Type nsPAYE = null;
	public static String[][] FIELD_NAMES = new String[][] {{"nsACCW", "ns:ACCW"},{"nsBENM", "ns:BENM"},{"nsDEBT", "ns:DEBT"},{"nsINTM", "ns:INTM"},{"nsPAYE", "ns:PAYE"},{"nsALTE", "ns:ALTE"},
	};
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE2_F95a_ALTE_Type nsALTE = null;
	

	public TMCommon_docType_MT54x_docTypeRef_ns_SeqE2_F95a_Type() {
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE2_F95a_ACCW_Type getNsACCW()  {
		if (nsACCW == null) {
			nsACCW = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE2_F95a_ACCW_Type();
		}
		return nsACCW;
	}


	public void setNsACCW(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE2_F95a_ACCW_Type nsACCW)  {
		this.nsACCW = nsACCW;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE2_F95a_BENM_Type getNsBENM()  {
		if (nsBENM == null) {
			nsBENM = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE2_F95a_BENM_Type();
		}
		return nsBENM;
	}


	public void setNsBENM(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE2_F95a_BENM_Type nsBENM)  {
		this.nsBENM = nsBENM;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE2_F95a_DEBT_Type getNsDEBT()  {
		if (nsDEBT == null) {
			nsDEBT = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE2_F95a_DEBT_Type();
		}
		return nsDEBT;
	}


	public void setNsDEBT(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE2_F95a_DEBT_Type nsDEBT)  {
		this.nsDEBT = nsDEBT;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE2_F95a_INTM_Type getNsINTM()  {
		if (nsINTM == null) {
			nsINTM = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE2_F95a_INTM_Type();
		}
		return nsINTM;
	}


	public void setNsINTM(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE2_F95a_INTM_Type nsINTM)  {
		this.nsINTM = nsINTM;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE2_F95a_PAYE_Type getNsPAYE()  {
		if (nsPAYE == null) {
			nsPAYE = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE2_F95a_PAYE_Type();
		}
		return nsPAYE;
	}


	public void setNsPAYE(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE2_F95a_PAYE_Type nsPAYE)  {
		this.nsPAYE = nsPAYE;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE2_F95a_ALTE_Type getNsALTE()  {
		if (nsALTE == null) {
			nsALTE = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE2_F95a_ALTE_Type();
		}
		return nsALTE;
	}


	public void setNsALTE(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE2_F95a_ALTE_Type nsALTE)  {
		this.nsALTE = nsALTE;
	}

}