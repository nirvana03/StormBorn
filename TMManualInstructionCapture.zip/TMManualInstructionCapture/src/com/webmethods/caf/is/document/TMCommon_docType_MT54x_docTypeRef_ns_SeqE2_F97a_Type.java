package com.webmethods.caf.is.document;

import java.io.Serializable;

/**
 * IS document wrapper
 */
public  class TMCommon_docType_MT54x_docTypeRef_ns_SeqE2_F97a_Type extends java.lang.Object implements Serializable {

	
	private static final long serialVersionUID = 1L;
	// IS Document type used to generate this class
	public static final String DOCUMENT_TYPE = "TMCommon.docType.MT54x:docTypeRef_ns_SeqE2_F97a_Type";
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE2_F97a_CASH_Type nsCASH = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE2_F97a_CHAR_Type nsCHAR = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE2_F97a_COMM_Type nsCOMM = null;
	public static String[][] FIELD_NAMES = new String[][] {{"nsCASH", "ns:CASH"},{"nsCHAR", "ns:CHAR"},{"nsCOMM", "ns:COMM"},{"nsTAXE", "ns:TAXE"},
	};
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE2_F97a_TAXE_Type nsTAXE = null;
	

	public TMCommon_docType_MT54x_docTypeRef_ns_SeqE2_F97a_Type() {
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE2_F97a_CASH_Type getNsCASH()  {
		if (nsCASH == null) {
			nsCASH = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE2_F97a_CASH_Type();
		}
		return nsCASH;
	}


	public void setNsCASH(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE2_F97a_CASH_Type nsCASH)  {
		this.nsCASH = nsCASH;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE2_F97a_CHAR_Type getNsCHAR()  {
		if (nsCHAR == null) {
			nsCHAR = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE2_F97a_CHAR_Type();
		}
		return nsCHAR;
	}


	public void setNsCHAR(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE2_F97a_CHAR_Type nsCHAR)  {
		this.nsCHAR = nsCHAR;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE2_F97a_COMM_Type getNsCOMM()  {
		if (nsCOMM == null) {
			nsCOMM = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE2_F97a_COMM_Type();
		}
		return nsCOMM;
	}


	public void setNsCOMM(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE2_F97a_COMM_Type nsCOMM)  {
		this.nsCOMM = nsCOMM;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE2_F97a_TAXE_Type getNsTAXE()  {
		if (nsTAXE == null) {
			nsTAXE = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE2_F97a_TAXE_Type();
		}
		return nsTAXE;
	}


	public void setNsTAXE(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE2_F97a_TAXE_Type nsTAXE)  {
		this.nsTAXE = nsTAXE;
	}

}