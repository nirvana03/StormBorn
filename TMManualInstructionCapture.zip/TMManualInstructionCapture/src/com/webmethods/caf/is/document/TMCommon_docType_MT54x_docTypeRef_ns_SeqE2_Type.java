package com.webmethods.caf.is.document;

import java.io.Serializable;

/**
 * IS document wrapper
 */
public  class TMCommon_docType_MT54x_docTypeRef_ns_SeqE2_Type extends java.lang.Object implements Serializable {

	
	private static final long serialVersionUID = 1L;
	// IS Document type used to generate this class
	public static final String DOCUMENT_TYPE = "TMCommon.docType.MT54x:docTypeRef_ns_SeqE2_Type";
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE2_F16a_1_Type nsF16a_1 = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE2_F95a_Type[] nsF95a = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE2_F97a_Type[] nsF97a = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE2_F70a_Type[] nsF70a = null;
	public static String[][] FIELD_NAMES = new String[][] {{"nsF16a_1", "ns:F16a_1"},{"nsF95a", "ns:F95a"},{"nsF97a", "ns:F97a"},{"nsF70a", "ns:F70a"},{"nsF16a_2", "ns:F16a_2"},
	};
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE2_F16a_2_Type nsF16a_2 = null;
	

	public TMCommon_docType_MT54x_docTypeRef_ns_SeqE2_Type() {
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE2_F16a_1_Type getNsF16a_1()  {
		if (nsF16a_1 == null) {
			nsF16a_1 = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE2_F16a_1_Type();
		}
		return nsF16a_1;
	}


	public void setNsF16a_1(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE2_F16a_1_Type nsF16a_1)  {
		this.nsF16a_1 = nsF16a_1;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE2_F95a_Type[] getNsF95a()  {
		if (nsF95a == null) {
			//TODO: create/set default value here
		}
		return nsF95a;
	}


	public void setNsF95a(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE2_F95a_Type[] nsF95a)  {
		this.nsF95a = nsF95a;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE2_F97a_Type[] getNsF97a()  {
		if (nsF97a == null) {
			//TODO: create/set default value here
		}
		return nsF97a;
	}


	public void setNsF97a(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE2_F97a_Type[] nsF97a)  {
		this.nsF97a = nsF97a;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE2_F70a_Type[] getNsF70a()  {
		if (nsF70a == null) {
			//TODO: create/set default value here
		}
		return nsF70a;
	}


	public void setNsF70a(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE2_F70a_Type[] nsF70a)  {
		this.nsF70a = nsF70a;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE2_F16a_2_Type getNsF16a_2()  {
		if (nsF16a_2 == null) {
			nsF16a_2 = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE2_F16a_2_Type();
		}
		return nsF16a_2;
	}


	public void setNsF16a_2(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE2_F16a_2_Type nsF16a_2)  {
		this.nsF16a_2 = nsF16a_2;
	}

}