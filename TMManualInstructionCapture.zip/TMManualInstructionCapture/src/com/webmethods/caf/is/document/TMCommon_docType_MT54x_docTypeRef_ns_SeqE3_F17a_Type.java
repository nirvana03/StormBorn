package com.webmethods.caf.is.document;

import java.io.Serializable;

/**
 * IS document wrapper
 */
public  class TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F17a_Type extends java.lang.Object implements Serializable {

	
	private static final long serialVersionUID = 1L;
	// IS Document type used to generate this class
	public static final String DOCUMENT_TYPE = "TMCommon.docType.MT54x:docTypeRef_ns_SeqE3_F17a_Type";
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F17a_ACRU_Type nsACRU = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F17a_STAM_Type nsSTAM = null;
	public static String[][] FIELD_NAMES = new String[][] {{"nsACRU", "ns:ACRU"},{"nsSTAM", "ns:STAM"},{"nsEXEC", "ns:EXEC"},
	};
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F17a_EXEC_Type nsEXEC = null;
	

	public TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F17a_Type() {
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F17a_ACRU_Type getNsACRU()  {
		if (nsACRU == null) {
			nsACRU = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F17a_ACRU_Type();
		}
		return nsACRU;
	}


	public void setNsACRU(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F17a_ACRU_Type nsACRU)  {
		this.nsACRU = nsACRU;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F17a_STAM_Type getNsSTAM()  {
		if (nsSTAM == null) {
			nsSTAM = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F17a_STAM_Type();
		}
		return nsSTAM;
	}


	public void setNsSTAM(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F17a_STAM_Type nsSTAM)  {
		this.nsSTAM = nsSTAM;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F17a_EXEC_Type getNsEXEC()  {
		if (nsEXEC == null) {
			nsEXEC = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F17a_EXEC_Type();
		}
		return nsEXEC;
	}


	public void setNsEXEC(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F17a_EXEC_Type nsEXEC)  {
		this.nsEXEC = nsEXEC;
	}

}