package com.webmethods.caf.is.document;

import java.io.Serializable;

/**
 * IS document wrapper
 */
public  class TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F19a_Type extends java.lang.Object implements Serializable {

	
	private static final long serialVersionUID = 1L;
	// IS Document type used to generate this class
	public static final String DOCUMENT_TYPE = "TMCommon.docType.MT54x:docTypeRef_ns_SeqE3_F19a_Type";
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F19a_ACRU_Type nsACRU = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F19a_CHAR_Type nsCHAR = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F19a_COUN_Type nsCOUN = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F19a_DEAL_Type nsDEAL = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F19a_EXEC_Type nsEXEC = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F19a_ISDI_Type nsISDI = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F19a_LADT_Type nsLADT = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F19a_LEVY_Type nsLEVY = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F19a_LOCL_Type nsLOCL = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F19a_LOCO_Type nsLOCO = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F19a_MARG_Type nsMARG = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F19a_OTHR_Type nsOTHR = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F19a_REGF_Type nsREGF = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F19a_SETT_Type nsSETT = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F19a_SHIP_Type nsSHIP = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F19a_SPCN_Type nsSPCN = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F19a_STAM_Type nsSTAM = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F19a_STEX_Type nsSTEX = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F19a_TRAN_Type nsTRAN = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F19a_TRAX_Type nsTRAX = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F19a_VATA_Type nsVATA = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F19a_WITH_Type nsWITH = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F19a_ANTO_Type nsANTO = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F19a_BOOK_Type nsBOOK = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F19a_COAX_Type nsCOAX = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F19a_ACCA_Type nsACCA = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F19a_RESU_Type nsRESU = null;
	public static String[][] FIELD_NAMES = new String[][] {{"nsACRU", "ns:ACRU"},{"nsCHAR", "ns:CHAR"},{"nsCOUN", "ns:COUN"},{"nsDEAL", "ns:DEAL"},{"nsEXEC", "ns:EXEC"},{"nsISDI", "ns:ISDI"},{"nsLADT", "ns:LADT"},{"nsLEVY", "ns:LEVY"},{"nsLOCL", "ns:LOCL"},{"nsLOCO", "ns:LOCO"},{"nsMARG", "ns:MARG"},{"nsOTHR", "ns:OTHR"},{"nsREGF", "ns:REGF"},{"nsSETT", "ns:SETT"},{"nsSHIP", "ns:SHIP"},{"nsSPCN", "ns:SPCN"},{"nsSTAM", "ns:STAM"},{"nsSTEX", "ns:STEX"},{"nsTRAN", "ns:TRAN"},{"nsTRAX", "ns:TRAX"},{"nsVATA", "ns:VATA"},{"nsWITH", "ns:WITH"},{"nsANTO", "ns:ANTO"},{"nsBOOK", "ns:BOOK"},{"nsCOAX", "ns:COAX"},{"nsACCA", "ns:ACCA"},{"nsRESU", "ns:RESU"},{"nsOCMT", "ns:OCMT"},
	};
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F19a_OCMT_Type nsOCMT = null;
	

	public TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F19a_Type() {
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F19a_ACRU_Type getNsACRU()  {
		if (nsACRU == null) {
			nsACRU = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F19a_ACRU_Type();
		}
		return nsACRU;
	}


	public void setNsACRU(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F19a_ACRU_Type nsACRU)  {
		this.nsACRU = nsACRU;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F19a_CHAR_Type getNsCHAR()  {
		if (nsCHAR == null) {
			nsCHAR = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F19a_CHAR_Type();
		}
		return nsCHAR;
	}


	public void setNsCHAR(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F19a_CHAR_Type nsCHAR)  {
		this.nsCHAR = nsCHAR;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F19a_COUN_Type getNsCOUN()  {
		if (nsCOUN == null) {
			nsCOUN = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F19a_COUN_Type();
		}
		return nsCOUN;
	}


	public void setNsCOUN(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F19a_COUN_Type nsCOUN)  {
		this.nsCOUN = nsCOUN;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F19a_DEAL_Type getNsDEAL()  {
		if (nsDEAL == null) {
			nsDEAL = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F19a_DEAL_Type();
		}
		return nsDEAL;
	}


	public void setNsDEAL(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F19a_DEAL_Type nsDEAL)  {
		this.nsDEAL = nsDEAL;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F19a_EXEC_Type getNsEXEC()  {
		if (nsEXEC == null) {
			nsEXEC = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F19a_EXEC_Type();
		}
		return nsEXEC;
	}


	public void setNsEXEC(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F19a_EXEC_Type nsEXEC)  {
		this.nsEXEC = nsEXEC;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F19a_ISDI_Type getNsISDI()  {
		if (nsISDI == null) {
			nsISDI = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F19a_ISDI_Type();
		}
		return nsISDI;
	}


	public void setNsISDI(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F19a_ISDI_Type nsISDI)  {
		this.nsISDI = nsISDI;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F19a_LADT_Type getNsLADT()  {
		if (nsLADT == null) {
			nsLADT = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F19a_LADT_Type();
		}
		return nsLADT;
	}


	public void setNsLADT(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F19a_LADT_Type nsLADT)  {
		this.nsLADT = nsLADT;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F19a_LEVY_Type getNsLEVY()  {
		if (nsLEVY == null) {
			nsLEVY = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F19a_LEVY_Type();
		}
		return nsLEVY;
	}


	public void setNsLEVY(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F19a_LEVY_Type nsLEVY)  {
		this.nsLEVY = nsLEVY;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F19a_LOCL_Type getNsLOCL()  {
		if (nsLOCL == null) {
			nsLOCL = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F19a_LOCL_Type();
		}
		return nsLOCL;
	}


	public void setNsLOCL(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F19a_LOCL_Type nsLOCL)  {
		this.nsLOCL = nsLOCL;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F19a_LOCO_Type getNsLOCO()  {
		if (nsLOCO == null) {
			nsLOCO = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F19a_LOCO_Type();
		}
		return nsLOCO;
	}


	public void setNsLOCO(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F19a_LOCO_Type nsLOCO)  {
		this.nsLOCO = nsLOCO;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F19a_MARG_Type getNsMARG()  {
		if (nsMARG == null) {
			nsMARG = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F19a_MARG_Type();
		}
		return nsMARG;
	}


	public void setNsMARG(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F19a_MARG_Type nsMARG)  {
		this.nsMARG = nsMARG;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F19a_OTHR_Type getNsOTHR()  {
		if (nsOTHR == null) {
			nsOTHR = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F19a_OTHR_Type();
		}
		return nsOTHR;
	}


	public void setNsOTHR(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F19a_OTHR_Type nsOTHR)  {
		this.nsOTHR = nsOTHR;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F19a_REGF_Type getNsREGF()  {
		if (nsREGF == null) {
			nsREGF = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F19a_REGF_Type();
		}
		return nsREGF;
	}


	public void setNsREGF(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F19a_REGF_Type nsREGF)  {
		this.nsREGF = nsREGF;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F19a_SETT_Type getNsSETT()  {
		if (nsSETT == null) {
			nsSETT = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F19a_SETT_Type();
		}
		return nsSETT;
	}


	public void setNsSETT(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F19a_SETT_Type nsSETT)  {
		this.nsSETT = nsSETT;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F19a_SHIP_Type getNsSHIP()  {
		if (nsSHIP == null) {
			nsSHIP = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F19a_SHIP_Type();
		}
		return nsSHIP;
	}


	public void setNsSHIP(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F19a_SHIP_Type nsSHIP)  {
		this.nsSHIP = nsSHIP;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F19a_SPCN_Type getNsSPCN()  {
		if (nsSPCN == null) {
			nsSPCN = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F19a_SPCN_Type();
		}
		return nsSPCN;
	}


	public void setNsSPCN(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F19a_SPCN_Type nsSPCN)  {
		this.nsSPCN = nsSPCN;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F19a_STAM_Type getNsSTAM()  {
		if (nsSTAM == null) {
			nsSTAM = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F19a_STAM_Type();
		}
		return nsSTAM;
	}


	public void setNsSTAM(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F19a_STAM_Type nsSTAM)  {
		this.nsSTAM = nsSTAM;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F19a_STEX_Type getNsSTEX()  {
		if (nsSTEX == null) {
			nsSTEX = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F19a_STEX_Type();
		}
		return nsSTEX;
	}


	public void setNsSTEX(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F19a_STEX_Type nsSTEX)  {
		this.nsSTEX = nsSTEX;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F19a_TRAN_Type getNsTRAN()  {
		if (nsTRAN == null) {
			nsTRAN = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F19a_TRAN_Type();
		}
		return nsTRAN;
	}


	public void setNsTRAN(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F19a_TRAN_Type nsTRAN)  {
		this.nsTRAN = nsTRAN;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F19a_TRAX_Type getNsTRAX()  {
		if (nsTRAX == null) {
			nsTRAX = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F19a_TRAX_Type();
		}
		return nsTRAX;
	}


	public void setNsTRAX(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F19a_TRAX_Type nsTRAX)  {
		this.nsTRAX = nsTRAX;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F19a_VATA_Type getNsVATA()  {
		if (nsVATA == null) {
			nsVATA = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F19a_VATA_Type();
		}
		return nsVATA;
	}


	public void setNsVATA(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F19a_VATA_Type nsVATA)  {
		this.nsVATA = nsVATA;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F19a_WITH_Type getNsWITH()  {
		if (nsWITH == null) {
			nsWITH = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F19a_WITH_Type();
		}
		return nsWITH;
	}


	public void setNsWITH(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F19a_WITH_Type nsWITH)  {
		this.nsWITH = nsWITH;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F19a_ANTO_Type getNsANTO()  {
		if (nsANTO == null) {
			nsANTO = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F19a_ANTO_Type();
		}
		return nsANTO;
	}


	public void setNsANTO(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F19a_ANTO_Type nsANTO)  {
		this.nsANTO = nsANTO;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F19a_BOOK_Type getNsBOOK()  {
		if (nsBOOK == null) {
			nsBOOK = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F19a_BOOK_Type();
		}
		return nsBOOK;
	}


	public void setNsBOOK(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F19a_BOOK_Type nsBOOK)  {
		this.nsBOOK = nsBOOK;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F19a_COAX_Type getNsCOAX()  {
		if (nsCOAX == null) {
			nsCOAX = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F19a_COAX_Type();
		}
		return nsCOAX;
	}


	public void setNsCOAX(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F19a_COAX_Type nsCOAX)  {
		this.nsCOAX = nsCOAX;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F19a_ACCA_Type getNsACCA()  {
		if (nsACCA == null) {
			nsACCA = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F19a_ACCA_Type();
		}
		return nsACCA;
	}


	public void setNsACCA(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F19a_ACCA_Type nsACCA)  {
		this.nsACCA = nsACCA;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F19a_RESU_Type getNsRESU()  {
		if (nsRESU == null) {
			nsRESU = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F19a_RESU_Type();
		}
		return nsRESU;
	}


	public void setNsRESU(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F19a_RESU_Type nsRESU)  {
		this.nsRESU = nsRESU;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F19a_OCMT_Type getNsOCMT()  {
		if (nsOCMT == null) {
			nsOCMT = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F19a_OCMT_Type();
		}
		return nsOCMT;
	}


	public void setNsOCMT(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F19a_OCMT_Type nsOCMT)  {
		this.nsOCMT = nsOCMT;
	}

}