package com.webmethods.caf.is.document;

import java.io.Serializable;

/**
 * IS document wrapper
 */
public  class TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F98a_Type extends java.lang.Object implements Serializable {

	
	private static final long serialVersionUID = 1L;
	// IS Document type used to generate this class
	public static final String DOCUMENT_TYPE = "TMCommon.docType.MT54x:docTypeRef_ns_SeqE3_F98a_Type";
	public static String[][] FIELD_NAMES = new String[][] {{"nsVALU", "ns:VALU"},
	};
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F98a_VALU_Type nsVALU = null;
	

	public TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F98a_Type() {
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F98a_VALU_Type getNsVALU()  {
		if (nsVALU == null) {
			nsVALU = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F98a_VALU_Type();
		}
		return nsVALU;
	}


	public void setNsVALU(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F98a_VALU_Type nsVALU)  {
		this.nsVALU = nsVALU;
	}

}