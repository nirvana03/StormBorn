package com.webmethods.caf.is.document;

import java.io.Serializable;

/**
 * IS document wrapper
 */
public  class TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F98a_VALU_Type extends java.lang.Object implements Serializable {

	
	private static final long serialVersionUID = 1L;
	// IS Document type used to generate this class
	public static final String DOCUMENT_TYPE = "TMCommon.docType.MT54x:docTypeRef_ns_SeqE3_F98a_VALU_Type";
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F98A_Type nsF98A = null;
	public static String[][] FIELD_NAMES = new String[][] {{"nsF98A", "ns:F98A"},{"nsF98C", "ns:F98C"},
	};
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F98C_Type nsF98C = null;
	

	public TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F98a_VALU_Type() {
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F98A_Type getNsF98A()  {
		if (nsF98A == null) {
			nsF98A = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F98A_Type();
		}
		return nsF98A;
	}


	public void setNsF98A(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F98A_Type nsF98A)  {
		this.nsF98A = nsF98A;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F98C_Type getNsF98C()  {
		if (nsF98C == null) {
			nsF98C = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F98C_Type();
		}
		return nsF98C;
	}


	public void setNsF98C(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F98C_Type nsF98C)  {
		this.nsF98C = nsF98C;
	}

}