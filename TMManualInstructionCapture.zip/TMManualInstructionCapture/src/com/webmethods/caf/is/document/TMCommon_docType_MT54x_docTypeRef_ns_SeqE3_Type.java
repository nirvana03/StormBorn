package com.webmethods.caf.is.document;

import java.io.Serializable;

/**
 * IS document wrapper
 */
public  class TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_Type extends java.lang.Object implements Serializable {

	
	private static final long serialVersionUID = 1L;
	// IS Document type used to generate this class
	public static final String DOCUMENT_TYPE = "TMCommon.docType.MT54x:docTypeRef_ns_SeqE3_Type";
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F16a_1_Type nsF16a_1 = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F17a_Type[] nsF17a = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F19a_Type[] nsF19a = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F98a_Type nsF98a = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F92a_Type nsF92a = null;
	public static String[][] FIELD_NAMES = new String[][] {{"nsF16a_1", "ns:F16a_1"},{"nsF17a", "ns:F17a"},{"nsF19a", "ns:F19a"},{"nsF98a", "ns:F98a"},{"nsF92a", "ns:F92a"},{"nsF16a_2", "ns:F16a_2"},
	};
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F16a_2_Type nsF16a_2 = null;
	

	public TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_Type() {
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F16a_1_Type getNsF16a_1()  {
		if (nsF16a_1 == null) {
			nsF16a_1 = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F16a_1_Type();
		}
		return nsF16a_1;
	}


	public void setNsF16a_1(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F16a_1_Type nsF16a_1)  {
		this.nsF16a_1 = nsF16a_1;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F17a_Type[] getNsF17a()  {
		if (nsF17a == null) {
			//TODO: create/set default value here
		}
		return nsF17a;
	}


	public void setNsF17a(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F17a_Type[] nsF17a)  {
		this.nsF17a = nsF17a;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F19a_Type[] getNsF19a()  {
		if (nsF19a == null) {
			//TODO: create/set default value here
		}
		return nsF19a;
	}


	public void setNsF19a(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F19a_Type[] nsF19a)  {
		this.nsF19a = nsF19a;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F98a_Type getNsF98a()  {
		if (nsF98a == null) {
			nsF98a = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F98a_Type();
		}
		return nsF98a;
	}


	public void setNsF98a(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F98a_Type nsF98a)  {
		this.nsF98a = nsF98a;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F92a_Type getNsF92a()  {
		if (nsF92a == null) {
			nsF92a = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F92a_Type();
		}
		return nsF92a;
	}


	public void setNsF92a(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F92a_Type nsF92a)  {
		this.nsF92a = nsF92a;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F16a_2_Type getNsF16a_2()  {
		if (nsF16a_2 == null) {
			nsF16a_2 = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F16a_2_Type();
		}
		return nsF16a_2;
	}


	public void setNsF16a_2(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_F16a_2_Type nsF16a_2)  {
		this.nsF16a_2 = nsF16a_2;
	}

}