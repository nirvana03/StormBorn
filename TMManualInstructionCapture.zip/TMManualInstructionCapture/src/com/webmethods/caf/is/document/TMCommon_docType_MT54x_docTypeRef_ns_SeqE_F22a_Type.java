package com.webmethods.caf.is.document;

import java.io.Serializable;

/**
 * IS document wrapper
 */
public  class TMCommon_docType_MT54x_docTypeRef_ns_SeqE_F22a_Type extends java.lang.Object implements Serializable {

	
	private static final long serialVersionUID = 1L;
	// IS Document type used to generate this class
	public static final String DOCUMENT_TYPE = "TMCommon.docType.MT54x:docTypeRef_ns_SeqE_F22a_Type";
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE_F22a_STCO_Type nsSTCO = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE_F22a_SETR_Type nsSETR = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE_F22a_TRCA_Type nsTRCA = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE_F22a_STAM_Type nsSTAM = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE_F22a_RTGS_Type nsRTGS = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE_F22a_REGT_Type nsREGT = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE_F22a_BENE_Type nsBENE = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE_F22a_CASY_Type nsCASY = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE_F22a_DBNM_Type nsDBNM = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE_F22a_TCPI_Type nsTCPI = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE_F22a_MACL_Type nsMACL = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE_F22a_FXCX_Type nsFXCX = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE_F22a_BLOC_Type nsBLOC = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE_F22a_REST_Type nsREST = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE_F22a_SETS_Type nsSETS = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE_F22a_NETT_Type nsNETT = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE_F22a_CCPT_Type nsCCPT = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE_F22a_LEOG_Type nsLEOG = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE_F22a_RTRN_Type nsRTRN = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE_F22a_COLA_Type nsCOLA = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE_F22a_TRAK_Type nsTRAK = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE_F22a_REPT_Type nsREPT = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE_F22a_COLE_Type nsCOLE = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE_F22a_SSBT_Type nsSSBT = null;
	public static String[][] FIELD_NAMES = new String[][] {{"nsSTCO", "ns:STCO"},{"nsSETR", "ns:SETR"},{"nsTRCA", "ns:TRCA"},{"nsSTAM", "ns:STAM"},{"nsRTGS", "ns:RTGS"},{"nsREGT", "ns:REGT"},{"nsBENE", "ns:BENE"},{"nsCASY", "ns:CASY"},{"nsDBNM", "ns:DBNM"},{"nsTCPI", "ns:TCPI"},{"nsMACL", "ns:MACL"},{"nsFXCX", "ns:FXCX"},{"nsBLOC", "ns:BLOC"},{"nsREST", "ns:REST"},{"nsSETS", "ns:SETS"},{"nsNETT", "ns:NETT"},{"nsCCPT", "ns:CCPT"},{"nsLEOG", "ns:LEOG"},{"nsRTRN", "ns:RTRN"},{"nsCOLA", "ns:COLA"},{"nsTRAK", "ns:TRAK"},{"nsREPT", "ns:REPT"},{"nsCOLE", "ns:COLE"},{"nsSSBT", "ns:SSBT"},{"nsCSBT", "ns:CSBT"},
	};
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE_F22a_CSBT_Type nsCSBT = null;
	

	public TMCommon_docType_MT54x_docTypeRef_ns_SeqE_F22a_Type() {
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE_F22a_STCO_Type getNsSTCO()  {
		if (nsSTCO == null) {
			nsSTCO = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE_F22a_STCO_Type();
		}
		return nsSTCO;
	}


	public void setNsSTCO(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE_F22a_STCO_Type nsSTCO)  {
		this.nsSTCO = nsSTCO;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE_F22a_SETR_Type getNsSETR()  {
		if (nsSETR == null) {
			nsSETR = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE_F22a_SETR_Type();
		}
		return nsSETR;
	}


	public void setNsSETR(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE_F22a_SETR_Type nsSETR)  {
		this.nsSETR = nsSETR;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE_F22a_TRCA_Type getNsTRCA()  {
		if (nsTRCA == null) {
			nsTRCA = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE_F22a_TRCA_Type();
		}
		return nsTRCA;
	}


	public void setNsTRCA(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE_F22a_TRCA_Type nsTRCA)  {
		this.nsTRCA = nsTRCA;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE_F22a_STAM_Type getNsSTAM()  {
		if (nsSTAM == null) {
			nsSTAM = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE_F22a_STAM_Type();
		}
		return nsSTAM;
	}


	public void setNsSTAM(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE_F22a_STAM_Type nsSTAM)  {
		this.nsSTAM = nsSTAM;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE_F22a_RTGS_Type getNsRTGS()  {
		if (nsRTGS == null) {
			nsRTGS = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE_F22a_RTGS_Type();
		}
		return nsRTGS;
	}


	public void setNsRTGS(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE_F22a_RTGS_Type nsRTGS)  {
		this.nsRTGS = nsRTGS;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE_F22a_REGT_Type getNsREGT()  {
		if (nsREGT == null) {
			nsREGT = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE_F22a_REGT_Type();
		}
		return nsREGT;
	}


	public void setNsREGT(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE_F22a_REGT_Type nsREGT)  {
		this.nsREGT = nsREGT;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE_F22a_BENE_Type getNsBENE()  {
		if (nsBENE == null) {
			nsBENE = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE_F22a_BENE_Type();
		}
		return nsBENE;
	}


	public void setNsBENE(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE_F22a_BENE_Type nsBENE)  {
		this.nsBENE = nsBENE;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE_F22a_CASY_Type getNsCASY()  {
		if (nsCASY == null) {
			nsCASY = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE_F22a_CASY_Type();
		}
		return nsCASY;
	}


	public void setNsCASY(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE_F22a_CASY_Type nsCASY)  {
		this.nsCASY = nsCASY;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE_F22a_DBNM_Type getNsDBNM()  {
		if (nsDBNM == null) {
			nsDBNM = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE_F22a_DBNM_Type();
		}
		return nsDBNM;
	}


	public void setNsDBNM(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE_F22a_DBNM_Type nsDBNM)  {
		this.nsDBNM = nsDBNM;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE_F22a_TCPI_Type getNsTCPI()  {
		if (nsTCPI == null) {
			nsTCPI = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE_F22a_TCPI_Type();
		}
		return nsTCPI;
	}


	public void setNsTCPI(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE_F22a_TCPI_Type nsTCPI)  {
		this.nsTCPI = nsTCPI;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE_F22a_MACL_Type getNsMACL()  {
		if (nsMACL == null) {
			nsMACL = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE_F22a_MACL_Type();
		}
		return nsMACL;
	}


	public void setNsMACL(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE_F22a_MACL_Type nsMACL)  {
		this.nsMACL = nsMACL;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE_F22a_FXCX_Type getNsFXCX()  {
		if (nsFXCX == null) {
			nsFXCX = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE_F22a_FXCX_Type();
		}
		return nsFXCX;
	}


	public void setNsFXCX(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE_F22a_FXCX_Type nsFXCX)  {
		this.nsFXCX = nsFXCX;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE_F22a_BLOC_Type getNsBLOC()  {
		if (nsBLOC == null) {
			nsBLOC = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE_F22a_BLOC_Type();
		}
		return nsBLOC;
	}


	public void setNsBLOC(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE_F22a_BLOC_Type nsBLOC)  {
		this.nsBLOC = nsBLOC;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE_F22a_REST_Type getNsREST()  {
		if (nsREST == null) {
			nsREST = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE_F22a_REST_Type();
		}
		return nsREST;
	}


	public void setNsREST(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE_F22a_REST_Type nsREST)  {
		this.nsREST = nsREST;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE_F22a_SETS_Type getNsSETS()  {
		if (nsSETS == null) {
			nsSETS = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE_F22a_SETS_Type();
		}
		return nsSETS;
	}


	public void setNsSETS(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE_F22a_SETS_Type nsSETS)  {
		this.nsSETS = nsSETS;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE_F22a_NETT_Type getNsNETT()  {
		if (nsNETT == null) {
			nsNETT = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE_F22a_NETT_Type();
		}
		return nsNETT;
	}


	public void setNsNETT(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE_F22a_NETT_Type nsNETT)  {
		this.nsNETT = nsNETT;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE_F22a_CCPT_Type getNsCCPT()  {
		if (nsCCPT == null) {
			nsCCPT = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE_F22a_CCPT_Type();
		}
		return nsCCPT;
	}


	public void setNsCCPT(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE_F22a_CCPT_Type nsCCPT)  {
		this.nsCCPT = nsCCPT;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE_F22a_LEOG_Type getNsLEOG()  {
		if (nsLEOG == null) {
			nsLEOG = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE_F22a_LEOG_Type();
		}
		return nsLEOG;
	}


	public void setNsLEOG(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE_F22a_LEOG_Type nsLEOG)  {
		this.nsLEOG = nsLEOG;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE_F22a_RTRN_Type getNsRTRN()  {
		if (nsRTRN == null) {
			nsRTRN = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE_F22a_RTRN_Type();
		}
		return nsRTRN;
	}


	public void setNsRTRN(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE_F22a_RTRN_Type nsRTRN)  {
		this.nsRTRN = nsRTRN;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE_F22a_COLA_Type getNsCOLA()  {
		if (nsCOLA == null) {
			nsCOLA = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE_F22a_COLA_Type();
		}
		return nsCOLA;
	}


	public void setNsCOLA(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE_F22a_COLA_Type nsCOLA)  {
		this.nsCOLA = nsCOLA;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE_F22a_TRAK_Type getNsTRAK()  {
		if (nsTRAK == null) {
			nsTRAK = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE_F22a_TRAK_Type();
		}
		return nsTRAK;
	}


	public void setNsTRAK(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE_F22a_TRAK_Type nsTRAK)  {
		this.nsTRAK = nsTRAK;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE_F22a_REPT_Type getNsREPT()  {
		if (nsREPT == null) {
			nsREPT = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE_F22a_REPT_Type();
		}
		return nsREPT;
	}


	public void setNsREPT(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE_F22a_REPT_Type nsREPT)  {
		this.nsREPT = nsREPT;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE_F22a_COLE_Type getNsCOLE()  {
		if (nsCOLE == null) {
			nsCOLE = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE_F22a_COLE_Type();
		}
		return nsCOLE;
	}


	public void setNsCOLE(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE_F22a_COLE_Type nsCOLE)  {
		this.nsCOLE = nsCOLE;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE_F22a_SSBT_Type getNsSSBT()  {
		if (nsSSBT == null) {
			nsSSBT = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE_F22a_SSBT_Type();
		}
		return nsSSBT;
	}


	public void setNsSSBT(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE_F22a_SSBT_Type nsSSBT)  {
		this.nsSSBT = nsSSBT;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE_F22a_CSBT_Type getNsCSBT()  {
		if (nsCSBT == null) {
			nsCSBT = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE_F22a_CSBT_Type();
		}
		return nsCSBT;
	}


	public void setNsCSBT(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE_F22a_CSBT_Type nsCSBT)  {
		this.nsCSBT = nsCSBT;
	}

}