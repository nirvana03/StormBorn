package com.webmethods.caf.is.document;

import java.io.Serializable;

/**
 * IS document wrapper
 */
public  class TMCommon_docType_MT54x_docTypeRef_ns_SeqE_Type extends java.lang.Object implements Serializable {

	
	private static final long serialVersionUID = 1L;
	// IS Document type used to generate this class
	public static final String DOCUMENT_TYPE = "TMCommon.docType.MT54x:docTypeRef_ns_SeqE_Type";
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE_F16a_1_Type nsF16a_1 = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE_F22a_Type[] nsF22a = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE1_Type[] nsSeqE1 = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE2_Type[] nsSeqE2 = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_Type[] nsSeqE3 = null;
	public static String[][] FIELD_NAMES = new String[][] {{"nsF16a_1", "ns:F16a_1"},{"nsF22a", "ns:F22a"},{"nsSeqE1", "ns:SeqE1"},{"nsSeqE2", "ns:SeqE2"},{"nsSeqE3", "ns:SeqE3"},{"nsF16a_2", "ns:F16a_2"},
	};
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE_F16a_2_Type nsF16a_2 = null;
	

	public TMCommon_docType_MT54x_docTypeRef_ns_SeqE_Type() {
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE_F16a_1_Type getNsF16a_1()  {
		if (nsF16a_1 == null) {
			nsF16a_1 = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE_F16a_1_Type();
		}
		return nsF16a_1;
	}


	public void setNsF16a_1(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE_F16a_1_Type nsF16a_1)  {
		this.nsF16a_1 = nsF16a_1;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE_F22a_Type[] getNsF22a()  {
		if (nsF22a == null) {
			//TODO: create/set default value here
		}
		return nsF22a;
	}


	public void setNsF22a(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE_F22a_Type[] nsF22a)  {
		this.nsF22a = nsF22a;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE1_Type[] getNsSeqE1()  {
		if (nsSeqE1 == null) {
			//TODO: create/set default value here
		}
		return nsSeqE1;
	}


	public void setNsSeqE1(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE1_Type[] nsSeqE1)  {
		this.nsSeqE1 = nsSeqE1;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE2_Type[] getNsSeqE2()  {
		if (nsSeqE2 == null) {
			//TODO: create/set default value here
		}
		return nsSeqE2;
	}


	public void setNsSeqE2(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE2_Type[] nsSeqE2)  {
		this.nsSeqE2 = nsSeqE2;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_Type[] getNsSeqE3()  {
		if (nsSeqE3 == null) {
			//TODO: create/set default value here
		}
		return nsSeqE3;
	}


	public void setNsSeqE3(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE3_Type[] nsSeqE3)  {
		this.nsSeqE3 = nsSeqE3;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE_F16a_2_Type getNsF16a_2()  {
		if (nsF16a_2 == null) {
			nsF16a_2 = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE_F16a_2_Type();
		}
		return nsF16a_2;
	}


	public void setNsF16a_2(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqE_F16a_2_Type nsF16a_2)  {
		this.nsF16a_2 = nsF16a_2;
	}

}