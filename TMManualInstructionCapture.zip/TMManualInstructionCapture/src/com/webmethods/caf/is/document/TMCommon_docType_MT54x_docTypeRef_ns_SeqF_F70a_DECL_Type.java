package com.webmethods.caf.is.document;

import java.io.Serializable;

/**
 * IS document wrapper
 */
public  class TMCommon_docType_MT54x_docTypeRef_ns_SeqF_F70a_DECL_Type extends java.lang.Object implements Serializable {

	
	private static final long serialVersionUID = 1L;
	// IS Document type used to generate this class
	public static final String DOCUMENT_TYPE = "TMCommon.docType.MT54x:docTypeRef_ns_SeqF_F70a_DECL_Type";
	public static String[][] FIELD_NAMES = new String[][] {{"nsF70E", "ns:F70E"},
	};
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F70E_Type nsF70E = null;
	

	public TMCommon_docType_MT54x_docTypeRef_ns_SeqF_F70a_DECL_Type() {
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F70E_Type getNsF70E()  {
		if (nsF70E == null) {
			nsF70E = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F70E_Type();
		}
		return nsF70E;
	}


	public void setNsF70E(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F70E_Type nsF70E)  {
		this.nsF70E = nsF70E;
	}

}