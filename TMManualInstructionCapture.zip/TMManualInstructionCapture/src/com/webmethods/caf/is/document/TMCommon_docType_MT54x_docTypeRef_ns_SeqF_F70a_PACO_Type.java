package com.webmethods.caf.is.document;

import java.io.Serializable;

/**
 * IS document wrapper
 */
public  class TMCommon_docType_MT54x_docTypeRef_ns_SeqF_F70a_PACO_Type extends java.lang.Object implements Serializable {

	
	private static final long serialVersionUID = 1L;
	// IS Document type used to generate this class
	public static final String DOCUMENT_TYPE = "TMCommon.docType.MT54x:docTypeRef_ns_SeqF_F70a_PACO_Type";
	public static String[][] FIELD_NAMES = new String[][] {{"nsF70C", "ns:F70C"},
	};
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F70C_Type nsF70C = null;
	

	public TMCommon_docType_MT54x_docTypeRef_ns_SeqF_F70a_PACO_Type() {
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F70C_Type getNsF70C()  {
		if (nsF70C == null) {
			nsF70C = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F70C_Type();
		}
		return nsF70C;
	}


	public void setNsF70C(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_F70C_Type nsF70C)  {
		this.nsF70C = nsF70C;
	}

}