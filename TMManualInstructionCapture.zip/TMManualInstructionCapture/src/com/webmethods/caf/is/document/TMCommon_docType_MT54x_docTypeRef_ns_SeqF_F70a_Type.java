package com.webmethods.caf.is.document;

import java.io.Serializable;

/**
 * IS document wrapper
 */
public  class TMCommon_docType_MT54x_docTypeRef_ns_SeqF_F70a_Type extends java.lang.Object implements Serializable {

	
	private static final long serialVersionUID = 1L;
	// IS Document type used to generate this class
	public static final String DOCUMENT_TYPE = "TMCommon.docType.MT54x:docTypeRef_ns_SeqF_F70a_Type";
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqF_F70a_DECL_Type nsDECL = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqF_F70a_REGI_Type nsREGI = null;
	public static String[][] FIELD_NAMES = new String[][] {{"nsDECL", "ns:DECL"},{"nsREGI", "ns:REGI"},{"nsPACO", "ns:PACO"},
	};
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqF_F70a_PACO_Type nsPACO = null;
	

	public TMCommon_docType_MT54x_docTypeRef_ns_SeqF_F70a_Type() {
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqF_F70a_DECL_Type getNsDECL()  {
		if (nsDECL == null) {
			nsDECL = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqF_F70a_DECL_Type();
		}
		return nsDECL;
	}


	public void setNsDECL(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqF_F70a_DECL_Type nsDECL)  {
		this.nsDECL = nsDECL;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqF_F70a_REGI_Type getNsREGI()  {
		if (nsREGI == null) {
			nsREGI = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqF_F70a_REGI_Type();
		}
		return nsREGI;
	}


	public void setNsREGI(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqF_F70a_REGI_Type nsREGI)  {
		this.nsREGI = nsREGI;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqF_F70a_PACO_Type getNsPACO()  {
		if (nsPACO == null) {
			nsPACO = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqF_F70a_PACO_Type();
		}
		return nsPACO;
	}


	public void setNsPACO(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqF_F70a_PACO_Type nsPACO)  {
		this.nsPACO = nsPACO;
	}

}