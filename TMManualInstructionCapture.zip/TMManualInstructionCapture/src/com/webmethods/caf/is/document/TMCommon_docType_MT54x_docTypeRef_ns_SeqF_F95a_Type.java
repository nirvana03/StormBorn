package com.webmethods.caf.is.document;

import java.io.Serializable;

/**
 * IS document wrapper
 */
public  class TMCommon_docType_MT54x_docTypeRef_ns_SeqF_F95a_Type extends java.lang.Object implements Serializable {

	
	private static final long serialVersionUID = 1L;
	// IS Document type used to generate this class
	public static final String DOCUMENT_TYPE = "TMCommon.docType.MT54x:docTypeRef_ns_SeqF_F95a_Type";
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqF_F95a_EXCH_Type nsEXCH = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqF_F95a_MEOR_Type nsMEOR = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqF_F95a_MERE_Type nsMERE = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqF_F95a_TRRE_Type nsTRRE = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqF_F95a_INVE_Type nsINVE = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqF_F95a_VEND_Type nsVEND = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqF_F95a_QFIN_Type nsQFIN = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqF_F95a_TRAG_Type nsTRAG = null;
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqF_F95a_BRKR_Type nsBRKR = null;
	public static String[][] FIELD_NAMES = new String[][] {{"nsEXCH", "ns:EXCH"},{"nsMEOR", "ns:MEOR"},{"nsMERE", "ns:MERE"},{"nsTRRE", "ns:TRRE"},{"nsINVE", "ns:INVE"},{"nsVEND", "ns:VEND"},{"nsQFIN", "ns:QFIN"},{"nsTRAG", "ns:TRAG"},{"nsBRKR", "ns:BRKR"},{"nsALTE", "ns:ALTE"},
	};
	private com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqF_F95a_ALTE_Type nsALTE = null;
	

	public TMCommon_docType_MT54x_docTypeRef_ns_SeqF_F95a_Type() {
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqF_F95a_EXCH_Type getNsEXCH()  {
		if (nsEXCH == null) {
			nsEXCH = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqF_F95a_EXCH_Type();
		}
		return nsEXCH;
	}


	public void setNsEXCH(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqF_F95a_EXCH_Type nsEXCH)  {
		this.nsEXCH = nsEXCH;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqF_F95a_MEOR_Type getNsMEOR()  {
		if (nsMEOR == null) {
			nsMEOR = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqF_F95a_MEOR_Type();
		}
		return nsMEOR;
	}


	public void setNsMEOR(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqF_F95a_MEOR_Type nsMEOR)  {
		this.nsMEOR = nsMEOR;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqF_F95a_MERE_Type getNsMERE()  {
		if (nsMERE == null) {
			nsMERE = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqF_F95a_MERE_Type();
		}
		return nsMERE;
	}


	public void setNsMERE(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqF_F95a_MERE_Type nsMERE)  {
		this.nsMERE = nsMERE;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqF_F95a_TRRE_Type getNsTRRE()  {
		if (nsTRRE == null) {
			nsTRRE = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqF_F95a_TRRE_Type();
		}
		return nsTRRE;
	}


	public void setNsTRRE(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqF_F95a_TRRE_Type nsTRRE)  {
		this.nsTRRE = nsTRRE;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqF_F95a_INVE_Type getNsINVE()  {
		if (nsINVE == null) {
			nsINVE = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqF_F95a_INVE_Type();
		}
		return nsINVE;
	}


	public void setNsINVE(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqF_F95a_INVE_Type nsINVE)  {
		this.nsINVE = nsINVE;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqF_F95a_VEND_Type getNsVEND()  {
		if (nsVEND == null) {
			nsVEND = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqF_F95a_VEND_Type();
		}
		return nsVEND;
	}


	public void setNsVEND(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqF_F95a_VEND_Type nsVEND)  {
		this.nsVEND = nsVEND;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqF_F95a_QFIN_Type getNsQFIN()  {
		if (nsQFIN == null) {
			nsQFIN = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqF_F95a_QFIN_Type();
		}
		return nsQFIN;
	}


	public void setNsQFIN(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqF_F95a_QFIN_Type nsQFIN)  {
		this.nsQFIN = nsQFIN;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqF_F95a_TRAG_Type getNsTRAG()  {
		if (nsTRAG == null) {
			nsTRAG = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqF_F95a_TRAG_Type();
		}
		return nsTRAG;
	}


	public void setNsTRAG(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqF_F95a_TRAG_Type nsTRAG)  {
		this.nsTRAG = nsTRAG;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqF_F95a_BRKR_Type getNsBRKR()  {
		if (nsBRKR == null) {
			nsBRKR = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqF_F95a_BRKR_Type();
		}
		return nsBRKR;
	}


	public void setNsBRKR(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqF_F95a_BRKR_Type nsBRKR)  {
		this.nsBRKR = nsBRKR;
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqF_F95a_ALTE_Type getNsALTE()  {
		if (nsALTE == null) {
			nsALTE = new com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqF_F95a_ALTE_Type();
		}
		return nsALTE;
	}


	public void setNsALTE(com.webmethods.caf.is.document.TMCommon_docType_MT54x_docTypeRef_ns_SeqF_F95a_ALTE_Type nsALTE)  {
		this.nsALTE = nsALTE;
	}

}