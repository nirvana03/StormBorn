package com.webmethods.caf.is.document;

import java.io.Serializable;

/**
 * IS document wrapper
 */
public  class TMCommon_docType_MsgChanges_MessageChanges extends java.lang.Object implements Serializable {

	
	private static final long serialVersionUID = 1L;
	// IS Document type used to generate this class
	public static final String DOCUMENT_TYPE = "TMCommon.docType.MsgChanges:MessageChanges";
	private static final String DOCUMENT_SRC = "http://10.20.165.29:3003";
	private java.lang.String user;
	private java.lang.String operation;
	private java.lang.String field;
	private java.lang.String oldValue;
	private java.lang.String newValue;
	private java.lang.String forceEdit;
	

	public TMCommon_docType_MsgChanges_MessageChanges() {
	}


	public java.lang.String getUser()  {
		
		return user;
	}


	public void setUser(java.lang.String user)  {
		this.user = user;
	}


	public java.lang.String getOperation()  {
		
		return operation;
	}


	public void setOperation(java.lang.String operation)  {
		this.operation = operation;
	}


	public java.lang.String getField()  {
		
		return field;
	}


	public void setField(java.lang.String field)  {
		this.field = field;
	}


	public java.lang.String getOldValue()  {
		
		return oldValue;
	}


	public void setOldValue(java.lang.String oldValue)  {
		this.oldValue = oldValue;
	}


	public java.lang.String getNewValue()  {
		
		return newValue;
	}


	public void setNewValue(java.lang.String newValue)  {
		this.newValue = newValue;
	}


	public java.lang.String getForceEdit()  {
		
		return forceEdit;
	}


	public void setForceEdit(java.lang.String forceEdit)  {
		this.forceEdit = forceEdit;
	}

}