package com.webmethods.caf.is.document;

import java.io.Serializable;

/**
 * IS document wrapper
 */
public  class TMCommon_docType_MsgChanges_changesList extends java.lang.Object implements Serializable {

	
	private static final long serialVersionUID = 1L;
	// IS Document type used to generate this class
	public static final String DOCUMENT_TYPE = "TMCommon.docType.MsgChanges:changesList";
	private static final String DOCUMENT_SRC = "http://172.31.92.133:6666";
	public static String[][] FIELD_NAMES = new String[][] {{"messageChanges", "MessageChanges"},
	};
	private com.webmethods.caf.is.document.TMCommon_docType_MsgChanges_MessageChanges[] messageChanges = null;
	

	public TMCommon_docType_MsgChanges_changesList() {
	}


	public com.webmethods.caf.is.document.TMCommon_docType_MsgChanges_MessageChanges[] getMessageChanges()  {
		if (messageChanges == null) {
			
		}
		return messageChanges;
	}


	public void setMessageChanges(com.webmethods.caf.is.document.TMCommon_docType_MsgChanges_MessageChanges[] messageChanges)  {
		this.messageChanges = messageChanges;
	}

}